from pathlib import Path
import hashlib
import json
import shutil
import tempfile
from core.completion import atomic_json, complete, fingerprint
from core.safe_output import validate_paths
from core.glossary import load_glossary
from providers.deepseek import DeepSeekProvider
from bruns.translate import cost_cny, load_env
from bruns.autocomplete import BudgetStop
from kag.source import load
from kag.adapter import extract, audit, render
from kag.xp3 import pack, read_scripts


def run(game,work,output,args,provider=None):
    game,work,output=map(Path,(game,work,output))
    # Analysis still writes manifests: prohibit work directories inside source.
    for source in (game,Path(args.extracted).resolve() if args.extracted else game):
        if source==work or source in work.parents or work in source.parents:
            raise ValueError('Source and --workdir must be separate, non-nested folders')
    if not (args.analyze or args.estimate):
        validate_paths(game,work,output)
        if args.extracted:validate_paths(Path(args.extracted).resolve(),work,output)
    files,origin=load(game,work,args.extracted,args.archive)
    units,docs=extract(files)
    if not units:raise ValueError('No supported visible KAG text found')
    manifest={'format':1,'game':str(game.resolve()),'origin':origin,
              'source_hashes':{n:hashlib.sha256(raw).hexdigest() for n,raw in files.items()}}
    mp=work/'kag_manifest.json'
    if mp.exists() and json.loads(mp.read_text(encoding='utf-8'))!=manifest:
        raise ValueError('Source changed or another game used this workspace; choose a new --workdir')
    atomic_json(mp,manifest);atomic_json(work/'kag_units.json',units)
    print(f'KAG: {len(units)} text units; {len(docs)} KS scripts; {sum(len(u["source"]) for u in units)} source characters')
    print('Excluded: TJS, script/macro blocks, comments, labels, tag arguments, escaped-bracket lines and image text.')
    if args.analyze or args.estimate:
        print('STATUS: ANALYSIS COMPLETE — NO API CALLS. Counts are not a price quote.');return
    cp=work/'kag_checkpoint.json';sig=fingerprint(units)
    state={'input_fingerprint':sig,'translations':{},'spent_rmb':0.}
    if cp.exists():
        state=json.loads(cp.read_text(encoding='utf-8'))
        if state.get('input_fingerprint')!=sig:raise ValueError('Checkpoint does not match source')
        for u in units:u['translation']=state.get('translations',{}).get(u['id'],'')
    glossary=load_glossary(args.glossary)
    for u in units:
        term=glossary.get(u['source'])
        if term and not u['translation'] and not audit(dict(u,translation=term['target']))['blocking']:
            u['translation']=term['target']
    selected=sorted(units,key=lambda u:(Path(u['file']).name.lower()!='first.ks',u['file'],u['location']))[:args.sample] if args.sample else units
    if args.sample:print(f'Sample: {len(selected)} units (first.ks menu first); remaining originals retained')
    def save(rows,st):
        st['translations']={u['id']:u.get('translation','') for u in units}
        atomic_json(cp,st)
        issues=[dict(id=u['id'],source=u['source'],translation=u['translation'],**audit(u)) for u in units if audit(u)['blocking']]
        atomic_json(work/'kag_completion_report.json',{'total':len(units),'blocking_count':len(issues),
                    'stop_reason':st.get('stop_reason'),'unresolved':issues,
                    'note':'Structural validation only; not a guarantee of translation quality or full game coverage'})
    session=0.
    def request(batch,phase):
        nonlocal provider,session
        if session>=args.max_cost_rmb:raise BudgetStop('Estimated session budget reached')
        if provider is None:provider=DeepSeekProvider()
        payload=[dict(u,context=u['context']+['Translate only the supplied visible text into Simplified Chinese. No newlines, script commands, brackets or backslashes.']) for u in batch]
        made,usage=provider.translate_batch(payload,glossary=glossary,source_language=args.source_language)
        used={'prompt_tokens':usage.prompt_tokens,'completion_tokens':usage.completion_tokens,
              'prompt_cache_hit_tokens':usage.cache_hit_tokens,'prompt_cache_miss_tokens':usage.cache_miss_tokens}
        cost=float(cost_cny(used,args.price_band));session+=cost
        state['session_spent_rmb']=session;state['spent_rmb']=state.get('spent_rmb',0.)+cost
        return made,used
    if not args.build_only:
        load_env()
        complete(selected,audit,request,save,rounds=args.repair_rounds,batch_size=args.batch_size,
                 stall_rounds=args.stall_rounds,state=state)
    else:
        state['stop_reason']='offline_build';save(units,state)
    if not any(u['translation'] and not audit(u)['blocking'] for u in selected):
        raise ValueError('No valid translations to build; inspect kag_completion_report.json')
    patch,unresolved=render(files,units,args.allow_partial or bool(args.sample),args.kag_font_face)
    output.parent.mkdir(parents=True,exist_ok=True)
    stage=Path(tempfile.mkdtemp(prefix='.gt-kag-',dir=output.parent))
    try:
        path=stage/'patch.xp3';path.write_bytes(pack(patch))
        if read_scripts(path)!=patch:raise ValueError('XP3 round-trip verification failed')
        (stage/'安装说明.txt').write_text('KAG 中文补丁（实验版）\n\n关闭游戏，备份游戏目录中已有的 patch.xp3。\n'
            '把本目录的 patch.xp3 放到游戏 EXE 同级目录，再启动原来的 EXE。\n'
            '不要直接覆盖官方补丁：已有官方 patch*.xp3 时，需先核实加载顺序和版本。\n'
            '测试补丁可备份后移走；更高优先级 patch2.xp3 等可能遮盖本补丁。\n'
            '卸载：移除本次安装的 patch.xp3，恢复原先备份。\n'
            '请从新游戏检查菜单、剧情推进、选择分支、存读档和文字换行。\n'
            '字体需要系统安装：'+args.kag_font_face+'\n'
            '本工具只处理可识别的 KS 正文，不翻译图片、TJS、宏和标签参数。\n'
            f'保留原文条目：{len(unresolved)}。零剩余仅表示已提取文本通过结构检查。\n',encoding='utf-8')
        atomic_json(stage/'build_report.json',{'changed_scripts':list(patch),'unresolved':len(unresolved),
                    'sample':args.sample,'font_face':args.kag_font_face,'source_manifest':manifest})
        if output.exists():raise ValueError('Output already exists; choose another --output')
        stage.rename(output)
    finally:
        if stage.exists():shutil.rmtree(stage)
    print('DONE — KAG patch:',output/'patch.xp3')
    if unresolved:print('WARNING: partial build; untranslated entries retained:',len(unresolved))
