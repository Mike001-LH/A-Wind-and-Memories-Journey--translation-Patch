from __future__ import annotations
import mmap
import struct
import zlib
from pathlib import Path, PurePosixPath

MAGIC = b'XP3\r\n \n\x1a\x8bg\x01'
LIMIT = 64*1024*1024


def has_archive(path):
    if Path(path).stat().st_size < 19: return False
    with open(path,'rb') as f, mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ) as data:
        return data.find(MAGIC) >= 0


def unpack_zlib(data, expected):
    if not 0 <= expected <= LIMIT: raise ValueError('XP3 decompression size limit')
    dec=zlib.decompressobj(); result=dec.decompress(data,expected+1)
    if len(result)!=expected or not dec.eof or dec.unused_data or dec.unconsumed_tail:
        raise ValueError('Invalid XP3 compressed block')
    return result


def chunks(data):
    pos=0
    while pos<len(data):
        if pos+12>len(data): raise ValueError('Truncated XP3 chunk')
        tag=data[pos:pos+4]; size=struct.unpack_from('<Q',data,pos+4)[0]; pos+=12
        if size>len(data)-pos: raise ValueError('Invalid XP3 chunk size')
        yield tag,data[pos:pos+size];pos+=size


def read_scripts(path):
    """EXEs may contain a signature constant before the actual embedded archive."""
    if Path(path).stat().st_size < 19: raise ValueError('No XP3 archive found')
    candidates=[]
    with open(path,'rb') as f, mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ) as data:
        pos=0
        while len(candidates)<64:
            pos=data.find(MAGIC,pos)
            if pos<0:break
            candidates.append(pos);pos+=len(MAGIC)
    errors=[]
    for base in candidates:
        try:return _read_scripts_at(path,base)
        except (ValueError,struct.error,zlib.error,UnicodeError) as exc:errors.append(str(exc))
    raise ValueError('Cannot read standard unencrypted XP3 scripts; use GARbro --extracted. ' + '; '.join(errors[-3:]))


def _read_scripts_at(path,base):
    with open(path,'rb') as f, mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ) as data:
        def take(offset,size):
            if offset<0 or size<0 or offset+size>len(data): raise ValueError('XP3 offset outside file')
            return data[offset:offset+size]
        indexpos=base+struct.unpack('<Q',take(base+11,8))[0]
        # v2 has an empty continuation index before the real index.
        seen=set(); entries=[]
        while True:
            if indexpos in seen or len(seen)>32: raise ValueError('XP3 index loop')
            seen.add(indexpos)
            flag=take(indexpos,1)[0];indexpos+=1
            if flag & 0x7e: raise ValueError('Unsupported XP3 index flags')
            packed=struct.unpack('<Q',take(indexpos,8))[0];indexpos+=8
            if packed>LIMIT: raise ValueError('XP3 index too large')
            if flag&1:
                size=struct.unpack('<Q',take(indexpos,8))[0];indexpos+=8
                index=unpack_zlib(take(indexpos,packed),size)
            else:index=take(indexpos,packed)
            indexpos+=packed
            entries.extend(chunks(index))
            if not flag&0x80:break
            indexpos=base+struct.unpack('<Q',take(indexpos,8))[0]
        output={};total=0
        for tag,entry in entries:
            if tag!=b'File':continue
            sections=dict(chunks(entry))
            if not all(k in sections for k in (b'info',b'segm',b'adlr')):
                raise ValueError('Incomplete XP3 file record')
            info=sections[b'info']
            if len(info)<22:raise ValueError('Invalid XP3 info')
            flags,size,packed,namelen=struct.unpack_from('<IQQH',info)
            if len(info)!=22+2*namelen:raise ValueError('Invalid XP3 name')
            name=info[22:].decode('utf-16le').replace('\\','/')
            parts=PurePosixPath(name)
            if parts.is_absolute() or '..' in parts.parts or ':' in name or '\0' in name:
                raise ValueError('Unsafe XP3 path')
            if parts.suffix.lower() not in ('.ks','.tjs'):continue
            if flags:raise ValueError('Encrypted XP3 scripts: extract with GARbro and select the extracted folder')
            if size>LIMIT or total+size>256*1024*1024:raise ValueError('XP3 script size limit')
            segs=sections[b'segm']
            if len(segs)%28:raise ValueError('Invalid XP3 segment table')
            content=[]; expanded=0; stored=0
            for pos in range(0,len(segs),28):
                sf,offset,us,ps=struct.unpack_from('<IQQQ',segs,pos)
                expanded+=us;stored+=ps
                if expanded>size or ps>LIMIT:raise ValueError('XP3 segment size mismatch')
                raw=take(base+offset,ps)
                if sf==1:raw=unpack_zlib(raw,us)
                elif sf!=0 or us!=ps:raise ValueError('Unsupported XP3 segment')
                content.append(raw)
            raw=b''.join(content)
            if len(raw)!=size or stored!=packed:raise ValueError('XP3 file size mismatch')
            if len(sections[b'adlr'])!=4 or zlib.adler32(raw)&0xffffffff!=struct.unpack('<I',sections[b'adlr'])[0]:
                raise ValueError('XP3 checksum failed; possible custom encryption. Use GARbro.')
            key=parts.as_posix()
            if key.casefold() in {n.casefold() for n in output}:raise ValueError('Duplicate XP3 script path')
            output[key]=raw;total+=size
        if not output:raise ValueError('No readable KS/TJS scripts in archive; use GARbro')
        return output


def chunk(tag,data):return tag+struct.pack('<Q',len(data))+data


def pack(files):
    body=bytearray(MAGIC+bytes(8));index=[]
    for name,data in sorted(files.items()):
        encoded=name.encode('utf-16le');offset=len(body);body.extend(data)
        info=struct.pack('<IQQH',0,len(data),len(data),len(encoded)//2)+encoded
        segment=struct.pack('<IQQQ',0,offset,len(data),len(data))
        index.append(chunk(b'File',chunk(b'info',info)+chunk(b'segm',segment)+
                           chunk(b'adlr',struct.pack('<I',zlib.adler32(data)&0xffffffff))))
    struct.pack_into('<Q',body,11,len(body));index=b''.join(index)
    body.extend(b'\0'+struct.pack('<Q',len(index))+index)
    return bytes(body)
