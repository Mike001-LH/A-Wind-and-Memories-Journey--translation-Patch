"""KAG text adapters and standard unencrypted XP3 support."""
