"""Conservative KAG visible-text adapter. Never translates tag arguments or TJS."""
import hashlib
import re


def decode(raw):
    if raw.startswith((b'\xff\xfe',b'\xfe\xff')):return raw.decode('utf-16')
    try:return raw.decode('utf-8-sig')
    except UnicodeDecodeError:return raw.decode('cp932')


def spans(text):
    offset=0;script=False;macro=False
    for line in text.splitlines(keepends=True):
        body=line.rstrip('\r\n'); stripped=body.lstrip()
        if stripped.startswith(';') or stripped.startswith('*'):
            offset+=len(line);continue
        # Inline script/macro sections are excluded completely, including their boundary lines.
        if re.search(r'(?:\[|^\s*@)iscript\b',body,re.I):script=True
        if re.search(r'(?:\[|^\s*@)macro\b',body,re.I):macro=True
        if script or macro:
            if re.search(r'(?:\[|^\s*@)endscript\b',body,re.I):script=False
            if re.search(r'(?:\[|^\s*@)endmacro\b',body,re.I):macro=False
            offset+=len(line);continue
        if stripped.startswith('@') or '[[' in body:
            offset+=len(line);continue
        end=len(body.rstrip())
        if end and body[end-1]=='\\':end-=1
        pos=0
        while pos<end:
            if body[pos]=='[':
                quote=None;j=pos+1
                while j<end:
                    c=body[j]
                    if quote:
                        if c==quote:quote=None
                    elif c in ('"',"'"):quote=c
                    elif c==']':break
                    j+=1
                if j==end:raise ValueError('Unclosed KAG tag; unsupported multiline/custom tag')
                pos=j+1;continue
            stop=body.find('[',pos,end)
            if stop<0:stop=end
            part=body[pos:stop]; left=len(part)-len(part.lstrip()); right=len(part.rstrip())
            if right>left:
                yield offset+pos+left,offset+pos+right
            pos=stop
        offset+=len(line)
    if script or macro:raise ValueError('Unclosed script/macro block')


def extract(files):
    units=[]; documents={}
    for name,raw in sorted(files.items()):
        if not name.lower().endswith('.ks'):continue
        text=decode(raw);documents[name]=text
        context=[]
        for start,end in spans(text):
            source=text[start:end]
            if not any(c.isalpha() for c in source):continue
            key=hashlib.sha256(f'{name}\0{start}\0{source}'.encode()).hexdigest()[:24]
            units.append({'id':'kag:'+key,'file':name,'location':start,'source':source,'translation':'',
                          'context':context[-3:],'protected_tokens':[],
                          'metadata':{'start':start,'end':end,'kind':'visible_text'}})
            context.append(source)
    return units,documents


def audit(u):
    value=u.get('translation',''); reasons=[]
    if not isinstance(value,str) or not value.strip():reasons.append('empty')
    else:
        if any(c in value for c in '\r\n\x00\u2028\u2029'):reasons.append('newline_or_control')
        if any(c in value for c in '[]\\') or value.lstrip().startswith(('@','*',';')):
            reasons.append('script_syntax_in_translation')
    return {'blocking':reasons,'advisory':[]}


def render(files,units,allow_partial,font_face):
    original,docs=extract(files)
    if [(u['id'],u['source'],u['metadata']) for u in original]!=[(u['id'],u['source'],u['metadata']) for u in units]:
        raise ValueError('Source/unit manifest mismatch')
    unresolved=[u['id'] for u in units if audit(u)['blocking']]
    if unresolved and not allow_partial:raise ValueError(f'{len(unresolved)} unresolved units; inspect kag_completion_report.json, or use --allow-partial')
    changed={}
    for name,text in docs.items():
        edits=[u for u in units if u['file']==name and not audit(u)['blocking']]
        for u in reversed(edits):
            start,end=u['metadata']['start'],u['metadata']['end']
            text=text[:start]+u['translation']+text[end:]
        if text!=docs[name]:changed[name]=text
    first=[n for n in docs if n.replace('\\','/').split('/')[-1].lower()=='first.ks']
    if len(first)!=1:raise ValueError('Expected one first.ks entry script; custom startup needs manual adaptation')
    if not font_face or any(c in font_face for c in '"[]\\\r\n'):raise ValueError('Invalid --kag-font-face')
    entry=first[0];text=changed.get(entry,docs[entry]);newline='\r\n' if '\r\n' in text else '\n'
    changed[entry]=f'[deffont face="{font_face}"][font face="{font_face}"]\\'+newline+text
    basenames=[n.split('/')[-1].casefold() for n in docs]
    if len(set(basenames))!=len(basenames):raise ValueError('Duplicate KS basenames: unsafe flat patch; custom storage adapter needed')
    return {name.split('/')[-1]:b'\xff\xfe'+text.encode('utf-16le') for name,text in changed.items()},unresolved
