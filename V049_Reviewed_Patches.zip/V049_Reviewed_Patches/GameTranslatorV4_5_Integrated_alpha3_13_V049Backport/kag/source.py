from pathlib import Path
from kag.xp3 import has_archive, read_scripts


def roots(game):
    game=Path(game)
    if (game/'scenario').is_dir() and list((game/'scenario').rglob('*.ks')):return [game]
    if game.name.lower()=='scenario' and list(game.glob('*.ks')):return [game]
    candidates=sorted(p for p in game.iterdir() if p.is_dir() and not p.name.endswith(('_GT_Work','_Chinese_Patch')))
    found=[]
    for root in candidates:
        if (root/'scenario').is_dir() and list((root/'scenario').rglob('*.ks')):
            found.append(root)
        elif list(root.glob('*.ks')) and root.name.lower()=='scenario':
            found.append(root)
    return found


def archives(game):
    return [p for p in sorted(Path(game).iterdir()) if p.is_file() and
            p.suffix.lower() in ('.exe','.xp3') and not p.stem.lower().startswith('patch') and has_archive(p)]


def detect(game):
    extracted=roots(game)
    if extracted:return [str(p) for p in extracted]
    return [str(p) for p in archives(game)]


def load(game,work,extracted=None,archive=None):
    game=Path(game); work=Path(work)
    if extracted and archive:raise ValueError('Choose --extracted OR --archive')
    choices=[Path(extracted).expanduser().resolve()] if extracted else ([] if archive else roots(game))
    if len(choices)>1:raise ValueError('Multiple extracted projects found; specify --extracted PATH')
    if choices:
        root=choices[0]
        if not root.is_dir():raise ValueError('Extracted folder does not exist')
        if any(p.is_symlink() for p in root.rglob('*')):raise ValueError('Extracted project contains symlinks; use a regular copy')
        files={p.relative_to(root).as_posix():p.read_bytes() for p in sorted(root.rglob('*'))
               if p.is_file() and p.suffix.lower() in ('.ks','.tjs') and not p.is_symlink()}
        origin=str(root); method='existing extracted scripts'
    else:
        candidates=[Path(archive).expanduser().resolve()] if archive else archives(game)
        if len(candidates)!=1:
            raise ValueError('No unique standard XP3/EXE found. Use --archive PATH or --extracted GARbro_FOLDER')
        origin=str(candidates[0]); files=read_scripts(candidates[0]); method='built-in XP3 script extraction'
        # A reviewable extraction cache, never used as a replacement for source validation.
        target=work/'kag_extracted'
        if target.is_symlink():raise ValueError('Extraction cache must not be a symlink')
        for name,raw in files.items():
            p=target/name
            if not p.resolve().is_relative_to(target.resolve()):raise ValueError('Unsafe extraction path')
            if p.exists() and p.read_bytes()!=raw:raise ValueError('Extraction cache differs; choose a new --workdir')
            p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
    if not any(n.lower().endswith('.ks') for n in files):raise ValueError('No KS scenario scripts found')
    print('Scripts:',method,'—',origin)
    patches=list(game.glob('patch*.xp3'))
    if patches:print('NOTICE: Existing patch archives detected; base-script analysis does not merge them. Back up/remove test patches before installing the generated patch.')
    return files,origin
