import argparse,json,os
from pathlib import Path
from core.models import TranslationUnit
from core.glossary import load_glossary
from core.character_glossary import load_character_glossary, merge_glossaries
from core.translator import translate_units
from providers.deepseek import DeepSeekProvider

def unit(x):
    return TranslationUnit(
        id=x["id"],source=x["source"],engine=x["engine"],file=x["file"],location=x["location"],
        translation=x.get("translation"),speaker=x.get("speaker"),context=x.get("context",[]),
        protected_tokens=x.get("protected_tokens",[]),metadata=x.get("metadata",{}))

def cost_rmb(usage,peak=False):
    # Official V4.1 Flash RMB / 1M tokens as of 2026-09-16.
    hit,miss,out=(0.04,2.0,8.0) if peak else (0.02,1.0,4.0)
    return (usage.get("cache_hit_tokens",0)*hit+usage.get("cache_miss_tokens",0)*miss+
            usage.get("completion_tokens",0)*out)/1_000_000

def load_dotenv():
    # Tiny dependency-free .env loader. Existing shell variables win.
    here=Path.cwd()
    candidates=[here/".env", Path(__file__).resolve().parent.parent/".env"]
    for env in candidates:
        if not env.exists(): continue
        for line in env.read_text(encoding="utf-8").splitlines():
            line=line.strip()
            if not line or line.startswith("#") or "=" not in line: continue
            key,value=line.split("=",1)
            key=key.strip(); value=value.strip()
            if len(value)>=2 and value[0]==value[-1] and value[0] in "\"'": value=value[1:-1]
            os.environ.setdefault(key,value)
        return env
    return None

def main():
    load_dotenv()
    p=argparse.ArgumentParser(description="Translate normalized V4 units with DeepSeek V4.1 Flash (alpha6.4.1)")
    p.add_argument("units")
    p.add_argument("--checkpoint",required=True)
    p.add_argument("--output",required=True)
    p.add_argument("--qa",required=True)
    p.add_argument("--glossary")
    p.add_argument("--character-glossary",help="Character Pass JSON; loaded as hard terminology")
    p.add_argument("--batch-size",type=int,default=10)
    p.add_argument("--limit",type=int)
    p.add_argument("--source-language",default="English")
    p.add_argument("--peak-pricing",action="store_true")
    p.add_argument("--attempts",type=int,default=3,help="API attempts before recursive batch bisection")
    a=p.parse_args()
    data=json.loads(Path(a.units).read_text(encoding="utf-8"))
    units=[unit(x) for x in data]
    provider=DeepSeekProvider()
    user_glossary=load_glossary(a.glossary)
    character_glossary=load_character_glossary(a.character_glossary)
    active_glossary=merge_glossaries(user_glossary,character_glossary)
    state,attempted=translate_units(
        units,provider,a.checkpoint,active_glossary,a.batch_size,a.limit,a.source_language,a.attempts)
    byid=state["translations"]
    out=[]
    for x in data:
        y=dict(x)
        if x["id"] in byid:
            y["translation"]=byid[x["id"]]["translation"]
            y.setdefault("metadata",{})["translation_qa"]=byid[x["id"]]["issues"]
        out.append(y)
    Path(a.output).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding="utf-8")
    # Regenerate QA from the entire checkpoint, not only this run.
    failures=[]
    for x in data:
        rec=byid.get(x["id"])
        if rec and rec.get("issues"):
            failures.append({"id":x["id"],"source":x["source"],"translation":rec["translation"],"issues":rec["issues"]})
    Path(a.qa).write_text(json.dumps(failures,ensure_ascii=False,indent=2),encoding="utf-8")
    u=state["usage"]
    print(f"Completed this run: {attempted}")
    print(f"Local hard-glossary fills: {state.get('last_run',{}).get('local_hard_glossary',0)}")
    print(f"API units requested: {state.get('last_run',{}).get('api_requested',0)}")
    print(f"Checkpoint total: {len(byid)} / {len(units)}")
    print(f"Input tokens: {u['prompt_tokens']} (cache hit {u['cache_hit_tokens']}, miss {u['cache_miss_tokens']})")
    print(f"Output tokens: {u['completion_tokens']}")
    print(f"Estimated RMB ({'peak' if a.peak_pricing else 'off-peak'}): ¥{cost_rmb(u,a.peak_pricing):.6f}")
    print(f"QA flagged in checkpoint: {len(failures)}")
    print("Output:",Path(a.output).resolve())
    print("QA:",Path(a.qa).resolve())

if __name__=="__main__": main()
