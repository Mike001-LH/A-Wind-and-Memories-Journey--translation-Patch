"""CP932 Chinese audit: Japanese grammar is evidence; shared kanji are not."""
import re
from collections import Counter

TOK = re.compile(r'\$[A-Z]|#[A-Za-z]+|&R[A-Z]')
HIRA = re.compile(r'[\u3041-\u3096]+')
KANA = re.compile(r'[\u3041-\u3096\u30a1-\u30fa\uff66-\uff9d]')


def audit(unit, allow=()):
    source = unit.get('source', '')
    target = unit.get('translation') or ''
    blocking, advisory = [], []
    if not target.strip():
        return {'blocking': ['empty'], 'advisory': []}
    try:
        target.encode('cp932')
    except UnicodeEncodeError:
        blocking.append('cp932_unencodable')
    if '"' in target or '\\' in target or '\n' in target or '\r' in target:
        blocking.append('unsafe_script_character')
    if TOK.findall(source) != TOK.findall(target):
        blocking.append('control_token_mismatch')
    s, t = TOK.sub('', source).strip(), TOK.sub('', target).strip()
    allowed = sorted(set(allow) | {unit.get('speaker') or ''}, key=len, reverse=True)
    for term in allowed:
        if term:
            s, t = s.replace(term, ''), t.replace(term, '')
    # Shared kanji such as 学校/先生 and configured names may legitimately be identical.
    if s and t == s and KANA.search(s):
        blocking.append('same_as_japanese_source')
    elif s and t == s and any(c.isalpha() for c in s):
        advisory.append('unchanged_shared_kanji_or_name')
    # Honorifics and isolated katakana names are advisory, not an endless retry trigger.
    check = re.sub(r'さん|くん', '', t)
    runs = HIRA.findall(check)
    if sum(map(len, runs)) >= 2 or ('の' in check and len(check) > 3):
        blocking.append('hiragana_prose_residue')
    elif runs:
        advisory.append('isolated_hiragana')
    if re.search(r'[\u30a1-\u30fa\uff66-\uff9d]', check):
        advisory.append('katakana_name_or_residue')
    if any(s[i:i+8] in t and HIRA.search(s[i:i+8]) for i in range(max(0, len(s)-7))):
        blocking.append('copied_japanese_fragment')
    return {'blocking': list(dict.fromkeys(blocking)), 'advisory': advisory}


def report(units, allow=()):
    rows = [dict(id=u['id'], source=u['source'], translation=u.get('translation', ''),
                 **audit(u, allow)) for u in units]
    bad = [u for u in rows if u['blocking']]
    return {'total': len(rows), 'blocking_count': len(bad),
            'heuristic_coverage': (len(rows)-len(bad))/max(1,len(rows)),
            'unresolved': bad, 'advisories': [u for u in rows if u['advisory']],
            'note': 'Heuristic coverage is not a semantic accuracy score.'}
