#!/usr/bin/env python3
"""Validated, game-independent Bruns writer; never deletes an existing output."""
from __future__ import annotations
import argparse
import json
import re
from pathlib import Path
from bruns.codec import decode, encode
from bruns.residual import audit, report
from core.completion import atomic_json
from core.safe_output import publish_copy, validate_paths

DIALOG = re.compile(r'^\$N\$([A-Z])【([^】]+)】\$K#R(.*)\$N$', re.S)


def build(game, workspace, output, *, allow_partial=False, allow=(), write=True):
    game, ws, output = (Path(p).resolve() for p in (game, workspace, output))
    validate_paths(game, ws, output)
    original = json.loads((ws/'bruns_units.json').read_text(encoding='utf-8'))
    units = json.loads((ws/'bruns_units_translated.json').read_text(encoding='utf-8'))
    if not original: raise ValueError('No extracted Bruns units')
    byid = {u['id']:u for u in units}
    if len(byid) != len(units) or set(byid) != {u['id'] for u in original}:
        raise ValueError('Unit IDs/count mismatch')
    plans, unresolved = {}, []
    for src in original:
        u = byid[src['id']]
        for key in ('source','kind','occurrences'):
            if u[key] != src[key]: raise ValueError('Unit source/locations modified: '+u['id'])
        issues = audit(u, allow)['blocking']
        if issues:
            unresolved.append({'id':u['id'], 'issues':issues})
            if allow_partial: continue
            raise ValueError('Unresolved Bruns unit '+u['id']+': '+','.join(issues))
        if not u.get('occurrences'): raise ValueError('Unit has no occurrences: '+u['id'])
        for oc in u['occurrences']:
            rel = Path(oc['file'])
            if rel.is_absolute() or '..' in rel.parts or game not in (game/rel).resolve().parents:
                raise ValueError('Unsafe occurrence path')
            plans.setdefault(rel, []).append((oc, u))
    patched = {}
    count = 0
    for rel, items in plans.items():
        packed = (game/rel).read_bytes()
        raw = decode(packed) if packed[:4] == b'EENZ' else packed
        replacements = []
        for oc, u in items:
            st, en = oc.get('start', oc.get('string_start')), oc.get('end', oc.get('string_end'))
            if not isinstance(st,int) or not isinstance(en,int) or not 0 <= st < en <= len(raw):
                raise ValueError('Invalid occurrence offset')
            old = raw[st:en].decode('cp932')
            if old != oc['raw_string']: raise ValueError('Game changed: source span mismatch '+u['id'])
            text = u['translation']
            if u['kind'] == 'dialogue':
                match = DIALOG.fullmatch(old)
                if not match or match.group(3) != u['source']: raise ValueError('Dialogue wrapper mismatch')
                text = f'$N${match.group(1)}【{match.group(2)}】$K#R{text}$N'
            elif old != u['source']: raise ValueError('Source text mismatch')
            replacements.append((st,en,text.encode('cp932')))
        replacements.sort()
        if any(a[1] > b[0] for a,b in zip(replacements,replacements[1:])):
            raise ValueError('Overlapping occurrence spans')
        expected = raw
        for st,en,value in reversed(replacements): expected = expected[:st]+value+expected[en:]
        data = encode(expected) if packed[:4] == b'EENZ' else expected
        if (decode(data) if packed[:4] == b'EENZ' else data) != expected:
            raise ValueError('Repack verification failed')
        patched[rel] = data
        count += len(replacements)
    result = {'units':len(units),'files_verified':len(patched),'occurrences_written':count,
              'unresolved':unresolved,'output':str(output),'status':'partial' if unresolved else 'passed',
              'residual_audit':report(units,allow)}
    if write:
        def patch(stage):
            for rel,data in patched.items():
                (stage/rel).write_bytes(data)
                if (stage/rel).read_bytes() != data: raise ValueError('Disk verification failed')
        publish_copy(game, output, patch)
        atomic_json(ws/'bruns_build_report.json', result)
    print('Bruns build:',result['status'],'files:',len(patched),'occurrences:',count,'unresolved:',len(unresolved))
    return result


def main():
    p=argparse.ArgumentParser(); p.add_argument('game'); p.add_argument('workspace')
    p.add_argument('--output', required=True); p.add_argument('--build',action='store_true')
    p.add_argument('--allow-partial',action='store_true'); p.add_argument('--allow-kana',action='append',default=[])
    a=p.parse_args()
    build(a.game,a.workspace,a.output,allow_partial=a.allow_partial,allow=a.allow_kana,write=a.build)

if __name__=='__main__': main()
