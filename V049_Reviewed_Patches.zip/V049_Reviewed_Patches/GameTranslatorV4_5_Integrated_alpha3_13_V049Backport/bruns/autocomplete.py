"""Primary translation + bounded residual repair, compatible with alpha9 checkpoints."""
from __future__ import annotations
import argparse
import json
import os
from decimal import Decimal
from pathlib import Path
from core.completion import atomic_json, complete, fingerprint
from bruns.translate import api_request, parsed_map, cost_cny, load_env, cp932_ok
from bruns.residual import audit, report


class BudgetStop(RuntimeError):
    stop_run = True
    reason = 'budget_limit'


def run(workspace, *, rounds=3, batch_size=15, max_cost=5., price_band='peak',
        stall_rounds=2, coverage=1., allow=(), repair_only=False, audit_only=False,
        transport=None, glossary=None):
    ws = Path(workspace)
    units = json.loads((ws/'bruns_units.json').read_text(encoding='utf-8'))
    if not units: raise ValueError('No supported Bruns text found')
    sig = fingerprint(units)
    cp = ws/'bruns_alpha9_checkpoint.json'
    state = {'spent_rmb': 0., 'usage': {}, 'input_fingerprint': sig}
    saved = []
    if cp.exists():
        old = json.loads(cp.read_text(encoding='utf-8'))
        if old.get('state', {}).get('input_fingerprint', sig) != sig:
            raise ValueError('Source changed; use a new workspace')
        saved = old.get('units', [])
        state.update(old.get('state', {}))
    elif (ws/'bruns_units_translated.json').exists():
        saved = json.loads((ws/'bruns_units_translated.json').read_text(encoding='utf-8'))
    lookup = {u['id']: u for u in saved}
    for u in units:
        old = lookup.get(u['id'])
        if old:
            if old['source'] != u['source'] or old.get('occurrences') != u.get('occurrences'):
                raise ValueError('Checkpoint source/locations changed; use a new workspace')
            u['translation'] = old.get('translation', '')
    state['input_fingerprint'] = sig
    allow = set(allow)
    glossary = glossary or {}
    allow.update(v['target'] for v in glossary.values())
    checker = lambda u: audit(u, allow)
    def save(rows, st):
        st['completed'] = sum(bool(x.get('translation')) for x in rows)
        atomic_json(cp, {'state': st, 'units': rows})
        atomic_json(ws/'bruns_units_translated.json', rows)
        r = report(rows, allow)
        r['stop_reason'] = st.get('stop_reason', 'running')
        r['history'] = st.get('completion_history', [])
        atomic_json(ws/'bruns_completion_report.json', r)
    if audit_only:
        r = report(units, allow)
        atomic_json(ws/'bruns_completion_report.json', r)
        return r
    session = Decimal('0')
    transport = transport or api_request
    def request(batch, phase):
        nonlocal session
        if session >= Decimal(str(max_cost)):
            raise BudgetStop('Estimated session budget reached; checkpoint saved')
        payload = []
        for u in batch:
            candidate = state.get('rejected_candidates', {}).get(u['id'], u.get('translation', ''))
            _, bad = cp932_ok(candidate)
            payload.append({'id': u['id'], 'kind': u['kind'], 'speaker': u.get('speaker'),
                            'source': u['source'], 'candidate': candidate,
                            'bad_chars': bad, 'reasons': checker(u)['blocking'],
                            'glossary': glossary,
                            'instruction': 'Translate the ORIGINAL source fully into CP932-compatible Chinese. '
                            'Remove untranslated Japanese prose, keep protected engine tokens exactly. '
                            'Use Chinese paraphrases when a glyph is unencodable. Do not copy the source. '
                            'Do not insert quotes, backslashes or physical newlines.'})
        obj = transport(payload, mode='repair' if phase else 'translate')
        usage = obj.get('usage', {})
        cost = cost_cny(usage, price_band)
        session += cost
        state['spent_rmb'] = float(Decimal(str(state.get('spent_rmb', 0))) + cost)
        state['session_spent_rmb'] = float(session)
        # Account and persist even if parsing the paid response fails.
        for key in ('prompt_tokens', 'completion_tokens', 'prompt_cache_hit_tokens', 'prompt_cache_miss_tokens'):
            state.setdefault('usage', {})[key] = state['usage'].get(key, 0) + usage.get(key, 0)
        save(units, state)
        return parsed_map(obj), usage
    complete(units, checker, request, save, rounds=rounds, batch_size=batch_size,
             stall_rounds=stall_rounds, target_coverage=coverage, repair_only=repair_only, state=state)
    r = report(units, allow)
    print(f"Bruns residual check: {r['blocking_count']}/{r['total']}; stop={state['stop_reason']}")
    return r


def main():
    p = argparse.ArgumentParser()
    p.add_argument('workspace')
    p.add_argument('--rounds', type=int, default=3)
    p.add_argument('--batch-size', type=int, default=15)
    p.add_argument('--max-cost-rmb', type=float, default=5.)
    p.add_argument('--price-band', choices=['peak','offpeak'], default='peak')
    p.add_argument('--stall-rounds', type=int, default=2)
    p.add_argument('--target-coverage', type=float, default=1.)
    p.add_argument('--allow-kana', action='append', default=[])
    p.add_argument('--repair-only', action='store_true')
    p.add_argument('--audit-only', action='store_true')
    p.add_argument('--glossary')
    a = p.parse_args()
    if a.max_cost_rmb <= 0: p.error('Budget must be positive')
    if not a.audit_only:
        load_env()
        if not os.getenv('DEEPSEEK_API_KEY'): p.error('DEEPSEEK_API_KEY is missing')
    from core.glossary import load_glossary
    run(a.workspace, rounds=a.rounds, batch_size=a.batch_size, max_cost=a.max_cost_rmb,
        price_band=a.price_band, stall_rounds=a.stall_rounds, coverage=a.target_coverage,
        allow=a.allow_kana, repair_only=a.repair_only, audit_only=a.audit_only,
        glossary=load_glossary(a.glossary))

if __name__ == '__main__': main()
