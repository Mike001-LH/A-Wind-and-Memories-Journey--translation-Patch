#!/usr/bin/env python3
# Bruns alpha8.6 — extractor semantics recovered by direct alpha1/alpha8.4 diff.
import argparse,re,json,struct,zlib,unicodedata
from pathlib import Path
from collections import Counter,OrderedDict
def key(n): return bytes([(n&255)^0xef,((n>>8)&255)^0xbe,((n>>16)&255)^0xad,((n>>24)&255)^0xde])
def dec(b):
    if b[:4]!=b"EENZ": return b
    n=struct.unpack("<I",b[4:8])[0]; k=key(n)
    d=zlib.decompress(bytes(x^k[i%4] for i,x in enumerate(b[8:])))
    assert len(d)==n
    return d
SEND=re.compile(rb'\(a3:send-string\s+"((?:[^"\\]|\\.)*)"\s+([0-9]+)\)')
MENU=re.compile(rb'\(a3:call-user-func\s+4100\s+[^\r\n()]*?"((?:[^"\\]|\\.)*)"\s*\)')
DIALOG=re.compile(r'^\$N\$([A-Z])【([^】]+)】\$K#R(.*)\$N$',re.S)
TOKEN=re.compile(r'\$[A-Z]|#[A-Za-z]+|&R[A-Z]')
def meaningful(s):
    # alpha1 excludes punctuation/spacing-only narration. Keep any Unicode letter/number.
    return any(unicodedata.category(ch)[0] in ("L","N") for ch in TOKEN.sub("",s))
def main():
    ap=argparse.ArgumentParser(); ap.add_argument("game"); ap.add_argument("--output",required=True)
    a=ap.parse_args(); game=Path(a.game).resolve(); out=Path(a.output).resolve(); out.mkdir(parents=True,exist_ok=True)
    groups=OrderedDict(); raw=0; filtered=Counter()
    for p in sorted((game/"scene").glob("*.bso")):
        d=dec(p.read_bytes()); matches=[]
        for form,rx in (("send",SEND),("menu",MENU)):
            for m in rx.finditer(d): matches.append((m.start(1),m.end(1),m.group(1),form,m))
        for s0,e0,bb,form,m in sorted(matches,key=lambda x:x[0]):
            try: rawtext=bb.decode("cp932")
            except UnicodeDecodeError: continue
            if not any(ord(c)>127 for c in rawtext): continue
            raw+=1
            speaker=None; speaker_code=None; source=rawtext
            if form=="menu":
                kind="menu"; dkey=("menu",source)
            else:
                dm=DIALOG.match(rawtext)
                if dm:
                    kind="dialogue"; speaker_code,speaker,source=dm.groups()
                    dkey=("dialogue",speaker,source)
                else:
                    kind="narration"
                    if not meaningful(source):
                        filtered[source]+=1; continue
                    dkey=("narration",source)
            rec=groups.setdefault(dkey,{"kind":kind,"source":source,"speaker":speaker,
                                      "speaker_code":speaker_code,"raw_string":rawtext,"occurrences":[]})
            rec["occurrences"].append({"file":str(p.relative_to(game)),"start":s0,"end":e0,
                                       "raw_string":rawtext,"form":form})
    units=[]
    for i,r in enumerate(groups.values()):
        units.append({"id":f"bruns:{i:06d}","engine":"bruns","kind":r["kind"],
                      "source":r["source"],"translation":"","speaker":r["speaker"],
                      "protected_tokens":TOKEN.findall(r["raw_string"]),
                      "metadata":{"raw_string":r["raw_string"],"speaker_code":r["speaker_code"]},
                      "occurrences":r["occurrences"]})
    kinds=Counter(x["kind"] for x in units)
    report={"engine":"Bruns","raw_candidates":raw,"filtered_punctuation_occurrences":sum(filtered.values()),
            "filtered_punctuation_unique":len(filtered),"units":len(units),"kinds":dict(kinds),
            "filtered":[{"source":s,"count":n} for s,n in filtered.items()]}
    (out/"bruns_units.json").write_text(json.dumps(units,ensure_ascii=False,indent=2),encoding="utf-8")
    (out/"bruns_extract_report.json").write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding="utf-8")
    print("Engine: Bruns")
    print("Raw candidates:",raw)
    print("Punctuation-only occurrences filtered:",sum(filtered.values()))
    print("Punctuation-only unique filtered:",len(filtered))
    print("Translation units:",len(units))
    print("Kinds:",dict(kinds))
    print("Filtered:",dict(filtered))
    print("STATUS: BRUNS EXTRACT COMPLETE")
if __name__=="__main__": main()
