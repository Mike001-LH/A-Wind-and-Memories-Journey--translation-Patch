#!/usr/bin/env python3
import argparse,json
from pathlib import Path
from bruns.residual import report
from core.completion import atomic_json

def main():
    p=argparse.ArgumentParser();p.add_argument("workspace")
    p.add_argument("--allow-kana",action="append",default=[])
    a=p.parse_args();w=Path(a.workspace)
    units=json.loads((w/"bruns_units_translated.json").read_text(encoding="utf-8"))
    result=report(units,a.allow_kana)
    atomic_json(w/"bruns_residual_audit.json",result)
    print("Units:",result["total"],"Blocking:",result["blocking_count"])
    raise SystemExit(2 if result["blocking_count"] else 0)

if __name__=="__main__":main()
