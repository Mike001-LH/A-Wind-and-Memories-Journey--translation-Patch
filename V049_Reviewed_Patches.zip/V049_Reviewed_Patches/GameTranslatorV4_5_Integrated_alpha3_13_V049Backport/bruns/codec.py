import struct,zlib
def key(size):
    return bytes([(size&255)^0xef,((size>>8)&255)^0xbe,((size>>16)&255)^0xad,((size>>24)&255)^0xde])
def decode(data):
    if data[:4]!=b"EENZ": raise ValueError("not EENZ")
    n=struct.unpack("<I",data[4:8])[0]; k=key(n)
    raw=zlib.decompress(bytes(b^k[i%4] for i,b in enumerate(data[8:])))
    if len(raw)!=n: raise ValueError("decoded size mismatch")
    return raw
def encode(raw):
    n=len(raw); c=zlib.compress(raw); k=key(n)
    return b"EENZ"+struct.pack("<I",n)+bytes(b^k[i%4] for i,b in enumerate(c))
