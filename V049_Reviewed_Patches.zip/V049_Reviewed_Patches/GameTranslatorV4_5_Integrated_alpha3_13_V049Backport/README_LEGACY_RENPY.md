# Game Translator V4.0.0-alpha8.2

## New in alpha8.2

- `pipeline.py --extract-only`: real extraction + audit with **zero translation API calls**.
- `preflight_audit.py`: offline semantic safety audit, risky/control-string report, speaker census, rough API-unit/token/RMB planning estimate.
- Character Detection 2.0: recognizes more `Character` / `DynamicCharacter` declaration forms.
- Source-mirror fix: direct `.rpy` games are copied into the isolated workspace so the Writer can patch source-distributed Ren'Py games. This fixes the Test Game #2 shape (hundreds of RPY, zero RPYC/RPA).
- Keeps alpha7.5 Writer semantic guard and alpha7.4 font patch.

### Recommended safe first run

```bash
python game_translator_v4_0_0_alpha8_2/pipeline.py \
  "/path/to/game" \
  --output "/path/to/test_patch" \
  --unrpyc "/path/to/unrpyc.py" \
  --glossary "/path/to/glossary.json" \
  --font "/path/to/CJK-font.otf" \
  --extract-only
```

This stops after extraction + semantic audit. It does not run Character Pass or DeepSeek translation.

---

# Game Translator V4.0.0-alpha6.3 — Character Pass

Alpha6.3 freezes character names **before** translating dialogue.

## Why
Alpha6.2 could learn names only after batches had already begun, and a fresh run could choose a different transliteration. Alpha6.3 makes names a separate, reviewable artifact.

## Stage A — Character Pass
```bash
python game_translator_v4_0_0_alpha6_3/character_pass.py \
  "/Users/mike/Downloads/manyuu_v4_alpha5_units.json" \
  --checkpoint "/Users/mike/Downloads/manyuu_alpha63_characters.state.json" \
  --output "/Users/mike/Downloads/manyuu_alpha63_character_glossary.json" \
  --glossary "$HOME/Documents/local-llm-translator/glossary.json"
```
Review/edit `manyuu_alpha63_character_glossary.json`. Every entry is treated as hard terminology during Stage B. Title aliases are generated automatically, e.g. `Mr. Munemaga -> 宗长先生` also creates `Munemaga -> 宗长`.

## Stage B — Dialogue test
Use a **new** dialogue checkpoint:
```bash
python game_translator_v4_0_0_alpha6_3/translate_units.py \
  "/Users/mike/Downloads/manyuu_v4_alpha5_units.json" \
  --checkpoint "/Users/mike/Downloads/manyuu_alpha63_test.state.json" \
  --output "/Users/mike/Downloads/manyuu_alpha63_test_translated.json" \
  --qa "/Users/mike/Downloads/manyuu_alpha63_test_qa.json" \
  --glossary "$HOME/Documents/local-llm-translator/glossary.json" \
  --character-glossary "/Users/mike/Downloads/manyuu_alpha63_character_glossary.json" \
  --limit 30 \
  --batch-size 10
```

The user glossary has final priority over the generated character glossary. The original game is still untouched.

## alpha6.4 changes

- Stage B now resolves exact **hard glossary** strings locally before API calls. Character Pass names therefore are not translated twice and cost 0 API tokens in Stage B.
- Normalization dedup is now **source + semantic kind**, not source-only. Dialogue, menu choices, character names and UI strings no longer collapse into one translation merely because their English text matches. `ui_string` and `screen_text` may still share a UI translation.
- QA now reports soft-glossary inconsistencies as advisory `soft_glossary_review:*` issues.
- QA includes a conservative Koto terminology check (`term_review:Koto=>筝`). For this project, adding `"Koto": {"target":"筝","mode":"hard"}` to the user glossary is recommended if that is the chosen localization.
- Retry + recursive bisection from alpha6.2/6.3 is retained.

### Important migration note

Context-aware dedup changes normalized unit IDs/representatives in some cases. For a production run, regenerate normalized units with alpha6.4 and use **new Stage A and Stage B checkpoints**. Do not reuse alpha6.3 translation checkpoints.


## alpha6.4.1 changes

- Fixed `--limit` semantics: it now caps **total newly completed units in the current run**, including zero-token exact hard-glossary fills.
- Example: with `--limit 100` and 23 local fills, at most 77 additional API units are requested, for 100 newly completed units total.
- Updated the CLI version banner to `Game Translator V4.0.0-alpha6.4.1`.
- No extraction/dedup format change from alpha6.4; alpha6.4 normalized units and Character Pass glossary remain compatible. For a clean A/B translation test, use a new Stage B checkpoint.

## alpha7: Ren'Py Writer

alpha7 adds `renpy_writer.py`. It writes translated strings back into decompiled `.rpy` source in a separate patch directory. It never modifies the original game or the decompile workspace.

```bash
python game_translator_v4_0_0_alpha7/renpy_writer.py \
  /path/to/full_translated.json \
  --workspace /path/to/decompiled_workspace \
  --output /path/to/generated_patch \
  --report /path/to/writer_report.json
```

The writer is conservative: it patches only an exact quoted source literal at the recorded file+line. Ambiguous/missing lines are reported and cause exit status 2. Test the generated patch on a COPY of the game.


## alpha7.3
- Fix Ren'Py Writer workspace resolution for alpha6 workspaces.
- Prefers `workspace/virtual_game/game/...`, then `workspace/decompiled/<basename>`, then legacy `workspace/game/...`.
- Report records the resolved source path for every written file.


## alpha7.3
When a source location has both a syntax-aware `screen_text` unit and a legacy malformed `dialogue` unit from the same Screen Language line, the writer now gives `screen_text` precedence and suppresses the false dialogue duplicate. This fixes same-line double writes and interpolation-only screen text without weakening literal matching.

## alpha7.5 — Ren'Py CJK Font Patch

After `renpy_writer.py` passes, run `font_patch.py` with a user-supplied licensed `.ttf` or `.otf` font. The tool copies the font into `patch/game/fonts/`, adds a patched `game/gui.rpy` with the three standard GUI font definitions redirected to that font, and rewrites inline `{font=...}` spans only when the translated span contains CJK characters. It does not bundle or download fonts.

Example:

```bash
python game_translator_v4_0_0_alpha7_4/font_patch.py \
  --patch "/Users/mike/Downloads/manyuu_alpha74_patch" \
  --workspace "/Users/mike/Downloads/manyuu_v4_alpha64_workspace" \
  --font "/path/to/your/ChineseFont.ttf"
```

---

## V4.0.0-alpha8.0 — One-command Ren'Py pipeline

`pipeline.py` connects the tested Ren'Py stages into one resumable command:

1. detect/analyze the game without modifying it;
2. copy/decompile RPYC/RPA scripts into an isolated workspace;
3. extract + normalize translation units;
4. Character Pass to build a hard character glossary;
5. DeepSeek translation with checkpointing and QA;
6. alpha7.5 semantic-safe Ren'Py writer;
7. CJK font patch using a user-supplied `.ttf`/`.otf`;
8. write a pipeline manifest and reports.

The original game directory is never used as an output destination.

Example:

```bash
python game_translator_v4_0_0_alpha8_0/pipeline.py \
  "/path/to/original-game" \
  --output "/path/to/chinese-patch" \
  --unrpyc "$HOME/Documents/local-llm-translator/unrpyc/unrpyc.py" \
  --glossary "$HOME/Documents/local-llm-translator/glossary.json" \
  --font "/path/to/NotoSansCJKsc-VF.otf"
```

Use `--plan` to print all stages without modifying files or calling the translation API.
Use `--translated existing.json` to reuse an existing translation and skip Character Pass/API translation.
Use `--skip-font` if you intentionally want a script-only patch.

### Safety inherited from alpha7.5

The writer performs semantic safety checks against Ren'Py source and suppresses translations of control values such as `layout "subtitle"`. Font patching changes GUI font definitions and CJK inline font tags without redistributing any font; the user supplies the font file.
