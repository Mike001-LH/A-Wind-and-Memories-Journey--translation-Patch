MV/MZ JSON format recovery — integrated alpha3.4

If a translation API response has invalid JSON or hits the output limit, retry the failed batch once in two smaller parts. A singleton gets one retry. If a retry still has a format error, keep those originals pending and continue the next batch. Later repair rounds can retry unresolved units. Every attempt counts against --max-api-calls, and all reported token usage counts toward accounting. Passing split results are saved before sending the next part. Request limits, budget limits, auth/HTTP errors and timeouts still stop the run; timeouts are never automatically retried. No automatic paid provider fallback.

Existing MV/MZ checkpoints and game/work paths remain compatible. Keep the same game path and work directory; choose a fresh output. This feature is enabled for both MV and MZ, using either configured provider. It does not alter other engines' retry behavior. Gateway prices remain unknown unless supplied explicitly.

This full toolkit includes alpha3.3 VX Ace English coverage fix and previous integrated features. Offline test suite: 113 tests PASS. No live API requests or Windows playtests performed during this update.

Resume example:
python3 unified.py "/Users/mike/Downloads/Game_for_fans_ver2_window" --provider xianyi --api-model nvidia/nemotron-3-ultra-550b-a55b-nothinking --api-thinking omit --source-language Japanese --batch-size 10 --repair-rounds 2 --max-api-calls 300 --allow-partial --output "/Users/mike/Downloads/Game_for_fans_ver2_window_Chinese_Nemotron_Full3"
