#!/usr/bin/env python3
from __future__ import annotations
import argparse, os, subprocess, sys, json, shutil
from pathlib import Path

ROOT=Path(__file__).resolve().parent
VERSION="4.5.0-integrated-alpha3.13-v049-backport"
RPG_ENGINES={"RPG Maker MV", "RPG Maker MZ"}

def detect_engine(game: Path):
    dxa=game/'data/data.dxa'
    if dxa.is_file():
        with dxa.open('rb') as f:signature=f.read(4)
        if signature==b'DX\x08\x00':return 'DxLib / DXA8 (experimental)',90,[str(dxa)]
    from vxace.adapter import engine_for as ace_engine
    if ace_engine(game):return "RPG Maker VX Ace",99,[str(game/"Data"/"System.rvdata2"),str(game/"Data"/"Scripts.rvdata2")]
    evidence=[]
    from rpgmaker.mv import engine_for
    try:
        root, engine, core = engine_for(game)
        return engine, 99, [str(root/"data"/"System.json"), str(root/"js"/core)]
    except ValueError:
        pass
    scene=game/"scene"
    bso=list(scene.glob("*.bso")) if scene.is_dir() else []
    if bso:
        eenz=0
        for p in bso[:12]:
            try:
                if p.read_bytes()[:4]==b"EENZ": eenz+=1
            except OSError: pass
        if eenz or any(b"a3:send-string" in p.read_bytes() for p in bso[:12]):
            return "Bruns", min(99,70+eenz*2), [f"scene/*.bso: {len(bso)}",f"EENZ headers sampled: {eenz}"]
    gd=game/"game"
    if gd.is_dir():
        rpy=len(list(gd.rglob("*.rpy"))); rpyc=len(list(gd.rglob("*.rpyc")))
        rpa=len(list(game.glob("*.rpa")))
        if rpy or rpyc or rpa:
            evidence=[f"game/ directory",f"RPY: {rpy}",f"RPYC: {rpyc}",f"RPA: {rpa}"]
            return "Ren'Py", min(99,65+min(30,(rpy+rpyc+rpa)*2)), evidence
    from kag.source import detect
    evidence = detect(game)
    if evidence: return "KAG / XP3", 85, evidence
    return "Unknown",0,[]

def run(cmd, env=None):
    print("$"," ".join(map(str,cmd)),flush=True)
    subprocess.run([str(x) for x in cmd],check=True,env=env,cwd=ROOT)

def bruns(game, work, output, args, env):
    from bruns.autocomplete import run as complete_bruns
    from bruns.write import build
    from core.glossary import load_glossary
    work.mkdir(parents=True, exist_ok=True)
    # A separate manifest anchors cached offsets/checkpoints to this exact source.
    from rpgmaker.mv import digest
    from core.completion import atomic_json
    manifest = {"game":str(game), "files":{p.relative_to(game).as_posix():digest(p)
                 for p in sorted((game/"scene").glob("*.bso"))}}
    mp = work/"bruns_manifest.json"
    if mp.exists() and json.loads(mp.read_text(encoding="utf-8")) != manifest:
        raise ValueError("Bruns source changed; choose a new --workdir")
    if not mp.exists() and (work/"bruns_units.json").exists():
        raise ValueError("Legacy workspace has no source manifest; use a new workspace or run bruns.autocomplete directly for repair")
    atomic_json(mp, manifest)
    if not (work/"bruns_units.json").exists():
        run([sys.executable, "-m", "bruns.extract", game, "--output", work], env)
    if args.analyze: return
    if args.estimate:
        run([sys.executable, "-m", "bruns.translate", work, "--estimate-only",
             "--batch-size",args.batch_size,"--max-cost-rmb",args.max_cost_rmb,
             "--price-band",args.price_band],env)
        return
    from bruns.translate import load_env
    load_env()
    glossary = load_glossary(args.glossary)
    allow = args.allow_kana + [v['target'] for v in glossary.values()]
    complete_bruns(work, rounds=args.repair_rounds, batch_size=args.batch_size,
                   max_cost=args.max_cost_rmb, price_band=args.price_band,
                   stall_rounds=args.stall_rounds, coverage=args.target_coverage,
                   allow=allow, glossary=glossary)
    build(game,work,output,allow_partial=args.allow_partial,allow=allow)
    print("DONE — Bruns translated game:", output)

def renpy(game, work, output, args, env):
    cmd=[sys.executable,ROOT/"pipeline.py",game,"--output",output,"--workdir",work,
         "--source-language",args.source_language,"--batch-size",str(args.batch_size)]
    if args.unrpyc: cmd += ["--unrpyc",args.unrpyc]
    if args.glossary: cmd += ["--glossary",args.glossary]
    if args.font: cmd += ["--font",args.font]
    else: cmd += ["--skip-font"]
    if args.analyze or args.estimate: cmd += ["--extract-only"]
    run(cmd,env)
    if args.estimate:
        units=work/"units.json"
        if units.exists():
            rows=json.loads(units.read_text(encoding="utf-8"))
            chars=sum(len(x.get("source","")) for x in rows)
            # Informational only; real billing depends on context/cache/output.
            print(f"\nRen'Py extracted units: {len(rows)}; source chars: {chars}")
            print("Estimate mode made NO translation API calls.")
    if not (args.analyze or args.estimate):
        print("\nDONE — Ren'Py patch:",output)

def main():
    p=argparse.ArgumentParser(description="Game Translator 4.5: Ren'Py / Bruns / MV / MZ / KAG / VX Ace. File tools: python3 translator.py files --help")
    p.add_argument("game")
    p.add_argument("--output"); p.add_argument("--workdir")
    p.add_argument("--analyze",action="store_true"); p.add_argument("--estimate",action="store_true")
    p.add_argument("--provider",choices=["deepseek","xianyi"],default="deepseek",help="VX Ace/MV/MZ: official DeepSeek or Xianyi gateway")
    p.add_argument("--api-base-url",help="VX Ace/MV/MZ: HTTPS host or /v1 base")
    p.add_argument("--api-model",help="VX Ace/MV/MZ: exact model ID")
    p.add_argument("--api-thinking",choices=["omit","disabled"],help="Xianyi defaults to omit (tested); disabled requests non-thinking mode")
    p.add_argument("--max-api-calls",type=int,help="VX Ace/MV/MZ: per-run request cap, including failed requests and repair rounds")
    p.add_argument("--api-input-rmb",type=float,help="VX Ace: RMB per million uncached input tokens")
    p.add_argument("--api-output-rmb",type=float,help="VX Ace: RMB per million output tokens, including reasoning")
    p.add_argument("--api-cached-input-rmb",type=float,help="VX Ace: RMB per million cached input tokens")
    p.add_argument("--ai-review-units",type=int,default=0,help="VX Ace: gateway semantic review of up to N accepted representatives; shares primary request cap")
    p.add_argument("--fallback-deepseek",action="store_true",help="VX Ace: opt in to official paid repair of already attempted failed units only")
    p.add_argument("--fallback-max-units",type=int,default=50,help="Maximum residual representatives sent to official DeepSeek per run")
    p.add_argument("--fallback-max-api-calls",type=int,default=5,help="Independent paid request cap")
    p.add_argument("--fallback-max-cost-rmb",type=float,default=1.,help="Independent estimated paid RMB budget; one request can exceed remainder")
    p.add_argument("--api-key"); p.add_argument("--batch-size",type=int,default=15)
    p.add_argument("--max-cost-rmb",type=float,default=5.0)
    p.add_argument("--price-band",choices=["offpeak","peak"],default="peak")
    p.add_argument("--source-language",default="Japanese")
    p.add_argument("--locale", help="MV/MZ DKTools JSON: select source slot, e.g. ja; all explicitly keeps legacy all-branch data-only behavior")
    p.add_argument("--font"); p.add_argument("--unrpyc"); p.add_argument("--glossary")
    p.add_argument("--repair-rounds", type=int, default=3)
    p.add_argument("--stall-rounds", type=int, default=2)
    p.add_argument("--target-coverage", type=float, default=1.0, help="Bruns heuristic coverage target")
    p.add_argument("--allow-kana", action="append", default=[])
    p.add_argument("--allow-partial", action="store_true", help="Explicitly retain unresolved originals in output")
    p.add_argument("--sample", type=int, help="RPG Maker MV/MZ, VX Ace or KAG: translate this many units for a partial test build")
    p.add_argument("--extracted", help="KAG: GARbro extracted folder")
    p.add_argument("--archive", help="KAG: exact standard XP3 or EXE to unpack")
    p.add_argument("--build-only", action="store_true", help="KAG/VX Ace: offline patch from checkpoint")
    p.add_argument("--kag-font-face", default="Microsoft YaHei,SimSun")
    p.add_argument("--target-language", choices=["en","ja","zh"], help="VX Ace target; en=English ja=Japanese zh=Chinese")
    p.add_argument("--reuse-from", help="VX Ace: old work/TM; MV/MZ: old work directory for exact-source checkpoint reuse")
    p.add_argument("--migrate-only", action="store_true", help="VX Ace offline migration report/checkpoint")
    p.add_argument("--import-translations", help="VX Ace reviewed translations JSON")
    p.add_argument("--vx-font", help="VX Ace installed Windows font name; optional. Prefer the game's original font when it already supports the target language")
    p.add_argument("--vx-sample-profile", choices=["mixed","menu","story"], default="mixed", help="VX Ace --sample selection: mixed (default), menu, or story")
    p.add_argument("--no-vx-reuse", action="store_true", help="VX Ace: disable context-matched duplicate reuse")
    p.add_argument("--economy",action="store_true",help="VX Ace/MV/MZ official DeepSeek: compact requests and short response IDs")
    p.add_argument("--batch-chars",type=int,default=3500,help="Economy source character limit per batch; a single longer unit stays intact")
    a=p.parse_args()
    if a.batch_chars<1:p.error("--batch-chars must be positive")
    if a.economy and a.provider!='deepseek':p.error("--economy supports official DeepSeek; gateway keeps its tested response format")
    if a.batch_size < 1 or a.max_cost_rmb <= 0 or a.repair_rounds < 0 or a.stall_rounds < 1 or not 0 < a.target_coverage <= 1 or (a.sample is not None and a.sample < 1):
        p.error("Invalid batch, budget, repair or coverage setting")
    game=Path(a.game).expanduser().resolve()
    if not game.is_dir(): raise SystemExit(f"Game folder not found: {game}")
    engine,score,evidence=detect_engine(game)
    if engine=='DxLib / DXA8 (experimental)':
        if not (a.analyze or a.estimate):p.error('DXA is offline/experimental: use python3 translator.py dxa --help; automatic full translation is not enabled')
        from dxa.cli import analyze
        analyze(game,a.workdir or game.parent/(game.name+'_DXA_Work'))
        return
    if a.locale and engine not in RPG_ENGINES:p.error("--locale requires RPG Maker MV/MZ")
    if a.locale and not __import__("re").fullmatch(r"[A-Za-z0-9_-]+",a.locale):p.error("Invalid locale code")
    if a.economy and engine not in {'RPG Maker VX Ace', *RPG_ENGINES}:p.error("--economy requires VX Ace, MV or MZ")
    if a.extracted or a.archive: engine,score,evidence="KAG / XP3",85,[a.extracted or a.archive]
    if a.build_only and engine not in {"KAG / XP3","RPG Maker VX Ace"}: p.error("--build-only requires KAG or VX Ace")
    if engine=="RPG Maker VX Ace" and not a.target_language:p.error("VX Ace requires --target-language en, ja or zh")
    if engine!="RPG Maker VX Ace" and (a.target_language or a.migrate_only or a.import_translations or a.vx_font or a.vx_sample_profile!="mixed" or a.no_vx_reuse):
        p.error("Target-language/migration options currently require VX Ace")
    if a.reuse_from and engine not in {"RPG Maker VX Ace",*RPG_ENGINES}:p.error("--reuse-from requires VX Ace or MV/MZ")
    if a.ai_review_units<0 or a.fallback_max_units<1 or a.fallback_max_api_calls<1 or not 0<a.fallback_max_cost_rmb<float("inf"):p.error("Invalid staged limits")
    if (a.fallback_deepseek or a.ai_review_units) and a.provider!="xianyi":p.error("Gateway review/paid fallback require --provider xianyi")
    api_options=(a.fallback_deepseek or a.ai_review_units or a.provider!="deepseek" or a.api_base_url or a.api_model or a.api_thinking or a.max_api_calls is not None or a.api_input_rmb is not None or a.api_output_rmb is not None or a.api_cached_input_rmb is not None)
    if (a.fallback_deepseek or a.ai_review_units) and engine!="RPG Maker VX Ace":p.error("Semantic review/paid fallback currently require VX Ace")
    if api_options and engine not in {"RPG Maker VX Ace", *RPG_ENGINES}:p.error("API selection/accounting supports VX Ace, MV and MZ")
    if a.max_api_calls is not None and a.max_api_calls<1:p.error("--max-api-calls must be positive")
    if a.migrate_only and not a.reuse_from:p.error("--migrate-only requires --reuse-from")
    print(f"Game Translator V{VERSION}\nEngine: {engine} ({score}%)")
    for e in evidence: print(" ✓",e)
    if engine=="Unknown": raise SystemExit("Unsupported/unknown engine.")
    if a.sample is not None and engine not in {*RPG_ENGINES,"KAG / XP3","RPG Maker VX Ace"}:
        p.error("--sample supports RPG Maker MV/MZ, VX Ace and KAG")
    suffix="_Chinese" if engine in {"Bruns",*RPG_ENGINES} else "_Chinese_Patch"
    if engine=="RPG Maker VX Ace":suffix="_"+{"en":"English","ja":"Japanese","zh":"Chinese"}[a.target_language]+"_Patch"
    if engine in {*RPG_ENGINES,"KAG / XP3","RPG Maker VX Ace"} and a.sample and not (a.analyze or a.estimate):
        suffix += f"_Sample{a.sample}"
    output=Path(a.output).expanduser().resolve() if a.output else game.parent/(game.name+suffix)
    work=Path(a.workdir).expanduser().resolve() if a.workdir else game.parent/(game.name+"_GT_Work")
    if engine=="RPG Maker VX Ace" and not a.workdir:work=game.parent/(game.name+"_GT_Work_"+a.target_language)
    if a.locale and a.locale!="all" and not a.workdir:work=game.parent/(game.name+"_GT_Work_locale_"+a.locale)
    env=os.environ.copy()
    if a.api_key:
        key_name="XIANYI_API_KEY" if a.provider=="xianyi" else "DEEPSEEK_API_KEY"
        env[key_name]=a.api_key
        os.environ[key_name]=a.api_key
    if not (a.analyze or a.estimate) and engine in {"Bruns",*RPG_ENGINES}:
        from core.safe_output import validate_paths
        validate_paths(game,work,output)
    if engine=="RPG Maker VX Ace":
        from vxace.pipeline import run as ace_run
        ace_run(game,work,output,a)
    elif engine=="Bruns": bruns(game,work,output,a,env)
    elif engine in RPG_ENGINES:
        from rpgmaker.pipeline import run as mv_run
        mv_run(game,work,output,a)
    elif engine=="KAG / XP3":
        from kag.pipeline import run as kag_run
        kag_run(game,work,output,a)
    else: renpy(game,work,output,a,env)
if __name__=="__main__":
    try:
        main()
    except (ValueError, OSError, RuntimeError) as exc:
        print("STOP:", exc, file=sys.stderr)
        raise SystemExit(2)
