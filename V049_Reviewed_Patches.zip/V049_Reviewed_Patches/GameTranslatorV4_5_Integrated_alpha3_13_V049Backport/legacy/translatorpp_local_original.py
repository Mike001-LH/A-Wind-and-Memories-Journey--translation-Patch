"""Translate Translator++ XLSX and MTool JSON using local Ollama models."""
from __future__ import annotations

import argparse
from collections import Counter
from dataclasses import dataclass, replace
import json
import os
from pathlib import Path
import re
import sys
import time
from typing import Any, Iterable

OLLAMA_URL = "http://localhost:11434/api/chat"
JA_MODEL = "hf.co/SakuraLLM/Sakura-GalTransl-14B-v3.8:Q4_K_M"
EN_MODEL = "qwen3.5:27b"
REVIEW_MODEL = "qwen3.5:27b"
SOURCE_HEADER, TARGET_HEADER = "Original Text", "Best translation"
LB_RE = re.compile(r"⟦LB_(\d{3})⟧")
PH_RE = re.compile(r"\{[^{}\n]+\}|%\d*\$?[sdif]|\\[A-Za-z]+(?:\[[^\]\n]*\])?|<[^<>\n]+>")
KANA_RE = re.compile(r"[\u3040-\u30ff\u31f0-\u31ff]")
KANJI_RE = re.compile(r"[\u3400-\u4dbf\u4e00-\u9fff]")
STUTTER_RE = re.compile(r"(?:^|[「『（(！？!?。…\s])([\u3040-\u30ff\u3400-\u9fff])、(?=\s*[\u3040-\u30ff\u3400-\u9fff])")


@dataclass(frozen=True)
class Item:
    item_id: str
    source: str
    group: str
    order: int
    locator: Any


def arguments() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Local game translator: Translator++ XLSX / MTool JSON")
    p.add_argument("input", type=Path)
    p.add_argument("--output", type=Path)
    p.add_argument("--model")
    p.add_argument("--japanese-model", default=JA_MODEL)
    p.add_argument("--english-model", default=EN_MODEL)
    p.add_argument("--review-model", default=REVIEW_MODEL)
    p.add_argument("--source-language", choices=("auto", "Japanese", "English"), default="auto")
    p.add_argument("--batch-size", type=int, default=16)
    p.add_argument("--context-size", type=int, default=3)
    p.add_argument("--quality", choices=("fast", "high"), default="high")
    p.add_argument("--start", type=int, default=0,
                   help="Skip this many eligible untranslated entries before --limit")
    p.add_argument("--limit", type=int)
    p.add_argument("--resume", action="store_true")
    p.add_argument("--overwrite-existing", action="store_true")
    p.add_argument("--translate-technical", action="store_true")
    p.add_argument("--glossary", type=Path)
    p.add_argument("--dry-run", action="store_true")
    p.add_argument("--qa-report", type=Path)
    p.add_argument("--state-file", type=Path)
    p.add_argument("--timeout", type=int, default=900)
    a = p.parse_args()
    if not 1 <= a.batch_size <= 50: p.error("--batch-size must be 1..50")
    if not 0 <= a.context_size <= 20: p.error("--context-size must be 0..20")
    if a.start < 0: p.error("--start must be zero or positive")
    if a.limit is not None and a.limit < 1: p.error("--limit must be positive")
    return a


def read_object(path: Path, name: str) -> dict[str, Any]:
    try: data = json.loads(path.read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError) as e: raise ValueError(f"Cannot read {name}: {e}") from e
    if not isinstance(data, dict): raise ValueError(f"{name} must be a JSON object")
    return data


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, path)


def glossary(path: Path | None) -> dict[str, str]:
    if path is None: return {}
    data = read_object(path, "glossary")
    if not all(isinstance(k, str) and isinstance(v, str) for k, v in data.items()):
        raise ValueError("Glossary must be string-to-string JSON")
    return data


def technical(text: str) -> bool:
    s = text.strip()
    if not s or len(s) > 1500: return True
    if re.fullmatch(r"#[0-9A-Fa-f]{3,8}|[-+]?\d+(?:\.\d+)?|[A-Z][A-Z0-9_]{2,}", s): return True
    if re.fullmatch(r"[%$#&*+=<>!;:._/\\-]+", s) or re.match(r"^(?:https?://|www\.)", s): return True
    if len(re.findall(r"(?:function\s*\(|=>|\bvar\s+|\blet\s+|\bconst\s+|[{};])", s)) >= 2: return True
    if ("/" in s or "\\" in s) and re.search(r"\.(?:png|jpe?g|gif|webp|mp[34]|ogg|wav|json|js|css|html?)$", s, re.I): return True
    return False


class Adapter:
    kind = ""
    def items(self) -> list[Item]: raise NotImplementedError
    def get(self, item: Item) -> str: raise NotImplementedError
    def set(self, item: Item, value: str) -> None: raise NotImplementedError
    def save(self, path: Path) -> None: raise NotImplementedError
    def pending(self, item: Item, overwrite: bool) -> bool: raise NotImplementedError
    def context(self, item: Item, n: int) -> tuple[list[str], list[str]]:
        pool = getattr(self, "active_items", self.items())
        peers = [x for x in pool if x.group == item.group]
        i = next(i for i, x in enumerate(peers) if x.item_id == item.item_id)
        return ([x.source for x in peers[max(0, i-n):i]], [x.source for x in peers[i+1:i+1+n]])


class ExcelAdapter(Adapter):
    kind = "Translator++ Excel"
    def __init__(self, path: Path):
        try: from openpyxl import load_workbook
        except ImportError as e: raise ValueError("Run: python -m pip install openpyxl") from e
        self.book = load_workbook(path)
        self._items, order = [], 0
        for ws in self.book.worksheets:
            header, src, dst = self._columns(ws)
            for row in range(header + 1, ws.max_row + 1):
                value = ws.cell(row, src).value
                if isinstance(value, str) and value.strip():
                    self._items.append(Item(f"{ws.title}::{row}", value, ws.title, order, (ws.title, row, dst)))
                    order += 1
    @staticmethod
    def _columns(ws: Any) -> tuple[int, int, int]:
        for row in range(1, min(ws.max_row, 20) + 1):
            h = {str(ws.cell(row, c).value).strip(): c for c in range(1, ws.max_column + 1) if ws.cell(row, c).value is not None}
            if SOURCE_HEADER in h and TARGET_HEADER in h: return row, h[SOURCE_HEADER], h[TARGET_HEADER]
        raise ValueError(f"Sheet {ws.title!r} lacks Translator++ headers")
    def items(self) -> list[Item]: return self._items
    def get(self, x: Item) -> str:
        sheet, row, col = x.locator; v = self.book[sheet].cell(row, col).value
        return v if isinstance(v, str) else ""
    def set(self, x: Item, value: str) -> None:
        sheet, row, col = x.locator; self.book[sheet].cell(row, col, value=value)
    def pending(self, x: Item, overwrite: bool) -> bool: return overwrite or not self.get(x).strip()
    def save(self, path: Path) -> None: path.parent.mkdir(parents=True, exist_ok=True); self.book.save(path)


class MToolAdapter(Adapter):
    kind = "MTool JSON"
    def __init__(self, path: Path):
        self.data = read_object(path, "MTool JSON")
        if not all(isinstance(k, str) and isinstance(v, str) for k, v in self.data.items()):
            raise ValueError("MTool JSON must be a flat string-to-string object")
        self._items = [Item(f"json::{i:06d}", key, "MTool", i, key) for i, key in enumerate(self.data)]
    def items(self) -> list[Item]: return self._items
    def get(self, x: Item) -> str: return self.data[x.locator]
    def set(self, x: Item, value: str) -> None: self.data[x.locator] = value
    def pending(self, x: Item, overwrite: bool) -> bool:
        value = self.get(x); return overwrite or not value.strip() or value == x.source
    def save(self, path: Path) -> None: write_json(path, self.data)


def adapter(path: Path) -> Adapter:
    if path.suffix.lower() == ".xlsx": return ExcelAdapter(path)
    if path.suffix.lower() == ".json": return MToolAdapter(path)
    raise ValueError("Input must be .xlsx or .json")


def regroup_mtool(items: list[Item], maximum_gap: int = 20) -> list[Item]:
    """Break MTool text into scenes when translatable keys are far apart."""
    if not items:
        return []
    scene, previous = 0, items[0].order
    regrouped = []
    for item in items:
        if item.order - previous > maximum_gap:
            scene += 1
        regrouped.append(replace(item, group=f"MTool::{scene:04d}"))
        previous = item.order
    return regrouped


def protect(text: str) -> str:
    parts = text.split("\n")
    return "".join(part + (f"⟦LB_{i:03d}⟧" if i < len(parts)-1 else "") for i, part in enumerate(parts))


def restore(text: str, source: str) -> str:
    # A child ID represents exactly one physical source line. Some models
    # (especially Sakura) still insert presentation newlines inside the JSON
    # string. Those are model formatting, not source structure, so flatten
    # them before validation. Chinese output does not need a joining space.
    if "\n" not in source:
        text = re.sub(r"\s*[\r\n]+\s*", "", text)
    found = [int(x) for x in LB_RE.findall(text)]
    expected = list(range(source.count("\n")))
    if found != expected: raise ValueError(f"line-break markers changed: expected {expected}, got {found}")
    return LB_RE.sub("\n", text).strip(" \t\r")


def detect(texts: Iterable[str]) -> str:
    s = "\n".join(texts); kana = len(KANA_RE.findall(s)); latin = len(re.findall(r"[A-Za-z]", s))
    return "Japanese" if kana >= 3 and kana >= latin * .05 else "English"


def matches_requested_language(text: str, requested: str) -> bool:
    """Avoid feeding asset names/English engine metadata to Sakura."""
    if requested == "Japanese":
        return bool(KANA_RE.search(text) or KANJI_RE.search(text))
    if requested == "English":
        return bool(re.search(r"[A-Za-z]", text))
    return True


def lang(items: list[Item], requested: str) -> str: return requested if requested != "auto" else detect(x.source for x in items)
def chosen_model(language: str, a: argparse.Namespace) -> str: return a.model or (a.japanese_model if language == "Japanese" else a.english_model)


def primary_prompt(language: str, terms: dict[str, str]) -> str:
    role = "你是擅长轻小说、漫画和 Galgame 的专业日中翻译。" if language == "Japanese" else "You are a professional English-to-Simplified-Chinese game localizer."
    return f"""{role}
将全部 scene_items 当作一段连续剧情，理解上下文后翻译成自然简体中文。
只返回一个 JSON 对象，键须与输入 ID 完全相同，值只能是译文。
每个 ID 的内容不可移动到其他 ID。带有 `#L000` 的 ID 是同一单元格的连续行，必须逐行返回。
占位符、变量、标签和转义序列必须原样保留。日语句首重复音节通常是口吃，要按后续词语译成中文口吃。
拟声词要结合动作本地化，不能机械音译假名。保持人物口吻、主客体、动作力度和成人/暴力内容；不弱化、不添加。
context_before/context_after 仅供理解，不要翻译。不要解释或 Markdown。
术语表：{json.dumps(terms, ensure_ascii=False)}"""


def review_prompt(terms: dict[str, str]) -> str:
    return f"""你是简体中文游戏本地化终审。只修正 items_to_review。
核对原文、上下文和草稿，重点修正主客体颠倒、口吃、拟声词、人称漂移、遗漏添加、异常标点及生硬中文。
带有 `#L000` 的 ID 是同一单元格的连续行，必须逐行返回；占位符必须原样保留。成人或暴力内容不得审查或弱化。
只返回键完全一致的 JSON 对象，不要解释或 Markdown。术语表：{json.dumps(terms, ensure_ascii=False)}"""


def parse_json(raw: Any) -> dict[str, str]:
    if isinstance(raw, dict): result: Any = raw
    else:
        content = re.sub(r"^```(?:json)?\s*|\s*```$", "", str(raw).strip())
        result = json.loads(content)
    if isinstance(result, dict):
        for name in ("translations", "translation", "results", "items"):
            if isinstance(result.get(name), (dict, list)): result = result[name]; break
    if isinstance(result, list):
        converted = {}
        for row in result:
            if not isinstance(row, dict): raise ValueError("JSON list contains non-object")
            key = row.get("id") or row.get("key"); value = row.get("translation") or row.get("text") or row.get("value")
            if not isinstance(key, str) or not isinstance(value, str): raise ValueError("JSON list item lacks ID/translation")
            converted[key] = value
        result = converted
    if not isinstance(result, dict): raise ValueError("Model output is not a JSON object")
    out = {}
    for key, value in result.items():
        if isinstance(value, dict): value = value.get("translation") or value.get("text") or value.get("value")
        if not isinstance(value, str): raise ValueError(f"Translation {key!r} is not a string")
        out[str(key)] = value
    return out


def structural(source: str, target: str) -> list[str]:
    out = []
    if not target.strip(): out.append("empty_translation")
    if source.count("\n") != target.count("\n"): out.append("newline_mismatch")
    if Counter(PH_RE.findall(source)) != Counter(PH_RE.findall(target)): out.append("placeholder_mismatch")
    if not re.search(r"[「」『』]", source) and re.search(r"[「」『』]", target): out.append("unexpected_japanese_quote")
    quote_comma = re.search(r"[」』][，,]\s*$", target)
    added_punctuation_burst = (
        re.search(r"[，,。！？!?]{3,}\s*$", target)
        and not re.search(r"[、,。！？!?]{3,}\s*$", source)
    )
    if quote_comma or added_punctuation_burst:
        out.append("suspicious_trailing_punctuation")
    return out


def qa(source: str, target: str) -> list[str]:
    out = structural(source, target)
    if KANA_RE.search(target): out.append("japanese_kana_remaining")
    if source == target and KANA_RE.search(source): out.append("unchanged_japanese")
    a, b = len(re.sub(r"\s+", "", source)), len(re.sub(r"\s+", "", target))
    if a and b < a * .18: out.append("translation_unusually_short")
    if a and b > a * 3: out.append("translation_unusually_long")
    if re.search(r"(?:あんた|あなた|お前|君たち|あんた達)", source) and re.search(r"(?:她们|他们)", target) and "你" not in target: out.append("possible_second_person_drift")
    return list(dict.fromkeys(out))


def risks(source: str, draft: str = "") -> list[str]:
    out = qa(source, draft) if draft else []
    compact = re.sub(r"\s+", "", source); kana = len(KANA_RE.findall(compact)); kanji = len(KANJI_RE.findall(compact))
    if len(compact) <= 24 and kana >= 2 and kanji == 0 and re.search(r"[!！?？ー～〜]|(.)\1{2,}", source): out.append("sound_or_vocalization")
    if STUTTER_RE.search(source): out.append("possible_japanese_stutter")
    grammar = re.search(r"(?:られ|され|させ|にも関わらず|と言わんばかり|に至|ながら|ものの|踏んで|あまり|まるで|一方|わけ|ように)", source)
    if KANA_RE.search(source) and (len(compact) >= 45 or grammar): out.append("complex_japanese_relation")
    return list(dict.fromkeys(out))


def call(model: str, system: str, payload: dict[str, Any], sources: dict[str, str], timeout: int, stage: str) -> dict[str, str]:
    try:
        import requests
    except ImportError as e:
        raise RuntimeError("Missing dependency. Run: python -m pip install requests") from e
    expected = set(sources)
    schema = {"type":"object", "properties":{k:{"type":"string"} for k in expected}, "required":sorted(expected), "additionalProperties":False}
    last: Exception | None = None
    for attempt in range(1, 4):
        try:
            r = requests.post(OLLAMA_URL, json={"model":model,"messages":[{"role":"system","content":system},{"role":"user","content":json.dumps(payload,ensure_ascii=False)}],"stream":False,"think":False,"format":schema,"keep_alive":"10m","options":{"temperature":.1}}, timeout=timeout)
            r.raise_for_status(); result = parse_json(r.json()["message"]["content"])
            if set(result) != expected: raise ValueError(f"IDs changed: missing={sorted(expected-set(result))}, extra={sorted(set(result)-expected)}")
            restored = {k: restore(v, sources[k]) for k, v in result.items()}
            for key, value in restored.items():
                bad = structural(sources[key], value)
                if bad: raise ValueError(f"{key}: {', '.join(bad)}")
            return restored
        except (requests.RequestException, KeyError, ValueError, json.JSONDecodeError) as e:
            last = e; print(f"  {stage} attempt {attempt}/3 failed: {e}")
            if attempt < 3: time.sleep(2 * attempt)
    raise RuntimeError(f"{stage} failed after 3 attempts: {last}")


def parse_labeled_block(content: str, labels: list[str]) -> dict[str, str]:
    """Parse Sakura-friendly [T0001] blocks; values may span many lines."""
    pattern = re.compile(r"(?m)^\s*\[(T\d{4})\]\s*")
    matches = list(pattern.finditer(content.strip()))
    seen = [match.group(1) for match in matches]
    if seen != labels:
        raise ValueError(f"labels changed: expected {labels}, got {seen}")
    result = {}
    for index, match in enumerate(matches):
        end = matches[index + 1].start() if index + 1 < len(matches) else len(content)
        value = content[match.end():end].strip()
        if not value:
            raise ValueError(f"empty translation for {match.group(1)}")
        result[match.group(1)] = value
    return result


def call_sakura(model: str, language: str, terms: dict[str, str], batch: list[Item],
                before: list[str], after: list[str], timeout: int) -> dict[str, str]:
    """Use the simple numbered format Sakura follows reliably in CLI tests."""
    try:
        import requests
    except ImportError as e:
        raise RuntimeError("Missing dependency. Run: python -m pip install requests") from e
    labels = [f"T{i:04d}" for i in range(1, len(batch) + 1)]
    label_to_item = dict(zip(labels, batch))
    source_block = "\n\n".join(f"[{label}] {item.source}" for label, item in zip(labels, batch))
    prompt = f"""请先完整理解这段连续的游戏剧情，再把每个编号的{language}原文翻译成自然准确的简体中文。
严格保留并按原顺序输出每个 [T0001] 编号。一个编号的译文可以包含多行，但不得把内容移到其他编号。
不要输出 JSON，不要解释，不要添加原文没有的信息。正确处理口吃、拟声词、人物口吻、动作主客体和成人内容。
占位符、变量、标签和转义序列必须原样保留。
术语表：{json.dumps(terms, ensure_ascii=False)}
前文（只供理解）：{json.dumps(before, ensure_ascii=False)}
后文（只供理解）：{json.dumps(after, ensure_ascii=False)}

原文：
{source_block}"""
    last: Exception | None = None
    for attempt in range(1, 3):
        try:
            response = requests.post(
                OLLAMA_URL,
                json={"model": model, "messages": [{"role": "user", "content": prompt}],
                      "stream": False, "think": False, "keep_alive": "10m",
                      "options": {"temperature": .1}},
                timeout=timeout,
            )
            response.raise_for_status()
            parsed = parse_labeled_block(response.json()["message"]["content"], labels)
            final = {}
            for label, value in parsed.items():
                item = label_to_item[label]
                # Exact source newlines are preferable but semantic cell
                # alignment is more important. Newline differences go to QA.
                problems = [x for x in structural(item.source, value) if x != "newline_mismatch"]
                if problems:
                    raise ValueError(f"{item.item_id}: {', '.join(problems)}")
                final[item.item_id] = value.strip()
            return final
        except (requests.RequestException, KeyError, ValueError, json.JSONDecodeError) as e:
            last = e
            print(f"  Sakura block attempt {attempt}/2 failed: {e}")
            if attempt < 2:
                time.sleep(2 * attempt)
    raise RuntimeError(f"Sakura block failed after 2 attempts: {last}")


def translate_sakura_adaptive(ad: Adapter, items: list[Item], language: str,
                              model: str, terms: dict[str, str], n: int,
                              timeout: int) -> dict[str, str]:
    """Recursively shrink only a block that Sakura cannot label reliably."""
    if not items:
        return {}
    before, _ = ad.context(items[0], n)
    _, after = ad.context(items[-1], n)
    try:
        return call_sakura(model, language, terms, items, before, after, timeout)
    except RuntimeError:
        if len(items) == 1:
            raise
        middle = len(items) // 2
        left, right = items[:middle], items[middle:]
        print(f"  Sakura could not keep labels; splitting {len(items)} items into {len(left)} + {len(right)}.")
        return {
            **translate_sakura_adaptive(ad, left, language, model, terms, n, timeout),
            **translate_sakura_adaptive(ad, right, language, model, terms, n, timeout),
        }


def groups(items: list[Item], size: int):
    batch: list[Item] = []
    for item in items:
        if batch and (len(batch) >= size or item.group != batch[0].group): yield batch; batch = []
        batch.append(item)
    if batch: yield batch


def translate(ad: Adapter, batch: list[Item], language: str, model: str, terms: dict[str,str], n: int, timeout: int) -> dict[str,str]:
    before, _ = ad.context(batch[0], n); _, after = ad.context(batch[-1], n)
    if language == "Japanese" and "sakura" in model.lower():
        exact = {x.item_id: terms[x.source] for x in batch if x.source in terms}
        generated_items = [x for x in batch if x.source not in terms]
        generated = translate_sakura_adaptive(ad, generated_items, language, model, terms, n, timeout)
        return {**generated, **exact}
    exact, generated, child_ids = {}, {}, {}
    for x in batch:
        if x.source in terms:
            exact[x.item_id] = terms[x.source]
            continue
        # Sakura often removes artificial line-break tokens even when the
        # prompt explicitly forbids it. Give every physical line a stable
        # child ID instead; the model still sees the complete ordered scene,
        # while Python—not the model—reconstructs the cell's exact newlines.
        ids = []
        for line_number, line in enumerate(x.source.split("\n")):
            child = x.item_id if "\n" not in x.source else f"{x.item_id}#L{line_number:03d}"
            ids.append(child)
            generated[child] = line
        child_ids[x.item_id] = ids
    made = call(model, primary_prompt(language, terms), {"context_before":before,"scene_items":generated,"context_after":after}, generated, timeout, "translation") if generated else {}
    rebuilt = {parent: "\n".join(made[child] for child in ids) for parent, ids in child_ids.items()}
    return {**rebuilt, **exact}


def review(ad: Adapter, batch: list[Item], model: str, terms: dict[str,str], n: int, timeout: int) -> tuple[dict[str,str],dict[str,list[str]]]:
    candidates, reasons, sources, child_ids = {}, {}, {}, {}
    for x in batch:
        why = risks(x.source, ad.get(x))
        if not why or x.source in terms: continue
        before, after = ad.context(x, n); reasons[x.item_id] = why
        source_lines, draft_lines = x.source.split("\n"), ad.get(x).split("\n")
        if len(source_lines) != len(draft_lines):
            # This should only happen with an output produced by an older
            # script. Let QA report it instead of silently inventing splits.
            continue
        ids = []
        for line_number, (source_line, draft_line) in enumerate(zip(source_lines, draft_lines)):
            child = x.item_id if len(source_lines) == 1 else f"{x.item_id}#L{line_number:03d}"
            ids.append(child); sources[child] = source_line
            candidates[child] = {"risk_types":why,"context_before":before,"source":source_line,"draft":draft_line,"context_after":after}
        child_ids[x.item_id] = ids
    made = call(model, review_prompt(terms), {"items_to_review":candidates}, sources, timeout, "review") if candidates else {}
    rebuilt = {parent:"\n".join(made[child] for child in ids) for parent,ids in child_ids.items()}
    return rebuilt, reasons


def save_all(ad: Adapter, output: Path, qa_path: Path, state_path: Path, selected: list[Item], state: dict[str,Any]) -> None:
    ad.save(output)
    complete = set(state["primary_completed"]); errors = []
    normalized_targets = Counter(
        re.sub(r"\s+", "", ad.get(x)) for x in selected
        if x.item_id in complete and len(re.sub(r"\s+", "", ad.get(x))) >= 12
    )
    for x in selected:
        if x.item_id in complete:
            problems = qa(x.source, ad.get(x))
            normalized = re.sub(r"\s+", "", ad.get(x))
            if len(normalized) >= 12 and normalized_targets[normalized] > 1:
                problems.append("duplicate_translation")
            if problems: errors.append({"id":x.item_id,"source":x.source,"translation":ad.get(x),"issues":problems})
    write_json(qa_path, {"output":str(output),"summary":{"selected":len(selected),"primary_completed":len(complete),"review_completed":len(state["review_completed"]),"error_count":len(errors),"reviewed_count":len(state["reviewed_items"])},"errors":errors,"reviewed_items":state["reviewed_items"]})
    write_json(state_path, state)


def main() -> int:
    a = arguments(); inp = a.input.expanduser().resolve(); out = (a.output or inp.with_name(f"{inp.stem}_translated{inp.suffix}")).expanduser().resolve()
    qa_path = (a.qa_report or out.with_name(f"{out.stem}_qa.json")).expanduser().resolve(); state_path = (a.state_file or out.with_name(f"{out.name}.state.json")).expanduser().resolve()
    if not inp.exists(): print(f"Error: input not found: {inp}"); return 1
    if inp == out: print("Error: output must differ from input"); return 1
    if a.resume and not out.exists(): print(f"Error: resume output missing: {out}"); return 1
    if out.exists() and not a.resume and not a.dry_run: print(f"Error: output exists: {out}\nUse --resume or another --output."); return 1
    try: ad = adapter(out if a.resume else inp); terms = glossary(a.glossary)
    except ValueError as e: print(f"Error: {e}"); return 1
    all_items = ad.items(); by_id = {x.item_id:x for x in all_items}
    eligible = [x for x in all_items if (a.translate_technical or not technical(x.source)) and matches_requested_language(x.source, a.source_language) and ad.pending(x, a.overwrite_existing)]
    if a.resume:
        if not state_path.exists(): print(f"Error: state missing: {state_path}"); return 1
        try:
            state = read_object(state_path, "state")
            selected = [by_id[x] for x in state["selected_ids"] if x in by_id]
            saved = state.get("settings", {})
            a.source_language = saved.get("source_language", a.source_language)
            a.quality = saved.get("quality", a.quality)
            a.japanese_model = saved.get("japanese_model", a.japanese_model)
            a.english_model = saved.get("english_model", a.english_model)
            a.review_model = saved.get("review_model", a.review_model)
            a.batch_size = saved.get("batch_size", a.batch_size)
            a.context_size = saved.get("context_size", a.context_size)
            a.timeout = saved.get("timeout", a.timeout)
            a.start = saved.get("start", a.start)
            if a.glossary is None and saved.get("glossary"):
                a.glossary = Path(saved["glossary"])
                terms = glossary(a.glossary)
        except (ValueError, KeyError) as e: print(f"Error: invalid state: {e}"); return 1
    else:
        window = eligible[a.start:]
        selected = window[:a.limit] if a.limit else window
        state = {"version":2,"input":str(inp),"output":str(out),"selected_ids":[x.item_id for x in selected],"primary_completed":[],"review_completed":[],"reviewed_items":[],"settings":{"source_language":a.source_language,"quality":a.quality,"japanese_model":a.japanese_model,"english_model":a.english_model,"review_model":a.review_model,"batch_size":a.batch_size,"context_size":a.context_size,"timeout":a.timeout,"start":a.start,"glossary":str(a.glossary.expanduser().resolve()) if a.glossary else None}}
    if isinstance(ad, MToolAdapter):
        selected = regroup_mtool(selected)
        ad.active_items = selected
    completed, reviewed = set(state["primary_completed"]), set(state["review_completed"])
    pending = [x for x in selected if x.item_id not in completed]
    print(f"Format: {ad.kind}\nReading: {out if a.resume else inp}\nEntries: {len(all_items)}\nTechnical skipped: {sum(technical(x.source) for x in all_items) if not a.translate_technical else 0}\nEligible entries skipped by --start: {a.start}\nSelected: {len(selected)}\nPrimary remaining: {len(pending)}")
    print(f"Quality: {a.quality}; batch={a.batch_size}; context={a.context_size}\nJapanese: {a.japanese_model}\nEnglish: {a.english_model}")
    if a.quality == "high": print(f"Deferred reviewer: {a.review_model}")
    if a.dry_run:
        print("Dry run: no API call or output.")
        for x in selected[:10]: print(f"  {x.item_id}: {x.source.replace(chr(10), '<NL>')[:100]}")
        return 0
    if not a.resume: save_all(ad, out, qa_path, state_path, selected, state); print(f"Created checkpoint: {out}")
    try:
        done = len(completed)
        for number, batch in enumerate(groups(pending, a.batch_size), 1):
            language = lang(batch, a.source_language); model = chosen_model(language, a)
            print(f"Primary batch {number}: {done+1}-{done+len(batch)}/{len(selected)} with {model} ({language})")
            result = translate(ad, batch, language, model, terms, a.context_size, a.timeout)
            for x in batch: ad.set(x, result[x.item_id]); completed.add(x.item_id)
            state["primary_completed"] = sorted(completed); done += len(batch); save_all(ad,out,qa_path,state_path,selected,state); print(f"  Checkpoint saved ({done}/{len(selected)}).")
        if a.quality == "high":
            candidates = [x for x in selected if x.item_id in completed and x.item_id not in reviewed and lang([x], a.source_language)=="Japanese" and risks(x.source, ad.get(x))]
            print(f"Deferred review candidates: {len(candidates)}")
            for number, batch in enumerate(groups(candidates, a.batch_size), 1):
                print(f"Review batch {number}: {len(batch)} item(s) with {a.review_model}")
                result, why = review(ad,batch,a.review_model,terms,a.context_size,a.timeout)
                for x in batch:
                    if x.item_id in result: ad.set(x,result[x.item_id])
                    reviewed.add(x.item_id); state["reviewed_items"] = [r for r in state["reviewed_items"] if r.get("id")!=x.item_id]
                    state["reviewed_items"].append({"id":x.item_id,"source":x.source,"translation":ad.get(x),"reasons":why.get(x.item_id,[])})
                state["review_completed"] = sorted(reviewed); save_all(ad,out,qa_path,state_path,selected,state); print(f"  Review checkpoint saved ({len(reviewed)} completed).")
    except KeyboardInterrupt:
        print(f"\nStopped; checkpoints saved. Resume with:\npython {Path(__file__).name} {inp.name} --output {out.name} --resume"); return 130
    except RuntimeError as e: print(f"Translation stopped: {e}\nCompleted batches remain saved; use --resume."); return 1
    save_all(ad,out,qa_path,state_path,selected,state)
    print(f"Translation completed.\nOutput: {out}\nQA: {qa_path}\nState: {state_path}"); return 0


if __name__ == "__main__": sys.exit(main())
