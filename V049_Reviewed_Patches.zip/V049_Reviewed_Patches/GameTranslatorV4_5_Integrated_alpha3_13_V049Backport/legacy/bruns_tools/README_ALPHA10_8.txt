alpha10.8
1) final_audit.py: NO API. Exports exact-copy survivors and mixed/partial translation suspects.
2) repair_final120.py: stronger one-by-one repair for exact-copy survivors only.
Run final_audit first. Existing checkpoint is reused.
