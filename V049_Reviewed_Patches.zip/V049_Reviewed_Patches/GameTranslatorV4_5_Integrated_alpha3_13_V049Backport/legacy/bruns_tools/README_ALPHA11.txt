alpha11 final cleaner
One-command high-confidence cleanup:
- exact source-copy survivors
- high-confidence Japanese prose residue
- repairs from ORIGINAL Japanese source
- preserves a pre-clean checkpoint backup
After this, run alpha10 QA/writer and residual audit.
