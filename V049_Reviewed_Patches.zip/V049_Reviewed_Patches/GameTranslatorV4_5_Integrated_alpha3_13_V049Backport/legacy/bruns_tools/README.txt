Bruns alpha9.4 — stubborn pending repair

Use after alpha9.3 plateaus. It does NOT retranslate completed units.
It processes each pending unit individually, up to 3 rounds, checkpoints after every
successful/failed paid request, keeps the same cost guard, and exports any survivors
to bruns_pending.json for inspection instead of endlessly re-rolling batches.

Run:
python ~/Documents/local-llm-translator/game_translator_v4_bruns_adapter_alpha9_4/bruns/repair_pending.py /Users/mike/Downloads/bruns_alpha8_6_workspace --max-cost-rmb 0.50 --price-band peak --max-rounds 3
