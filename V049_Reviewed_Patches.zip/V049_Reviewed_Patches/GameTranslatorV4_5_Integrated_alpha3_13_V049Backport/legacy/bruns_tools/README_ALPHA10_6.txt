alpha10.6
Pipeline: translate -> deterministic local CP932 conversion -> CP932 gate -> LLM repair only as last resort.
Repairs only translation==source units. Existing checkpoint/good translations preserved.
Start with --audit-only; then use --repair with a cost cap.
