alpha10.7 survivor cleaner
Processes only translation==source survivors, one item at a time.
Local CP932 substitutions are applied before a last-resort focused paraphrase.
Checkpoint is persisted after every processed paid item. Existing good translations untouched.
