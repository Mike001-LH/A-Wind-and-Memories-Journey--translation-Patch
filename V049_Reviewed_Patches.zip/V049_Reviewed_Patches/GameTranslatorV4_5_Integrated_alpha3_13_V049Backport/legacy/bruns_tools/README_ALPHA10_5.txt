alpha10.5: repairs ONLY certain failures where translation == source.
Good/mixed translations are untouched. CP932-invalid translated candidates automatically
receive a second repair pass. Checkpoint saved after each batch. Start with --audit-only.
