Bruns alpha10.3 quality repair.
First run --audit-only (NO API). It detects translations that are empty, identical to source,
or still contain Japanese kana after stripping engine tokens.
Then run --repair with a cost cap. Every accepted repair must be CP932-safe AND pass the same
quality gate. Checkpoint is saved after each paid batch. Existing good translations are untouched.
