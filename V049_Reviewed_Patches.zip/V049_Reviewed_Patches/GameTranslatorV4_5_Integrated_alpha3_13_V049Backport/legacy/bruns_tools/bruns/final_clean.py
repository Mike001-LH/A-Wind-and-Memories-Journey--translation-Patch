#!/usr/bin/env python3
import argparse,json,re,subprocess,sys
from pathlib import Path

HIRA=re.compile(r'[\u3040-\u309f]')
TOK=re.compile(r'\$[A-Z]|#[A-Za-z]+|&R[A-Z]')
ALLOW=("さん","くん")
def v(s): return TOK.sub("",s or "").strip()
def certain(u): return bool(v(u.get("source"))) and v(u.get("translation"))==v(u.get("source"))
def high_mixed(u):
    s=v(u.get("source")); t=v(u.get("translation"))
    if not t or certain(u): return False
    # Hiragana surviving in a Chinese translation is high-confidence, except isolated honorifics.
    x=t
    for a in ALLOW: x=x.replace(a,"")
    if HIRA.search(x): return True
    # Long exact Japanese source fragments surviving after translation.
    for n in range(min(16,len(s)),9,-1):
        if any(s[i:i+n] in t and HIRA.search(s[i:i+n]) for i in range(len(s)-n+1)):
            return True
    return False

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("workspace")
    ap.add_argument("--repair",action="store_true")
    ap.add_argument("--max-cost-rmb",type=float,default=1.0)
    ap.add_argument("--price-band",default="peak")
    a=ap.parse_args(); ws=Path(a.workspace)
    cp=ws/"bruns_alpha9_checkpoint.json"
    data=json.loads(cp.read_text(encoding="utf-8")); units=data["units"]
    bad=[u for u in units if certain(u) or high_mixed(u)]
    out=ws/"bruns_final_high_confidence.json"
    out.write_text(json.dumps([{"id":u["id"],"source":u["source"],"translation":u.get("translation",""),
                                "reason":"certain" if certain(u) else "mixed"} for u in bad],
                              ensure_ascii=False,indent=2),encoding="utf-8")
    print("Certain:",sum(certain(u) for u in units))
    print("High-confidence mixed:",sum(high_mixed(u) for u in units))
    print("Final repair targets:",len(bad))
    if not a.repair:
        print("STATUS: FINAL CLEAN AUDIT — NO API CALLS"); return
    # Convert high-confidence mixed entries back to source-identical temporarily so the proven survivor
    # repairer retranslates from ORIGINAL source, never from the partial translation.
    ids={u["id"] for u in bad}
    backup=ws/"bruns_alpha11_preclean_backup.json"
    backup.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding="utf-8")
    for u in units:
        if u["id"] in ids: u["translation"]=u["source"]
    cp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding="utf-8")
    (ws/"bruns_units_translated.json").write_text(json.dumps(units,ensure_ascii=False,indent=2),encoding="utf-8")
    cleaner=Path(__file__).with_name("repair_final120.py")
    cmd=[sys.executable,str(cleaner),str(ws),"--repair","--max-cost-rmb",str(a.max_cost_rmb),
         "--price-band",a.price_band]
    print("Starting final paid repair...")
    rc=subprocess.call(cmd)
    # final audit
    data=json.loads(cp.read_text(encoding="utf-8")); units=data["units"]
    c=sum(certain(u) for u in units); m=sum(high_mixed(u) for u in units)
    print("FINAL Certain remaining:",c)
    print("FINAL high-confidence mixed remaining:",m)
    print("Backup:",backup)
    print("STATUS:","FINAL CLEAN PASSED" if c==0 and m==0 else "FINAL CLEAN PARTIAL")
    raise SystemExit(rc)
if __name__=="__main__": main()
