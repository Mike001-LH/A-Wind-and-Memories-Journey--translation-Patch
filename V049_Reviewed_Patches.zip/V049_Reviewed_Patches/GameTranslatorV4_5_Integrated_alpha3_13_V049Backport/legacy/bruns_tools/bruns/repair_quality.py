#!/usr/bin/env python3
import argparse,json,os,re,time
from pathlib import Path
from decimal import Decimal
from translate import load_env, api_request, parsed_map, cp932_ok, cost_cny

KANA_RUN=re.compile(r'[\u3040-\u30ffー]+')
TOK=re.compile(r'\$[A-Z]|#[A-Za-z]+|&R[A-Z]')
# Short katakana names/onomatopoeia may legitimately remain. Long Japanese grammar runs should not.
JP_GRAMMAR=re.compile(r'(です|ます|でした|ません|ない|する|した|して|から|ので|けど|なら|まで|より|って|という|この|その|あの|これ|それ|どう|なに|何を|私|僕|俺|先輩)')
def visible(s): return TOK.sub("",s or "")

def residual_score(source,translation):
    """Return evidence of untranslated Japanese, allowing isolated proper names."""
    t=visible(translation); s=visible(source)
    evidence=[]
    if not t.strip(): return ["empty"]
    if t.strip()==s.strip(): return ["same_as_source"]
    # Japanese grammatical material is strong evidence.
    for m in JP_GRAMMAR.finditer(t):
        evidence.append("jp_grammar:"+m.group(0))
    # Hiragana is rarely needed in 日繁 Chinese; tolerate only tiny isolated interjections (<=1).
    hira_runs=re.findall(r'[\u3040-\u309f]+',t)
    for r in hira_runs:
        if len(r)>=2: evidence.append("hiragana:"+r)
    # Katakana alone is allowed (names such as ハレイス/ミニオン/リロイ).
    # But if a long source fragment survives verbatim, flag it.
    for n in range(12,5,-1):
        found=False
        for i in range(max(0,len(s)-n+1)):
            frag=s[i:i+n]
            if frag in t and re.search(r'[\u3040-\u30ff]',frag):
                evidence.append("source_fragment:"+frag); found=True; break
        if found: break
    return evidence

def suspicious(u):
    return residual_score(u.get("source",""),u.get("translation",""))

def save(ws,cp,state,units):
    cp.write_text(json.dumps({"state":state,"units":units},ensure_ascii=False,indent=2),encoding="utf-8")
    (ws/"bruns_units_translated.json").write_text(json.dumps(units,ensure_ascii=False,indent=2),encoding="utf-8")

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("workspace"); ap.add_argument("--audit-only",action="store_true")
    ap.add_argument("--repair",action="store_true"); ap.add_argument("--batch-size",type=int,default=15)
    ap.add_argument("--max-cost-rmb",type=float,default=3.0)
    ap.add_argument("--price-band",choices=["offpeak","peak"],default="peak")
    a=ap.parse_args(); ws=Path(a.workspace); cp=ws/"bruns_alpha9_checkpoint.json"
    data=json.loads(cp.read_text(encoding="utf-8")); units=data["units"]; state=data["state"]
    bad=[(u,suspicious(u)) for u in units if suspicious(u)]
    out=[{"id":u["id"],"kind":u["kind"],"speaker":u.get("speaker"),"source":u["source"],
          "translation":u.get("translation",""),"reasons":r} for u,r in bad]
    (ws/"bruns_quality_pending.json").write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding="utf-8")
    print("Units:",len(units)); print("Quality-suspicious:",len(bad))
    from collections import Counter
    c=Counter(x for _,r in bad for x in r); print("Reasons:",dict(c))
    print("Pending file:",ws/"bruns_quality_pending.json")
    if a.audit_only or not a.repair:
        print("STATUS: QUALITY AUDIT ONLY — NO API CALLS"); return
    load_env()
    if not os.getenv("DEEPSEEK_API_KEY"): raise SystemExit("DEEPSEEK_API_KEY not found")
    session=Decimal("0")
    targets=[u for u,_ in bad]
    for bi in range(0,len(targets),a.batch_size):
        if session>=Decimal(str(a.max_cost_rmb)): print("COST GUARD reached"); break
        batch=targets[bi:bi+a.batch_size]
        items=[{"id":u["id"],"source":u["source"],"candidate":u.get("translation",""),
                "speaker":u.get("speaker"),"kind":u["kind"],
                "bad_chars":[],
                "instruction":"""The prior candidate is incomplete, partially Japanese, or not CP932-safe. Fully translate all Japanese grammar and prose into natural 日繁 Chinese that Python can encode with cp932. Isolated katakana proper names such as ハレイス, ミニオン, リロイ may remain unchanged. Do NOT leave Japanese grammatical phrases. Avoid CP932-unsafe Chinese characters such as 吧, 啊, 嗯, 產; paraphrase them using CP932-safe wording. Do not copy the Japanese source. Preserve engine tokens exactly if present."""} for u in batch]
        obj=got=None
        for attempt in range(3):
            try:
                obj=api_request(items,mode="repair"); got=parsed_map(obj); break
            except Exception as e:
                print("RETRY",attempt+1,repr(e)); time.sleep(attempt+1)
        if not obj or not got: continue
        usage=obj.get("usage",{}); cost=cost_cny(usage,a.price_band); session+=cost
        accepted=0
        for u in batch:
            t=got.get(u["id"],""); ok,badchars=cp932_ok(t)
            trial=dict(u); trial["translation"]=t
            why=suspicious(trial)
            if t and ok and not why:
                u["translation"]=t; accepted+=1
            else:
                print("QUALITY REJECT",u["id"],"cp932_bad=",badchars,"reasons=",why)
        state["spent_rmb"]=float(Decimal(str(state.get("spent_rmb",0)))+cost)
        state["completed"]=sum(bool(x.get("translation")) for x in units)
        for k,v in [("prompt",usage.get("prompt_tokens",0)),("completion",usage.get("completion_tokens",0)),
                    ("hit",usage.get("prompt_cache_hit_tokens",0)),("miss",usage.get("prompt_cache_miss_tokens",0))]:
            state["usage"][k]=state["usage"].get(k,0)+v
        save(ws,cp,state,units)
        print(f"Batch {bi//a.batch_size+1}: accepted {accepted}/{len(batch)}; ¥{cost:.4f}; session ¥{session:.4f}; checkpoint saved")
    left=[(u,suspicious(u)) for u in units if suspicious(u)]
    (ws/"bruns_quality_pending.json").write_text(json.dumps(
        [{"id":u["id"],"source":u["source"],"translation":u.get("translation",""),"reasons":r} for u,r in left],
        ensure_ascii=False,indent=2),encoding="utf-8")
    print("Quality remaining:",len(left)); print("Session cost: ¥%.4f"%session)
    print("STATUS:","QUALITY PASS COMPLETE" if not left else "QUALITY REPAIR PARTIAL")
if __name__=="__main__":main()
