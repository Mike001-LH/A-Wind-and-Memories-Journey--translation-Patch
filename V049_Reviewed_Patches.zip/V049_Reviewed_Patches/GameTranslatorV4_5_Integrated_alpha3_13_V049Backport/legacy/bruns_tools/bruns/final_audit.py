#!/usr/bin/env python3
import argparse,json,re
from pathlib import Path

HIRA=re.compile(r'[\u3040-\u309f]+')
KATA=re.compile(r'[\u30a0-\u30ffー]+')
TOK=re.compile(r'\$[A-Z]|#[A-Za-z]+|&R[A-Z]')
# Common isolated names/titles can remain; this audit does not auto-repair them.
ALLOW_KATA={"ハレイス","ミニオン","リロイ","バルダム","ホムンクルス"}

def vis(s): return TOK.sub("",s or "")
def exact_bad(u):
    return bool(vis(u.get("source","")).strip()) and vis(u.get("translation","")).strip()==vis(u.get("source","")).strip()

def mixed_reasons(u):
    s=vis(u.get("source","")); t=vis(u.get("translation",""))
    if not t.strip() or exact_bad(u): return []
    r=[]
    # multi-character hiragana is strong evidence of Japanese prose residue
    hrs=HIRA.findall(t)
    badh=[x for x in hrs if len(x)>=2 and x not in {"さん","くん"}]
    if badh: r.append("hiragana:"+",".join(badh[:4]))
    # surviving long Japanese source fragment
    best=""
    for n in range(min(18,len(s)),7,-1):
        for i in range(len(s)-n+1):
            f=s[i:i+n]
            if f in t and (HIRA.search(f) or KATA.search(f)):
                # do not flag a fragment that is essentially just an allowed proper name
                if any(name in f and len(f)<=len(name)+2 for name in ALLOW_KATA): continue
                best=f; break
        if best: break
    if best: r.append("source_fragment:"+best)
    return r

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("workspace")
    a=ap.parse_args(); ws=Path(a.workspace)
    cp=ws/"bruns_alpha9_checkpoint.json"
    data=json.loads(cp.read_text(encoding="utf-8")); units=data["units"]
    certain=[u for u in units if exact_bad(u)]
    mixed=[(u,mixed_reasons(u)) for u in units if mixed_reasons(u)]
    (ws/"bruns_final120.json").write_text(json.dumps(
        [{"id":u["id"],"kind":u.get("kind"),"speaker":u.get("speaker"),"source":u["source"]} for u in certain],
        ensure_ascii=False,indent=2),encoding="utf-8")
    (ws/"bruns_mixed_audit.json").write_text(json.dumps(
        [{"id":u["id"],"kind":u.get("kind"),"speaker":u.get("speaker"),"source":u["source"],
          "translation":u.get("translation",""),"reasons":r} for u,r in mixed],
        ensure_ascii=False,indent=2),encoding="utf-8")
    print("Units:",len(units))
    print("Certain bad remaining:",len(certain))
    print("Mixed/partial suspects:",len(mixed))
    print("Certain file:",ws/"bruns_final120.json")
    print("Mixed audit:",ws/"bruns_mixed_audit.json")
    print("STATUS: FINAL AUDIT COMPLETE — NO API CALLS")
if __name__=="__main__": main()
