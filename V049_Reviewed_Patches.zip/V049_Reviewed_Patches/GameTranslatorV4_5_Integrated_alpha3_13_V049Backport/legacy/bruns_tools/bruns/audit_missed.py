#!/usr/bin/env python3
import argparse,re,json,unicodedata
from pathlib import Path
from codec import decode

# Broad audit: every quoted A3 string, then identify the containing command/form.
Q=re.compile(rb'"((?:[^"\\]|\\.)*)"')
JP=re.compile(r'[\u3040-\u30ff\u3400-\u9fff\uff01-\uff60]')
SEND=re.compile(rb'\(a3:send-string\s+"((?:[^"\\]|\\.)*)"\s+([0-9]+)\)')
MENU=re.compile(rb'\(a3:call-user-func\s+4100\s+[^\r\n()]*?"((?:[^"\\]|\\.)*)"\s*\)')

def meaningful(s):
    return bool(JP.search(s))

def line_bounds(raw,pos):
    a=raw.rfind(b'\n',0,pos)+1; b=raw.find(b'\n',pos)
    if b<0:b=len(raw)
    return a,b

def main():
    ap=argparse.ArgumentParser();ap.add_argument("game");ap.add_argument("--output",required=True)
    a=ap.parse_args(); game=Path(a.game); out=Path(a.output);out.mkdir(parents=True,exist_ok=True)
    rows=[]; perfile={}
    for f in sorted((game/"scene").glob("*.bso")):
        raw=decode(f.read_bytes())
        known=set()
        for rx in (SEND,MENU):
            for m in rx.finditer(raw):
                # quoted group is group 1 for both
                known.add((m.start(1),m.end(1)))
        total=miss=0
        for m in Q.finditer(raw):
            try:s=m.group(1).decode("cp932")
            except:continue
            if not meaningful(s):continue
            total+=1
            isknown=(m.start(1),m.end(1)) in known
            if not isknown:
                miss+=1
                la,lb=line_bounds(raw,m.start())
                try:line=raw[la:lb].decode("cp932")
                except:line=repr(raw[la:lb])
                rows.append({"file":str(f.relative_to(game)),"offset":m.start(1),
                             "text":s,"line":line})
        perfile[str(f.relative_to(game))]={"all_japanese_quoted":total,"outside_current_extractor":miss}
    report={"summary":{"files":len(perfile),
                       "all_japanese_quoted":sum(x["all_japanese_quoted"] for x in perfile.values()),
                       "outside_current_extractor":len(rows)},
            "per_file":perfile,"missed":rows}
    (out/"bruns_alpha10_1_missed_strings.json").write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding="utf-8")
    print("BSO files:",len(perfile))
    print("All Japanese-bearing quoted strings:",report["summary"]["all_japanese_quoted"])
    print("Outside current extractor:",len(rows))
    print("Files with missed strings:")
    for f,x in perfile.items():
        if x["outside_current_extractor"]:print(" ",f,":",x["outside_current_extractor"],"/",x["all_japanese_quoted"])
    print("\nFirst 40 missed:")
    for r in rows[:40]:
        print(f'[{r["file"]} @ {r["offset"]}] {r["text"][:100]!r}')
        print("  FORM:",r["line"][:180])
    print("\nReport:",out/"bruns_alpha10_1_missed_strings.json")
    print("STATUS: AUDIT COMPLETE — NO FILES MODIFIED")
if __name__=="__main__":main()
