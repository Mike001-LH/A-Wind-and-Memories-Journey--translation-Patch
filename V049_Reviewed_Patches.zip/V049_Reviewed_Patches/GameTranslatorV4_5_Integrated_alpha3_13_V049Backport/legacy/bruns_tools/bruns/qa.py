#!/usr/bin/env python3
import argparse,json,re
from pathlib import Path
TOK=re.compile(r'\$[A-Z]|#[A-Za-z]+|&R[A-Z]')
def main():
 p=argparse.ArgumentParser();p.add_argument("workspace");a=p.parse_args();w=Path(a.workspace)
 f=w/"bruns_units_translated.json"
 u=json.loads(f.read_text(encoding="utf-8"))
 bad=[]; pending=0
 for x in u:
  t=x.get("translation","")
  if not t: pending+=1;continue
  try:t.encode("cp932")
  except UnicodeEncodeError as e:bad.append((x["id"],"cp932",str(e)))
  if '"' in t:bad.append((x["id"],"quote",t))
 print("Units:",len(u));print("Pending:",pending);print("QA errors:",len(bad))
 for z in bad[:50]:print(*z)
 print("STATUS:","QA PASSED" if not bad and not pending else "QA NOT READY")
if __name__=="__main__":main()
