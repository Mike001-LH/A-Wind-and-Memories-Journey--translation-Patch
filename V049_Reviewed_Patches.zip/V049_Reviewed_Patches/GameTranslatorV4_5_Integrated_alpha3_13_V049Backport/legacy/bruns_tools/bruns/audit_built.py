#!/usr/bin/env python3
import argparse,re,json
from pathlib import Path
from codec import decode

Q=re.compile(rb'"((?:[^"\\]|\\.)*)"')
JP_KANA=re.compile(r'[\u3040-\u30ff]')
DIALOG=re.compile(r'^\$N\$([A-Z])【([^】]+)】\$K#R(.*)\$N$',re.S)

def norm(s):
    m=DIALOG.match(s)
    return m.group(3) if m else s

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("original")
    ap.add_argument("built")
    ap.add_argument("workspace")
    ap.add_argument("--output",required=True)
    a=ap.parse_args()
    orig=Path(a.original); built=Path(a.built); ws=Path(a.workspace); out=Path(a.output)
    out.mkdir(parents=True,exist_ok=True)
    units=json.loads((ws/"bruns_units_translated.json").read_text(encoding="utf-8"))
    srcmap={}
    for u in units:
        srcmap.setdefault(u["source"],[]).append(u)
    rows=[]; stats={}
    for bf in sorted((built/"scene").glob("*.bso")):
        rel=str(bf.relative_to(built))
        raw=decode(bf.read_bytes())
        oraw=decode((orig/rel).read_bytes()) if (orig/rel).exists() else b""
        residual=[]
        for m in Q.finditer(raw):
            try:s=m.group(1).decode("cp932")
            except:continue
            # kana is the strongest signal of untranslated Japanese; don't flag Chinese/Japanese shared kanji alone
            if not JP_KANA.search(s): continue
            visible=norm(s)
            matches=srcmap.get(visible,[])
            residual.append({
              "offset":m.start(1),"raw":s,"visible":visible,
              "in_translation_units":bool(matches),
              "unit_ids":[x["id"] for x in matches[:10]],
              "translations":[x.get("translation","") for x in matches[:3]]
            })
        stats[rel]=len(residual)
        rows += [{"file":rel,**r} for r in residual]
    known=sum(r["in_translation_units"] for r in rows)
    unknown=len(rows)-known
    report={"summary":{"residual_japanese_strings":len(rows),
                       "already_in_translation_units":known,
                       "not_in_translation_units":unknown},
            "per_file":stats,"residual":rows}
    rp=out/"bruns_alpha10_2_residual_report.json"
    rp.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding="utf-8")
    print("Built game:",built)
    print("Residual Japanese strings:",len(rows))
    print("Residuals already present in translation units:",known)
    print("Residuals NOT present in translation units:",unknown)
    print("Files with residual Japanese:")
    for f,n in stats.items():
        if n: print(" ",f,":",n)
    print("\nFirst 60 residuals:")
    for r in rows[:60]:
        print(f'[{r["file"]} @ {r["offset"]}] {r["visible"][:100]!r}')
        print("  in units:",r["in_translation_units"],"ids:",r["unit_ids"][:3])
        if r["translations"]: print("  expected translation:",r["translations"][0][:100])
    print("\nReport:",rp)
    print("STATUS: RESIDUAL AUDIT COMPLETE — NO FILES MODIFIED")
if __name__=="__main__":main()
