#!/usr/bin/env python3
import argparse,json,os,re,time,urllib.request,urllib.error
from pathlib import Path
from decimal import Decimal

API="https://api.deepseek.com/chat/completions"
MODEL="deepseek-flash"
# Current official CNY prices, 2026-09-16.
PRICE={
 "offpeak":{"hit":Decimal("0.02"),"miss":Decimal("1"),"out":Decimal("4")},
 "peak":{"hit":Decimal("0.04"),"miss":Decimal("2"),"out":Decimal("8")},
}
TOKEN_RE=re.compile(r'\$[A-Z]|#[A-Za-z]+|&R[A-Z]')

def load_env():
    p=Path.home()/"Documents/local-llm-translator/.env"
    if p.exists():
        for line in p.read_text(encoding="utf-8").splitlines():
            if "=" in line and not line.lstrip().startswith("#"):
                k,v=line.split("=",1); os.environ.setdefault(k.strip(),v.strip().strip("'\""))

def cp932_ok(s):
    try:s.encode("cp932"); return True,[]
    except UnicodeEncodeError:
        bad=sorted(set(ch for ch in s if _bad(ch)))
        return False,bad
def _bad(ch):
    try:ch.encode("cp932"); return False
    except UnicodeEncodeError:return True

def cost_cny(usage,band):
    p=PRICE[band]
    hit=Decimal(str(usage.get("prompt_cache_hit_tokens",0)))
    miss=Decimal(str(usage.get("prompt_cache_miss_tokens",
                 max(0,usage.get("prompt_tokens",0)-int(hit)))))
    out=Decimal(str(usage.get("completion_tokens",0)))
    return (hit*p["hit"]+miss*p["miss"]+out*p["out"])/Decimal(1_000_000)

def api_request(items, mode="translate", timeout=180):
    constraint = """
ABSOLUTE CHARACTER RULE:
Every returned text MUST pass Python `text.encode("cp932")`.
This is NOT ordinary Traditional Chinese. It is Japanese-CP932-compatible Chinese.
Never use known unsafe glyphs such as:
你 她 啊 吧 呢 嗎 啟 檔 說 值 跑 咕 嚕 嘎 丟 狀 嗯 喔 盯 懂 啦 睞 辦 咦.
Never use em dash —.
Use CP932-safe Japanese kanji/kana or alternative Chinese wording instead.
Examples: 你→君/貴方, 她→彼女, 啟→起動, 檔→記錄/文件, 值→數値, 狀→状態.
"""
    if mode=="repair":
        task="""Repair the candidate translations. Preserve their meaning, but replace EVERY
character listed in bad_chars with CP932-encodable wording. Do not merely repeat the candidate.
Output JSON only: {"translations":[{"id":"...","text":"..."}]}."""
    else:
        task="""Translate Japanese visual-novel text into natural readable CP932-compatible
日繁 Chinese. Preserve meaning, tone, names and adult register.
Output JSON only: {"translations":[{"id":"...","text":"..."}]}."""
    payload={"model":MODEL,"messages":[
        {"role":"system","content":task+constraint},
        {"role":"user","content":json.dumps(items,ensure_ascii=False)}],
        "response_format":{"type":"json_object"},"temperature":0.2,
        "thinking":{"type":"disabled"}}
    req=urllib.request.Request(API,data=json.dumps(payload,ensure_ascii=False).encode(),
        headers={"Authorization":"Bearer "+os.environ["DEEPSEEK_API_KEY"],
                 "Content-Type":"application/json"})
    with urllib.request.urlopen(req,timeout=timeout) as r:
        return json.loads(r.read().decode())

def parsed_map(obj):
    content=obj["choices"][0]["message"].get("content","").strip()
    # tolerate accidental markdown fences / surrounding prose
    if content.startswith("```"):
        content=re.sub(r'^```(?:json)?\s*|\s*```$',"",content,flags=re.I|re.S).strip()
    try:
        data=json.loads(content)
    except json.JSONDecodeError:
        lo=content.find("{"); hi=content.rfind("}")
        if lo>=0 and hi>lo:
            data=json.loads(content[lo:hi+1])
        else:
            raise
    rows=data.get("translations")
    if not isinstance(rows,list):
        raise ValueError("API JSON missing translations list")
    out={}
    for x in rows:
        if isinstance(x,dict) and isinstance(x.get("id"),str) and isinstance(x.get("text"),str):
            out[x["id"]]=x["text"]
    if not out:
        raise ValueError("API returned no usable translations")
    return out

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("workspace")
    ap.add_argument("--estimate-only",action="store_true")
    ap.add_argument("--translate",action="store_true")
    ap.add_argument("--batch-size",type=int,default=25)
    ap.add_argument("--max-units",type=int)
    ap.add_argument("--max-cost-rmb",type=float,default=5.0)
    ap.add_argument("--price-band",choices=["offpeak","peak"],default="peak",
                    help="Cost guard price band. Default peak = conservative.")
    a=ap.parse_args(); ws=Path(a.workspace)
    units=json.loads((ws/"bruns_units.json").read_text(encoding="utf-8"))
    pending=[u for u in units if not u.get("translation")]
    if a.max_units: pending=pending[:a.max_units]
    chars=sum(len(u["source"]) for u in pending)
    # intentionally conservative preflight range; actual cost uses API usage exactly
    approx_in=int(chars*1.8 + len(pending)*35 + 1800*((len(pending)+a.batch_size-1)//a.batch_size))
    approx_out=int(chars*1.5 + len(pending)*10)
    worst=(Decimal(approx_in)*PRICE["peak"]["miss"]+Decimal(approx_out)*PRICE["peak"]["out"])/Decimal(1_000_000)
    print("Model:",MODEL); print("Pending units:",len(pending)); print("Source chars:",chars)
    print("Batch size:",a.batch_size); print("Estimated conservative peak cost: ¥%.4f"%worst)
    print("Hard session cost limit: ¥%.2f"%a.max_cost_rmb)
    if a.estimate_only or not a.translate:
        print("STATUS: ESTIMATE ONLY — NO API CALLS"); return
    load_env()
    if not os.getenv("DEEPSEEK_API_KEY"): raise SystemExit("DEEPSEEK_API_KEY not found")
    cp=ws/"bruns_alpha9_checkpoint.json"
    state={"spent_rmb":0.0,"usage":{"prompt":0,"completion":0,"hit":0,"miss":0},"completed":0}
    if cp.exists():
        old=json.loads(cp.read_text(encoding="utf-8")); state.update(old.get("state",{}))
        saved={x["id"]:x["translation"] for x in old.get("units",[]) if x.get("translation")}
        for u in units:
            if u["id"] in saved:u["translation"]=saved[u["id"]]
        pending=[u for u in units if not u.get("translation")]
        if a.max_units:pending=pending[:a.max_units]
        print("Checkpoint resumed. Remaining selected:",len(pending))
    session=Decimal("0")
    for bi in range(0,len(pending),a.batch_size):
        batch=pending[bi:bi+a.batch_size]
        # conservative guard before every call
        if session >= Decimal(str(a.max_cost_rmb)):
            print("COST GUARD: limit reached before next request."); break
        inp=[{"id":u["id"],"kind":u["kind"],"speaker":u.get("speaker"),"source":u["source"]} for u in batch]
        got=None
        for attempt in range(3):
            try:
                obj=api_request(inp, mode='translate')
                got=parsed_map(obj)
                break
            except Exception as e:
                print(f"TRANSLATE RETRY {attempt+1}/3:",repr(e))
                if attempt==2:
                    print("BATCH SKIPPED: malformed/failed API response; units remain pending")
                    obj=None
                    break
                time.sleep(2*(attempt+1))
        if obj is None or got is None:
            continue
        usage=obj.get("usage",{})
        c=cost_cny(usage,a.price_band); session+=c
        accepted=0; rejected=[]
        for u in batch:
            t=got.get(u["id"],"")
            ok,bad=cp932_ok(t)
            if not t or not ok:
                print("CP932 REJECT",u["id"],"bad=",bad,"source=",u["source"][:40])
                rejected.append((u,t,bad)); continue
            u["translation"]=t; accepted+=1

        repair_cost=Decimal("0")
        if rejected and session < Decimal(str(a.max_cost_rmb)):
            repair_items=[{"id":u["id"],"source":u["source"],"candidate":t,
                           "bad_chars":bad,"speaker":u.get("speaker"),"kind":u["kind"]}
                          for u,t,bad in rejected]
            # one repair request for only failed units
            try:
                robj=api_request(repair_items, mode="repair")
                ru=robj.get("usage",{}); repair_cost=cost_cny(ru,a.price_band)
                session+=repair_cost
                rgot=parsed_map(robj)
                for u,old_t,old_bad in rejected:
                    t=rgot.get(u["id"],"")
                    ok,bad=cp932_ok(t)
                    if t and ok:
                        u["translation"]=t; accepted+=1
                        print("CP932 REPAIR OK",u["id"])
                    else:
                        print("CP932 REPAIR FAILED",u["id"],"bad=",bad)
                state["usage"]["prompt"]+=ru.get("prompt_tokens",0)
                state["usage"]["completion"]+=ru.get("completion_tokens",0)
                state["usage"]["hit"]+=ru.get("prompt_cache_hit_tokens",0)
                state["usage"]["miss"]+=ru.get("prompt_cache_miss_tokens",0)
            except Exception as e:
                print("REPAIR REQUEST FAILED:",repr(e))
        state["spent_rmb"]=float(Decimal(str(state.get("spent_rmb",0)))+c+repair_cost)
        state["completed"]=sum(bool(u.get("translation")) for u in units)
        state["usage"]["prompt"]+=usage.get("prompt_tokens",0)
        state["usage"]["completion"]+=usage.get("completion_tokens",0)
        state["usage"]["hit"]+=usage.get("prompt_cache_hit_tokens",0)
        state["usage"]["miss"]+=usage.get("prompt_cache_miss_tokens",0)
        cp.write_text(json.dumps({"state":state,"units":units},ensure_ascii=False,indent=2),encoding="utf-8")
        (ws/"bruns_units_translated.json").write_text(json.dumps(units,ensure_ascii=False,indent=2),encoding="utf-8")
        print(f"Batch {bi//a.batch_size+1}: accepted {accepted}/{len(batch)}; translate ¥{c:.4f}; repair ¥{repair_cost:.4f}; session ¥{session:.4f}; checkpoint saved")
        if session >= Decimal(str(a.max_cost_rmb)):
            print("COST GUARD: session limit reached."); break
    print("Translated total:",sum(bool(u.get("translation")) for u in units),"/",len(units))
    print("This session charged estimate from API usage: ¥%.4f"%session)
    print("STATUS: TRANSLATION PASS COMPLETE")
if __name__=="__main__":main()
