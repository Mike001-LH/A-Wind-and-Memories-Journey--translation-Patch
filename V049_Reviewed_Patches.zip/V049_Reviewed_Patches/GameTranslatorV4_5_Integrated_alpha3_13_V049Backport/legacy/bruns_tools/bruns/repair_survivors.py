#!/usr/bin/env python3
import argparse,json,os,time
from pathlib import Path
from decimal import Decimal
from translate import load_env,api_request,parsed_map,cp932_ok,cost_cny

# Local semantic/orthographic cleanup for common CP932 rejects.
SUB={
"这":"這","药":"藥","觉":"覺","调":"調","边":"邊","摄":"攝","针":"針","锐":"銳",
"产":"産","仅":"僅","处":"處","强":"強","为":"為","说":"說","值":"値","状":"状態",
"后":"後","发":"發","开":"開","关":"關","门":"門","体":"體","应":"應","动":"動",
"实":"實","验":"驗","术":"術","师":"師","学":"學","气":"氣","长":"長","见":"見",
"间":"間","过":"過","还":"還","对":"對","话":"話","声":"聲","脸":"臉","变":"變",
"无":"無","会":"會","来":"來","进":"進","给":"給","当":"當","从":"從","现":"現",
"经":"經","样":"樣","种":"種","让":"讓","别":"別","该":"該","难":"難",
# observed survivor characters: use CP932-friendly semantic alternatives
"喂":"喂", "佈":"布", "份":"部分", "吧":"呀", "哎":"唉", "噗":"噗",
"嚕":"嚕", "嘻":"呵", "扭":"轉", "步":"歩", "絕":"絶", "髒":"汚",
}
def exact_bad(u):
    s=(u.get("source") or "").strip(); t=(u.get("translation") or "").strip()
    return bool(s) and s==t

def localize(t):
    out="".join(SUB.get(c,c) for c in t)
    return out

def save(ws,cp,data,units):
    data["units"]=units
    cp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding="utf-8")
    (ws/"bruns_units_translated.json").write_text(json.dumps(units,ensure_ascii=False,indent=2),encoding="utf-8")

def call_one(u, extra):
    item={"id":u["id"],"source":u["source"],"speaker":u.get("speaker"),"kind":u.get("kind"),
          "instruction":extra}
    last=None
    for n in range(3):
        try:
            obj=api_request([item],mode="repair"); return obj,parsed_map(obj).get(u["id"],"")
        except Exception as e:
            last=e; print("RETRY",n+1,u["id"],repr(e)); time.sleep(n+1)
    return None,""

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("workspace"); ap.add_argument("--audit-only",action="store_true")
    ap.add_argument("--repair",action="store_true"); ap.add_argument("--max-cost-rmb",type=float,default=.5)
    ap.add_argument("--price-band",choices=["offpeak","peak"],default="peak")
    a=ap.parse_args(); ws=Path(a.workspace); cp=ws/"bruns_alpha9_checkpoint.json"
    data=json.loads(cp.read_text(encoding="utf-8")); units=data["units"]; state=data["state"]
    targets=[u for u in units if exact_bad(u)]
    print("Survivors:",len(targets))
    if a.audit_only or not a.repair:
        print("STATUS: SURVIVOR AUDIT ONLY — NO API CALLS"); return
    load_env()
    if not os.getenv("DEEPSEEK_API_KEY"): raise SystemExit("DEEPSEEK_API_KEY not found")
    session=Decimal("0"); fixed=0
    for i,u in enumerate(targets,1):
        if session>=Decimal(str(a.max_cost_rmb)):
            print("COST GUARD reached"); break
        prompt="""Translate this ONE Japanese game string completely into natural 日繁 Chinese.
The previous attempts copied the Japanese source, so copying any Japanese sentence is invalid.
Keep isolated proper names if necessary. Preserve engine control tokens exactly.
Prefer CP932-compatible wording. Return only this item's translation in the required JSON format."""
        obj,t=call_one(u,prompt)
        if obj:
            c=cost_cny(obj.get("usage",{}),a.price_band); session+=c
        t=localize((t or "").strip())
        ok,bad=cp932_ok(t)
        if t and t!=u["source"].strip() and ok:
            u["translation"]=t; fixed+=1
            print(f"[{i}/{len(targets)}] OK {u['id']}")
        else:
            # one final focused paraphrase only if budget remains
            if session<Decimal(str(a.max_cost_rmb)) and t and t!=u["source"].strip():
                p=f"""Translate the Japanese source fully, then paraphrase the Chinese so Python cp932 can encode it.
Current candidate: {t}
Unsupported characters: {bad}
Do not use those characters. Do not copy Japanese prose. Return only the translation JSON."""
                obj2,t2=call_one(u,p)
                if obj2: session+=cost_cny(obj2.get("usage",{}),a.price_band)
                t2=localize((t2 or "").strip()); ok2,bad2=cp932_ok(t2)
                if t2 and t2!=u["source"].strip() and ok2:
                    u["translation"]=t2; fixed+=1; print(f"[{i}/{len(targets)}] OK2 {u['id']}")
                else: print(f"[{i}/{len(targets)}] STILL BAD {u['id']} bad={bad2}")
            else: print(f"[{i}/{len(targets)}] STILL BAD {u['id']} bad={bad}")
        # Persist after every paid survivor.
        save(ws,cp,data,units)
    left=[u for u in units if exact_bad(u)]
    (ws/"bruns_survivors.json").write_text(json.dumps(
        [{"id":u["id"],"source":u["source"]} for u in left],ensure_ascii=False,indent=2),encoding="utf-8")
    print("Fixed this run:",fixed); print("Certain bad remaining:",len(left))
    print("Session cost: ¥%.4f"%session)
    print("STATUS:","SURVIVORS CLEARED" if not left else "SURVIVOR REPAIR PARTIAL")
if __name__=="__main__": main()
