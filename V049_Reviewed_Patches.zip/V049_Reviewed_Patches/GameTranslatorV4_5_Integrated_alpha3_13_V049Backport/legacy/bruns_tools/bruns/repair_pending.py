#!/usr/bin/env python3
import argparse,json,os,time
from pathlib import Path
from decimal import Decimal
from translate import load_env, api_request, parsed_map, cp932_ok, cost_cny

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("workspace")
    ap.add_argument("--max-cost-rmb",type=float,default=.50)
    ap.add_argument("--price-band",choices=["offpeak","peak"],default="peak")
    ap.add_argument("--max-rounds",type=int,default=3)
    a=ap.parse_args()
    ws=Path(a.workspace); cp=ws/"bruns_alpha9_checkpoint.json"
    if not cp.exists(): raise SystemExit("checkpoint not found")
    data=json.loads(cp.read_text(encoding="utf-8"))
    units=data["units"]; state=data["state"]
    pending=[u for u in units if not u.get("translation")]
    print("Pending stubborn units:",len(pending))
    load_env()
    if not os.getenv("DEEPSEEK_API_KEY"): raise SystemExit("DEEPSEEK_API_KEY not found")
    session=Decimal("0")
    for ri in range(a.max_rounds):
        pending=[u for u in units if not u.get("translation")]
        if not pending: break
        print(f"Repair round {ri+1}: {len(pending)} pending")
        for n,u in enumerate(pending,1):
            if session >= Decimal(str(a.max_cost_rmb)):
                print("COST GUARD reached"); break
            item={"id":u["id"],"source":u["source"],"speaker":u.get("speaker"),
                  "kind":u["kind"],
                  "candidate":"", "bad_chars":[],
                  "instruction":"Translate/rewrite this single line using ONLY Python cp932-encodable characters. Prefer Japanese-safe kanji/kana. Avoid ordinary Chinese-only glyphs."}
            obj=None; got=None
            for attempt in range(3):
                try:
                    obj=api_request([item],mode="repair"); got=parsed_map(obj); break
                except Exception as e:
                    print("retry",u["id"],attempt+1,repr(e)); time.sleep(attempt+1)
            if not obj or not got: continue
            usage=obj.get("usage",{}); c=cost_cny(usage,a.price_band); session+=c
            t=got.get(u["id"],""); ok,bad=cp932_ok(t)
            if t and ok:
                u["translation"]=t; print(f"[{n}/{len(pending)}] OK",u["id"])
            else:
                print(f"[{n}/{len(pending)}] FAIL",u["id"],bad)
            state["spent_rmb"]=float(Decimal(str(state.get("spent_rmb",0)))+c)
            state["completed"]=sum(bool(x.get("translation")) for x in units)
            for k,v in [("prompt",usage.get("prompt_tokens",0)),("completion",usage.get("completion_tokens",0)),
                        ("hit",usage.get("prompt_cache_hit_tokens",0)),("miss",usage.get("prompt_cache_miss_tokens",0))]:
                state["usage"][k]+=v
            cp.write_text(json.dumps({"state":state,"units":units},ensure_ascii=False,indent=2),encoding="utf-8")
            (ws/"bruns_units_translated.json").write_text(json.dumps(units,ensure_ascii=False,indent=2),encoding="utf-8")
        if session >= Decimal(str(a.max_cost_rmb)): break
    left=[u for u in units if not u.get("translation")]
    (ws/"bruns_pending.json").write_text(json.dumps(left,ensure_ascii=False,indent=2),encoding="utf-8")
    print("Translated total:",len(units)-len(left),"/",len(units))
    print("Pending:",len(left))
    print("Session cost: ¥%.4f"%session)
    print("Pending file:",ws/"bruns_pending.json")
    print("STATUS:","ALL TRANSLATED" if not left else "PENDING EXPORTED")
if __name__=="__main__": main()
