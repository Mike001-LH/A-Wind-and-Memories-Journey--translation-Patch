#!/usr/bin/env python3
import argparse,json,os,time
from pathlib import Path
from decimal import Decimal
from translate import load_env,api_request,parsed_map,cp932_ok,cost_cny

def exact_bad(u):
    s=(u.get("source") or "").strip()
    t=(u.get("translation") or "").strip()
    return bool(s) and t==s

def save(ws,cp,data,units):
    data["units"]=units
    cp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding="utf-8")
    (ws/"bruns_units_translated.json").write_text(json.dumps(units,ensure_ascii=False,indent=2),encoding="utf-8")

def call(items,mode):
    last=None
    for n in range(3):
        try:
            obj=api_request(items,mode=mode); return obj,parsed_map(obj)
        except Exception as e:
            last=e; print("API/JSON RETRY",n+1,repr(e)); time.sleep(n+1)
    print("API FAILED:",repr(last)); return None,{}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("workspace"); ap.add_argument("--audit-only",action="store_true")
    ap.add_argument("--repair",action="store_true"); ap.add_argument("--batch-size",type=int,default=15)
    ap.add_argument("--max-cost-rmb",type=float,default=.5)
    ap.add_argument("--price-band",choices=["offpeak","peak"],default="peak")
    a=ap.parse_args(); ws=Path(a.workspace); cp=ws/"bruns_alpha9_checkpoint.json"
    data=json.loads(cp.read_text(encoding="utf-8")); units=data["units"]; state=data["state"]
    targets=[u for u in units if exact_bad(u)]
    print("Units:",len(units)); print("Certain bad (translation == source):",len(targets))
    if a.audit_only or not a.repair:
        print("STATUS: CERTAIN-BAD AUDIT ONLY — NO API CALLS"); return
    load_env()
    if not os.getenv("DEEPSEEK_API_KEY"): raise SystemExit("DEEPSEEK_API_KEY not found")
    session=Decimal("0")
    for bi in range(0,len(targets),a.batch_size):
        if session>=Decimal(str(a.max_cost_rmb)):
            print("COST GUARD reached"); break
        batch=targets[bi:bi+a.batch_size]
        items=[{"id":u["id"],"source":u["source"],"speaker":u.get("speaker"),"kind":u.get("kind"),
          "instruction":"Translate ALL Japanese prose into natural 日繁 Chinese. The previous output copied the source and is invalid. Isolated proper names may remain katakana. Preserve engine tokens. Output must be Python cp932 encodable; avoid unsupported colloquial Chinese characters."} for u in batch]
        obj,got=call(items,"repair")
        if not obj: continue
        usage=obj.get("usage",{}); c=cost_cny(usage,a.price_band); session+=c
        accepted=0; need=[]
        for u in batch:
            t=got.get(u["id"],"")
            ok,bad=cp932_ok(t)
            if t.strip() and t.strip()!=u["source"].strip() and ok:
                u["translation"]=t; accepted+=1
            elif t.strip() and t.strip()!=u["source"].strip():
                need.append((u,t,bad))
        # Automatic second pass ONLY for otherwise-translated CP932 failures.
        if need and session<Decimal(str(a.max_cost_rmb)):
            ritems=[{"id":u["id"],"source":u["source"],"candidate":t,"bad_chars":bad,
              "instruction":"Rewrite candidate with exactly the same meaning into CP932-encodable 日繁 Chinese. Replace every listed unsupported character. Do not revert to Japanese. Preserve proper names and engine tokens."}
              for u,t,bad in need]
            robj,rgot=call(ritems,"repair")
            if robj:
                ru=robj.get("usage",{}); rc=cost_cny(ru,a.price_band); session+=rc
                for u,t,bad in need:
                    rt=rgot.get(u["id"],""); ok2,bad2=cp932_ok(rt)
                    if rt.strip() and rt.strip()!=u["source"].strip() and ok2:
                        u["translation"]=rt; accepted+=1
                    else: print("FINAL REJECT",u["id"],"bad=",bad2)
        # usage accounting for successful first request; state cost is conservative tracked successful calls.
        state["spent_rmb"]=float(Decimal(str(state.get("spent_rmb",0)))+c)
        save(ws,cp,data,units)
        left=sum(exact_bad(x) for x in units)
        print(f"Batch {bi//a.batch_size+1}: accepted {accepted}/{len(batch)}; remaining {left}; session ¥{session:.4f}; checkpoint saved")
    left=[u for u in units if exact_bad(u)]
    (ws/"bruns_certain_bad_pending.json").write_text(json.dumps(
        [{"id":u["id"],"source":u["source"],"translation":u.get("translation","")} for u in left],
        ensure_ascii=False,indent=2),encoding="utf-8")
    print("Certain bad remaining:",len(left)); print("Session cost: ¥%.4f"%session)
    print("STATUS:","CERTAIN-BAD PASS COMPLETE" if not left else "CERTAIN-BAD REPAIR PARTIAL")
if __name__=="__main__":main()
