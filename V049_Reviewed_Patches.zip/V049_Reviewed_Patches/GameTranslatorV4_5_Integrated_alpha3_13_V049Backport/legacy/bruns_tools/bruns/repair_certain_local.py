#!/usr/bin/env python3
import argparse,json,os,time,re
from pathlib import Path
from decimal import Decimal
from translate import load_env,api_request,parsed_map,cp932_ok,cost_cny

# Deterministic local conversions learned from Bruns CP932 failures.
# Only substitutions that preserve meaning/register reasonably are placed here.
MAP = {
"这":"這","药":"藥","觉":"覺","调":"調","边":"邊","摄":"攝","针":"針","锐":"銳",
"产":"産","仅":"僅","处":"處","强":"強","为":"為","说":"說","档":"檔","值":"値",
"状":"状態","丢":"丟","吗":"嗎","她":"彼女","你":"君","们":"們","后":"後","里":"裡",
"发":"發","开":"開","关":"關","门":"門","体":"體","应":"應","动":"動","实":"實",
"验":"驗","术":"術","师":"師","学":"學","气":"氣","长":"長","见":"見","间":"間",
"过":"過","还":"還","对":"對","话":"話","声":"聲","脸":"臉","变":"變","无":"無",
"会":"會","来":"來","进":"進","给":"給","当":"當","从":"從","现":"現","经":"經",
"样":"樣","么":"麼","种":"種","让":"讓","别":"別","该":"該","难":"難","么":"麼",
}
# CP932-safe semantic fallbacks for common Chinese particles/characters whose traditional form
# may still not exist in CP932.
FALLBACK = {
"吧":"吧", "啊":"呀", "嗯":"唔", "喔":"哦", "啦":"啦",
}

def exact_bad(u):
    s=(u.get("source") or "").strip(); t=(u.get("translation") or "").strip()
    return bool(s) and s==t

def local_cp932(text):
    out="".join(MAP.get(ch,ch) for ch in text)
    # Iteratively replace known unsupported colloquial chars only when they are actually bad.
    ok,bad=cp932_ok(out)
    if not ok:
        out="".join(FALLBACK.get(ch,ch) if ch in bad else ch for ch in out)
    return out

def save(ws,cp,data,units):
    data["units"]=units
    cp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding="utf-8")
    (ws/"bruns_units_translated.json").write_text(json.dumps(units,ensure_ascii=False,indent=2),encoding="utf-8")

def call(items,mode):
    last=None
    for n in range(3):
        try:
            obj=api_request(items,mode=mode); return obj,parsed_map(obj)
        except Exception as e:
            last=e; print("API/JSON RETRY",n+1,repr(e)); time.sleep(n+1)
    print("API FAILED:",repr(last)); return None,{}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("workspace"); ap.add_argument("--audit-only",action="store_true")
    ap.add_argument("--repair",action="store_true"); ap.add_argument("--batch-size",type=int,default=15)
    ap.add_argument("--max-cost-rmb",type=float,default=.5)
    ap.add_argument("--price-band",choices=["offpeak","peak"],default="peak")
    a=ap.parse_args(); ws=Path(a.workspace); cp=ws/"bruns_alpha9_checkpoint.json"
    data=json.loads(cp.read_text(encoding="utf-8")); units=data["units"]; state=data["state"]
    targets=[u for u in units if exact_bad(u)]
    print("Units:",len(units)); print("Certain bad:",len(targets))
    if a.audit_only or not a.repair:
        print("STATUS: ALPHA10.6 AUDIT ONLY — NO API CALLS"); return
    load_env()
    if not os.getenv("DEEPSEEK_API_KEY"): raise SystemExit("DEEPSEEK_API_KEY not found")
    session=Decimal("0"); local_saved=0; llm_repairs=0
    for bi in range(0,len(targets),a.batch_size):
        if session>=Decimal(str(a.max_cost_rmb)):
            print("COST GUARD reached"); break
        batch=targets[bi:bi+a.batch_size]
        items=[{"id":u["id"],"source":u["source"],"speaker":u.get("speaker"),"kind":u.get("kind"),
          "instruction":"Fully translate Japanese prose into natural Chinese. Preserve engine tokens and isolated proper names. Do not copy source. Prefer Japanese-compatible traditional kanji where natural."} for u in batch]
        obj,got=call(items,"repair")
        if not obj: continue
        usage=obj.get("usage",{}); c=cost_cny(usage,a.price_band); session+=c
        accepted=0; need=[]
        for u in batch:
            t=got.get(u["id"],"").strip()
            if not t or t==u["source"].strip(): continue
            lt=local_cp932(t); ok,bad=cp932_ok(lt)
            if ok:
                u["translation"]=lt; accepted+=1
                if lt!=t: local_saved+=1
            else:
                need.append((u,lt,bad))
        # LLM is last resort only after deterministic local conversion.
        if need and session<Decimal(str(a.max_cost_rmb)):
            ritems=[{"id":u["id"],"source":u["source"],"candidate":t,"bad_chars":bad,
              "instruction":"Paraphrase only enough to eliminate every unsupported character while preserving meaning. Output must encode in Python cp932. Do not revert to Japanese."}
              for u,t,bad in need]
            robj,rgot=call(ritems,"repair")
            if robj:
                ru=robj.get("usage",{}); rc=cost_cny(ru,a.price_band); session+=rc; llm_repairs+=len(need)
                for u,t,bad in need:
                    rt=local_cp932(rgot.get(u["id"],"").strip())
                    ok2,bad2=cp932_ok(rt)
                    if rt and rt!=u["source"].strip() and ok2:
                        u["translation"]=rt; accepted+=1
                    else: print("FINAL REJECT",u["id"],"bad=",bad2)
        state["spent_rmb"]=float(Decimal(str(state.get("spent_rmb",0)))+c)
        save(ws,cp,data,units)
        left=sum(exact_bad(x) for x in units)
        print(f"Batch {bi//a.batch_size+1}: accepted {accepted}/{len(batch)}; remaining {left}; session ¥{session:.4f}; local-fixed {local_saved}; checkpoint saved")
    left=[u for u in units if exact_bad(u)]
    (ws/"bruns_certain_bad_pending.json").write_text(json.dumps(
        [{"id":u["id"],"source":u["source"]} for u in left],ensure_ascii=False,indent=2),encoding="utf-8")
    print("Certain bad remaining:",len(left)); print("Local CP932 fixes:",local_saved)
    print("LLM last-resort repair items:",llm_repairs); print("Session cost: ¥%.4f"%session)
    print("STATUS:","CERTAIN-BAD PASS COMPLETE" if not left else "CERTAIN-BAD REPAIR PARTIAL")
if __name__=="__main__": main()
