Bruns alpha10.4 fixes alpha10.3's over-strict kana gate.
- Allows isolated katakana names (ハレイス / ミニオン / リロイ etc.).
- Flags Japanese grammar, multi-hiragana runs, identical source, and surviving Japanese source fragments.
- Prompt explicitly asks for CP932-safe paraphrases and allows proper names.
First run --audit-only. No API.
Do NOT resume alpha10.3.
