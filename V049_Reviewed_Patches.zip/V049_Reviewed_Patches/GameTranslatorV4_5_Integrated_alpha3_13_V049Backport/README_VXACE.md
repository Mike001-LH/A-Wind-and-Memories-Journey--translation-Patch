# VX Ace 4.4.0 alpha2 — 中文 → 英文／日文与跨版本译文迁移

本版在 4.3.0 基础上新增 VX Ace 命令行适配。原有 Ren'Py、Bruns、MV/MZ、KAG 流程保留。VX Ace 当前需要已经展开的 Data/*.rvdata2，不自动解包 rgss3a；本次 V0.49 提供的就是展开数据。需要 Python 3.10+，不需要安装 Ruby。本版没有执行游戏脚本，也没有使用付费翻译 API 实测。

这是第一版数据读写/迁移测试工具，尚未在用户的 Windows 游戏运行时完成验证。先测试免费菜单补丁，再做小样本或全量翻译。

## 实际覆盖

处理数据库名称/说明/战斗消息、普通事件对话/滚动文本/选项及分支标签、改名、地图显示名、系统词汇，以及标准 Vocab 脚本中的简单字符串常量。

保留事件命令和控制符、资源文件名、地图 Table 数据及 Ruby 对象引用。混合 CRLF/CR/LF 在提取时规范化，在写回时恢复原来每个分隔符。采用被动 Marshal 4.8 解析，只替换指定字符串的长度和字节，不重新执行或重新序列化游戏对象。

不自动翻译所有 Ruby 脚本、备注/插件配置、事件脚本、图片、编辑器内部名称。共享字符串对象和非 UTF-8 编码标记条目保守排除。这些候选写入 ace_excluded_review.json，不能把其条数视为实际可见漏译条数。此游戏有大量自定义脚本，后续需按界面实测逐项增加适配。

## 分析：不调用 API

在本工具目录打开终端。Mac 使用 python3，Windows 可改为 py。

```bash
python3 unified.py "/路径/原版游戏" --source-language Chinese --target-language en --analyze
python3 unified.py "/路径/原版游戏" --source-language Chinese --target-language ja --analyze
```

--target-language 支持 en、ja、zh。本轮新增的目标语言/迁移参数只开放给 VX Ace，旧引擎保持原流程。VX Ace GUI 尚未接入目标语言选择，使用命令行。

默认分别创建 游戏名_GT_Work_en 和 游戏名_GT_Work_ja。即使手动指定 --workdir，也会核对语言，拒绝混用 checkpoint。

## 试译与全量

已有 .env 可在自己的电脑复制到本工具目录（不要发给别人），或使用 DEEPSEEK_API_KEY 环境变量。没有密钥时分析、迁移和离线出包仍可使用。

```bash
python3 unified.py "/路径/原版游戏" --source-language Chinese --target-language en --sample 10 --batch-size 5 --repair-rounds 2 --max-cost-rmb 5
python3 unified.py "/路径/原版游戏" --source-language Chinese --target-language ja --sample 10 --batch-size 5 --repair-rounds 2 --max-cost-rmb 5
```

默认样本优先标题菜单，再普通菜单、Vocab、剧情。需要专门验证剧情窗口时加 `--vx-sample-profile story`；只验证菜单可用 `--vx-sample-profile menu`。去掉 --sample 是全量。--allow-partial 可在有剩余条目时保留原文并出包。每批保存 checkpoint，Ctrl+C 后可重跑继续；不要同时运行同一语言同一工作目录的两个任务。

费用使用原工具的估算逻辑，本次没有核验供应商实时价格；--max-cost-rmb 是每次运行的估算预算，一批返回后才知道用量，可能略超。新版没有默认改动已有 API 模型或供应商配置。

英文/日文输出分别为 游戏名_English_Patch、游戏名_Japanese_Patch；样本附加 _Sample10。已有输出目录时请加 --output 指向新目录，工具不会删除旧成果。

--vx-font 仅作为显式兼容选项：设置系统已安装的 Windows 字体名，通过 Main 开始前设置 Font.default_name。**如果游戏原字体已经覆盖目标语言，不要使用此参数。** 本项目 V0.49 的萝莉体已确认覆盖日文，因此日文测试默认保留原字体与原字号，不再强制 Meiryo。该参数不附带字体，也不替换自定义窗口里的硬编码字体。

英文较长时保留原行数并记录 layout_review，不保证自动排版完美。日文允许汉字/假名，不能简单用“出现汉字”判断中文残留；完全未变的汉字文本会列为人工复核提示。

## 免费离线出包与人工修订

```bash
python3 unified.py "/路径/原版游戏" --source-language Chinese --target-language en --build-only --allow-partial --output "/路径/英文修订补丁"
```

人工修订使用 JSON，可从 ace_units.json 查 id/source：

```json
{
  "target_language": "en",
  "entries": [
    {"id": "这里填实际单元ID", "source": "开始游戏", "translation": "New Game"}
  ]
}
```

增加 --import-translations "/路径/reviewed.json" 导入。导入会核对 ID、原文、目标语言和控制符，并标记 reviewed。有效人工译文不会被普通续译覆盖。明确导入新的人工修订可覆盖旧人工译文。

## 跨版本迁移

保留旧版游戏及其对应工作目录，尤其 translation_memory.json。新版游戏用新的目录/工作区：

```bash
python3 unified.py "/路径/新版原游戏" --source-language Chinese --target-language en --reuse-from "/路径/旧版游戏_GT_Work_en" --migrate-only
```

此命令不调用 API，生成新 checkpoint、translation_memory.json 和 ace_migration_report.json。

- 原文相同：结合类别、位置、上下文匹配；唯一旧条目可迁移到新位置。
- 相同原文有不同译文且不能消除歧义：不自动写入，列出冲突候选。
- 原文小改且原位置相同：旧译文仅作为下一次翻译的参考，不标记完成。
- 原文已改且位置也改：可能列为新增，而不会猜测复用。
- 英文旧记忆不能导入日文工作区；源语言名称也须一致。
- 人工审订记录会跟随已确认的精确匹配迁移；同级人工译文冲突仍需复核。
- “旧条目未复用”不一定表示被删除；可能是冲突或已修改，旧记忆不删除。

查看报告后，使用同一新版路径与目标语言正常翻译，会复用已迁移条目，只请求剩余内容。新版补丁始终基于新版源数据构建，绝不拿旧版数据文件覆盖新版逻辑。

目前 --reuse-from 接受本适配器的 gt-memory-1，不直接把旧汉化游戏或早期 MTool/Excel 文件当成翻译记忆。旧游戏与译文成品对齐导入、其他引擎的迁移入口尚需后续适配。仅有一个真实版本，本轮版本迁移使用合成版本差异测试，未声称完成两份真实版本的迁移验证。

## 补丁安装

1. 关闭游戏，分别复制一份对应版本的原游戏用于英文、日文测试。
2. 在游戏副本里备份原 Data 文件夹。
3. 将补丁 Data 里的文件合并到副本 Data，替换同名文件。不要删除或整体移走副本的 Data。
4. 从新游戏检查标题、剧情、选项、战斗、存读档、字形和排版。旧存档可能保留旧角色名字。
5. 卸载时恢复原 Data；不要把两种语言补丁叠在同一个游戏副本里。

## 此次 V0.49 检查

- 381 个 .rvdata2 数据文件成功被动解析；另有字库 .dat 和两个 JPG 不参与文本翻译。
- 提取 26,848 个单元、577,213 个源字符，其中 50 个为标准 Vocab 常量。
- 共 9,739 个排除/待复核候选：事件注释 4,157、自定义脚本行 3,072、备注配置 1,830、共享字符串 656、事件脚本 24。大量是程序或注释，不应整体送去翻译。
- 28 项自动测试通过：包含旧引擎测试，以及 VX Ace Unicode 写回、对象链接/循环、分支标签、控制符、续译、离线出包、语言隔离和迁移冲突。
- 菜单测试补丁是离线人工填入的中性 UI 文本，无 API 费用；完整正文尚未翻译，也未宣称全部界面覆盖。

Marshal 格式参考：https://docs.ruby-lang.org/en/master/language/marshal_rdoc.html


## alpha3：同一版本内的重复文本复用

默认启用，仅 VX Ace；不改变原文提取、ID、字体和字号。原文、语言、类型、文件、已提取的前三段上下文、控制符和旧版本参考必须一致。无上下文的事件文本进一步限定事件/页面位置。匹配的是提取出的上下文，不保证涵盖所有剧情语义；请抽查实际效果。

同组只请求一个代表，通过 QA 后填入所选范围的其余位置，并在同一次批次保存中写入检查点。存在不同合格译文的组不合并；已有合格译文不覆盖。样本模式不会扩散到未选中的条目。复用位置记录来源 ID，但不会自动标记为人工审校。

旧检查点和跨版本记忆保持兼容。首次用新版续跑会自动备份原检查点。先停止旧任务，等待终端返回提示符，再运行新版；同一语言工作目录不要同时运行两份进程。英文和日文可以分别运行。继续使用相同原版路径和原工作目录，输出选新目录（例如 Full_v2），不要删除 GT_Work 文件夹。

--analyze 会免费输出复用预估；ace_reuse_report.json 记录代表条目数、潜在少请求条目数、本次实际复用数及冲突组数。重试日志中的分母是代表条目数；完成报告仍统计所有文本位置。预算、失败和控制符校验仍生效。--no-vx-reuse 可关闭复用（不会撤销此前已有的译文）。

V0.49 的节省统计为静态规划，不是 API 价格或运行时间承诺；已有进度会改变实际请求数。


## alpha3.1 校验修复与离线恢复

普通百分比不再误识别为printf占位符。提取元数据保留原始格式以兼容旧检查点；新请求使用修正后的保护标记。`python3 -m vxace.recover GAME --target-language en --output NEW_OUTPUT --allow-partial` 会使用已保存候选恢复和重建，不实例化API提供者。`--repair-newlines` 可选恢复缺失换行，逐条通过QA后采用，细节保存在ace_offline_recovery_report.json。裸字母控制码与英文连接时插入空格以符合原游戏RGSS解析；不修改方括号参数或自定义长控制码。恢复前备份检查点，保留合格译文和人工审校结果。


## alpha3.2 角色名及变量语序

离线恢复支持将被误写为真实换行的角色名代码还原；限定原文中的索引、大小写和出现次数，歧义保留。英文变量语序改变时，只在同一物理行的格式码序列不变且全部控制符计数一致时接纳V/N/P替换码的重排。换行修复可清理多余空白末行，仍需实机检查。保持旧提取元数据和检查点指纹。
