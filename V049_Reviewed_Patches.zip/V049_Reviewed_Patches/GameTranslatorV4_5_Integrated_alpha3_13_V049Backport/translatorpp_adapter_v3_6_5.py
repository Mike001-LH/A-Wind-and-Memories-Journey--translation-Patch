"""Compatibility entry point for existing V3.6.5 commands."""
from translatorpp_adapter import *
if __name__ == '__main__':
    raise SystemExit(main())
