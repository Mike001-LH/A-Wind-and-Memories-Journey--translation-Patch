"""DXA version 8 reader and structural-preserving offline rebuilder."""
from dataclasses import dataclass
import hashlib
from pathlib import Path, PurePosixPath
import os
import shutil
import struct
import tempfile
from .codec import crypt,key_bytes,huffman_decode,huffman_encode,lz_decode,lz_encode,LIMIT

NONE=(1<<64)-1
HEADER=struct.Struct('<HHIQQQQIIB15s')

@dataclass
class Entry:
    path:str
    record:int
    offset:int
    size:int
    lz:int
    huffman:int
    suffix:bytes

class Archive:
    def __init__(self,path,key=b''):
        self.path=Path(path).resolve();self.key=key
        self.length=self.path.stat().st_size
        with self.path.open('rb') as f:
            raw=f.read(64)
            if len(raw)!=64:raise ValueError('Truncated DXA header')
            h=list(HEADER.unpack(raw));self.header=h
            magic,version,size,base,index,files,dirs,cp,flags,hkb,_=h
            if magic!=0x5844 or version!=8:raise ValueError('Only DXA version 8 is supported')
            if flags&~3 or not 64<=base<=index<self.length or not 0<files<dirs<size<=LIMIT:
                raise ValueError('Unsupported or invalid DXA8 header')
            if cp not in (932,65001):raise ValueError('Unsupported DXA filename encoding')
            if self.length-index>LIMIT:raise ValueError('DXA index exceeds limit')
            f.seek(index);packed=f.read()
        self.master=None if flags&1 else key_bytes(key)
        packed=crypt(packed,self.master)
        self.index=packed[:size] if flags&2 else lz_decode(huffman_decode(packed))
        if len(self.index)!=size:raise ValueError('DXA index length mismatch / wrong key')
        self.entries={};self._visited=set();self._names=set()
        self._walk(0,(),())

    def _walk(self,at,path,parents):
        _,_,_,base,index,files,dirs,cp,_,_,_=self.header
        if at in self._visited or len(path)>64 or at<0 or dirs+at+32>len(self.index):raise ValueError('Invalid DXA directory tree')
        self._visited.add(at)
        _,_,count,start=struct.unpack_from('<4Q',self.index,dirs+at)
        if count>100000 or files+start+count*72>dirs:raise ValueError('DXA file table bounds violation')
        for i in range(count):
            position=files+start+i*72
            na,attr,_,_,_,address,size,lz,huff=struct.unpack_from('<9Q',self.index,position)
            if na+4>files:raise ValueError('Invalid DXA name offset')
            width=struct.unpack_from('<H',self.index,na)[0]*4
            if not width or na+4+width*2>files:raise ValueError('Invalid DXA name length')
            upper=self.index[na+4:na+4+width].split(b'\0',1)[0]
            name=self.index[na+4+width:na+4+width*2].split(b'\0',1)[0].decode('cp932' if cp==932 else 'utf-8')
            if not name or name in ('.','..') or any(c in name for c in '/\\:\0'):raise ValueError('Unsafe DXA name')
            relative='/'.join((*path,name));fold=relative.casefold()
            if fold in self._names:raise ValueError('Duplicate DXA path')
            self._names.add(fold)
            if attr&16:self._walk(address,(*path,name),(upper,*parents));continue
            entry=Entry(relative,position,base+address,size,lz,huff,upper+b''.join(parents))
            if entry.offset<base or entry.offset+self.stored_size(entry)>index:raise ValueError('DXA data outside body')
            self.entries[relative]=entry

    def stored_size(self,entry):
        size=entry.lz if entry.lz!=NONE else entry.size
        if entry.huffman!=NONE:
            chunk=self.header[9]*1024
            if self.header[9]!=255 and size>2*chunk:
                if not chunk:raise ValueError('Invalid partial Huffman block')
                return entry.huffman+size-2*chunk
            return entry.huffman
        return size

    def _key(self,entry):return None if self.master is None else key_bytes(self.key+entry.suffix)

    def read(self,path):
        entry=self.entries[path];length=self.stored_size(entry)
        if entry.size>LIMIT or length>LIMIT:raise ValueError('DXA entry exceeds in-memory extraction limit')
        with self.path.open('rb') as f:f.seek(entry.offset);packed=f.read(length)
        if len(packed)!=length:raise ValueError('Truncated DXA entry')
        packed=crypt(packed,self._key(entry),entry.size)
        if entry.huffman!=NONE:
            head=huffman_decode(packed[:entry.huffman]);size=entry.lz if entry.lz!=NONE else entry.size
            chunk=self.header[9]*1024
            if self.header[9]!=255 and size>2*chunk:
                if len(head)!=2*chunk:raise ValueError('Partial Huffman output mismatch')
                packed=head[:chunk]+packed[entry.huffman:]+head[chunk:]
            else:packed=head
        if entry.lz!=NONE:packed=lz_decode(packed)
        if len(packed)!=entry.size:raise ValueError('DXA decoded size mismatch')
        return packed

    def encode(self,entry,data):
        if len(data)>LIMIT:raise ValueError('Replacement exceeds limit')
        packed=lz_encode(data) if entry.lz!=NONE else data
        lz=len(packed) if entry.lz!=NONE else NONE;huff=NONE
        if entry.huffman!=NONE:
            chunk=self.header[9]*1024
            if self.header[9]!=255 and len(packed)>2*chunk:
                head=huffman_encode(packed[:chunk]+packed[-chunk:]);packed=head+packed[chunk:-chunk];huff=len(head)
            else:packed=huffman_encode(packed);huff=len(packed)
        return crypt(packed,self._key(entry),len(data)),lz,huff

def sha256(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()

def transfer(source,dest,count):
    while count:
        chunk=source.read(min(count,1024*1024))
        if not chunk:raise ValueError('Unexpected end of archive')
        dest.write(chunk);count-=len(chunk)

def same_range(a,offset_a,b,offset_b,count):
    a.seek(offset_a);b.seek(offset_b)
    while count:
        size=min(count,1024*1024);x=a.read(size);y=b.read(size)
        if len(x)!=size or x!=y:return False
        count-=size
    return True

def rebuild(archive,output,replacements=None):
    replacements=replacements or {};output=Path(output).resolve()
    if output.exists():raise ValueError('Output exists; choose a new output path')
    if set(replacements)-set(archive.entries):raise ValueError('Cannot add unrecognized paths to DXA')
    output.parent.mkdir(parents=True,exist_ok=True)
    fd,name=tempfile.mkstemp(prefix='.dxa-build-',dir=output.parent);os.close(fd);temp=Path(name)
    index=bytearray(archive.index);header=list(archive.header);header[3]=64
    try:
        with temp.open('wb') as out,archive.path.open('rb') as src:
            out.write(b'\0'*64)
            for entry in sorted(archive.entries.values(),key=lambda e:e.offset):
                out.write(b'\0'*((-out.tell())%4));address=out.tell()-64
                if entry.path in replacements:
                    data=replacements[entry.path];packed,lz,huff=archive.encode(entry,data);size=len(data);out.write(packed)
                else:
                    src.seek(entry.offset);transfer(src,out,archive.stored_size(entry));size,lz,huff=entry.size,entry.lz,entry.huffman
                struct.pack_into('<4Q',index,entry.record+40,address,size,lz,huff)
            out.write(b'\0'*((-out.tell())%4));header[4]=out.tell()
            packed=bytes(index) if header[8]&2 else huffman_encode(lz_encode(index))
            out.write(crypt(packed,archive.master));out.seek(0);out.write(HEADER.pack(*header))
        check=Archive(temp,archive.key)
        if check.entries.keys()!=archive.entries.keys():raise ValueError('Rebuilt DXA path mismatch')
        unchanged=0
        with archive.path.open('rb') as src,temp.open('rb') as dst:
            for path,entry in archive.entries.items():
                new=check.entries[path]
                if path in replacements:
                    if check.read(path)!=replacements[path]:raise ValueError('Rebuilt replacement mismatch: '+path)
                else:
                    if (entry.size,entry.lz,entry.huffman)!=(new.size,new.lz,new.huffman) or not same_range(src,entry.offset,dst,new.offset,archive.stored_size(entry)):
                        raise ValueError('Unmodified resource changed: '+path)
                    unchanged+=1
        # Exclusive publish: never silently replace a file created while building.
        with output.open('xb') as dst,temp.open('rb') as src:shutil.copyfileobj(src,dst,1024*1024)
        return {'resources':len(check.entries),'unchanged_resources_byte_verified':unchanged,
                'changed_paths':list(replacements),'output_sha256':sha256(output),
                'source_sha256':sha256(archive.path),'size':output.stat().st_size,
                'windows_runtime_verified':False}
    finally:temp.unlink(missing_ok=True)
