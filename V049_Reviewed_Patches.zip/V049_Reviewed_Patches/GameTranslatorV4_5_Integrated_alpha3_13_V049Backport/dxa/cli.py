"""Witch's Forest 1.01 offline DXA analysis, extraction and diagnostics."""
import argparse
from collections import Counter
import json
from pathlib import Path
import shutil
import tempfile
from .archive import Archive,rebuild,sha256
from .compat import require_compatible, unsupported, MENU_SOURCE, MENU_ZH

ROOT=Path(__file__).resolve().parent
PROFILE=json.loads((ROOT/'witch_forest_101.json').read_text(encoding='utf-8'))

def locate(path):
    path=Path(path).expanduser().resolve()
    if path.is_file():return path
    for candidate in (path/'data/data.dxa',path/'data.dxa'):
        if candidate.is_file():return candidate
    raise ValueError('Cannot find data/data.dxa; provide game folder or original archive')

def open_game(path):
    path=locate(path)
    if path.stat().st_size!=PROFILE['size'] or sha256(path)!=PROFILE['sha256']:
        raise ValueError('This profile requires the unchanged Witch’s Forest 1.01 data.dxa. Restore the original archive first.')
    return Archive(path,bytes.fromhex(PROFILE['archive_key_hex']))

def text_encoding(path,data):
    if data.startswith(b'\xef\xbb\xbf'):return 'utf-8-sig'
    if path in PROFILE['menu_paths']:
        data.decode('utf-8');return 'utf-8'
    try:data.decode('utf-8');return 'utf-8' if any(x>127 for x in data) else 'ascii'
    except UnicodeError:data.decode('cp932');return 'cp932'

def menu_units(archive):
    units=[]
    for path in PROFILE['menu_paths']:
        raw=archive.read(path)
        for line_number,line in enumerate(raw.decode('utf-8').splitlines(keepends=True),1):
            if line.startswith('-----') and not line.startswith('------'):
                source=line[5:].rstrip('\r\n')
                if source.strip():units.append({'id':f'{path}:{line_number}','path':path,'line':line_number,
                    'source':source,'translation':'','encoding':'utf-8'})
    return {'schema':'witch-menu-1','profile':PROFILE['id'],'source_sha256':PROFILE['sha256'],'units':units}

def analyze(path,workdir=None):
    archive=open_game(path);inventory=[];encodings=Counter()
    for path,entry in archive.entries.items():
        row={'path':path,'size':entry.size,'stored_size':archive.stored_size(entry)}
        if path.lower().endswith('.txt'):
            data=archive.read(path)
            try:row['encoding']=text_encoding(path,data)
            except UnicodeError:row['encoding']='unknown'
            encodings[row['encoding']]+=1;row['sha256']=__import__('hashlib').sha256(data).hexdigest()
        inventory.append(row)
    units=menu_units(archive)
    report={'profile':PROFILE['id'],'archive':str(archive.path),'source_sha256':PROFILE['sha256'],
        'resources':len(inventory),'text_files':sum(encodings.values()),'text_encodings':dict(encodings),
        'menu_units':len(units['units']),'status':'experimental; Windows runtime validation pending',
        'exclusions':'Only menu-label writeback implemented; event dialogue/commands/images/fonts are not translated.',
        'files':inventory}
    if workdir:
        work=Path(workdir).expanduser().resolve()
        if work==archive.path.parent or work in archive.path.parents:raise ValueError('Use a separate analysis directory')
        work.mkdir(parents=True,exist_ok=True)
        target=work/'dxa_analysis.json'
        if target.exists() and json.loads(target.read_text())['source_sha256']!=PROFILE['sha256']:raise ValueError('Analysis workspace source mismatch')
        target.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
        target=work/'menu_units.json'
        if not target.exists():target.write_text(json.dumps(units,ensure_ascii=False,indent=2),encoding='utf-8')
    print('DXA8 / Witch’s Forest 1.01 — OFFLINE, NO API CALLS')
    print('Resources:',len(inventory),'TXT files:',sum(encodings.values()),'Menu labels:',len(units['units']))
    print('Text encodings:',dict(encodings))
    if workdir:print('Analysis and editable menu_units.json:',work)
    print('Experimental: full dialogue translation and Windows compatibility are not yet confirmed.')
    return report

def extract(path,output):
    archive=open_game(path);output=Path(output).expanduser().resolve()
    if output.exists():raise ValueError('Extraction directory exists; choose a new directory')
    output.parent.mkdir(parents=True,exist_ok=True)
    staging=Path(tempfile.mkdtemp(prefix='.dxa-extract-',dir=output.parent))
    try:
        manifest={}
        for path in archive.entries:
            if not path.lower().endswith('.txt'):continue
            raw=archive.read(path);target=staging/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
            manifest[path]=__import__('hashlib').sha256(raw).hexdigest()
        (staging/'extraction_report.json').write_text(json.dumps({'profile':PROFILE['id'],'source_sha256':PROFILE['sha256'],'files':manifest},indent=2))
        if output.exists():raise ValueError('Extraction output appeared while working')
        staging.rename(output)
    finally:
        if staging.exists():shutil.rmtree(staging)
    print('Extracted',len(manifest),'TXT files without changing encoding:',output)

def diagnostic_replacements(archive,mode):
    if mode=='repack':return {}
    if mode=='compatible-menu':
        path='data01/wtex_jp.txt'
        lines=archive.read(path).decode('utf-8').splitlines(keepends=True)
        positions=[i for i,line in enumerate(lines) if line.startswith('-----') and not line.startswith('------')][:5]
        if [lines[i][5:].rstrip('\r\n') for i in positions]!=MENU_SOURCE:
            raise ValueError('Title menu structure mismatch')
        for i,label in zip(positions,MENU_ZH):
            require_compatible(label, str(i+1))
            old=lines[i];ending='\r\n' if old.endswith('\r\n') else '\n' if old.endswith('\n') else ''
            lines[i]='-----'+label+ending
        return {path:''.join(lines).encode('utf-8')}

    path='data01/wtex_jp.txt';raw=archive.read(path);lines=raw.splitlines(keepends=True)
    for i,line in enumerate(lines):
        if line.startswith(b'-----') and not line.startswith(b'------'):
            ending=b'\r\n' if line.endswith(b'\r\n') else b'\n' if line.endswith(b'\n') else b''
            old=line[5:len(line)-len(ending) if ending else len(line)]
            label=b'START' if mode=='ascii' else '开始新游戏'.encode('utf-8')
            if len(label)>len(old):raise ValueError('Diagnostic label exceeds original byte length')
            lines[i]=b'-----'+label+b' '*(len(old)-len(label))+ending
            changed=b''.join(lines)
            if len(changed)!=len(raw):raise ValueError('Diagnostic changed text length')
            return {path:changed}
    raise ValueError('Expected menu label was not found')

def save_report(output,report):
    path=Path(output).with_name(Path(output).name+'.report.json')
    with path.open('x',encoding='utf-8') as f:json.dump(report,f,ensure_ascii=False,indent=2)

def diagnose(path,mode,output):
    archive=open_game(path);output=Path(output).expanduser().resolve()
    if output.exists() or output.with_name(output.name+'.report.json').exists():raise ValueError('Output/report exists; choose a new path')
    if mode=='clone':
        output.parent.mkdir(parents=True,exist_ok=True)
        with output.open('xb') as dst,archive.path.open('rb') as src:shutil.copyfileobj(src,dst,1024*1024)
        digest=sha256(output)
        if digest!=PROFILE['sha256']:raise ValueError('Clone hash mismatch')
        report={'source_sha256':digest,'output_sha256':digest,'changed_paths':[],'windows_runtime_verified':False}
    else:report=rebuild(archive,output,diagnostic_replacements(archive,mode))
    report['mode']=mode;report['profile']=PROFILE['id']
    if mode=='compatible-menu': report['menu_labels']=MENU_ZH;report['compatibility_gate']='cp932';report['resource_encoding']='utf-8'
    save_report(output,report)
    print('OFFLINE DXA DIAGNOSTIC — NO API CALLS; mode:',mode)
    print('Output:',output)
    print('Unmodified resources verified:',report.get('unchanged_resources_byte_verified',len(archive.entries)))
    print('Changed paths:',report['changed_paths'])
    print('Install only in a game COPY. Runtime result must be checked on Windows.')

def build_menu(path,translations,output,allow_partial=False):
    archive=open_game(path);template=menu_units(archive);doc=json.loads(Path(translations).read_text(encoding='utf-8'))
    if not isinstance(doc,dict) or any(doc.get(k)!=template[k] for k in ('schema','profile','source_sha256')):raise ValueError('Menu translation source/profile mismatch')
    expected={u['id']:u for u in template['units']};received={};changes={};remaining=0
    for row in doc.get('units',[]):
        if not isinstance(row,dict) or row.get('id') not in expected or row['id'] in received:raise ValueError('Unknown/duplicate menu unit')
        original=expected[row['id']]
        if any(row.get(k)!=original[k] for k in ('source','path','line','encoding')):raise ValueError('Menu source or location changed')
        received[row['id']]=row
    if received.keys()!=expected.keys():raise ValueError('Menu unit list incomplete')
    for uid,row in received.items():
        text=row.get('translation','')
        if not isinstance(text,str):raise ValueError('Menu translation must be a string')
        if not text.strip():remaining+=1;continue
        if any(c in text for c in '\r\n\0') or text.startswith('-----'):raise ValueError('Menu translation contains structural delimiter')
        require_compatible(text, uid)
        if len(text.encode('utf-8'))>256:raise ValueError('Menu label too long')
        path=row['path'];lines=changes.setdefault(path,archive.read(path).decode('utf-8').splitlines(keepends=True))
        old=lines[row['line']-1];ending='\r\n' if old.endswith('\r\n') else '\n' if old.endswith('\n') else ''
        lines[row['line']-1]='-----'+text+ending
    if remaining and not allow_partial:raise ValueError(f'{remaining} menu units untranslated; use --allow-partial explicitly')
    if not changes:raise ValueError('No translated menu labels')
    output=Path(output).expanduser().resolve()
    if output.with_name(output.name+'.report.json').exists():raise ValueError('Output report exists')
    report=rebuild(archive,output,{p:''.join(lines).encode('utf-8') for p,lines in changes.items()})
    report.update(mode='reviewed_menu_import',untranslated_menu_units=remaining);save_report(output,report)
    print('OFFLINE MENU BUILD — NO API CALLS:',output)
    print('Menu labels still original:',remaining,'; Windows runtime validation required.')

def main():
    p=argparse.ArgumentParser(description=__doc__);sub=p.add_subparsers(dest='command',required=True)
    for command in ('analyze','extract','diagnose','build-menu'):
        q=sub.add_parser(command);q.add_argument('game',help='Original game directory or data.dxa')
        if command=='analyze':q.add_argument('--workdir')
        else:q.add_argument('--output',required=True)
        if command=='diagnose':q.add_argument('--mode',choices=('clone','repack','ascii','chinese','compatible-menu'),default='repack')
        if command=='build-menu':q.add_argument('--translations',required=True);q.add_argument('--allow-partial',action='store_true')
    a=p.parse_args()
    try:
        if a.command=='analyze':analyze(a.game,a.workdir)
        elif a.command=='extract':extract(a.game,a.output)
        elif a.command=='diagnose':diagnose(a.game,a.mode,a.output)
        else:build_menu(a.game,a.translations,a.output,a.allow_partial)
    except (OSError,ValueError,KeyError) as e:p.exit(2,'STOP: '+str(e)+'\n')

if __name__=='__main__':main()
