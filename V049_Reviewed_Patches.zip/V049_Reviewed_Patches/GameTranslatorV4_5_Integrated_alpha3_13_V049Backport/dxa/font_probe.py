"""Offline, version-locked font identity probe. Not a proven text encoding fix."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import struct
import tempfile
from .cli import open_game, diagnostic_replacements
from .archive import rebuild

EXE_SHA='7650218ca1449fd746c44ec40d2110eddb4678400a723ada145e14d754611a53'
FAMILY='WFProbe'

def checksum(data):
    data=bytes(data)+b'\0'*((-len(data))%4)
    return sum(struct.unpack('>'+str(len(data)//4)+'I',data))&0xffffffff

def rename_font(raw):
    if raw[:4]!=b'\0\1\0\0':raise ValueError('Expected TrueType sfnt')
    count=struct.unpack_from('>H',raw,4)[0]
    tables={}
    for i in range(count):
        tag,cs,off,size=struct.unpack_from('>4sIII',raw,12+16*i)
        if off+size>len(raw) or tag in tables:raise ValueError('Invalid font directory')
        tables[tag]=raw[off:off+size]
    original=dict(tables)
    name=tables[b'name'];fmt,n,base=struct.unpack_from('>HHH',name)
    if fmt!=0:raise ValueError('Unsupported name table')
    records=[];strings=bytearray();changed=0
    for i in range(n):
        platform,encoding,language,nid,size,off=struct.unpack_from('>6H',name,6+12*i)
        value=name[base+off:base+off+size]
        if len(value)!=size:raise ValueError('Invalid font name record')
        if nid in (1,3,4,6,16,18,21):
            if platform in (0,3):value=FAMILY.encode('utf-16be')
            elif platform==1:value=FAMILY.encode('ascii')
            else:raise ValueError('Unsupported name platform')
            changed+=1
        records.append(struct.pack('>6H',platform,encoding,language,nid,len(value),len(strings)))
        strings.extend(value)
    if not changed:raise ValueError('No font family records')
    tables[b'name']=struct.pack('>HHH',0,n,6+12*n)+b''.join(records)+strings
    head=bytearray(tables[b'head']);head[8:12]=b'\0'*4;tables[b'head']=bytes(head)
    out=bytearray(raw[:12]+b'\0'*(16*count));offsets={}
    for i,(tag,blob) in enumerate(tables.items()):
        out.extend(b'\0'*((-len(out))%4));off=len(out);offsets[tag]=off
        struct.pack_into('>4sIII',out,12+16*i,tag,checksum(blob),off,len(blob));out.extend(blob)
    out.extend(b'\0'*((-len(out))%4))
    struct.pack_into('>I',out,offsets[b'head']+8,(0xb1b0afba-checksum(out))&0xffffffff)
    if checksum(out)!=0xb1b0afba:raise ValueError('Font checksum mismatch')
    for tag,blob in tables.items():
        if tag not in (b'name',b'head') and blob!=original[tag]:raise ValueError('Font glyph data changed')
    return bytes(out)

def patch_exe(raw):
    if hashlib.sha256(raw).hexdigest()!=EXE_SHA:raise ValueError('Unrecognized EXE; use the original Witch’s Forest 1.01 EXE')
    old=b'MS Gothic\0'
    if raw.count(old)!=1:raise ValueError('Unexpected font reference count')
    pos=raw.index(old);new=FAMILY.encode()+b'\0'*(len(old)-len(FAMILY))
    result=raw[:pos]+new+raw[pos+len(old):]
    assert len(result)==len(raw)
    return result,pos

def build(game,output,exe=None):
    game=Path(game).expanduser().resolve();archive=open_game(game)
    candidates=[Path(exe).expanduser().resolve()] if exe else sorted(game.glob('*.exe'))
    matches=[p for p in candidates if p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==EXE_SHA]
    if len(matches)!=1:raise ValueError('Cannot uniquely locate original Witch’s Forest 1.01 EXE; specify --exe PATH')
    source=matches[0];patched,pos=patch_exe(source.read_bytes())
    replacements=diagnostic_replacements(archive,'compatible-menu')
    replacements['MSGOTHIC.TTF']=rename_font(archive.read('MSGOTHIC.TTF'))
    output=Path(output).expanduser().resolve()
    if output.exists():raise ValueError('Output exists; choose a new folder')
    output.parent.mkdir(parents=True,exist_ok=True)
    stage=Path(tempfile.mkdtemp(prefix='.wf-font-probe-',dir=output.parent))
    try:
        report=rebuild(archive,stage/'data/data.dxa',replacements)
        # Original game filename is required, including when --exe points at an uploaded copy.
        target=stage/"Witch's_Forest_1.01.exe";target.write_bytes(patched)
        report.update(exe_source_sha256=EXE_SHA,exe_output_sha256=hashlib.sha256(patched).hexdigest(),
                      exe_font_string_offset=pos,font_family=FAMILY,windows_runtime_verified=False,
                      purpose='Diagnose runtime font selection; no glyph/size changes; not a proven fix')
        (stage/'font_probe_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
        (stage/'INSTALL.txt').write_text('Close the game. Use a complete game COPY. Replace its Witch\'s_Forest_1.01.exe and data/data.dxa with BOTH files from this folder. Keep Japanese system locale and Japanese game mode. Start the copied EXE directly. Restore BOTH original files to undo. This is a diagnostic patch, not a standalone game. No API calls.\n',encoding='utf-8')
        if output.exists():raise ValueError('Output appeared while working')
        stage.rename(output)
    finally:
        if stage.exists():shutil.rmtree(stage)
    print('OFFLINE FONT IDENTITY PROBE — NO API CALLS')
    print('Patch folder:',output)
    print('Install BOTH EXE and data/data.dxa in a full game COPY.')
    print('Original font glyphs and sizes retained; Windows runtime verification required.')

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('game');p.add_argument('--output',required=True);p.add_argument('--exe')
    a=p.parse_args()
    try:build(a.game,a.output,a.exe)
    except (OSError,ValueError,KeyError,struct.error) as e:p.exit(2,'STOP: '+str(e)+'\n')
if __name__=='__main__':main()
