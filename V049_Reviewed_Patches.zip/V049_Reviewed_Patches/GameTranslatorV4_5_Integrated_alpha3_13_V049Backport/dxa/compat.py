"""Conservative CP932 character gate; keep each resource's original encoding."""
def unsupported(text):
    result=[]
    for ch in dict.fromkeys(text):
        try: ch.encode('cp932', errors='strict')
        except UnicodeEncodeError: result.append({'character':ch,'codepoint':f'U+{ord(ch):04X}'})
    return result

def require_compatible(text, location='text'):
    bad=unsupported(text)
    if bad:
        details=', '.join(f"{x['character']} ({x['codepoint']})" for x in bad)
        raise ValueError(f'CP932 incompatible characters at {location}: {details}. Use reviewed compatible wording; characters were NOT deleted or replaced.')

MENU_SOURCE=['はじめから','つづきから','ギャラリー','オプション','ゲーム終了']
MENU_ZH=['開始遊戲','繼續遊戲','回想畫廊','設定','結束遊戲']
