"""Bounded, pure Python codecs for DXA8 (no native module/compiler required)."""
from collections import Counter, defaultdict, deque
import heapq
import struct
import zlib

LIMIT = 64 * 1024 * 1024

def key_bytes(value):
    if len(value)<4:value+=b'DXBDXARC'
    return struct.pack('<I',zlib.crc32(value[::2]))+struct.pack('<I',zlib.crc32(value[1::2]))[:3]

def crypt(data,key,position=0):
    if key is None:return data
    return bytes(v ^ key[(i+position)%7] for i,v in enumerate(data))

class Bits:
    def __init__(self,data=b''):self.data=bytearray(data);self.pos=0
    def read(self,n):
        if n<0 or self.pos+n>len(self.data)*8:raise ValueError('Truncated Huffman header')
        v=0
        for _ in range(n):
            v=(v<<1)|((self.data[self.pos//8]>>(7-self.pos%8))&1);self.pos+=1
        return v
    def write(self,n,v):
        for i in range(n-1,-1,-1):
            if self.pos//8==len(self.data):self.data.append(0)
            self.data[self.pos//8]|=((v>>i)&1)<<(7-self.pos%8);self.pos+=1

def tree(weights):
    heap=[(w,i) for i,w in enumerate(weights)];heapq.heapify(heap)
    nodes=[None]*256
    while len(heap)>1:
        a,x=heapq.heappop(heap);b,y=heapq.heappop(heap)
        i=len(nodes);nodes.append((x,y));heapq.heappush(heap,(a+b,i))
    return nodes

def huffman_decode(data,limit=LIMIT):
    bits=Bits(data)
    size=bits.read(bits.read(6)+1);packed=bits.read(bits.read(6)+1)
    if size>limit:raise ValueError('Huffman output exceeds limit')
    weights=[];last=0
    for i in range(256):
        width=(bits.read(3)+1)*2;minus=bits.read(1);delta=bits.read(width)
        last=delta if i==0 else last-delta if minus else last+delta
        if not 0<=last<=65535:raise ValueError('Invalid Huffman weight')
        weights.append(last)
    start=(bits.pos+7)//8
    if packed>len(data)-start:raise ValueError('Truncated Huffman payload')
    payload=data[start:start+packed];nodes=tree(weights)
    # First nine bits are enough for the frequent symbols in the DXA index.
    lookup=[]
    for v in range(512):
        node=510;n=0
        while node>255 and n<9:node=nodes[node][(v>>n)&1];n+=1
        lookup.append((node,n))
    acc=0;available=0;at=0;out=bytearray()
    while len(out)<size:
        while available<9 and at<len(payload):acc|=payload[at]<<available;available+=8;at+=1
        if available>=9:node,n=lookup[acc&511];acc>>=n;available-=n
        else:node=510
        while node>255:
            if not available:
                if at>=len(payload):raise ValueError('Truncated Huffman symbol')
                acc=payload[at];available=8;at+=1
            node=nodes[node][acc&1];acc>>=1;available-=1
        out.append(node)
    return bytes(out)

def huffman_encode(data):
    counts=Counter(data);weights=[counts[i]*65535//max(1,len(data)) for i in range(256)]
    nodes=tree(weights);codes={}
    def walk(node,code=0,width=0):
        if node<256:codes[node]=(code,width);return
        a,b=nodes[node];walk(a,code,width+1);walk(b,code|(1<<width),width+1)
    walk(510)
    payload=bytearray();acc=0;available=0
    for byte in data:
        code,n=codes[byte];acc|=code<<available;available+=n
        while available>=8:payload.append(acc&255);acc>>=8;available-=8
    if available or not payload:payload.append(acc)
    bits=Bits();n=max(1,len(data).bit_length());bits.write(6,n-1);bits.write(n,len(data))
    # Match the reference encoder's extra leading size bit.
    n=max(1,len(payload).bit_length());bits.write(6,n);bits.write(n+1,len(payload))
    last=0
    for weight in weights:
        delta=weight-last;last=weight;n=max(1,(abs(delta).bit_length()+1)//2)
        bits.write(3,n-1);bits.write(1,int(delta<0));bits.write(n*2,abs(delta))
    return bytes(bits.data)+bytes(payload)

def lz_decode(data,limit=LIMIT):
    if len(data)<9:raise ValueError('Truncated LZ header')
    size,total=struct.unpack_from('<II',data)
    if size>limit or total<9 or total>len(data):raise ValueError('Invalid LZ size')
    marker=data[8];at=9;out=bytearray()
    def read(n):
        nonlocal at
        if at+n>total:raise ValueError('Truncated LZ token')
        value=data[at:at+n];at+=n;return value
    while at<total:
        v=read(1)[0]
        if v!=marker:out.append(v)
        else:
            c=read(1)[0]
            if c==marker:out.append(c)
            else:
                if c>marker:c-=1
                count=c>>3
                if c&4:count|=read(1)[0]<<5
                count+=4;width=(c&3)+1
                if width>3:raise ValueError('Invalid LZ distance width')
                distance=int.from_bytes(read(width),'little')+1
                if distance>len(out) or len(out)+count>size:raise ValueError('Invalid LZ backreference')
                # Repeat copies handle overlap without one Python iteration per byte.
                start=len(out)-distance;chunk=bytes(out[start:start+min(distance,count)])
                out.extend((chunk*((count+len(chunk)-1)//len(chunk)))[:count])
        if len(out)>size:raise ValueError('LZ output exceeds declared size')
    if len(out)!=size:raise ValueError('LZ output size mismatch')
    return bytes(out)

def lz_encode(data):
    data=bytes(data)
    counts=Counter(data);marker=min(range(256),key=lambda i:counts[i]);out=bytearray()
    positions=defaultdict(lambda:deque(maxlen=32));at=0
    while at<len(data):
        signature=data[at:at+4];best=0;distance=0
        if len(signature)==4:
            for start in reversed(positions[signature]):
                d=at-start
                if d>0x1000000:break
                n=4;maximum=min(8195,len(data)-at)
                while n<maximum and data[start+n]==data[at+n]:n+=1
                if n>best:best=n;distance=d
                if n==maximum:break
        if best>=4:
            offset=distance-1;width=max(1,(offset.bit_length()+7)//8)
            count=best-4;c=((count&31)<<3)|(4 if count>=32 else 0)|(width-1)
            out.extend((marker,c+1 if c>=marker else c))
            if count>=32:out.append(count>>5)
            out.extend(offset.to_bytes(width,'little'));take=best
        else:
            value=data[at];out.append(value)
            if value==marker:out.append(value)
            take=1
        for i in range(at,at+take):
            if i+4<=len(data):positions[data[i:i+4]].append(i)
        at+=take
    return struct.pack('<II',len(data),len(out)+9)+bytes([marker])+out
