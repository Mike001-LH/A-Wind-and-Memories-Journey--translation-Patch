# MV/MZ Economy alpha3.5

Official DeepSeek --economy now supports MV and MZ as well as VX Ace.
Short response IDs, compact JSON, shared engine rules once per batch, context references,
and --batch-chars limit. MV/MZ target remains Simplified Chinese.
Existing checkpoints and structural QA are unchanged. JSON failures retain bounded
split retries, per-child persistence, usage accounting and request caps.
No global duplicate reuse is added: distinct context remains distinct.
--economy remains official DeepSeek only; Xianyi uses its existing tested format.
119 offline tests passed. No real API request or runtime game test was made.
A representative 20-row offline payload comparison measures UTF-8 bytes, not tokens;
actual savings depend on text and cache usage. Existing legacy price estimates remain
approximate; use account billing for actual cost. A budget can overshoot by one request.

Stop the previous process before using the same game checkpoint from this version.
Copy the previous version's .env locally if present; never publish the key file.
Suggested starting batch: 20 units / 2000 source characters. All other integrated
engine and file features are retained.
