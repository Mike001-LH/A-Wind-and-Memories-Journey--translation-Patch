# alpha3 变更

- 在 Unified alpha2 基础上新增 `core/completion.py` 多轮检查与补译控制器。
- 新增 Bruns residual/autocomplete：区分阻断问题和提示；保留旧译文；断点保存；无进展/轮数/会话费用停止。
- Bruns writer 去掉游戏特定数量；添加源文本/偏移验证、重叠检查和安全输出；QA 使用残留检查。
- 新增 rpgmaker.mv / pipeline：MV JSON 白名单提取、对话上下文、选项关联、控制符校验、精确路径回写。
- Unified 自动识别 MV；GUI 增加源语言与补译轮数；修复旧进度解析索引错误。
- 保留 Ren'Py 原翻译/提取流程，以及原有模型配置。Bruns API 输出增加 4096 token 上限。
- 测试采用合成样本和模拟模型，不包含用户游戏内容、缓存、历史译文、虚拟环境或密钥。

- alpha3.1：MV GUI/CLI 增加默认 10 条剧情优先试译，单独生成部分汉化副本，可从 checkpoint 续跑。
