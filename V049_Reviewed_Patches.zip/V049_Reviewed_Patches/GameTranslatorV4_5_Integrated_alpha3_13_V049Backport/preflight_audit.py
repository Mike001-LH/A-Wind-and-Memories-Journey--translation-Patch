#!/usr/bin/env python3
"""Offline pre-translation semantic/speaker audit. Never calls an API."""
import argparse, json, re
from collections import Counter, defaultdict
from pathlib import Path

CONTROL_PREFIXES={'layout','style','image','scene','show','hide','play','queue','stop','voice','camera','jump','call','use','key','timer','define','default','window','pause','with','extend','nvl','layeredimage','transform','screen','label','translate','python','init','return'}
SCREEN_WORDS={'text','textbutton','tooltip','style_prefix','text_style','idle','hover','selected_idle','selected_hover','insensitive','action','alternate','focus','default_focus','key','timer','use','has','add','bar','vbar','viewport','vpgrid','grid','hbox','vbox','fixed','frame','window','button','imagebutton','imagemap','hotspot','hotbar','drag','draggroup','mousearea','side','transform','null','input','on','showif','for','if','elif','else','unscrollable','scrollbars','thumb','layer','auto','id'}
IDENT=re.compile(r'^[A-Za-z_][A-Za-z0-9_.:-]*$')
PATHLIKE=re.compile(r'(?i)^[\w./@:+\- ]+\.(?:png|jpe?g|webp|gif|ogg|mp3|wav|flac|mp4|webm|rpyc?|rpymc?|ttf|otf)$')
SUSPICIOUS_ASSIGN=re.compile(r'(?i)\b(?:layout|style|action|screen|label|image|layer|transform|font)\s*[=:]?\s*$')
ASSIGN=re.compile(r'^\s*(?:\$\s*)?(?P<var>[A-Za-z_]\w*)\s*=\s*(?P<rhs>.+?)\s*(?:#.*)?$')
DEFINE_CHAR=re.compile(r'^\s*define\s+(?P<var>[A-Za-z_]\w*)\s*=\s*(?:Character|DynamicCharacter)\s*\(')

def estimate_tokens(text):
    cjk=len(re.findall(r'[\u3040-\u30ff\u3400-\u9fff]',text)); other=max(0,len(text)-cjk)
    return max(1, round(cjk/1.5 + other/4))

def reason(u):
    src=(u.get('source') or '').strip(); meta=u.get('metadata') or {}; kind=meta.get('kind','unknown'); speaker=(u.get('speaker') or '').lower()
    if kind=='dialogue' and speaker in CONTROL_PREFIXES|SCREEN_WORDS: return 'control_or_screen_prefix_as_speaker','block'
    if PATHLIKE.fullmatch(src): return 'resource_path','block'
    if kind=='dialogue' and IDENT.fullmatch(src) and len(src)<80: return 'identifier_like_dialogue','review'
    if SUSPICIOUS_ASSIGN.search(' '.join(u.get('context') or [])[-160:]): return 'control_context','review'
    if len(u.get('protected_tokens') or [])>=8: return 'many_protected_tokens','review'
    return None,None

def scan_workspace(workspace):
    assigned=Counter(); char_defs=set(); examples=defaultdict(list)
    if not workspace: return assigned,char_defs,examples
    w=Path(workspace)
    for p in w.rglob('*.rpy'):
        try: lines=p.read_text(encoding='utf-8-sig').splitlines()
        except UnicodeDecodeError: continue
        for n,line in enumerate(lines,1):
            m=DEFINE_CHAR.match(line)
            if m: char_defs.add(m.group('var'))
            m=ASSIGN.match(line)
            if m:
                v=m.group('var'); assigned[v]+=1
                if len(examples[v])<3: examples[v].append({'file':str(p.relative_to(w)),'line':n,'rhs':m.group('rhs')[:240]})
    return assigned,char_defs,examples

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('units'); ap.add_argument('--report',required=True); ap.add_argument('--workspace'); ap.add_argument('--strict',action='store_true'); a=ap.parse_args()
    data=json.loads(Path(a.units).read_text(encoding='utf-8')); assigned,char_defs,assign_examples=scan_workspace(a.workspace)
    blocked=[]; review=[]; kinds=Counter(); chars=0; input_tokens=0; speakers=Counter()
    for u in data:
        kind=(u.get('metadata') or {}).get('kind','unknown'); kinds[kind]+=1
        if kind=='character_name': chars+=1
        if u.get('speaker'): speakers[u['speaker']]+=1
        r,level=reason(u); item={'id':u.get('id'),'file':u.get('file'),'line':(u.get('metadata') or {}).get('line'),'kind':kind,'source':u.get('source'),'reason':r}
        if level=='block': blocked.append(item); continue
        if level=='review': review.append(item)
        input_tokens+=estimate_tokens(u.get('source') or '')
    false_screen=[]; dynamic=[]; static=[]
    for sp,count in speakers.most_common():
        low=sp.lower()
        row={'speaker':sp,'uses':count}
        if low in SCREEN_WORDS or low in CONTROL_PREFIXES: false_screen.append(row)
        elif sp in assigned and sp not in char_defs:
            row['assignments']=assigned[sp]; row['examples']=assign_examples[sp]; dynamic.append(row)
        else:
            row['character_declared']=sp in char_defs; static.append(row)
    api_units=len(data)-len(blocked); output_tokens=round(input_tokens*.65); est=input_tokens/1e6*1.0+output_tokens/1e6*4.0
    report={'units':len(data),'api_units_after_blocks':api_units,'blocked':blocked,'review':review,'character_name_units':chars,'speaker_variables':speakers.most_common(200),'speaker_classification':{'dynamic_runtime':dynamic,'static_candidates':static,'screen_or_control_false_speakers':false_screen},'by_kind':dict(kinds),'rough_token_estimate':{'input':input_tokens,'output':output_tokens},'rough_offpeak_rmb_upper_estimate':round(est,4),'note':'Offline planning estimate; dynamic speakers are runtime objects and must not be forced into a fixed-name glossary.'}
    Path(a.report).parent.mkdir(parents=True,exist_ok=True); Path(a.report).write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print('Semantic preflight / Speaker Detection 2.1'); print(f'  Units: {len(data)}'); print(f'  Blocked technical/control: {len(blocked)}'); print(f'  Review recommended: {len(review)}'); print(f'  Character-name units: {chars}'); print(f'  Distinct apparent speaker variables: {len(speakers)}'); print(f'    Dynamic runtime speakers: {len(dynamic)}'); print(f'    Static candidates: {len(static)}'); print(f'    Screen/control false speakers: {len(false_screen)}'); print(f'  Estimated API units after blocks: {api_units}'); print(f'  Rough tokens: input {input_tokens}, output {output_tokens}'); print(f'  Rough off-peak upper estimate: ¥{est:.2f}')
    if dynamic: print('  ✓ Dynamic Person-style speakers detected; they will not be treated as fixed character names.')
    if false_screen: print('  ⚠ Screen/control tokens appeared as speakers; parser hardening is recommended. Examples: '+', '.join(x['speaker'] for x in false_screen[:10]))
    print('Report:',Path(a.report).resolve())
    if a.strict and (blocked or review or false_screen): raise SystemExit('STATUS: PREFLIGHT NEEDS REVIEW')
    print('STATUS: PREFLIGHT PASSED' if not blocked else 'STATUS: PREFLIGHT PASSED WITH BLOCKS')
if __name__=='__main__': main()
