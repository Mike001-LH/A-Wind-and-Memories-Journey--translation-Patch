#!/bin/bash
cd "$(dirname "$0")"
command -v python3 >/dev/null || { echo "需要 Python 3"; read; exit 1; }
python3 app.py
