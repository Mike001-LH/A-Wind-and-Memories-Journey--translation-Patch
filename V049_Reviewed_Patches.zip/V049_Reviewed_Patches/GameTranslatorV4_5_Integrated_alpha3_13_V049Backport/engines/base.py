from abc import ABC, abstractmethod
class EngineAdapter(ABC):
    name = "Unknown"
    @abstractmethod
    def detect(self, game_dir): ...
    @abstractmethod
    def analyze(self, game_dir, **kwargs): ...
