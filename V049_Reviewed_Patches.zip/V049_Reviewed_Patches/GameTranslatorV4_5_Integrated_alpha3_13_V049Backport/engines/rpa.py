from __future__ import annotations
import pickle, re, zlib
from dataclasses import dataclass
from pathlib import Path, PurePosixPath

class RPAError(Exception): pass

@dataclass
class RPAMember:
    name: str
    offset: int
    length: int
    prefix: bytes = b""

class RPAArchive:
    """Read-only RPA-2.0 / RPA-3.0 / RPA-3.2 archive reader for analysis."""
    def __init__(self, path: Path):
        self.path = Path(path)
        self.version = ""
        self.key = 0
        self.index_offset = 0
        self.members: list[RPAMember] = []

    def load(self):
        with self.path.open("rb") as f:
            header = f.readline().decode("ascii", "replace").strip()
            if header.startswith("RPA-3.0 "):
                self.version = "3.0"
                parts = header.split()
                self.index_offset = int(parts[1], 16)
                self.key = int(parts[2], 16)
            elif header.startswith("RPA-3.2 "):
                self.version = "3.2"
                parts = header.split()
                self.index_offset = int(parts[1], 16)
                self.key = int(parts[2], 16)
            elif header.startswith("RPA-2.0 "):
                self.version = "2.0"
                self.index_offset = int(header.split()[1], 16)
                self.key = 0
            else:
                raise RPAError(f"Unsupported RPA header: {header[:80]}")
            f.seek(self.index_offset)
            raw = f.read()
        try:
            index = pickle.loads(zlib.decompress(raw), encoding="bytes")
        except TypeError:
            index = pickle.loads(zlib.decompress(raw))
        except Exception as e:
            raise RPAError(f"Unable to decode RPA index: {e}") from e

        members = []
        for raw_name, chunks in index.items():
            name = raw_name.decode("utf-8", "surrogateescape") if isinstance(raw_name, bytes) else str(raw_name)
            for chunk in chunks:
                off, length = int(chunk[0]), int(chunk[1])
                prefix = chunk[2] if len(chunk) >= 3 else b""
                if self.version.startswith("3"):
                    off ^= self.key
                    length ^= self.key
                members.append(RPAMember(name, off, length, prefix or b""))
        self.members = members
        return self

    def safe_script_members(self):
        return [m for m in self.members if m.name.lower().endswith((".rpy", ".rpyc", ".rpym", ".rpymc"))]

    @staticmethod
    def _safe_target(base: Path, name: str) -> Path:
        pp = PurePosixPath(name)
        if pp.is_absolute() or ".." in pp.parts:
            raise RPAError(f"Unsafe archive path: {name}")
        target = (base / Path(*pp.parts)).resolve()
        base_r = base.resolve()
        if target != base_r and base_r not in target.parents:
            raise RPAError(f"Archive path escapes output directory: {name}")
        return target

    def extract_scripts(self, output_dir: Path):
        output_dir.mkdir(parents=True, exist_ok=True)
        written = []
        with self.path.open("rb") as f:
            for m in self.safe_script_members():
                target = self._safe_target(output_dir, m.name)
                target.parent.mkdir(parents=True, exist_ok=True)
                f.seek(m.offset)
                data = m.prefix + f.read(m.length)
                target.write_bytes(data)
                written.append(target)
        return written
