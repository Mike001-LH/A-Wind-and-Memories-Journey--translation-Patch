from __future__ import annotations
import re
from pathlib import Path
from core.models import AnalysisResult, Detection, TranslationUnit
from engines.base import EngineAdapter
from engines.rpa import RPAArchive, RPAError

SAY = re.compile(r'^\s*(?:(?P<speaker>[A-Za-z_]\w*)\s+)?(?P<q>["\'])(?P<text>.*)(?P=q)\s*(?:#.*)?$')
MENU = re.compile(r'^\s*(?P<q>["\'])(?P<text>.*)(?P=q)\s*(?:if\b.*)?\s*:\s*(?:#.*)?$')
TR = re.compile(r'(?P<fn>__?|_)\(\s*(?P<q>["\'])(?P<text>.*?)(?P=q)\s*\)')
PROT = re.compile(r'(\[[^\]\n]+\]|\{[^{}\n]+\})')

# Tokens that can syntactically precede a quoted string but are Ren'Py
# statements/properties, not Character variables. Without this guard a line
# such as `layout "subtitle"` looks like a say statement with speaker=layout.
NON_SAY_PREFIXES = {
    'layout','style','image','scene','show','hide','play','queue','stop','voice',
    'camera','jump','call','use','key','timer','define','default','window','pause',
    'with','extend','nvl','layeredimage','transform','screen','label','translate',
    'python','init','return','text','textbutton','tooltip','style_prefix','text_style',
    'idle','hover','selected_idle','selected_hover','insensitive','action','alternate',
    'focus','default_focus','auto','id','thumb','layer','unscrollable','scrollbars'
}

def is_safe_say_match(sm):
    speaker=(sm.group('speaker') or '').lower()
    return not speaker or speaker not in NON_SAY_PREFIXES

def confidence(n): return "High" if n >= 80 else ("Medium" if n >= 45 else "Low")
def visible(s): return bool(s.strip()) and bool(re.search(r'[A-Za-z\u3040-\u30ff\u3400-\u9fff]', s))

def platforms(root: Path):
    found = []
    if list(root.glob("*.exe")): found.append("Windows")
    if list(root.glob("*.app")) or list(root.parent.glob("*.app")): found.append("macOS")
    if list(root.glob("*.sh")): found.append("Linux")
    return found or ["Unknown desktop"]

class RenPyAdapter(EngineAdapter):
    name = "Ren'Py"

    def detect(self, root):
        game = root / "game"; score = 0; ev = []
        rpy = list(game.rglob("*.rpy")) if game.is_dir() else []
        rpyc = list(game.rglob("*.rpyc")) if game.is_dir() else []
        rpa = (list(root.glob("*.rpa")) + list(game.glob("*.rpa"))) if game.is_dir() else list(root.glob("*.rpa"))
        if game.is_dir(): score += 10; ev.append("game/ directory")
        if rpy: score += 55; ev.append(f"{len(rpy)} .rpy source script(s)")
        if rpyc: score += 35; ev.append(f"{len(rpyc)} .rpyc compiled script(s)")
        if rpa: score += 15; ev.append(f"{len(rpa)} .rpa archive(s)")
        if (root/"renpy").is_dir(): score += 20; ev.append("renpy/ runtime directory")
        score = min(score, 100)
        return Detection(self.name, score, confidence(score), ev, platforms(root))

    def inspect_archives(self, root):
        game = root/"game"
        archives = list(root.glob("*.rpa")) + (list(game.glob("*.rpa")) if game.is_dir() else [])
        reports = []
        for a in archives:
            try:
                r = RPAArchive(a).load()
                scripts = r.safe_script_members()
                reports.append({"path": a, "version": r.version, "members": len(r.members), "scripts": scripts, "error": None})
            except Exception as e:
                reports.append({"path": a, "version": None, "members": 0, "scripts": [], "error": str(e)})
        return reports


    def _extract_rpy(self, root, paths):
        """
        Conservative source extractor. It deliberately prefers false negatives
        over translating Python/internal strings.
        """
        units=[]; skipped=[]; scanned=0
        py_block_indent=None
        init_py_indent=None

        # Character Detection 2.0: common Ren'Py declaration forms, including
        # Character(_("Name")), DynamicCharacter("Name"), and name="Name".
        char_decl = re.compile(
            r'^\s*define\s+(?P<var>[A-Za-z_]\w*)\s*=\s*(?:Character|DynamicCharacter)\(\s*'
            r'(?:_\(\s*)?(?P<q>["\'])(?P<name>.*?)(?P=q)'
        )
        char_decl_kw = re.compile(
            r'^\s*define\s+(?P<var>[A-Za-z_]\w*)\s*=\s*(?:Character|DynamicCharacter)\([^#\n]*?'
            r'\bname\s*=\s*(?:_\(\s*)?(?P<q>["\'])(?P<name>.*?)(?P=q)'
        )
        screen_text = re.compile(
            r'^\s*(?:text|textbutton)\s+(?P<q>["\'])(?P<text>.*?)(?P=q)'
        )
        label_re = re.compile(r'^\s*label\s+([A-Za-z_]\w*)\s*:')
        translate_re = re.compile(r'^\s*translate\s+\S+\s+([A-Za-z_]\w*)\s*:')
        python_start = re.compile(r'^\s*(?:init(?:\s+-?\d+)?\s+)?python\s*:\s*(?:#.*)?$')
        init_python_start = re.compile(r'^\s*init(?:\s+-?\d+)?\s+python\s*:\s*(?:#.*)?$')

        for p in paths:
            rel=p.relative_to(root).as_posix() if root in p.parents else p.as_posix()
            if "/tl/" in f"/{rel}/": skipped.append(rel+" (existing tl/)"); continue
            try: lines=p.read_text(encoding="utf-8-sig").splitlines()
            except UnicodeDecodeError: skipped.append(rel+" (non-UTF-8)"); continue
            scanned+=1; in_menu=False; menu_indent=-1; prev=[]; current_label=None
            py_block_indent=None

            for n,line in enumerate(lines,1):
                s=line.strip()
                indent=len(line)-len(line.lstrip())

                # Leave a Python block once indentation returns to its opener.
                if py_block_indent is not None and s and indent <= py_block_indent:
                    py_block_indent=None
                if python_start.match(line):
                    py_block_indent=indent
                    continue
                in_python = py_block_indent is not None

                lm=label_re.match(line) or translate_re.match(line)
                if lm and not in_python:
                    current_label=lm.group(1)
                    in_menu=False
                    continue

                if not in_python and (s.startswith("menu:") or re.match(r'^menu\s+[^:]+:',s)):
                    in_menu=True; menu_indent=indent; continue
                if in_menu and s and indent<=menu_indent and not s.startswith("#"):
                    in_menu=False

                found=[]
                if not in_python:
                    cm=char_decl.match(line) or char_decl_kw.match(line)
                    if cm and visible(cm.group("name")):
                        found.append(("character_name",None,cm.group("name")))

                    mm=MENU.match(line) if in_menu else None
                    if mm:
                        found.append(("menu",None,mm.group("text")))

                    # Say statements are only accepted as complete Ren'Py
                    # statements, outside Python blocks. Reject doubled-quote
                    # artifacts/docstrings such as ""foo"".
                    sm=SAY.match(line)
                    if sm and not mm and is_safe_say_match(sm):
                        t=sm.group("text")
                        raw=s
                        if not (raw.startswith('""') or raw.startswith("''")):
                            found.append(("dialogue",sm.group("speaker"),t))

                    stm=screen_text.match(line)
                    if stm and visible(stm.group("text")):
                        found.append(("screen_text",None,stm.group("text")))

                    for tm in TR.finditer(line):
                        found.append(("ui_string",None,tm.group("text")))

                seen=set()
                for kind,speaker,text in found:
                    if (kind,speaker,text) in seen or not visible(text): continue
                    seen.add((kind,speaker,text))
                    # Skip obvious resource/path-only strings.
                    low=text.lower().strip()
                    if re.fullmatch(r'[\w./@:+-]+\.(?:png|jpg|jpeg|webp|gif|ogg|mp3|wav|mp4|webm|rpy|rpyc)', low):
                        continue
                    units.append(TranslationUnit(
                        id=f"{rel}::{n}::{kind}", source=text, engine=self.name,
                        file=rel, location=f"line {n}", speaker=speaker,
                        context=prev[-3:],
                        protected_tokens=list(dict.fromkeys(PROT.findall(text))),
                        metadata={"kind":kind,"line":n,"label":current_label,
                                  "risk":"safe" if kind in {"dialogue","menu","character_name"} else "caution"}))
                    prev.append(text)
        return units, skipped, scanned

    def analyze(self, root, extracted_dir=None):
        detection=self.detect(root); game=root/"game"
        direct_rpy=list(game.rglob("*.rpy")) if game.is_dir() else []
        units, skipped, scanned=self._extract_rpy(root,direct_rpy)
        reports=self.inspect_archives(root)
        archived_scripts=sum(len(x["scripts"]) for x in reports)
        archived_rpyc=sum(1 for x in reports for m in x["scripts"] if m.name.lower().endswith((".rpyc",".rpymc")))
        if extracted_dir:
            for rep in reports:
                if rep["error"]: continue
                try:
                    r=RPAArchive(rep["path"]).load()
                    out=Path(extracted_dir)/rep["path"].stem
                    r.extract_scripts(out)
                except Exception as e:
                    skipped.append(f"{rep['path'].name} extraction failed: {e}")
        return AnalysisResult(
            detection, units, scanned, skipped,
            compiled_scripts=len(list(game.rglob("*.rpyc"))) if game.is_dir() else 0,
            archives=len(reports), archive_members=sum(x["members"] for x in reports),
            archived_compiled_scripts=archived_rpyc)
