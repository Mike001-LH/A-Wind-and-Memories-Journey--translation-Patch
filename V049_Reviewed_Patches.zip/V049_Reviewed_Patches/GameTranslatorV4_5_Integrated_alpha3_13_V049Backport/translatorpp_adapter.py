"""Translate Translator++ XLSX projects/files and MTool JSON using local Ollama or DeepSeek API.

V3.6.5 adds a selective repair workflow for finished Translator++ projects. By
default project runs skip ``renpy/common/`` engine-library workbooks, and
``--repair-existing`` retranslates only existing rows that violate the glossary
(or are still untranslated) instead of paying to redo the whole project. An
optional ``--restore-renpy-common-from`` source project can restore those skipped
engine workbooks when repairing a V3.6.4 output. Number QA also normalizes
percent/fraction forms and checks source-number preservation rather than exact
bidirectional equality.

V3.6.4 fixes false-positive number QA for natural Chinese localization (for example
``Chapter 2`` -> ``第二章`` and ``try again`` -> ``再试一次``). Number
comparison now runs only when the source actually contains a recognized number,
and common Chinese number units include chapter/page/level-style counters.

V3.6.3 adds RMB cost reporting, conservative Translator++ technical-field
filtering, and stronger glossary consistency. Exact glossary matches are
resolved locally without an API call, and QA flags translations that omit a
required glossary target term.

V3.6.2 adds DeepSeek V4.1 Flash support: the canonical API model is now
``deepseek-flash``, cost estimation uses the September 10, 2026 V4.1 Flash
pricing, and high-quality review defaults to V4.1 Flash instead of the
retiring V4 Pro alias.

V3.6.1 adds project-level Translator++ deduplication and source-language diagnostics.

V3.6 adds project-level Translator++ support: the input may be a directory containing
any number of .xlsx files in nested folders. The translated output mirrors the original
folder structure while sharing one translation/QA/checkpoint pipeline across all books.
"""
from __future__ import annotations

import argparse
from collections import Counter
from dataclasses import dataclass, replace
from datetime import datetime, timezone, timedelta
import json
import os
from pathlib import Path
import re
import shutil
import sys
import time
from typing import Any, Iterable

OLLAMA_URL = "http://localhost:11434/api/chat"
JA_MODEL = "hf.co/SakuraLLM/Sakura-GalTransl-14B-v3.8:Q4_K_M"
EN_MODEL = "qwen3.5:27b"
REVIEW_MODEL = "qwen3.5:27b"
DEEPSEEK_URL = "https://api.deepseek.com/chat/completions"
DEEPSEEK_MODEL = "deepseek-flash"
# DeepSeek announced that V4 Pro is being phased out and will route to V4.1
# Flash. Keep a separate CLI option for future V4.1 Pro, but default review
# to the canonical V4.1 Flash endpoint today.
DEEPSEEK_REVIEW_MODEL = "deepseek-flash"
# V3.5.4.4: cap hosted-model output so a malformed JSON/repetition event cannot
# run away into tens of thousands of completion tokens. The per-request limit is
# still computed dynamically from the amount of source text.
DEEPSEEK_MAX_OUTPUT_TOKENS = 4096
DEEPSEEK_MIN_OUTPUT_TOKENS = 512
SOURCE_HEADER, TARGET_HEADER = "Original Text", "Best translation"
LB_RE = re.compile(r"⟦LB_(\d{3})⟧")
PH_RE = re.compile(r"\{[^{}\n]+\}|%\d*\$?[sdif]|\\[A-Za-z]+(?:\[[^\]\n]*\])?|<[^<>\n]+>")
KANA_RE = re.compile(r"[\u3040-\u30ff\u31f0-\u31ff]")
KANJI_RE = re.compile(r"[\u3400-\u4dbf\u4e00-\u9fff]")
STUTTER_RE = re.compile(r"(?:^|[「『（(！？!?。…\s])([\u3040-\u30ff\u3400-\u9fff])、(?=\s*[\u3040-\u30ff\u3400-\u9fff])")

# Conservative exact labels commonly exported by Translator++/game scripts.
# Keep this list intentionally small: visible UI such as Save/Load/Start must
# still be translated.
TRANSLATORPP_TECHNICAL_EXACT = {
    "words", "word_count", "wordcount",
    "filename", "file_name", "filepath", "file_path",
    "image_path", "imagepath", "audio_path", "sound_path",
    "resource_path", "script_name",
    "debug", "debug_mode", "configuration",
    "null", "none", "true", "false",
}

DEFAULT_USD_CNY_RATE = float(os.environ.get("USD_CNY_RATE", "7.10"))


@dataclass(frozen=True)
class Item:
    item_id: str
    source: str
    group: str
    order: int
    locator: Any


@dataclass
class DeepSeekUsage:
    prompt_tokens: int = 0
    cached_tokens: int = 0
    completion_tokens: int = 0
    requests: int = 0

    def add(self, usage: dict[str, Any]) -> None:
        self.prompt_tokens += int(usage.get("prompt_tokens", 0) or 0)
        cached = usage.get("prompt_cache_hit_tokens")
        if cached is None:
            cached = (usage.get("prompt_tokens_details") or {}).get("cached_tokens", 0)
        self.cached_tokens += int(cached or 0)
        self.completion_tokens += int(usage.get("completion_tokens", 0) or 0)
        self.requests += 1

    @property
    def miss_tokens(self) -> int:
        return max(0, self.prompt_tokens - self.cached_tokens)

    def estimated_usd(self, model: str) -> tuple[float | None, str]:
        """Estimate DeepSeek API cost in USD using V4.1 Flash pricing.

        DeepSeek V4.1 Flash pricing effective 2026-09-10:
          off-peak: $0.003 / $0.15 / $0.60 per 1M tokens
                    (cache hit / cache miss / output)
          peak:     exactly 2x the off-peak rates.

        Peak-hour scheduling follows the existing Beijing-time policy used by
        this adapter (weekdays 09:00-12:00 and 14:00-18:00). Prices can change,
        so this is intentionally only an estimate.
        """
        bj = datetime.now(timezone(timedelta(hours=8)))
        peak = bj.weekday() < 5 and (9 <= bj.hour < 12 or 14 <= bj.hour < 18)
        period = "peak" if peak else "off-peak"
        name = model.lower()

        # Canonical V4.1 endpoint plus temporary compatibility aliases. V4 Pro
        # is being phased out/routed to V4.1 Flash, so estimate it at V4.1 Flash
        # rates as well rather than using the obsolete V4 Pro table.
        if name in {"deepseek-flash", "deepseek-v4-flash", "deepseek-v4-pro"} or "v4.1" in name:
            cached_rate, miss_rate, output_rate = (0.003, 0.15, 0.60)
            if peak:
                cached_rate *= 2
                miss_rate *= 2
                output_rate *= 2
        else:
            return None, period

        cost = (
            self.cached_tokens * cached_rate
            + self.miss_tokens * miss_rate
            + self.completion_tokens * output_rate
        ) / 1_000_000
        return cost, period

    def line(self, model: str, usd_cny_rate: float = DEFAULT_USD_CNY_RATE) -> str:
        cost, period = self.estimated_usd(model)
        if cost is not None:
            cny = cost * usd_cny_rate
            cost_text = (f"${cost:.6f} / ¥{cny:.6f} estimated "
                         f"({period}, 1 USD≈¥{usd_cny_rate:.4f})")
        else:
            cost_text = "cost estimate unavailable"
        return (f"DeepSeek usage: requests={self.requests}, input={self.prompt_tokens} "
                f"(cached={self.cached_tokens}, miss={self.miss_tokens}), "
                f"output={self.completion_tokens}, {cost_text}")


def arguments() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Local game translator: Translator++ XLSX project/file / MTool JSON")
    p.add_argument("input", type=Path,
                   help="MTool .json, one Translator++ .xlsx, or a directory recursively containing Translator++ .xlsx files")
    p.add_argument("--output", type=Path)
    p.add_argument("--model")
    p.add_argument("--japanese-model", default=JA_MODEL)
    p.add_argument("--english-model", default=EN_MODEL)
    p.add_argument("--review-model", default=REVIEW_MODEL)
    p.add_argument("--provider", choices=("local", "deepseek"), default="local",
                   help="Translation backend. local keeps the existing Ollama workflow; deepseek uses the DeepSeek API.")
    p.add_argument("--deepseek-model", default=DEEPSEEK_MODEL)
    p.add_argument("--deepseek-review-model", default=DEEPSEEK_REVIEW_MODEL,
                   help="Reviewer model used by --quality high. Defaults to V4.1 Flash because V4 Pro is being phased out; override this when a future V4.1 Pro endpoint is available.")
    p.add_argument("--source-language", choices=("auto", "Japanese", "English"), default="auto")
    p.add_argument("--batch-size", type=int, default=16)
    p.add_argument("--context-size", type=int, default=3)
    p.add_argument("--quality", choices=("fast", "balanced", "high"), default="balanced")
    p.add_argument("--start", type=int, default=0,
                   help="Skip this many eligible untranslated entries before --limit")
    p.add_argument("--limit", type=int)
    p.add_argument("--resume", action="store_true")
    p.add_argument("--overwrite-existing", action="store_true")
    p.add_argument("--translate-technical", action="store_true")
    p.add_argument("--include-renpy-common", action="store_true",
                   help="Translator++ project only: include renpy/common engine-library workbooks. V3.6.5 skips them by default.")
    p.add_argument("--repair-existing", action="store_true",
                   help="Translator++ only: selectively retranslate existing rows that violate the glossary or are still untranslated. Designed for repairing a completed output without redoing good rows.")
    p.add_argument("--restore-renpy-common-from", type=Path,
                   help="Translator++ project repair helper: after each save, restore renpy/common/*.xlsx from this original project root.")
    p.add_argument("--mtool-line-range",
                   help="For MTool JSON only: restrict candidates to one inclusive JSON file line range, e.g. 515:2533. "
                        "Kept for backward compatibility; prefer --mtool-line-ranges for new projects.")
    p.add_argument("--mtool-line-ranges",
                   help="For MTool JSON only: comma-separated inclusive JSON file ranges, e.g. "
                        "563:4144,6961:26225. Single lines are allowed as N or N:N. "
                        "This is useful when real game text is split by large script/resource blocks.")
    p.add_argument("--include-outside-ui", action="store_true",
                   help="With --mtool-line-range, also include a small conservative whitelist of obvious player-visible Japanese UI strings outside the story range.")
    p.add_argument("--glossary", type=Path)
    p.add_argument("--usd-cny-rate", type=float, default=DEFAULT_USD_CNY_RATE,
                   help="USD→RMB exchange rate used only for the local cost report (default: %(default)s; env USD_CNY_RATE also supported).")
    p.add_argument("--budget-rmb", type=float,
                   help="Optional RMB budget. If set, print estimated spent/remaining budget after each run.")
    p.add_argument("--dry-run", action="store_true")
    p.add_argument("--qa-report", type=Path)
    p.add_argument("--state-file", type=Path)
    p.add_argument("--timeout", type=int, default=900)
    a = p.parse_args()
    if not 1 <= a.batch_size <= 50: p.error("--batch-size must be 1..50")
    if not 0 <= a.context_size <= 20: p.error("--context-size must be 0..20")
    if a.start < 0: p.error("--start must be zero or positive")
    if a.limit is not None and a.limit < 1: p.error("--limit must be positive")
    if a.usd_cny_rate <= 0: p.error("--usd-cny-rate must be positive")
    if a.repair_existing and a.overwrite_existing:
        p.error("--repair-existing and --overwrite-existing are mutually exclusive")
    if a.repair_existing and a.resume:
        p.error("Start --repair-existing with a fresh --output; use --resume only after that repair run has created its checkpoint")
    if a.budget_rmb is not None and a.budget_rmb <= 0: p.error("--budget-rmb must be positive")
    return a


def load_deepseek_key() -> str:
    """Load DEEPSEEK_API_KEY from the environment or a local .env file."""
    from bruns.translate import load_env
    load_env()
    try:
        from dotenv import load_dotenv
    except ImportError:
        load_dotenv = None
    if load_dotenv is not None:
        # Current working directory is normally the project directory. Loading
        # the script directory as well makes the command less fragile.
        load_dotenv(Path.cwd() / ".env", override=False)
        load_dotenv(Path(__file__).resolve().parent / ".env", override=False)
    key = os.environ.get("DEEPSEEK_API_KEY", "").strip()
    if not key:
        hint = "Create .env with DEEPSEEK_API_KEY=sk-..."
        if load_dotenv is None:
            hint += " (or run: python -m pip install python-dotenv)"
        raise RuntimeError(f"DEEPSEEK_API_KEY is missing. {hint}")
    return key


def read_object(path: Path, name: str) -> dict[str, Any]:
    try: data = json.loads(path.read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError) as e: raise ValueError(f"Cannot read {name}: {e}") from e
    if not isinstance(data, dict): raise ValueError(f"{name} must be a JSON object")
    return data


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, path)


def glossary(path: Path | None) -> dict[str, str]:
    if path is None: return {}
    data = read_object(path, "glossary")
    if not all(isinstance(k, str) and isinstance(v, str) for k, v in data.items()):
        raise ValueError("Glossary must be string-to-string JSON")
    return data


def technical(text: str) -> bool:
    s = text.strip()
    if not s or len(s) > 1500: return True
    if re.fullmatch(r"#[0-9A-Fa-f]{3,8}|[-+]?\d+(?:\.\d+)?|[A-Z][A-Z0-9_]{2,}", s): return True
    if re.fullmatch(r"[%$#&*+=<>!;:._/\\-]+", s) or re.match(r"^(?:https?://|www\.)", s): return True
    if len(re.findall(r"(?:function\s*\(|=>|\bvar\s+|\blet\s+|\bconst\s+|[{};])", s)) >= 2: return True
    if ("/" in s or "\\" in s) and re.search(r"\.(?:png|jpe?g|gif|webp|mp[34]|ogg|wav|json|js|css|html?)$", s, re.I): return True
    return False


def technical_for_adapter(text: str, ad: "Adapter") -> bool:
    """Apply generic technical filtering plus a tiny Translator++-specific exact list."""
    if technical(text):
        return True
    return is_excel_adapter(ad) and text.strip().casefold() in TRANSLATORPP_TECHNICAL_EXACT


def source_contains_term(source: str, term: str) -> bool:
    """Match glossary terms conservatively; ASCII words require token boundaries."""
    t = term.strip()
    if not t:
        return False
    if re.fullmatch(r"[A-Za-z0-9_ .'-]+", t):
        return re.search(r"(?<![A-Za-z0-9_])" + re.escape(t) + r"(?![A-Za-z0-9_])", source, re.I) is not None
    return t in source


def glossary_qa(source: str, translation: str, terms: dict[str, str]) -> list[str]:
    issues: list[str] = []
    for src, dst in terms.items():
        src, dst = src.strip(), dst.strip()
        if not src or not dst or src == dst:
            continue
        if source_contains_term(source, src) and dst not in translation:
            issues.append(f"glossary_missing:{src}->{dst}")
    return issues


PLAYER_UI_EXACT = {
    "はじめから",
    "つづきから",
    "CGモード",
    "回想モード",
    "ゲームスタート",
    "タイトルに戻ります。よろしいですね？",
    "ウィンドウを閉じて終了します。よろしいですね？",
    "まだ、保存されているデータがありません",
}

def parse_line_range(spec: str | None) -> tuple[int, int] | None:
    if not spec:
        return None
    m = re.fullmatch(r"\s*(\d+)\s*:\s*(\d+)\s*", spec)
    if not m:
        raise ValueError("--mtool-line-range must look like START:END, e.g. 515:2533")
    start, end = int(m.group(1)), int(m.group(2))
    if start < 2 or end < start:
        raise ValueError("--mtool-line-range must use JSON file lines >= 2 and END >= START")
    return start, end

def parse_line_ranges(single: str | None, multi: str | None) -> list[tuple[int, int]]:
    if single and multi:
        raise ValueError("Use either --mtool-line-range or --mtool-line-ranges, not both")
    if single:
        one = parse_line_range(single)
        return [one] if one else []
    if not multi:
        return []
    ranges: list[tuple[int, int]] = []
    for raw in multi.split(","):
        token = raw.strip()
        if not token:
            continue
        if re.fullmatch(r"\d+", token):
            start = end = int(token)
        else:
            m = re.fullmatch(r"(\d+)\s*:\s*(\d+)", token)
            if not m:
                raise ValueError("--mtool-line-ranges must look like START:END,START:END (single N is also allowed)")
            start, end = int(m.group(1)), int(m.group(2))
        if start < 2 or end < start:
            raise ValueError("MTool JSON line ranges must use lines >= 2 and END >= START")
        ranges.append((start, end))
    if not ranges:
        return []
    # Merge overlapping/adjacent ranges so reporting and resume state stay deterministic.
    ranges.sort()
    merged: list[tuple[int, int]] = []
    for start, end in ranges:
        if merged and start <= merged[-1][1] + 1:
            merged[-1] = (merged[-1][0], max(merged[-1][1], end))
        else:
            merged.append((start, end))
    return merged

def line_in_ranges(line: int, ranges: list[tuple[int, int]]) -> bool:
    return not ranges or any(start <= line <= end for start, end in ranges)

def format_line_ranges(ranges: list[tuple[int, int]]) -> str:
    return ",".join(str(a) if a == b else f"{a}:{b}" for a, b in ranges)

def mtool_json_line(item: Item) -> int:
    # Flat MTool JSON has one key/value entry per rendered file line:
    # line 1 is "{", therefore zero-based entry order N is JSON line N+2.
    return item.order + 2

def in_mtool_scope(item: Item, line_ranges: list[tuple[int, int]], include_outside_ui: bool) -> bool:
    if not line_ranges:
        return True
    line = mtool_json_line(item)
    if line_in_ranges(line, line_ranges):
        return True
    return include_outside_ui and item.source.strip() in PLAYER_UI_EXACT


class Adapter:
    kind = ""
    def items(self) -> list[Item]: raise NotImplementedError
    def get(self, item: Item) -> str: raise NotImplementedError
    def set(self, item: Item, value: str) -> None: raise NotImplementedError
    def save(self, path: Path) -> None: raise NotImplementedError
    def pending(self, item: Item, overwrite: bool) -> bool: raise NotImplementedError
    def context(self, item: Item, n: int) -> tuple[list[str], list[str]]:
        pool = getattr(self, "active_items", self.items())
        peers = [x for x in pool if x.group == item.group]
        i = next(i for i, x in enumerate(peers) if x.item_id == item.item_id)
        return ([x.source for x in peers[max(0, i-n):i]], [x.source for x in peers[i+1:i+1+n]])


class ExcelAdapter(Adapter):
    kind = "Translator++ Excel"
    def __init__(self, path: Path):
        try: from openpyxl import load_workbook
        except ImportError as e: raise ValueError("Run: python -m pip install openpyxl") from e
        self.book = load_workbook(path)
        self._items, order = [], 0
        for ws in self.book.worksheets:
            header, src, dst = self._columns(ws)
            for row in range(header + 1, ws.max_row + 1):
                value = ws.cell(row, src).value
                if isinstance(value, str) and value.strip():
                    self._items.append(Item(f"{ws.title}::{row}", value, ws.title, order, (ws.title, row, dst)))
                    order += 1
    @staticmethod
    def _columns(ws: Any) -> tuple[int, int, int]:
        for row in range(1, min(ws.max_row, 20) + 1):
            h = {str(ws.cell(row, c).value).strip(): c for c in range(1, ws.max_column + 1) if ws.cell(row, c).value is not None}
            if SOURCE_HEADER in h and TARGET_HEADER in h: return row, h[SOURCE_HEADER], h[TARGET_HEADER]
        raise ValueError(f"Sheet {ws.title!r} lacks Translator++ headers")
    def items(self) -> list[Item]: return self._items
    def get(self, x: Item) -> str:
        sheet, row, col = x.locator; v = self.book[sheet].cell(row, col).value
        return v if isinstance(v, str) else ""
    def set(self, x: Item, value: str) -> None:
        sheet, row, col = x.locator; self.book[sheet].cell(row, col, value=value)
    def pending(self, x: Item, overwrite: bool) -> bool: return overwrite or not self.get(x).strip()
    def save(self, path: Path) -> None: path.parent.mkdir(parents=True, exist_ok=True); self.book.save(path)


class ExcelProjectAdapter(Adapter):
    """Treat a directory tree of Translator++ workbooks as one logical project.

    Item IDs include the relative workbook path, sheet name and Excel row so they remain
    globally unique across projects such as game/script.xlsx + renpy/script.xlsx.
    Context is grouped per workbook+sheet and therefore never leaks across files.
    """
    kind = "Translator++ Excel project"

    def __init__(self, root: Path):
        try:
            from openpyxl import load_workbook
        except ImportError as e:
            raise ValueError("Run: python -m pip install openpyxl") from e

        self.root = root.resolve()
        self.books: dict[str, Any] = {}
        self._items: list[Item] = []
        self.workbook_paths: list[str] = []
        self.skipped_workbooks: list[str] = []
        self.skipped_sheets: list[str] = []
        self.restore_renpy_common_from: Path | None = None
        order = 0

        paths = sorted(
            (x for x in self.root.rglob("*.xlsx") if x.is_file() and not x.name.startswith("~$")),
            key=lambda x: x.relative_to(self.root).as_posix().lower(),
        )
        if not paths:
            raise ValueError(f"No .xlsx files found under Translator++ project: {self.root}")

        for path in paths:
            rel = path.relative_to(self.root).as_posix()
            try:
                book = load_workbook(path)
            except Exception as e:
                self.skipped_workbooks.append(f"{rel}: cannot open ({e})")
                continue

            compatible_sheets = 0
            for ws in book.worksheets:
                try:
                    header, src, dst = ExcelAdapter._columns(ws)
                except ValueError:
                    self.skipped_sheets.append(f"{rel}::{ws.title}")
                    continue
                compatible_sheets += 1
                group = f"{rel}::{ws.title}"
                for row in range(header + 1, ws.max_row + 1):
                    value = ws.cell(row, src).value
                    if isinstance(value, str) and value.strip():
                        item_id = f"{rel}::{ws.title}::{row}"
                        self._items.append(Item(item_id, value, group, order, (rel, ws.title, row, dst)))
                        order += 1

            if compatible_sheets:
                self.books[rel] = book
                self.workbook_paths.append(rel)
            else:
                self.skipped_workbooks.append(f"{rel}: no Translator++ sheet with '{SOURCE_HEADER}' + '{TARGET_HEADER}'")

        if not self.books:
            raise ValueError("No compatible Translator++ workbooks were found in the directory")

    def items(self) -> list[Item]:
        return self._items

    def get(self, x: Item) -> str:
        rel, sheet, row, col = x.locator
        value = self.books[rel][sheet].cell(row, col).value
        return value if isinstance(value, str) else ""

    def set(self, x: Item, value: str) -> None:
        rel, sheet, row, col = x.locator
        self.books[rel][sheet].cell(row, col, value=value)

    def pending(self, x: Item, overwrite: bool) -> bool:
        return overwrite or not self.get(x).strip()

    def save(self, path: Path) -> None:
        path.mkdir(parents=True, exist_ok=True)
        for rel, book in self.books.items():
            target = path / Path(rel)
            target.parent.mkdir(parents=True, exist_ok=True)
            book.save(target)

        # Repairing an already-translated V3.6.4 project may otherwise carry
        # translated Ren'Py library docs forward. When an original project is
        # supplied, restore those workbooks byte-for-byte after every save.
        if self.restore_renpy_common_from is not None:
            source_dir = self.restore_renpy_common_from / "renpy" / "common"
            if source_dir.is_dir():
                for source in source_dir.rglob("*.xlsx"):
                    rel = source.relative_to(self.restore_renpy_common_from)
                    target = path / rel
                    target.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(source, target)


class MToolAdapter(Adapter):
    kind = "MTool JSON"
    def __init__(self, path: Path):
        self.data = read_object(path, "MTool JSON")
        if not all(isinstance(k, str) and isinstance(v, str) for k, v in self.data.items()):
            raise ValueError("MTool JSON must be a flat string-to-string object")
        self._items = [Item(f"json::{i:06d}", key, "MTool", i, key) for i, key in enumerate(self.data)]
    def items(self) -> list[Item]: return self._items
    def get(self, x: Item) -> str: return self.data[x.locator]
    def set(self, x: Item, value: str) -> None: self.data[x.locator] = value
    def pending(self, x: Item, overwrite: bool) -> bool:
        value = self.get(x); return overwrite or not value.strip() or value == x.source
    def save(self, path: Path) -> None: write_json(path, self.data)


def adapter(path: Path) -> Adapter:
    if path.is_dir(): return ExcelProjectAdapter(path)
    if path.suffix.lower() == ".xlsx": return ExcelAdapter(path)
    if path.suffix.lower() == ".json": return MToolAdapter(path)
    raise ValueError("Input must be a Translator++ project directory, .xlsx, or MTool .json")


def regroup_mtool(items: list[Item], maximum_gap: int = 20) -> list[Item]:
    """Break MTool text into scenes when translatable keys are far apart."""
    if not items:
        return []
    scene, previous = 0, items[0].order
    regrouped = []
    for item in items:
        if item.order - previous > maximum_gap:
            scene += 1
        regrouped.append(replace(item, group=f"MTool::{scene:04d}"))
        previous = item.order
    return regrouped


def protect(text: str) -> str:
    parts = text.split("\n")
    return "".join(part + (f"⟦LB_{i:03d}⟧" if i < len(parts)-1 else "") for i, part in enumerate(parts))


def restore(text: str, source: str) -> str:
    # A child ID represents exactly one physical source line. Some models
    # (especially Sakura) still insert presentation newlines inside the JSON
    # string. Those are model formatting, not source structure, so flatten
    # them before validation. Chinese output does not need a joining space.
    if "\n" not in source:
        text = re.sub(r"\s*[\r\n]+\s*", "", text)
    found = [int(x) for x in LB_RE.findall(text)]
    expected = list(range(source.count("\n")))
    if found != expected: raise ValueError(f"line-break markers changed: expected {expected}, got {found}")
    return LB_RE.sub("\n", text).strip(" \t\r")


def detect(texts: Iterable[str]) -> str:
    s = "\n".join(texts); kana = len(KANA_RE.findall(s)); latin = len(re.findall(r"[A-Za-z]", s))
    return "Japanese" if kana >= 3 and kana >= latin * .05 else "English"


def matches_requested_language(text: str, requested: str) -> bool:
    """Avoid feeding asset names/English engine metadata to Sakura."""
    if requested == "Japanese":
        return bool(KANA_RE.search(text) or KANJI_RE.search(text))
    if requested == "English":
        return bool(re.search(r"[A-Za-z]", text))
    return True


def lang(items: list[Item], requested: str) -> str: return requested if requested != "auto" else detect(x.source for x in items)
def chosen_model(language: str, a: argparse.Namespace) -> str: return a.model or (a.japanese_model if language == "Japanese" else a.english_model)


def primary_prompt(language: str, terms: dict[str, str]) -> str:
    role = "你是擅长轻小说、漫画和 Galgame 的专业日中翻译。" if language == "Japanese" else "You are a professional English-to-Simplified-Chinese game localizer."
    return f"""{role}
将全部 scene_items 当作一段连续剧情，理解上下文后翻译成自然简体中文。
只返回一个 JSON 对象，键须与输入 ID 完全相同，值只能是译文。
每个 ID 的内容不可移动到其他 ID。带有 `#L000` 的 ID 是同一单元格的连续行，必须逐行返回。
占位符、变量、标签和转义序列必须原样保留。日语句首重复音节通常是口吃，要按后续词语译成中文口吃。
拟声词要结合动作本地化，不能机械音译假名。保持人物口吻、主客体、动作力度和成人/暴力内容；不弱化、不添加。
context_before/context_after 仅供理解，不要翻译。不要解释或 Markdown。
术语表：{json.dumps(terms, ensure_ascii=False)}"""


def review_prompt(terms: dict[str, str], quality: str = "balanced") -> str:
    if quality == "high":
        mode = """你是独立的高级日中游戏本地化终审。不要先相信 draft。
对每一项先只根据 source、context_before、context_after 在内部独立判断原意，再回头比较 draft；不要让已有译文锚定你的判断。
如果 risk_types 含 slurred_or_corrupted_speech：先在内部推断角色原本想说的正常日语词/短语，再判断 draft 是否把故意含糊、幼儿音、错音或崩坏发音误当成了别的词。
若无法可靠还原，不要编造；只有有明确依据时才改。
对于 semantic_relation_high_risk，重点复核可能/已经、否定、比较、被动/使役、条件、因果和动作是否真实发生。
高标准终审，但正确草稿仍应原样保留；只有能明确提高准确性、自然度或上下文一致性时才修改。"""
    else:
        mode = """你是简体中文游戏本地化终审。只处理明确有风险的句子；若草稿准确自然，必须原样返回，不要为了换一种说法而改写。
如果 risk_types 含 slurred_or_corrupted_speech，请先根据 source 和上下文判断它是否是某个正常日语词/短语的故意含糊发音，再检查 draft 是否误解；没有把握就保留草稿。"""
    return f"""{mode}
逐项核对 source、draft、context_before、context_after 和 risk_types。
必须特别检查：
- 主客体、人称、否定、条件、因果、时间、完成/未完成状态、可能/已经发生的区别；
- 程度、数量、数字、比较关系、被动/使役关系；
- 人物口吻、口吃、拟声词、成人/暴力描写是否忠实且自然；
- 遗漏、添加、重复、机械直译和不自然中文。
禁止擅自补充原文没有的事实，禁止把“可能/仿佛/几乎”改成“已经发生”，也禁止弱化内容。
带有 `#L000` 的 ID 是同一单元格的连续行，必须逐行返回；占位符、变量、标签、数字和转义序列必须原样保留。
如果 draft 没有明确问题，原样返回 draft。
只返回键完全一致的 JSON 对象，不要解释或 Markdown。
JSON 的每个 value 必须直接是字符串，例如：{{"T0001":"译文","T0002":"译文"}}。
不要返回 {{"T0001":{{"translation":"译文","changed":true}}}} 这种嵌套对象，也不要附带 changed、reason、comment 等元数据。
术语表：{json.dumps(terms, ensure_ascii=False)}"""



def independent_retranslation_prompt(terms: dict[str, str], quality: str = "balanced") -> str:
    reviewer = "高级日中游戏本地化专家" if quality == "high" else "专业日中游戏本地化译者"
    return f"""你是{reviewer}。这是一次独立重译，不是校对现有译文。
输入中故意不提供任何 draft；不要猜测、引用或延续之前模型可能给出的译法。

对每个 item：
1. 先根据 source、context_before、context_after 独立理解原意；
2. 如果 source 是口齿不清、幼儿音、错音、呻吟中夹杂词语或故意崩坏的日语，先在内部推断最可能的正常日语词/短语；
3. 再把实际表达自然翻成简体中文，同时保留角色说话含糊、结巴或失控的感觉；
4. 无法可靠还原时，不要凭空创造具体词义，采用保守译法。

必须保持主客体、人称、否定、时态/状态、条件、因果、比较、数量与动作是否已经发生。
占位符、变量、标签、数字和转义序列必须原样保留。context_before/context_after 只供理解，不要翻译。
只返回键完全一致的 JSON 对象，每个 value 必须直接是译文字符串，不要解释、reason、comment 或 Markdown。
术语表：{json.dumps(terms, ensure_ascii=False)}"""

def parse_json(raw: Any) -> dict[str, str]:
    if isinstance(raw, dict): result: Any = raw
    else:
        content = re.sub(r"^```(?:json)?\s*|\s*```$", "", str(raw).strip())
        result = json.loads(content)
    if isinstance(result, dict):
        for name in ("translations", "translation", "results", "items"):
            if isinstance(result.get(name), (dict, list)): result = result[name]; break
    if isinstance(result, list):
        converted = {}
        for row in result:
            if not isinstance(row, dict): raise ValueError("JSON list contains non-object")
            key = row.get("id") or row.get("key"); value = row.get("translation") or row.get("text") or row.get("value")
            if not isinstance(key, str) or not isinstance(value, str): raise ValueError("JSON list item lacks ID/translation")
            converted[key] = value
        result = converted
    if not isinstance(result, dict): raise ValueError("Model output is not a JSON object")
    out = {}
    preferred_fields = (
        "translation", "final_translation", "revised_translation",
        "reviewed_translation", "text", "value", "result", "output",
        "final", "review", "draft",
    )
    for key, value in result.items():
        if isinstance(value, dict):
            picked = None
            for field in preferred_fields:
                candidate = value.get(field)
                if isinstance(candidate, str):
                    picked = candidate
                    break
            # Some models wrap the answer in an otherwise metadata-only object.
            # If there is exactly one string value, it is safe to treat that as
            # the translation.
            if picked is None:
                string_values = [v for v in value.values() if isinstance(v, str)]
                if len(string_values) == 1:
                    picked = string_values[0]
            value = picked
        elif isinstance(value, list) and len(value) == 1 and isinstance(value[0], str):
            value = value[0]
        if not isinstance(value, str):
            shape = type(value).__name__
            raise ValueError(f"Translation {key!r} is not a string (parsed type: {shape})")
        out[str(key)] = value
    return out


def structural(source: str, target: str) -> list[str]:
    out = []
    if not target.strip(): out.append("empty_translation")
    if source.count("\n") != target.count("\n"): out.append("newline_mismatch")
    if Counter(PH_RE.findall(source)) != Counter(PH_RE.findall(target)): out.append("placeholder_mismatch")
    if not re.search(r"[「」『』]", source) and re.search(r"[「」『』]", target): out.append("unexpected_japanese_quote")
    quote_comma = re.search(r"[」』][，,]\s*$", target)
    added_punctuation_burst = (
        re.search(r"[，,。！？!?]{3,}\s*$", target)
        and not re.search(r"[、,。！？!?]{3,}\s*$", source)
    )
    if quote_comma or added_punctuation_burst:
        out.append("suspicious_trailing_punctuation")
    return out


def digits(text: str) -> list[str]:
    return re.findall(r"\d+(?:[.,]\d+)?%?", text)


def _normalize_number_token(token: str) -> str:
    """Normalize an Arabic number for semantic QA comparison."""
    value = token.replace(",", "").strip()
    if "." in value:
        value = value.rstrip("0").rstrip(".")
    return value or "0"


def _chinese_number_to_int(token: str) -> int | None:
    """Parse a common Chinese integer numeral used in localized game text."""
    token = token.replace("兩", "两").replace("〇", "零")
    digit_map = {"零": 0, "一": 1, "二": 2, "两": 2, "三": 3, "四": 4,
                 "五": 5, "六": 6, "七": 7, "八": 8, "九": 9}
    unit_map = {"十": 10, "百": 100, "千": 1000, "万": 10000, "萬": 10000}

    if token and all(ch in digit_map for ch in token):
        try:
            return int("".join(str(digit_map[ch]) for ch in token))
        except ValueError:
            return None

    total = 0
    section = 0
    number = 0
    saw = False
    for ch in token:
        if ch in digit_map:
            number = digit_map[ch]
            saw = True
        elif ch in unit_map:
            saw = True
            unit = unit_map[ch]
            if unit == 10000:
                section = (section + number) * unit
                total += section
                section = 0
                number = 0
            else:
                if number == 0:
                    number = 1
                section += number * unit
                number = 0
        else:
            return None
    if not saw:
        return None
    return total + section + number


def number_signature(text: str) -> set[str]:
    """Semantic number signature used by QA.

    Percent spellings (``100 percent`` / ``100%``), hundredth fractions
    (``1/100`` / ``百分之一``), Arabic numerals and Chinese counter forms are
    normalized to comparable tags. Numeric spans consumed by a percent/fraction
    expression are removed before ordinary-number extraction so one concept is
    not double-counted.
    """
    sig: set[str] = set()
    masked = text

    def mask_span(a: int, b: int) -> None:
        nonlocal masked
        masked = masked[:a] + (" " * (b - a)) + masked[b:]

    spans: list[tuple[int, int]] = []

    # English/Arabic percentage notation.
    pct_re = re.compile(r"(?<![\w.])([+-]?\d+(?:[.,]\d+)?)\s*(%|percent\b)", re.I)
    for m in pct_re.finditer(text):
        sig.add("pct:" + _normalize_number_token(m.group(1)))
        spans.append(m.span())

    # Fractions. x/100 is semantically equivalent to x percent.
    frac_re = re.compile(r"(?<![\w.])(\d+(?:\.\d+)?)\s*/\s*(\d+(?:\.\d+)?)(?:st|nd|rd|th)?(?![\w.])", re.I)
    for m in frac_re.finditer(text):
        num = _normalize_number_token(m.group(1))
        den = _normalize_number_token(m.group(2))
        sig.add(("pct:" + num) if den == "100" else f"frac:{num}/{den}")
        spans.append(m.span())

    # Chinese 百分之X.
    cn_pct_re = re.compile(r"百分之([零〇一二两兩三四五六七八九十百千万萬]+)")
    for m in cn_pct_re.finditer(text):
        value = _chinese_number_to_int(m.group(1))
        if value is not None:
            sig.add(f"pct:{value}")
            spans.append(m.span())

    for a, b in sorted(spans, reverse=True):
        mask_span(a, b)

    # Remaining Arabic numbers. Hyphens in labels like chapter-3 are separators,
    # not negative signs, so signs are intentionally ignored here.
    for m in re.finditer(r"(?<![\w.])\d+(?:[.,]\d+)?(?![\w.])", masked):
        sig.add("num:" + _normalize_number_token(m.group(0)))

    # Chinese number + common counter/unit forms.
    units = "次秒分时時天日周週月年倍个個名人只枚本场場厘米毫米米公斤克岁歲层層回章节節页頁级級号號卷话話集"
    pattern = rf"([零〇一二两兩三四五六七八九十百千万萬]+)(?=[{units}])"
    for match in re.finditer(pattern, masked):
        value = _chinese_number_to_int(match.group(1))
        if value is not None:
            sig.add(f"num:{value}")
    return sig

def qa(source: str, target: str) -> list[str]:
    out = structural(source, target)
    if KANA_RE.search(target): out.append("japanese_kana_remaining")
    if source == target and KANA_RE.search(source): out.append("unchanged_japanese")
    a, b = len(re.sub(r"\s+", "", source)), len(re.sub(r"\s+", "", target))
    if a and b < a * .18: out.append("translation_unusually_short")
    if a and b > a * 3: out.append("translation_unusually_long")
    # Only enforce number preservation when the source itself contains a
    # recognized number. Natural Chinese often introduces numeral-looking
    # measure words where English has none (e.g. "again" -> "再试一次"),
    # which must not be treated as a mismatch.
    source_numbers = number_signature(source)
    target_numbers = number_signature(target)
    if source_numbers and not source_numbers.issubset(target_numbers):
        out.append("number_mismatch")
    if re.search(r"(?:あんた|あなた|お前|君たち|あんた達)", source) and re.search(r"(?:她们|他们)", target) and "你" not in target:
        out.append("possible_second_person_drift")
    return list(dict.fromkeys(out))


def risks(source: str, draft: str = "", quality: str = "balanced") -> list[str]:
    out = qa(source, draft) if draft else []
    compact = re.sub(r"\s+", "", source)
    kana = len(KANA_RE.findall(compact)); kanji = len(KANJI_RE.findall(compact))

    # Vocalizations, stutters and sound effects are easy to mistranslate even
    # when there is no deterministic QA error.
    if len(compact) <= 28 and kana >= 2 and kanji == 0 and re.search(r"[!！?？ー～〜]|(.)\1{2,}", source):
        out.append("sound_or_vocalization")
    if STUTTER_RE.search(source):
        out.append("possible_japanese_stutter")

    # Relations that often change meaning when translated too freely.
    relation = re.search(
        r"(?:られ|され|させ|にも関わらず|と言わんばかり|に至|ながら|ものの|踏んで|あまり|"
        r"まるで|一方|わけ|ように|そうな|そうに|ほど|しか|だけ|まだ|すでに|もう|はず|"
        r"かもしれ|かも知れ|ようと|ないまま|ずに|たびに|よりも|ほどの)", source
    )
    if KANA_RE.search(source) and (len(compact) >= 42 or relation):
        out.append("complex_japanese_relation")

    # Dialogue and long narration get extra scrutiny only in high mode.
    if quality == "high":
        if re.search(r"[「」『』]|[!！?？…]", source) and KANA_RE.search(source):
            out.append("dialogue_or_expressive_line")
        if len(compact) >= 30 and KANA_RE.search(source):
            out.append("long_japanese_line")

    return list(dict.fromkeys(out))


def slurred_or_corrupted_speech(source: str) -> bool:
    """Heuristic for heavily slurred / deliberately broken Japanese dialogue.

    This is intentionally narrower than ordinary stutter or sound effects. It
    looks for kana-heavy expressive text with multiple broken chunks, where a
    literal dictionary reading is especially likely to be wrong.
    """
    compact = re.sub(r"\s+", "", source)
    if not KANA_RE.search(source) or KANJI_RE.search(source):
        return False
    if len(compact) > 45:
        return False
    broken = len(re.findall(r"(?:…|\.{2,}|、)", source)) >= 2
    expressive = bool(re.search(r"[!！?？ー～〜]|[ぁぃぅぇぉゃゅょっ]{2,}", source))
    kana_runs = re.findall(r"[\u3040-\u30ff]{3,}", source)
    repeated_chunk = any(source.count(run) >= 2 for run in kana_runs if len(run) >= 3)
    return broken and expressive and (repeated_chunk or len(kana_runs) >= 2)


def review_reasons(source: str, draft: str, quality: str = "balanced") -> list[str]:
    """Return only risks worth spending a model-review call on.

    V3.5.4.4 keeps the broad QA/advisory layer, but makes ``balanced`` a true
    selective-review mode. In particular, residual kana and ordinary soft
    style warnings no longer trigger a paid review by themselves.
    """
    all_risks = risks(source, draft, quality)
    compact = re.sub(r"\s+", "", source)
    target_compact = re.sub(r"\s+", "", draft)

    # Structural / objective failures are always worth a paid review.
    hard_always = {
        "empty_translation", "newline_mismatch", "placeholder_mismatch",
        "unexpected_japanese_quote", "suspicious_trailing_punctuation",
        "translation_unusually_short", "translation_unusually_long",
        "number_mismatch", "possible_second_person_drift",
    }
    chosen = [r for r in all_risks if r in hard_always]

    # Remaining Japanese is useful QA evidence but extremely noisy for names,
    # SFX and deliberate vocalizations. Escalate only substantial residue.
    if "japanese_kana_remaining" in all_risks:
        residual_kana = len(KANA_RE.findall(draft))
        if len(compact) >= 12 and len(target_compact) >= 12 and residual_kana >= 6:
            chosen.append("japanese_kana_remaining_substantial")

    # An unchanged full sentence is suspicious; tiny labels/names/fragments stay
    # in the QA report instead of automatically spending another API request.
    if "unchanged_japanese" in all_risks and len(compact) >= 8:
        chosen.append("unchanged_japanese_substantial")

    # Truly corrupted/slurred speech remains worth an independent no-draft pass.
    if slurred_or_corrupted_speech(source):
        chosen.append("slurred_or_corrupted_speech")

    # Only relation-heavy sentences with meaningful length are reviewed in
    # balanced mode. This avoids reviewing ordinary dialogue simply because it
    # contains one common Japanese grammar marker.
    high_risk_relation = re.search(
        r"(?:かもしれ|かも知れ|ないまま|ずに|にも関わらず|よりも|しか|"
        r"はず|わけ|させ|られ|され|ようと)", source
    )
    min_relation_len = 45 if quality == "balanced" else 30
    if len(compact) >= min_relation_len and high_risk_relation:
        chosen.append("semantic_relation_high_risk")

    # Multiple soft warnings were a major source of over-review in V3.5.4.3.
    # Keep that extra scrutiny for high mode only.
    if quality == "high":
        hard_seen = set(hard_always) | {"japanese_kana_remaining", "unchanged_japanese"}
        soft = {r for r in all_risks if r not in hard_seen}
        if "complex_japanese_relation" in soft and len(soft) >= 2:
            chosen.append("multiple_soft_risks")
        if "complex_japanese_relation" in all_risks and len(compact) >= 55:
            chosen.append("high_long_relation_review")
        if "dialogue_or_expressive_line" in all_risks and "complex_japanese_relation" in all_risks and len(compact) >= 35:
            chosen.append("high_dialogue_relation_review")

    return list(dict.fromkeys(chosen))


def call(model: str, system: str, payload: dict[str, Any], sources: dict[str, str], timeout: int, stage: str) -> dict[str, str]:
    try:
        import requests
    except ImportError as e:
        raise RuntimeError("Missing dependency. Run: python -m pip install requests") from e
    expected = set(sources)
    schema = {"type":"object", "properties":{k:{"type":"string"} for k in expected}, "required":sorted(expected), "additionalProperties":False}
    last: Exception | None = None
    for attempt in range(1, 4):
        try:
            r = requests.post(OLLAMA_URL, json={"model":model,"messages":[{"role":"system","content":system},{"role":"user","content":json.dumps(payload,ensure_ascii=False)}],"stream":False,"think":False,"format":schema,"keep_alive":"10m","options":{"temperature":.1}}, timeout=timeout)
            r.raise_for_status(); result = parse_json(r.json()["message"]["content"])
            if set(result) != expected: raise ValueError(f"IDs changed: missing={sorted(expected-set(result))}, extra={sorted(set(result)-expected)}")
            restored = {k: restore(v, sources[k]) for k, v in result.items()}
            for key, value in restored.items():
                bad = structural(sources[key], value)
                if bad: raise ValueError(f"{key}: {', '.join(bad)}")
            return restored
        except (requests.RequestException, KeyError, ValueError, json.JSONDecodeError) as e:
            last = e; print(f"  {stage} attempt {attempt}/3 failed: {e}")
            if attempt < 3: time.sleep(2 * attempt)
    raise RuntimeError(f"{stage} failed after 3 attempts: {last}")


def is_safe_fragment_fallback(text: str) -> bool:
    """Return True only for tiny Japanese layout fragments that may be omitted by an LLM.

    MTool/Kirikiri exports sometimes split one displayed sentence across entries,
    leaving items such as 「あ」, 「が」 or 「識」 on their own. Hosted models can
    legitimately omit such an item even when every normal sentence is returned.
    We keep these fragments verbatim instead of failing the whole API batch; the
    ordinary QA layer will then flag remaining Japanese for later review.
    """
    compact = re.sub(r"\s+", "", text)
    if not compact or len(compact) > 2:
        return False
    if PH_RE.search(text) or re.search(r"[A-Za-z0-9]", compact):
        return False
    # Require Japanese script; punctuation-only strings are not treated as text fragments.
    return bool(KANA_RE.search(compact) or KANJI_RE.search(compact))


def deepseek_output_budget(sources: dict[str, str]) -> int:
    """Estimate a safe completion-token budget for one structured response.

    Japanese/Chinese game text normally needs fewer output tokens than source
    characters. The generous multiplier leaves room for JSON keys/escaping while
    the hard cap prevents a malformed response from producing a 100k-token bill.
    """
    source_chars = sum(len(re.sub(r"\s+", "", text)) for text in sources.values())
    item_overhead = 24 * max(1, len(sources))
    estimate = int(source_chars * 1.8) + item_overhead + 256
    return max(DEEPSEEK_MIN_OUTPUT_TOKENS, min(DEEPSEEK_MAX_OUTPUT_TOKENS, estimate))


def call_deepseek(model: str, system: str, payload: dict[str, Any], sources: dict[str, str],
                  timeout: int, stage: str, api_key: str, usage_total: DeepSeekUsage) -> dict[str, str]:
    """Call DeepSeek using temporary model-facing IDs, then map them back.

    Some hosted models normalize keys such as ``json::002235`` into ``002235``.
    To keep Translator++/MTool locators completely opaque to the model, expose
    only simple T0001-style IDs and restore the real IDs in Python.
    """
    try:
        import requests
    except ImportError as e:
        raise RuntimeError("Missing dependency. Run: python -m pip install requests") from e

    real_ids = list(sources)
    real_to_temp = {real_id: f"T{i:04d}" for i, real_id in enumerate(real_ids, 1)}
    temp_to_real = {temp_id: real_id for real_id, temp_id in real_to_temp.items()}
    temp_sources = {real_to_temp[real_id]: text for real_id, text in sources.items()}
    expected = set(temp_sources)

    def remap_keys(value: Any) -> Any:
        if isinstance(value, dict):
            return {real_to_temp.get(str(k), str(k)): remap_keys(v) for k, v in value.items()}
        if isinstance(value, list):
            return [remap_keys(v) for v in value]
        return value

    api_payload = remap_keys(payload)
    base_max_tokens = deepseek_output_budget(temp_sources)
    last: Exception | None = None
    for attempt in range(1, 4):
        # If a legitimate response hits the estimated limit, allow retries to
        # expand up to the absolute cap. Malformed/repetitive responses can never
        # exceed DEEPSEEK_MAX_OUTPUT_TOKENS in one request.
        request_max_tokens = min(DEEPSEEK_MAX_OUTPUT_TOKENS, base_max_tokens * (2 ** (attempt - 1)))
        try:
            response = requests.post(
                DEEPSEEK_URL,
                headers={
                    "Content-Type": "application/json",
                    "Authorization": f"Bearer {api_key}",
                },
                json={
                    "model": model,
                    "messages": [
                        {"role": "system", "content": system},
                        {"role": "user", "content": json.dumps(api_payload, ensure_ascii=False)},
                    ],
                    "thinking": {"type": "disabled"},
                    "stream": False,
                    "temperature": 0.1,
                    "max_tokens": request_max_tokens,
                },
                timeout=timeout,
            )
            response.raise_for_status()
            body = response.json()
            usage_total.add(body.get("usage") or {})
            choice = body["choices"][0]
            if choice.get("finish_reason") == "length":
                raise ValueError(f"response hit max_tokens={request_max_tokens}")
            result = parse_json(choice["message"]["content"])
            missing = expected - set(result)
            extra = set(result) - expected
            if extra:
                raise ValueError(f"temporary IDs changed: missing={sorted(missing)}, extra={sorted(extra)}")
            if missing:
                unsafe_missing = [key for key in missing if not is_safe_fragment_fallback(temp_sources[key])]
                if unsafe_missing:
                    raise ValueError(f"temporary IDs changed: missing={sorted(missing)}, extra=[]")
                # V3.5.4.2: tiny Japanese fragments can be formatting/script shards
                # rather than meaningful standalone translation units. Preserve the
                # source shard so one omitted kana/kanji cannot kill a whole batch.
                # QA will flag unchanged Japanese in the rebuilt parent item.
                for key in sorted(missing):
                    result[key] = temp_sources[key]
                real_missing = [temp_to_real[key] for key in sorted(missing)]
                print(f"  Fragment fallback: model omitted {real_missing}; preserved source for QA instead of failing batch.")

            temp_restored = {k: restore(v, temp_sources[k]) for k, v in result.items()}
            for key, value in temp_restored.items():
                bad = structural(temp_sources[key], value)
                if bad:
                    raise ValueError(f"{temp_to_real[key]}: {', '.join(bad)}")

            return {temp_to_real[temp_id]: value for temp_id, value in temp_restored.items()}
        except (requests.RequestException, KeyError, IndexError, ValueError, json.JSONDecodeError) as e:
            last = e
            detail = ""
            if isinstance(e, requests.HTTPError) and e.response is not None:
                try:
                    detail = f" | {e.response.text[:500]}"
                except Exception:
                    pass
            print(f"  DeepSeek {stage} attempt {attempt}/3 failed: {e}{detail}")
            if attempt < 3:
                time.sleep(2 * attempt)
    raise RuntimeError(f"DeepSeek {stage} failed after 3 attempts: {last}")


def parse_labeled_block(content: str, labels: list[str]) -> dict[str, str]:
    """Parse Sakura-friendly [T0001] blocks; values may span many lines."""
    pattern = re.compile(r"(?m)^\s*\[(T\d{4})\]\s*")
    matches = list(pattern.finditer(content.strip()))
    seen = [match.group(1) for match in matches]
    if seen != labels:
        raise ValueError(f"labels changed: expected {labels}, got {seen}")
    result = {}
    for index, match in enumerate(matches):
        end = matches[index + 1].start() if index + 1 < len(matches) else len(content)
        value = content[match.end():end].strip()
        if not value:
            raise ValueError(f"empty translation for {match.group(1)}")
        result[match.group(1)] = value
    return result


def call_sakura(model: str, language: str, terms: dict[str, str], batch: list[Item],
                before: list[str], after: list[str], timeout: int) -> dict[str, str]:
    """Use the simple numbered format Sakura follows reliably in CLI tests."""
    try:
        import requests
    except ImportError as e:
        raise RuntimeError("Missing dependency. Run: python -m pip install requests") from e
    labels = [f"T{i:04d}" for i in range(1, len(batch) + 1)]
    label_to_item = dict(zip(labels, batch))
    source_block = "\n\n".join(f"[{label}] {item.source}" for label, item in zip(labels, batch))
    prompt = f"""请先完整理解这段连续的游戏剧情，再把每个编号的{language}原文翻译成自然准确的简体中文。
严格保留并按原顺序输出每个 [T0001] 编号。一个编号的译文可以包含多行，但不得把内容移到其他编号。
不要输出 JSON，不要解释，不要添加原文没有的信息。正确处理口吃、拟声词、人物口吻、动作主客体和成人内容。
占位符、变量、标签和转义序列必须原样保留。
术语表：{json.dumps(terms, ensure_ascii=False)}
前文（只供理解）：{json.dumps(before, ensure_ascii=False)}
后文（只供理解）：{json.dumps(after, ensure_ascii=False)}

原文：
{source_block}"""
    last: Exception | None = None
    for attempt in range(1, 3):
        try:
            response = requests.post(
                OLLAMA_URL,
                json={"model": model, "messages": [{"role": "user", "content": prompt}],
                      "stream": False, "think": False, "keep_alive": "10m",
                      "options": {"temperature": .1}},
                timeout=timeout,
            )
            response.raise_for_status()
            parsed = parse_labeled_block(response.json()["message"]["content"], labels)
            final = {}
            for label, value in parsed.items():
                item = label_to_item[label]
                # Exact source newlines are preferable but semantic cell
                # alignment is more important. Newline differences go to QA.
                problems = [x for x in structural(item.source, value) if x != "newline_mismatch"]
                if problems:
                    raise ValueError(f"{item.item_id}: {', '.join(problems)}")
                final[item.item_id] = value.strip()
            return final
        except (requests.RequestException, KeyError, ValueError, json.JSONDecodeError) as e:
            last = e
            print(f"  Sakura block attempt {attempt}/2 failed: {e}")
            if attempt < 2:
                time.sleep(2 * attempt)
    raise RuntimeError(f"Sakura block failed after 2 attempts: {last}")


def translate_sakura_adaptive(ad: Adapter, items: list[Item], language: str,
                              model: str, terms: dict[str, str], n: int,
                              timeout: int) -> dict[str, str]:
    """Recursively shrink only a block that Sakura cannot label reliably."""
    if not items:
        return {}
    before, _ = ad.context(items[0], n)
    _, after = ad.context(items[-1], n)
    try:
        return call_sakura(model, language, terms, items, before, after, timeout)
    except RuntimeError:
        if len(items) == 1:
            raise
        middle = len(items) // 2
        left, right = items[:middle], items[middle:]
        print(f"  Sakura could not keep labels; splitting {len(items)} items into {len(left)} + {len(right)}.")
        return {
            **translate_sakura_adaptive(ad, left, language, model, terms, n, timeout),
            **translate_sakura_adaptive(ad, right, language, model, terms, n, timeout),
        }


def groups(items: list[Item], size: int):
    batch: list[Item] = []
    for item in items:
        if batch and (len(batch) >= size or item.group != batch[0].group): yield batch; batch = []
        batch.append(item)
    if batch: yield batch


def translate(ad: Adapter, batch: list[Item], language: str, model: str, terms: dict[str,str],
              n: int, timeout: int, provider: str = "local", api_key: str = "",
              usage_total: DeepSeekUsage | None = None) -> dict[str,str]:
    before, _ = ad.context(batch[0], n); _, after = ad.context(batch[-1], n)
    if provider == "local" and language == "Japanese" and "sakura" in model.lower():
        exact = {x.item_id: terms[x.source] for x in batch if x.source in terms}
        generated_items = [x for x in batch if x.source not in terms]
        generated = translate_sakura_adaptive(ad, generated_items, language, model, terms, n, timeout)
        return {**generated, **exact}
    exact, generated, passthrough, child_ids = {}, {}, {}, {}
    for x in batch:
        if x.source in terms:
            exact[x.item_id] = terms[x.source]
            continue
        ids = []
        for line_number, line in enumerate(x.source.split("\n")):
            child = x.item_id if "\n" not in x.source else f"{x.item_id}#L{line_number:03d}"
            ids.append(child)
            # Blank/whitespace-only child lines carry layout only. Sending them
            # to the model makes a correct empty response look like an
            # empty_translation failure. Keep them byte-for-byte in Python and
            # only ask the model to translate meaning-bearing lines.
            if line.strip():
                generated[child] = line
            else:
                passthrough[child] = line
        child_ids[x.item_id] = ids
    if generated:
        payload = {"context_before":before, "scene_items":generated, "context_after":after}
        system = primary_prompt(language, terms)
        if provider == "deepseek":
            if usage_total is None:
                raise RuntimeError("Internal error: DeepSeek usage tracker is missing")
            made = call_deepseek(model, system, payload, generated, timeout, "translation", api_key, usage_total)
        else:
            made = call(model, system, payload, generated, timeout, "translation")
    else:
        made = {}
    made.update(passthrough)
    rebuilt = {parent: "\n".join(made[child] for child in ids) for parent, ids in child_ids.items()}
    return {**rebuilt, **exact}


def translate_resilient(ad: Adapter, batch: list[Item], language: str, model: str, terms: dict[str,str],
                        n: int, timeout: int, provider: str = "local", api_key: str = "",
                        usage_total: DeepSeekUsage | None = None,
                        failure_records: list[dict[str, Any]] | None = None) -> dict[str, str]:
    """Translate a batch without allowing one permanently bad item to stop the job.

    Normal batches still get the ordinary 3-attempt strict translation path. If that
    path is exhausted, V3.5.4.3 bisects the batch until the failing item is isolated.
    A singleton that still fails is preserved verbatim, recorded for manual review,
    and the rest of the job continues. This is intentionally a last-resort fallback:
    normal omissions, placeholder damage, and malformed responses still retry first.
    """
    try:
        return translate(ad, batch, language, model, terms, n, timeout, provider, api_key, usage_total)
    except RuntimeError as e:
        if len(batch) > 1:
            mid = len(batch) // 2
            left, right = batch[:mid], batch[mid:]
            print(f"  Batch fallback: strict translation failed; isolating {len(batch)} items as {len(left)} + {len(right)}.")
            return {
                **translate_resilient(ad, left, lang(left, language), model, terms, n, timeout, provider, api_key, usage_total, failure_records),
                **translate_resilient(ad, right, lang(right, language), model, terms, n, timeout, provider, api_key, usage_total, failure_records),
            }

        item = batch[0]
        record = {
            "id": item.item_id,
            "source": item.source,
            "translation": item.source,
            "reason": "translation_failed_after_retries",
            "error": str(e),
            "manual_review": True,
        }
        if failure_records is not None:
            failure_records[:] = [r for r in failure_records if r.get("id") != item.item_id]
            failure_records.append(record)
        print(f"  Manual fallback: {item.item_id} still failed after isolation; preserved source and queued for manual review.")
        return {item.item_id: item.source}


def review(ad: Adapter, batch: list[Item], model: str, terms: dict[str,str], n: int, timeout: int,
           provider: str = "local", api_key: str = "",
           usage_total: DeepSeekUsage | None = None, quality: str = "balanced") -> tuple[dict[str,str],dict[str,list[str]],dict[str,str],dict[str,str]]:
    """Review risky translations.

    V3.5 splits review into two modes:
    - ordinary semantic/QA risks: conservative source-vs-draft review;
    - slurred/corrupted speech: independent retranslation with NO draft shown.

    The second path is intentionally isolated so a bad primary translation
    cannot anchor the reviewer.
    """
    normal_candidates, independent_candidates, passthrough = {}, {}, {}
    reasons, sources, child_ids, initial, strategies = {}, {}, {}, {}, {}

    for x in batch:
        draft = ad.get(x)
        why = review_reasons(x.source, draft, quality)
        if not why or x.source in terms:
            continue
        before, after = ad.context(x, n)
        reasons[x.item_id] = why
        initial[x.item_id] = draft
        independent = "slurred_or_corrupted_speech" in why
        strategies[x.item_id] = "independent_retranslation" if independent else "conservative_review"

        source_lines, draft_lines = x.source.split("\n"), draft.split("\n")
        if len(source_lines) != len(draft_lines):
            continue
        ids = []
        for line_number, (source_line, draft_line) in enumerate(zip(source_lines, draft_lines)):
            child = x.item_id if len(source_lines) == 1 else f"{x.item_id}#L{line_number:03d}"
            ids.append(child)
            sources[child] = source_line
            # Layout-only blank lines need no semantic review. Preserve the
            # source whitespace exactly and exclude them from model calls.
            if not source_line.strip():
                passthrough[child] = source_line
                continue
            if independent:
                # Deliberately omit draft. V3.5 keeps this no-draft path, but treats its result as a manual-review candidate rather than an automatic replacement.
                independent_candidates[child] = {
                    "risk_types": why,
                    "context_before": before,
                    "source": source_line,
                    "context_after": after,
                    "mode": "independent_retranslation_no_draft",
                }
            else:
                normal_candidates[child] = {
                    "risk_types": why,
                    "context_before": before,
                    "source": source_line,
                    "draft": draft_line,
                    "context_after": after,
                    "mode": "conservative_source_vs_draft_review",
                }
        child_ids[x.item_id] = ids

    made: dict[str, str] = {}

    def invoke(payload_items: dict[str, Any], system: str, stage: str) -> dict[str, str]:
        if not payload_items:
            return {}
        payload = {"items_to_review": payload_items}
        sub_sources = {key: sources[key] for key in payload_items}
        if provider == "deepseek":
            if usage_total is None:
                raise RuntimeError("Internal error: DeepSeek usage tracker is missing")
            return call_deepseek(model, system, payload, sub_sources, timeout, stage, api_key, usage_total)
        return call(model, system, payload, sub_sources, timeout, stage)

    # Normal review can see the draft because its job is conservative QA.
    made.update(invoke(normal_candidates, review_prompt(terms, quality), "review"))
    # Slurred/corrupted speech is translated from scratch, in a separate call,
    # and the request contains no previous translation at all.
    made.update(invoke(independent_candidates, independent_retranslation_prompt(terms, quality), "independent retranslation"))
    made.update(passthrough)

    rebuilt = {parent:"\n".join(made[child] for child in ids) for parent,ids in child_ids.items()}
    return rebuilt, reasons, initial, strategies

def usage_dict(u: DeepSeekUsage) -> dict[str, int]:
    return {
        "requests": u.requests,
        "prompt_tokens": u.prompt_tokens,
        "cached_tokens": u.cached_tokens,
        "completion_tokens": u.completion_tokens,
    }


def usage_from(data: Any) -> DeepSeekUsage:
    if not isinstance(data, dict):
        return DeepSeekUsage()
    return DeepSeekUsage(
        prompt_tokens=int(data.get("prompt_tokens", 0) or 0),
        cached_tokens=int(data.get("cached_tokens", 0) or 0),
        completion_tokens=int(data.get("completion_tokens", 0) or 0),
        requests=int(data.get("requests", 0) or 0),
    )


def combine_usage(a: DeepSeekUsage, b: DeepSeekUsage) -> DeepSeekUsage:
    return DeepSeekUsage(
        prompt_tokens=a.prompt_tokens + b.prompt_tokens,
        cached_tokens=a.cached_tokens + b.cached_tokens,
        completion_tokens=a.completion_tokens + b.completion_tokens,
        requests=a.requests + b.requests,
    )


def save_all(ad: Adapter, output: Path, qa_path: Path, state_path: Path, selected: list[Item],
             state: dict[str,Any], primary_usage: DeepSeekUsage | None = None,
             review_usage: DeepSeekUsage | None = None, primary_model_for_cost: str = DEEPSEEK_MODEL,
             review_model_for_cost: str | None = None, terms: dict[str, str] | None = None,
             usd_cny_rate: float = DEFAULT_USD_CNY_RATE, budget_rmb: float | None = None) -> None:
    ad.save(output)
    complete = set(state["primary_completed"]); errors = []
    normalized_targets = Counter(
        re.sub(r"\s+", "", ad.get(x)) for x in selected
        if x.item_id in complete and len(re.sub(r"\s+", "", ad.get(x))) >= 12
    )
    for x in selected:
        if x.item_id in complete:
            problems = qa(x.source, ad.get(x))
            if terms:
                problems.extend(glossary_qa(x.source, ad.get(x), terms))
            normalized = re.sub(r"\s+", "", ad.get(x))
            if len(normalized) >= 12 and normalized_targets[normalized] > 1:
                problems.append("duplicate_translation")
            if problems:
                errors.append({"id":x.item_id,"source":x.source,"translation":ad.get(x),"issues":list(dict.fromkeys(problems))})

    advisories = []
    for x in selected:
        if x.item_id not in complete or not (KANA_RE.search(x.source) or KANJI_RE.search(x.source)):
            continue
        broad = risks(x.source, ad.get(x), "balanced")
        paid = review_reasons(x.source, ad.get(x), "balanced")
        advisory_only = [r for r in broad if r not in paid]
        if advisory_only:
            advisories.append({
                "id": x.item_id,
                "source": x.source,
                "translation": ad.get(x),
                "issues": advisory_only,
            })

    usage_block = None
    if primary_usage is not None and review_usage is not None:
        total = combine_usage(primary_usage, review_usage)
        state["usage"] = {"primary": usage_dict(primary_usage), "review": usage_dict(review_usage), "total": usage_dict(total)}
        review_model_for_cost = review_model_for_cost or primary_model_for_cost
        pcost, pperiod = primary_usage.estimated_usd(primary_model_for_cost)
        rcost, rperiod = review_usage.estimated_usd(review_model_for_cost)
        tcost = (pcost + rcost) if pcost is not None and rcost is not None else None
        tperiod = pperiod if pperiod == rperiod else f"{pperiod}/{rperiod}"
        pcny = pcost * usd_cny_rate if pcost is not None else None
        rcny = rcost * usd_cny_rate if rcost is not None else None
        tcny = tcost * usd_cny_rate if tcost is not None else None
        remaining = (budget_rmb - tcny) if budget_rmb is not None and tcny is not None else None
        usage_block = {
            "primary": {**usage_dict(primary_usage), "estimated_usd": pcost, "estimated_rmb": pcny, "pricing_period": pperiod},
            "review": {**usage_dict(review_usage), "estimated_usd": rcost, "estimated_rmb": rcny, "pricing_period": rperiod},
            "total": {**usage_dict(total), "estimated_usd": tcost, "estimated_rmb": tcny, "pricing_period": tperiod},
            "usd_cny_rate": usd_cny_rate,
            "budget_rmb": budget_rmb,
            "estimated_budget_remaining_rmb": remaining,
        }

    manual_review_items = [
        {
            "id": r.get("id"),
            "source": r.get("source"),
            "reason": "slurred_or_corrupted_speech",
            "initial_translation": r.get("initial_translation"),
            "candidate_translation": r.get("candidate_translation"),
            "suspected_reconstruction": r.get("suspected_reconstruction"),
            "manual_review": True,
        }
        for r in state["reviewed_items"]
        if r.get("manual_review")
    ]
    # V3.5.4.3: permanently failing primary items are isolated instead of
    # stopping the whole job. Keep them in the same manual-review artifact.
    for r in state.get("translation_failures", []):
        manual_review_items.append({
            "id": r.get("id"),
            "source": r.get("source"),
            "reason": r.get("reason", "translation_failed_after_retries"),
            "initial_translation": r.get("translation", r.get("source")),
            "candidate_translation": None,
            "suspected_reconstruction": None,
            "error": r.get("error"),
            "manual_review": True,
        })

    write_json(qa_path, {
        "output": str(output),
        "summary": {
            "selected": len(selected),
            "primary_completed": len(complete),
            "review_completed": len(state["review_completed"]),
            "error_count": len(errors),
            "reviewed_count": len(state["reviewed_items"]),
            "review_changed_count": sum(1 for x in state["reviewed_items"] if x.get("changed")),
            "advisory_count": len(advisories),
            "manual_review_count": len(manual_review_items),
            "primary_fallback_count": len(state.get("translation_failures", [])),
        },
        "usage": usage_block,
        "errors": errors,
        "advisories": advisories,
        "manual_review_items": manual_review_items,
        "reviewed_items": state["reviewed_items"],
    })
    manual_review_path = output.with_name(f"{output.name if output.is_dir() else output.stem}_manual_review.json")
    write_json(manual_review_path, {
        "output": str(output),
        "count": len(manual_review_items),
        "items": manual_review_items,
    })
    write_json(state_path, state)



def is_excel_adapter(ad: Adapter) -> bool:
    return isinstance(ad, (ExcelAdapter, ExcelProjectAdapter))


def is_renpy_common_item(x: Item, ad: Adapter) -> bool:
    """Return True for Ren'Py's bundled common-library workbooks in project mode."""
    if not isinstance(ad, ExcelProjectAdapter):
        return False
    rel = str(x.locator[0]).replace("\\", "/").casefold()
    return rel.startswith("renpy/common/")


def source_language_profile(items: list[Item], translate_technical: bool, ad: Adapter, overwrite: bool,
                            include_renpy_common: bool = False, repair_existing: bool = False,
                            terms: dict[str, str] | None = None) -> dict[str, int]:
    """Count likely source-language candidates before the requested-language filter."""
    counts = {"Japanese": 0, "English": 0, "Mixed": 0, "Other": 0}
    terms = terms or {}
    for x in items:
        if not include_renpy_common and is_renpy_common_item(x, ad):
            continue
        if not translate_technical and technical_for_adapter(x.source, ad):
            continue
        if repair_existing:
            current = ad.get(x).strip()
            needs_repair = (not current or current == x.source or bool(glossary_qa(x.source, current, terms)))
            if not needs_repair:
                continue
        elif not ad.pending(x, overwrite):
            continue
        has_jp = bool(KANA_RE.search(x.source) or KANJI_RE.search(x.source))
        has_en = bool(re.search(r"[A-Za-z]", x.source))
        if has_jp and has_en:
            counts["Mixed"] += 1
        elif has_jp:
            counts["Japanese"] += 1
        elif has_en:
            counts["English"] += 1
        else:
            counts["Other"] += 1
    return counts


def deduplicate_excel_candidates(items: list[Item]) -> tuple[list[Item], dict[str, list[str]], int]:
    """Return one representative per exact source string plus rep->all item IDs.

    Deduplication is deliberately exact and project-wide. This keeps repeated names/UI
    text consistent while avoiding fuzzy merges that could collapse context-sensitive
    strings. The first occurrence remains the representative used for model context.
    """
    first_by_source: dict[str, Item] = {}
    targets: dict[str, list[str]] = {}
    unique: list[Item] = []
    duplicate_rows = 0
    for x in items:
        rep = first_by_source.get(x.source)
        if rep is None:
            first_by_source[x.source] = x
            unique.append(x)
            targets[x.item_id] = [x.item_id]
        else:
            targets[rep.item_id].append(x.item_id)
            duplicate_rows += 1
    return unique, targets, duplicate_rows


def apply_translation_with_aliases(ad: Adapter, rep: Item, value: str,
                                   dedup_targets: dict[str, list[str]], by_id: dict[str, Item]) -> None:
    """Write one translated value to the representative and every exact duplicate row."""
    ids = dedup_targets.get(rep.item_id, [rep.item_id])
    for item_id in ids:
        target = by_id.get(item_id)
        if target is not None:
            ad.set(target, value)


def main() -> int:
    a = arguments()
    inp = a.input.expanduser().resolve()
    if a.output is not None:
        out = a.output.expanduser().resolve()
    elif inp.is_dir():
        out = inp.with_name(f"{inp.name}_translated").resolve()
    else:
        out = inp.with_name(f"{inp.stem}_translated{inp.suffix}").resolve()
    qa_path = (a.qa_report or out.with_name(f"{out.name if out.is_dir() else out.stem}_qa.json")).expanduser().resolve()
    state_path = (a.state_file or out.with_name(f"{out.name}.state.json")).expanduser().resolve()

    if not inp.exists(): print(f"Error: input not found: {inp}"); return 1
    if inp == out: print("Error: output must differ from input"); return 1
    if a.resume and not out.exists(): print(f"Error: resume output missing: {out}"); return 1
    if out.exists() and not a.resume and not a.dry_run:
        print(f"Error: output exists: {out}\nUse --resume or another --output."); return 1

    try:
        ad = adapter(out if a.resume else inp)
        terms = glossary(a.glossary)
    except ValueError as e:
        print(f"Error: {e}"); return 1

    if a.restore_renpy_common_from is not None:
        restore_root = a.restore_renpy_common_from.expanduser().resolve()
        if not isinstance(ad, ExcelProjectAdapter):
            print("Error: --restore-renpy-common-from requires a Translator++ project directory input"); return 1
        if not (restore_root / "renpy" / "common").is_dir():
            print(f"Error: original renpy/common directory not found under: {restore_root}"); return 1
        ad.restore_renpy_common_from = restore_root

    all_items = ad.items(); by_id = {x.item_id:x for x in all_items}
    try:
        mtool_line_ranges = parse_line_ranges(a.mtool_line_range, a.mtool_line_ranges)
    except ValueError as e:
        print(f"Error: {e}"); return 1
    if mtool_line_ranges and not isinstance(ad, MToolAdapter):
        print("Error: --mtool-line-range/--mtool-line-ranges are only valid for MTool JSON input"); return 1

    language_profile = source_language_profile(
        all_items, a.translate_technical, ad, a.overwrite_existing,
        include_renpy_common=a.include_renpy_common,
        repair_existing=a.repair_existing, terms=terms,
    )

    def row_needs_work(x: Item) -> bool:
        if a.repair_existing:
            current = ad.get(x).strip()
            return (not current or current == x.source or bool(glossary_qa(x.source, current, terms)))
        return ad.pending(x, a.overwrite_existing)

    eligible_rows = [
        x for x in all_items
        if (a.include_renpy_common or not is_renpy_common_item(x, ad))
        and (a.translate_technical or not technical_for_adapter(x.source, ad))
        and matches_requested_language(x.source, a.source_language)
        and (not isinstance(ad, MToolAdapter) or in_mtool_scope(x, mtool_line_ranges, a.include_outside_ui))
        and row_needs_work(x)
    ]

    # An explicit glossary is authoritative. Exact source matches do not need
    # an API call at all; they can be written deterministically and consistently.
    glossary_exact_rows = [x for x in eligible_rows if x.source in terms and terms[x.source].strip()]
    glossary_exact_ids = {x.item_id for x in glossary_exact_rows}
    api_eligible_rows = [x for x in eligible_rows if x.item_id not in glossary_exact_ids]
    if not a.dry_run and not a.resume:
        for x in glossary_exact_rows:
            ad.set(x, terms[x.source])

    dedup_targets: dict[str, list[str]] = {}
    duplicate_rows_saved = 0
    if is_excel_adapter(ad):
        eligible, dedup_targets, duplicate_rows_saved = deduplicate_excel_candidates(api_eligible_rows)
    else:
        eligible = api_eligible_rows
        dedup_targets = {x.item_id: [x.item_id] for x in eligible}

    if a.resume:
        if not state_path.exists(): print(f"Error: state missing: {state_path}"); return 1
        try:
            state = read_object(state_path, "state")
            selected = [by_id[x] for x in state["selected_ids"] if x in by_id]
            saved_targets = state.get("dedup_targets", {})
            dedup_targets = {
                rep_id: [item_id for item_id in ids if item_id in by_id]
                for rep_id, ids in saved_targets.items() if rep_id in by_id and isinstance(ids, list)
            } or {x.item_id: [x.item_id] for x in selected}
            duplicate_rows_saved = sum(max(0, len(ids) - 1) for ids in dedup_targets.values())
            saved = state.get("settings", {})
            a.source_language = saved.get("source_language", a.source_language)
            a.quality = saved.get("quality", a.quality)
            a.japanese_model = saved.get("japanese_model", a.japanese_model)
            a.english_model = saved.get("english_model", a.english_model)
            a.review_model = saved.get("review_model", a.review_model)
            a.provider = saved.get("provider", a.provider)
            a.deepseek_model = saved.get("deepseek_model", a.deepseek_model)
            a.deepseek_review_model = saved.get("deepseek_review_model", a.deepseek_review_model)
            a.batch_size = saved.get("batch_size", a.batch_size)
            a.context_size = saved.get("context_size", a.context_size)
            a.timeout = saved.get("timeout", a.timeout)
            a.start = saved.get("start", a.start)
            a.mtool_line_range = saved.get("mtool_line_range", a.mtool_line_range)
            a.mtool_line_ranges = saved.get("mtool_line_ranges", a.mtool_line_ranges)
            a.include_outside_ui = saved.get("include_outside_ui", a.include_outside_ui)
            a.include_renpy_common = saved.get("include_renpy_common", a.include_renpy_common)
            a.repair_existing = saved.get("repair_existing", a.repair_existing)
            mtool_line_ranges = parse_line_ranges(a.mtool_line_range, a.mtool_line_ranges)
            if a.glossary is None and saved.get("glossary"):
                a.glossary = Path(saved["glossary"]); terms = glossary(a.glossary)
            a.usd_cny_rate = float(saved.get("usd_cny_rate", a.usd_cny_rate))
            if a.budget_rmb is None and saved.get("budget_rmb") is not None:
                a.budget_rmb = float(saved["budget_rmb"])
        except (ValueError, KeyError) as e:
            print(f"Error: invalid state: {e}"); return 1
    else:
        window = eligible[a.start:]
        selected = window[:a.limit] if a.limit else window
        state = {
            "version": 17,
            "input": str(inp),
            "output": str(out),
            "selected_ids": [x.item_id for x in selected],
            "dedup_targets": {x.item_id: dedup_targets.get(x.item_id, [x.item_id]) for x in selected},
            "primary_completed": [],
            "review_completed": [],
            "reviewed_items": [],
            "translation_failures": [],
            "usage": {"primary": {}, "review": {}, "total": {}},
            "settings": {
                "source_language": a.source_language,
                "quality": a.quality,
                "provider": a.provider,
                "deepseek_model": a.deepseek_model,
                "deepseek_review_model": a.deepseek_review_model,
                "japanese_model": a.japanese_model,
                "english_model": a.english_model,
                "review_model": a.review_model,
                "batch_size": a.batch_size,
                "context_size": a.context_size,
                "timeout": a.timeout,
                "start": a.start,
                "mtool_line_range": a.mtool_line_range,
                "mtool_line_ranges": a.mtool_line_ranges,
                "include_outside_ui": a.include_outside_ui,
                "include_renpy_common": a.include_renpy_common,
                "repair_existing": a.repair_existing,
                "restore_renpy_common_from": str(a.restore_renpy_common_from.expanduser().resolve()) if a.restore_renpy_common_from else None,
                "glossary": str(a.glossary.expanduser().resolve()) if a.glossary else None,
                "usd_cny_rate": a.usd_cny_rate,
                "budget_rmb": a.budget_rmb,
                "input_kind": ad.kind,
            },
        }

    if isinstance(ad, MToolAdapter):
        selected = regroup_mtool(selected)
        ad.active_items = selected

    state.setdefault("translation_failures", [])
    completed, reviewed = set(state["primary_completed"]), set(state["review_completed"])
    pending = [x for x in selected if x.item_id not in completed]
    usage_saved = state.get("usage", {})
    primary_usage = usage_from(usage_saved.get("primary"))
    review_usage = usage_from(usage_saved.get("review"))

    api_key = ""
    if a.provider == "deepseek" and not a.dry_run:
        try: api_key = load_deepseek_key()
        except RuntimeError as e: print(f"Error: {e}"); return 1

    print(f"Format: {ad.kind}\nReading: {out if a.resume else inp}\nEntries: {len(all_items)}")
    if isinstance(ad, ExcelProjectAdapter):
        print(f"Translator++ workbooks: {len(ad.workbook_paths)}")
        print(f"Translator++ sheets skipped: {len(ad.skipped_sheets)}")
        print(f"Translator++ workbooks skipped: {len(ad.skipped_workbooks)}")
        for rel in ad.workbook_paths[:8]:
            print(f"  XLSX: {rel}")
        if len(ad.workbook_paths) > 8:
            print(f"  ... and {len(ad.workbook_paths) - 8} more")
        renpy_common_rows = sum(is_renpy_common_item(x, ad) for x in all_items)
        if not a.include_renpy_common:
            print(f"Ren'Py common rows skipped by default: {renpy_common_rows}")
        if a.restore_renpy_common_from is not None:
            print(f"Ren'Py common workbooks restored from: {a.restore_renpy_common_from.expanduser().resolve()}")
    print(f"Technical skipped: {sum(technical_for_adapter(x.source, ad) for x in all_items if a.include_renpy_common or not is_renpy_common_item(x, ad)) if not a.translate_technical else 0}")
    if a.repair_existing:
        print(f"Repair mode candidates before glossary/dedup: {len(eligible_rows)}")
    if is_excel_adapter(ad):
        print("Detected source-language candidates: "
              f"English={language_profile['English']}, Japanese={language_profile['Japanese']}, "
              f"Mixed={language_profile['Mixed']}, Other={language_profile['Other']}")
        print(f"Eligible Translator++ rows before glossary/dedup: {len(eligible_rows)}")
        print(f"Exact glossary rows resolved locally: {len(glossary_exact_rows)}")
        print(f"API-eligible rows before dedup: {len(api_eligible_rows)}")
        print(f"Unique API source texts: {len(eligible)}")
        print(f"Duplicate hits saved: {duplicate_rows_saved}")
        if a.source_language in ("English", "Japanese") and not eligible:
            opposite = "English" if a.source_language == "Japanese" else "Japanese"
            requested_count = language_profile.get(a.source_language, 0) + language_profile.get("Mixed", 0)
            opposite_count = language_profile.get(opposite, 0) + language_profile.get("Mixed", 0)
            if requested_count == 0 and opposite_count > 0:
                print(f"WARNING: no {a.source_language} candidates matched; project appears to contain {opposite} text. "
                      f"Try --source-language {opposite} or auto.")
    if isinstance(ad, MToolAdapter) and mtool_line_ranges:
        story_candidates = [
            x for x in all_items
            if line_in_ranges(mtool_json_line(x), mtool_line_ranges)
            and (a.translate_technical or not technical_for_adapter(x.source, ad))
            and matches_requested_language(x.source, a.source_language)
            and ad.pending(x, a.overwrite_existing)
        ]
        ui_candidates = [
            x for x in all_items
            if not line_in_ranges(mtool_json_line(x), mtool_line_ranges)
            and a.include_outside_ui
            and x.source.strip() in PLAYER_UI_EXACT
            and (a.translate_technical or not technical_for_adapter(x.source, ad))
            and matches_requested_language(x.source, a.source_language)
            and ad.pending(x, a.overwrite_existing)
        ]
        outside_language_candidates = [
            x for x in all_items
            if not line_in_ranges(mtool_json_line(x), mtool_line_ranges)
            and (a.translate_technical or not technical_for_adapter(x.source, ad))
            and matches_requested_language(x.source, a.source_language)
            and ad.pending(x, a.overwrite_existing)
        ]
        print(f"MTool translation line ranges: {format_line_ranges(mtool_line_ranges)}")
        print(f"In-range candidates: {len(story_candidates)}")
        print(f"Outside-range UI included: {len(ui_candidates)}")
        print(f"Outside-range Japanese candidates skipped: {max(0, len(outside_language_candidates) - len(ui_candidates))}")
        print(f"API candidates before --start/--limit: {len(story_candidates) + len(ui_candidates)}")
    print(f"Eligible entries skipped by --start: {a.start}\nSelected: {len(selected)}\nPrimary remaining: {len(pending)}")
    if is_excel_adapter(ad):
        selected_rows = sum(len(dedup_targets.get(x.item_id, [x.item_id])) for x in selected)
        print(f"Selected Translator++ rows represented: {selected_rows}")
        print(f"API unique texts selected: {len(selected)}")
    print(f"Quality: {a.quality}; batch={a.batch_size}; context={a.context_size}; provider={a.provider}")
    if a.provider == "deepseek":
        print(f"DeepSeek primary: {a.deepseek_model} (thinking disabled)")
        print(f"DeepSeek output guard: dynamic max_tokens, hard cap={DEEPSEEK_MAX_OUTPUT_TOKENS}")
        print(f"RMB cost report: 1 USD≈¥{a.usd_cny_rate:.4f}" + (f"; budget=¥{a.budget_rmb:.2f}" if a.budget_rmb is not None else ""))
        if a.quality == "balanced":
            print(f"Selective reviewer: {a.deepseek_model} via DeepSeek")
            print("Balanced review policy: selective hard QA + substantial residue + long high-risk semantics; slurred speech uses independent no-draft retranslation")
        if a.quality == "high": print(f"Independent expert reviewer: {a.deepseek_review_model} via DeepSeek (stricter selective review + no-draft slurred retranslation)")
    else:
        print(f"Japanese: {a.japanese_model}\nEnglish: {a.english_model}")
        if a.quality != "fast": print(f"Selective reviewer: {a.review_model}")

    if a.dry_run:
        print("Dry run: no API call or output.")
        for x in selected[:10]: print(f"  {x.item_id}: {x.source.replace(chr(10), '<NL>')[:100]}")
        return 0

    if not a.resume:
        save_all(ad, out, qa_path, state_path, selected, state, primary_usage, review_usage, a.deepseek_model, (a.deepseek_model if a.quality != "high" else a.deepseek_review_model), terms=terms, usd_cny_rate=a.usd_cny_rate, budget_rmb=a.budget_rmb)
        print(f"Created checkpoint: {out}")

    try:
        done = len(completed)
        for number, batch in enumerate(groups(pending, a.batch_size), 1):
            language = lang(batch, a.source_language)
            model = a.deepseek_model if a.provider == "deepseek" else chosen_model(language, a)
            print(f"Primary batch {number}: {done+1}-{done+len(batch)}/{len(selected)} with {model} ({language})")
            result = translate_resilient(
                ad, batch, language, model, terms, a.context_size, a.timeout,
                provider=a.provider, api_key=api_key, usage_total=primary_usage,
                failure_records=state["translation_failures"],
            )
            for x in batch:
                apply_translation_with_aliases(ad, x, result[x.item_id], dedup_targets, by_id)
                completed.add(x.item_id)
            state["primary_completed"] = sorted(completed); done += len(batch)
            save_all(ad,out,qa_path,state_path,selected,state,primary_usage,review_usage,a.deepseek_model,(a.deepseek_model if a.quality != "high" else a.deepseek_review_model), terms=terms, usd_cny_rate=a.usd_cny_rate, budget_rmb=a.budget_rmb)
            print(f"  Checkpoint saved ({done}/{len(selected)}).")
            if a.provider == "deepseek": print(f"  Primary {primary_usage.line(a.deepseek_model, a.usd_cny_rate)}")

        if a.quality != "fast":
            candidates = [
                x for x in selected
                if x.item_id in completed
                and x.item_id not in reviewed
                and lang([x], a.source_language) == "Japanese"
                and review_reasons(x.source, ad.get(x), a.quality)
            ]
            review_total = len(candidates) + len(reviewed)
            review_rate = (100.0 * review_total / len(selected)) if selected else 0.0
            print(f"Deferred review candidates: {review_total}/{len(selected)} ({review_rate:.1f}%); remaining {len(candidates)}")
            for number, batch in enumerate(groups(candidates, a.batch_size), 1):
                if a.provider == "deepseek":
                    review_model = a.deepseek_model if a.quality == "balanced" else a.deepseek_review_model
                else:
                    review_model = a.review_model
                print(f"Review batch {number}: {len(batch)} item(s) with {review_model}")
                result, why, initial, strategies = review(
                    ad,batch,review_model,terms,a.context_size,a.timeout,
                    provider=a.provider, api_key=api_key, usage_total=review_usage, quality=a.quality
                )
                for x in batch:
                    before = initial.get(x.item_id, ad.get(x))
                    strategy = strategies.get(x.item_id, "conservative_review")
                    candidate = result.get(x.item_id)

                    # V3.5 safety rule: independent retranslation is advisory only.
                    # It must never silently overwrite the primary translation.
                    if candidate is not None and strategy != "independent_retranslation":
                        apply_translation_with_aliases(ad, x, candidate, dedup_targets, by_id)
                    after = ad.get(x)

                    reviewed.add(x.item_id)
                    record = {
                        "id": x.item_id,
                        "source": x.source,
                        "initial_translation": before,
                        "final_translation": after,
                        "changed": before != after,
                        "reasons": why.get(x.item_id, []),
                        "review_strategy": strategy,
                    }
                    if strategy == "independent_retranslation":
                        record["candidate_translation"] = candidate
                        record["manual_review"] = bool(candidate and candidate != before)
                        record["suspected_reconstruction"] = None
                    state["reviewed_items"] = [r for r in state["reviewed_items"] if r.get("id") != x.item_id]
                    state["reviewed_items"].append(record)
                state["review_completed"] = sorted(reviewed)
                save_all(ad,out,qa_path,state_path,selected,state,primary_usage,review_usage,a.deepseek_model,(a.deepseek_model if a.quality != "high" else a.deepseek_review_model), terms=terms, usd_cny_rate=a.usd_cny_rate, budget_rmb=a.budget_rmb)
                remaining_review = max(0, review_total - len(reviewed))
                review_pct = (100.0 * len(reviewed) / review_total) if review_total else 100.0
                print(f"  Review checkpoint saved ({len(reviewed)}/{review_total}, {review_pct:.1f}%; remaining {remaining_review}).")
                if a.provider == "deepseek": print(f"  Review {review_usage.line(review_model, a.usd_cny_rate)}")

    except KeyboardInterrupt:
        save_all(ad,out,qa_path,state_path,selected,state,primary_usage,review_usage,a.deepseek_model,(a.deepseek_model if a.quality != "high" else a.deepseek_review_model), terms=terms, usd_cny_rate=a.usd_cny_rate, budget_rmb=a.budget_rmb)
        print(f"\nStopped; checkpoints saved. Resume with:\npython {Path(__file__).name} {inp.name} --output {out.name} --resume")
        return 130
    except RuntimeError as e:
        save_all(ad,out,qa_path,state_path,selected,state,primary_usage,review_usage,a.deepseek_model,(a.deepseek_model if a.quality != "high" else a.deepseek_review_model), terms=terms, usd_cny_rate=a.usd_cny_rate, budget_rmb=a.budget_rmb)
        print(f"Translation stopped: {e}\nCompleted batches remain saved; use --resume.")
        return 1

    save_all(ad,out,qa_path,state_path,selected,state,primary_usage,review_usage,a.deepseek_model,(a.deepseek_model if a.quality != "high" else a.deepseek_review_model), terms=terms, usd_cny_rate=a.usd_cny_rate, budget_rmb=a.budget_rmb)
    if a.provider == "deepseek":
        total = combine_usage(primary_usage, review_usage)
        print(f"Primary {primary_usage.line(a.deepseek_model, a.usd_cny_rate)}")
        review_model = a.deepseek_model if a.quality != "high" else a.deepseek_review_model
        print(f"Review  {review_usage.line(review_model, a.usd_cny_rate)}")
        pcost, period1 = primary_usage.estimated_usd(a.deepseek_model)
        rcost, period2 = review_usage.estimated_usd(review_model)
        total_cost = (pcost + rcost) if pcost is not None and rcost is not None else None
        if total_cost is not None:
            total_rmb = total_cost * a.usd_cny_rate
            total_cost_text = f"${total_cost:.6f} / ¥{total_rmb:.6f} estimated (1 USD≈¥{a.usd_cny_rate:.4f})"
        else:
            total_rmb = None
            total_cost_text = "cost estimate unavailable"
        print(f"Total   DeepSeek usage: requests={total.requests}, input={total.prompt_tokens} "
              f"(cached={total.cached_tokens}, miss={total.miss_tokens}), output={total.completion_tokens}, {total_cost_text}")
        if a.budget_rmb is not None and total_rmb is not None:
            remaining = a.budget_rmb - total_rmb
            used_pct = 100.0 * total_rmb / a.budget_rmb
            print(f"Budget  RMB: ¥{a.budget_rmb:.2f}; estimated spent=¥{total_rmb:.6f} ({used_pct:.2f}%); remaining=¥{remaining:.6f}")
    manual_review_path = out.with_name(f"{out.name if out.is_dir() else out.stem}_manual_review.json")
    manual_review_count = (
        sum(1 for item in state.get("reviewed_items", []) if item.get("manual_review"))
        + len(state.get("translation_failures", []))
    )
    print(
        f"Translation completed.\n"
        f"Output: {out}\n"
        f"QA: {qa_path}\n"
        f"Manual review: {manual_review_count} item(s)\n"
        f"Manual review file: {manual_review_path}\n"
        f"State: {state_path}"
    )
    return 0


if __name__ == "__main__": sys.exit(main())
