from __future__ import annotations
import shutil, subprocess, sys
from pathlib import Path
from decompilers.base import DecompilerBackend, DecompileResult

class UnrpycBackend(DecompilerBackend):
    """
    External CLI backend. Prefer explicit --unrpyc; otherwise use the bundled
    user-supplied checkout with its original license.
    """
    name = "unrpyc"

    def __init__(self, unrpyc_path: str | None):
        bundled=Path(__file__).resolve().parent.parent/'vendor/unrpyc/unrpyc.py'
        self.path = Path(unrpyc_path).expanduser().resolve() if unrpyc_path else (bundled if bundled.is_file() else None)

    def available(self):
        if not self.path:
            return False, "No unrpyc.py configured."
        if not self.path.is_file():
            return False, f"unrpyc.py not found: {self.path}"
        modules = self.path.parent / "decompiler"
        if not modules.exists():
            return False, f"Official unrpyc checkout appears incomplete (missing {modules})."
        if sys.version_info < (3, 9):
            return False, f"Python {sys.version.split()[0]} is too old for unrpyc v2; Python 3.9+ required."
        return True, f"Using {self.path}"

    def decompile_tree(self, source_dir: Path, output_dir: Path, try_harder=False):
        ok, why = self.available()
        if not ok:
            return DecompileResult(self.name, warnings=[why])

        source_dir = Path(source_dir).resolve()
        output_dir = Path(output_dir).resolve()
        output_dir.mkdir(parents=True, exist_ok=True)

        compiled = sorted(list(source_dir.rglob("*.rpyc")) + list(source_dir.rglob("*.rpymc")))
        result = DecompileResult(self.name, attempted=len(compiled))
        if not compiled:
            return result

        # Work only on copies. unrpyc writes .rpy beside .rpyc.
        for f in compiled:
            rel = f.relative_to(source_dir)
            target = output_dir / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(f, target)

        cmd = [sys.executable, str(self.path), "-c"]
        if try_harder:
            cmd.append("--try-harder")
        cmd.append(str(output_dir))
        proc = subprocess.run(cmd, text=True, capture_output=True)
        result.stdout = proc.stdout
        result.stderr = proc.stderr

        generated = sorted(output_dir.rglob("*.rpy")) + sorted(output_dir.rglob("*.rpym"))
        result.generated = generated
        result.succeeded = len(generated)
        result.failed = max(0, result.attempted - result.succeeded)
        if proc.returncode != 0:
            result.warnings.append(f"unrpyc exited with status {proc.returncode}.")
        if result.failed:
            result.warnings.append(f"{result.failed} compiled script(s) did not produce source output.")
        return result
