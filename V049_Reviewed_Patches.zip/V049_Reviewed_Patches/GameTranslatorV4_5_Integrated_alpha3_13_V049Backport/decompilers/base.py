from dataclasses import dataclass, field
from pathlib import Path

@dataclass
class DecompileResult:
    backend: str
    attempted: int = 0
    succeeded: int = 0
    failed: int = 0
    generated: list[Path] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    stdout: str = ""
    stderr: str = ""

class DecompilerBackend:
    name = "unknown"
    def available(self) -> tuple[bool, str]:
        raise NotImplementedError
    def decompile_tree(self, source_dir: Path, output_dir: Path, **kwargs) -> DecompileResult:
        raise NotImplementedError
