# alpha3.11 VX Ace shared choices

- Admit shared 102/402 string objects only with complete, single-choice ownership proof.
- Reject strings with unknown references and descendants of shared containers.
- Preserve all existing unit IDs and metadata; migrate old work to a new workspace to add newly discovered units.
- Protect ChoiceEX if()/en() condition expressions in prompts and validation.
- Reviewed Wind V0.50 labels and an idempotent Main display hook cover supported old-save choice display without altering branch indices or fonts.
- Report extracted/pending choices separately. Existing migration and layout supplements remain active.
- No API calls made during development or offline verification. Windows runtime verification remains required.
