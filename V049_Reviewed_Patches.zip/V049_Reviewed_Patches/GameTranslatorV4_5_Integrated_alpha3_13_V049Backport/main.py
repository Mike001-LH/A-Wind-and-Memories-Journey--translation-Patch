import argparse, json, shutil, tempfile
from collections import Counter
from dataclasses import asdict
from pathlib import Path
from core.detector import EngineDetector
from core.normalizer import normalize_units
from decompilers.unrpyc_backend import UnrpycBackend

VERSION="4.0.0-alpha8.2"

def copy_direct_compiled(game_root: Path, workspace: Path):
    src = game_root/"game"
    dst = workspace/"compiled"
    dst.mkdir(parents=True, exist_ok=True)
    copied=0
    for pat in ("*.rpyc","*.rpymc"):
        for f in src.rglob(pat):
            if "/tl/" in f"/{f.relative_to(game_root).as_posix()}/":
                continue
            rel=f.relative_to(src)
            t=dst/rel; t.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(f,t); copied+=1
    return dst,copied

def main():
    p=argparse.ArgumentParser(description="Game Translator V4 alpha3 - Ren'Py decompiler pipeline")
    p.add_argument("game")
    p.add_argument("--analyze",action="store_true")
    p.add_argument("--inspect-archives",action="store_true")
    p.add_argument("--workspace",help="Workspace directory; original game is never modified")
    p.add_argument("--unrpyc",help="Path to official CensoredUsername/unrpyc/unrpyc.py")
    p.add_argument("--decompile",action="store_true",help="Copy RPYC into workspace and decompile there")
    p.add_argument("--try-harder",action="store_true",help="Pass unrpyc --try-harder")
    p.add_argument("--dump-units")
    p.add_argument("--dump-qa", help="Write normalization/QA report JSON")
    a=p.parse_args()

    game=Path(a.game).expanduser().resolve()
    if not game.is_dir(): raise SystemExit(f"Not a directory: {game}")
    d,adapter=EngineDetector().best_adapter(game)
    print(f"Game Translator V{VERSION}\nScanning: {game}")
    print(f"\nEngine\n  {d.engine}\n  Confidence: {d.confidence} ({d.score}%)")
    print("\nPlatforms\n  "+"\n  ".join(d.platforms))
    print("\nEvidence")
    for e in d.evidence: print("  ✓",e)
    if adapter is None: raise SystemExit("\nNo supported engine detected.")

    reports=adapter.inspect_archives(game)
    if a.inspect_archives or a.analyze:
        print("\nArchives")
        if not reports: print("  None")
        for r in reports:
            if r["error"]: print(f"  ✗ {r['path'].name}: {r['error']}")
            else: print(f"  ✓ {r['path'].name}: RPA-{r['version']}, {r['members']} members, {len(r['scripts'])} script member(s)")

    result=adapter.analyze(game)
    units=list(result.units)

    print(f"\nContent\n  Direct RPY scanned: {result.scripts_scanned}")
    print(f"  Direct RPYC found: {result.compiled_scripts}")
    print(f"  RPA archives: {result.archives}")
    print(f"  RPA members: {result.archive_members}")
    print(f"  Archived compiled scripts: {result.archived_compiled_scripts}")

    if a.decompile:
        if not a.workspace:
            raise SystemExit("\n--decompile requires --workspace so original game is never touched.")
        ws=Path(a.workspace).expanduser().resolve()
        ws.mkdir(parents=True,exist_ok=True)
        compiled_dir,copied=copy_direct_compiled(game,ws)
        # Extract archived script members into the same isolated compiled tree.
        for rep in reports:
            if rep["error"] or not rep["scripts"]: continue
            from engines.rpa import RPAArchive
            RPAArchive(rep["path"]).load().extract_scripts(compiled_dir)
        print(f"\nWorkspace\n  {ws}\n  Direct compiled scripts copied: {copied}")

        backend=UnrpycBackend(a.unrpyc)
        ok,why=backend.available()
        print(f"\nDecompiler\n  Backend: unrpyc\n  Available: {'yes' if ok else 'no'}\n  {why}")
        if ok:
            dec=backend.decompile_tree(compiled_dir,ws/"decompiled",try_harder=a.try_harder)
            print(f"  Attempted: {dec.attempted}\n  Generated RPY/RPYM: {dec.succeeded}\n  Failed: {dec.failed}")
            for w in dec.warnings: print("  ⚠",w)
            if dec.stderr.strip():
                print("\nDecompiler stderr (tail)")
                print("\n".join(dec.stderr.strip().splitlines()[-12:]))

            # Build a complete isolated source mirror for the writer. Direct .rpy
            # sources are copied first, then decompiled scripts overlay them. This
            # is required for source-distributed Ren'Py games (0 RPYC is valid).
            virtual=ws/"virtual_game"
            shutil.rmtree(virtual,ignore_errors=True)
            (virtual/"game").mkdir(parents=True)
            direct_copied=0
            source_game=game/"game"
            if source_game.is_dir():
                for f in source_game.rglob("*.rpy"):
                    if "/tl/" in f"/{f.relative_to(game).as_posix()}/":
                        continue
                    rel=f.relative_to(source_game)
                    t=virtual/"game"/rel; t.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(f,t)
                    direct_copied += 1
            decompiled_copied=0
            for f in (ws/"decompiled").rglob("*.rpy"):
                rel=f.relative_to(ws/"decompiled")
                t=virtual/"game"/rel; t.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(f,t)
                decompiled_copied += 1
            # Only parse decompiled material here; direct sources were already
            # parsed above. Parsing the full mirror would duplicate all units.
            if decompiled_copied:
                dec_virtual=ws/"decompiled_virtual"
                shutil.rmtree(dec_virtual,ignore_errors=True); (dec_virtual/"game").mkdir(parents=True)
                for f in (ws/"decompiled").rglob("*.rpy"):
                    rel=f.relative_to(ws/"decompiled")
                    t=dec_virtual/"game"/rel; t.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(f,t)
                parsed=adapter.analyze(dec_virtual)
                units.extend(parsed.units)
                parsed_count=parsed.scripts_scanned; parsed_units=len(parsed.units)
            else:
                parsed_count=0; parsed_units=0
            print(f"\nWorkspace source mirror\n  Direct RPY copied: {direct_copied}\n  Decompiled RPY copied: {decompiled_copied}")
            print(f"\nDecompiled text extraction\n  RPY scanned: {parsed_count}\n  Translation units: {parsed_units}")

    raw_kinds=Counter(u.metadata.get("kind","unknown") for u in units)
    print(f"\nRaw extraction: {len(units)}")
    print(f"  Dialogue: {raw_kinds['dialogue']}\n  Menu choices: {raw_kinds['menu']}\n  UI strings: {raw_kinds['ui_string']}\n  Screen text: {raw_kinds['screen_text']}\n  Character names: {raw_kinds['character_name']}")

    normalized, qa = normalize_units(units)
    print("\nNormalization / QA")
    print(f"  Extracted: {qa.extracted}")
    print(f"  Technical skipped: {qa.technical_skipped}")
    print(f"  Duplicate occurrences: {qa.duplicate_occurrences}")
    print(f"  Unique translatable: {qa.unique_translatable}")
    print(f"  Safe: {qa.safe}")
    print(f"  Caution: {qa.caution}")
    print(f"  Protected-token units: {qa.protected_token_units}")
    print("  Unique by kind:")
    for k,v in sorted(qa.by_kind.items()):
        print(f"    {k}: {v}")

    if normalized:
        print("\nFirst normalized candidates")
        for u in normalized[:12]:
            print(f"  {u.file}:{u.metadata.get('line')} [{u.metadata.get('kind')}/{u.metadata.get('risk')}] {u.source}")

    if a.dump_units:
        out=Path(a.dump_units).expanduser().resolve(); out.parent.mkdir(parents=True,exist_ok=True)
        out.write_text(json.dumps([asdict(u) for u in normalized],ensure_ascii=False,indent=2),encoding="utf-8")
        print("\nNormalized units JSON:",out)
    if a.dump_qa:
        out=Path(a.dump_qa).expanduser().resolve(); out.parent.mkdir(parents=True,exist_ok=True)
        out.write_text(json.dumps(asdict(qa),ensure_ascii=False,indent=2),encoding="utf-8")
        print("QA JSON:",out)

if __name__=="__main__": main()
