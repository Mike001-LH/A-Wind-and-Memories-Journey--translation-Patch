"""Display recorded cost estimates; incomplete usage is never claimed as actual billing."""
from decimal import Decimal
from bruns.translate import cost_cny

class CostDisplay:
    def __init__(self,state,budget,band,rates=None):
        self.state=state;self.budget=Decimal(str(budget));self.band=band
        self.rates=[Decimal(str(r)) for r in rates] if rates is not None else None
        self.session=Decimal('0');self.total=Decimal(str(state.get('spent_rmb') or 0))
        state['session_spent_rmb']=0.
        self.summary(Decimal('0'))
        rate_label='用户指定费率' if self.rates is not None else f'沿用旧版 {band} 费率'
        print(f'费用估算启动 | 本次预算 ¥{self.budget:.2f} | 历史已记录 ¥{self.total:.6f} | {rate_label}；实际扣费以供应商账户为准',flush=True)
        if state.get('api_usage_without_price') or state.get('cost_usage_missing'):
            print('费用记录不完整：历史未知价格或未返回用量的请求不计入已记录金额。',flush=True)
    def summary(self,batch):
        self.state['cost_summary']={'last_batch_estimated_rmb':float(batch),
          'session_recorded_estimated_rmb':float(self.session),'historical_recorded_estimated_rmb':float(self.total),
          'session_budget_rmb':float(self.budget),'estimated_remaining_rmb':float(max(Decimal('0'),self.budget-self.session)),
          'price_band':self.band,'actual_billing':False,'rates_rmb_per_million':[float(x) for x in self.rates] if self.rates is not None else None,
          'incomplete_records':bool(self.state.get('api_usage_without_price') or self.state.get('cost_usage_missing'))}
    def record(self,usage):
        if self.rates is None:cost=cost_cny(usage,self.band)
        else:
            inp,out,cached=self.rates
            hit=usage.get('prompt_cache_hit_tokens',0)
            miss=usage.get('prompt_cache_miss_tokens',max(0,usage.get('prompt_tokens',0)-hit))
            cost=(Decimal(miss)*inp+Decimal(hit)*cached+Decimal(usage.get('completion_tokens',0))*out)/Decimal(1000000)
        self.session+=cost;self.total+=cost
        self.state['session_spent_rmb']=float(self.session);self.state['spent_rmb']=float(self.total)
        self.summary(cost)
        print(f'费用估算 | 本批 ¥{cost:.6f} | 本次累计 ¥{self.session:.6f} | 历史已记录 ¥{self.total:.6f} | 本次预算剩余 ¥{max(Decimal("0"),self.budget-self.session):.6f}',flush=True)
    def missing(self):
        self.state['cost_usage_missing']=True;self.summary(Decimal('0'))
        print(f'请求未返回可记录用量，费用未知 | 本次已记录 ¥{self.session:.6f} | 历史已记录 ¥{self.total:.6f}',flush=True)
    def finish(self,reason):
        print(f'费用估算结束 | 本次累计 ¥{self.session:.6f} | 历史已记录 ¥{self.total:.6f} | 停止原因 {reason}',flush=True)
