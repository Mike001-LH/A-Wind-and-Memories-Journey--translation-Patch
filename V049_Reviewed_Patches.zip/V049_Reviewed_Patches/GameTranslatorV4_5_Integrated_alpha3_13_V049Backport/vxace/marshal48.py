"""Passive Ruby Marshal 4.8 reader and surgical string editor.

Never loads Ruby classes, runs scripts or calls serialization hooks. Unknown
representations fail closed. Unchanged bytes, reference tables and blob data
are retained verbatim; only selected string byte sequences are replaced.
"""
from dataclasses import dataclass, field

@dataclass(eq=False)
class Node:
    kind: str
    value: object = None
    attrs: dict = field(default_factory=dict)
    class_name: str = ''
    span: tuple | None = None
    refs: int = 0

class Reader:
    def __init__(self, raw):
        if len(raw)>128*1024*1024:raise ValueError('Marshal file too large')
        self.raw=raw;self.pos=0;self.objects=[];self.symbols=[];self.nodes=0
    def take(self,n):
        if n<0 or self.pos+n>len(self.raw):raise ValueError('Invalid Marshal length/EOF')
        b=self.raw[self.pos:self.pos+n];self.pos+=n;return b
    def integer(self):
        c=int.from_bytes(self.take(1),'little',signed=True)
        if c==0:return 0
        if c>4:return c-5
        if c< -4:return c+5
        b=int.from_bytes(self.take(abs(c)),'little')
        return b if c>0 else b-(1<<(8*abs(c)))
    def count(self):
        n=self.integer()
        if n<0 or n>2_000_000 or n>len(self.raw)-self.pos:raise ValueError('Invalid Marshal count')
        return n
    def byte_sequence(self):
        start=self.pos;b=self.take(self.count());return b,(start,self.pos)
    def register(self,node):self.objects.append(node);return node
    def symbol(self,depth):
        n=self.read(depth+1)
        if not isinstance(n,Node) or n.kind!=':':raise ValueError('Expected symbol')
        return n.value.decode('utf-8')
    def pairs(self,depth):
        result={}
        for _ in range(self.count()):
            name=self.symbol(depth)
            if name in result:raise ValueError('Duplicate Marshal member')
            result[name]=self.read(depth+1)
        return result
    def read(self,depth=0):
        if depth>200:raise ValueError('Marshal nesting limit')
        self.nodes+=1
        if self.nodes>3_000_000:raise ValueError('Marshal object limit')
        t=self.take(1).decode('latin1')
        if t=='0':return None
        if t=='T':return True
        if t=='F':return False
        if t=='i':return self.integer()
        if t==':':
            b,span=self.byte_sequence();n=Node(t,b,span=span);self.symbols.append(n);return n
        if t in (';','@'):
            idx=self.integer();table=self.symbols if t==';' else self.objects
            if idx<0 or idx>=len(table):raise ValueError('Invalid Marshal link')
            n=table[idx];n.refs+=1;return n
        if t=='I':
            n=self.read(depth+1)
            if not isinstance(n,Node):raise ValueError('Instance vars on primitive')
            n.attrs.update(self.pairs(depth));return n
        if t in ('e','C'):
            name=self.symbol(depth);n=self.read(depth+1)
            if not isinstance(n,Node):raise ValueError('Extension on primitive')
            n.attrs['__wrapper_'+t]=name;return n
        if t in ('"','f','/','c','m','M'):
            b,span=self.byte_sequence();n=self.register(Node(t,b,span=span))
            if t=='/':n.attrs['options']=self.take(1)
            return n
        if t=='l':
            sign=self.take(1);n=self.count();return self.register(Node(t,(sign,self.take(n*2))))
        if t=='[':
            n=self.register(Node(t,[]));count=self.count()
            for _ in range(count):n.value.append(self.read(depth+1))
            return n
        if t in ('{','}'):
            n=self.register(Node(t,[]));count=self.count()
            for _ in range(count):n.value.append((self.read(depth+1),self.read(depth+1)))
            if t=='}':n.attrs['default']=self.read(depth+1)
            return n
        if t in ('o','S'):
            name=self.symbol(depth);n=self.register(Node(t,class_name=name));n.attrs=self.pairs(depth);return n
        if t=='u':
            name=self.symbol(depth);b,span=self.byte_sequence();return self.register(Node(t,b,class_name=name,span=span))
        if t in ('U','d'):
            name=self.symbol(depth);n=self.register(Node(t,class_name=name));n.value=self.read(depth+1);return n
        raise ValueError(f'Unsupported Marshal tag {t!r} at {self.pos-1}')
    def parse(self):
        if self.take(2)!=b'\x04\x08':raise ValueError('Expected Ruby Marshal 4.8 header')
        root=self.read()
        if self.pos!=len(self.raw):raise ValueError('Trailing bytes in Marshal stream')
        return root


def length(n):
    if n<0 or n>0xffffffff:raise ValueError('Invalid byte length')
    if n==0:return b'\0'
    if n<123:return bytes([n+5])
    k=(n.bit_length()+7)//8;return bytes([k])+n.to_bytes(k,'little')


def patch(raw,edits):
    """edits maps byte-sequence spans (including old length) to replacement bytes."""
    last=0;parts=[]
    for (start,end),value in sorted(edits.items()):
        if start<last or end<start or end>len(raw):raise ValueError('Overlapping/out-of-bounds edit')
        parts.extend((raw[last:start],length(len(value)),value));last=end
    parts.append(raw[last:]);return b''.join(parts)


def text(node):
    if not isinstance(node,Node) or node.kind!='"':return None
    encoding=node.attrs.get('encoding')
    if isinstance(encoding,Node):
        codec=encoding.value.decode('ascii')
    elif node.attrs.get('E') is False:codec='ascii'
    else:codec='utf-8'
    try:return node.value.decode(codec)
    except (UnicodeError,LookupError):return None


def array(n):return n.value if isinstance(n,Node) and n.kind=='[' else []
def attr(n,k,default=None):return n.attrs.get('@'+k,default) if isinstance(n,Node) else default
