"""Conservative offline repair for candidates rejected only for missing newlines."""
import unicodedata
from vxace.adapter import AUDIT_TOKEN as TOKEN, audit


def repair_newlines(unit, candidate, target_language):
    if not isinstance(candidate, str): return None
    if audit(dict(unit, translation=candidate), target_language)['blocking'] != ['newline_mismatch']:
        return None
    source = unit['source']
    lines = source.split('\n')
    if candidate.count('\n') >= len(lines)-1 or any(not s.strip() for s in lines):
        return None
    # Never strip spaces or rewrite text. Treat escape sequences as indivisible.
    text = candidate.replace('\n', '')
    atoms = []
    index = 0
    while index < len(text):
        match = TOKEN.match(text, index)
        if match:
            atoms.append((match.group(), 0))
            index = match.end()
        else:
            end = index + 1
            while end < len(text) and (unicodedata.combining(text[end]) or text[end] in '\ufe0e\ufe0f'):
                end += 1
            char = text[index:end]
            width = 2 if unicodedata.east_asian_width(char[0]) in ('W','F') else 1
            atoms.append((char, width))
            index = end
    widths = [0]
    visible = [0]
    for char, width in atoms:
        widths.append(widths[-1]+width)
        visible.append(visible[-1]+int(width > 0 and bool(char.strip())))
    count = len(lines)
    if visible[-1] < count: return None
    cuts = [0]
    for number in range(1, count):
        previous = cuts[-1]
        ideal = widths[previous] + (widths[-1]-widths[previous])/(count-number+1)
        choices = [i for i in range(previous+1, len(atoms))
                   if visible[i] > visible[previous] and visible[-1]-visible[i] >= count-number
                   and atoms[i-1][1] > 0
                   and not (atoms[i-1][0][-1].isascii() and atoms[i-1][0][-1].isalnum()
                            and atoms[i][0][0].isascii() and atoms[i][0][0].isalnum())]
        if not choices: return None
        def score(i):
            penalty = 0
            if atoms[i][0][0] in '，。！？、；：）》」』】❤': penalty += 5
            if atoms[i-1][0][-1] in '（《「『【': penalty += 5
            if atoms[i-1][0][-1] in '，。！？、；：…': penalty -= 2
            if atoms[i-1][0][-1].isascii() and atoms[i-1][0][-1].isalnum() and atoms[i][0][0].isascii() and atoms[i][0][0].isalnum():
                penalty += 5
            return abs(widths[i]-ideal)+penalty
        cuts.append(min(choices, key=score))
    cuts.append(len(atoms))
    result = '\n'.join(''.join(char for char, _ in atoms[a:b]) for a,b in zip(cuts,cuts[1:]))
    if result.replace('\n','') != text or audit(dict(unit, translation=result), target_language)['blocking']:
        return None
    return result
