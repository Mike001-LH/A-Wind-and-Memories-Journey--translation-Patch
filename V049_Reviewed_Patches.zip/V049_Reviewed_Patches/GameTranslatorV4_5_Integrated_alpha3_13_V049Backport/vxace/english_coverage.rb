# GT English coverage profile v1 -- Wind and Memories demo V0.49 only.
# Handles already-loaded event data in saves as well as new-game data.
class Game_Message
  alias gt_extra_message_add add
  def add(text)
    if $game_party && $game_party.in_battle && $game_troop &&
       $game_troop.troop && $game_troop.troop.id == 701
      text = GT_EXTRA_BOSS_LINES[text] || text
    end
    gt_extra_message_add(text)
  end
end

class Window_ChoiceList
  alias gt_extra_choice_start start
  def start
    # Choice branches use indices. Replace display strings, not source commands.
    $game_message.choices.map! {|s| GT_EXTRA_CHOICES[s] || s }
    gt_extra_choice_start
  end
end

module GTExtraWordWrap
  def gt_extra_lines(text, width)
    lines = []; line = ''
    text.to_s.split(/\s+/).each do |word|
      if !line.empty? && text_size(line + ' ' + word).width <= width
        line += ' ' + word
        next
      end
      lines << line unless line.empty?
      line = ''
      word.each_char do |c|
        if !line.empty? && text_size(line + c).width > width
          lines << line; line = ''
        end
        line += c
      end
    end
    lines << line unless line.empty?
    lines.empty? ? [''] : lines
  end
end

class Window_k_ShortMove_Command
  include GTExtraWordWrap
  def item_height
    line_height * 3
  end
  def draw_item(index)
    rect = item_rect_for_text(index)
    change_color(normal_color, command_enabled?(index))
    gt_extra_lines(command_name(index), rect.width).first(3).each_with_index do |line, i|
      draw_text(rect.x, rect.y + i * line_height, rect.width, line_height, line)
    end
  end
end

class Window_k_ShortMove_Info
  include GTExtraWordWrap
  def refresh
    return if @select.nil?
    title = KURE::ShortMove::MOVE_LIST[@select][0][0]
    descriptions = KURE::ShortMove::EXPLAN[@select] || []
    lines = ([title] + descriptions).map {|s| gt_extra_lines(s, contents_width - 8) }.flatten
    needed = [contents_height, lines.size * line_height].max
    if contents.height != needed
      contents.dispose
      self.contents = Bitmap.new(contents_width, needed)
    end
    self.oy = 0; contents.clear; reset_font_settings
    lines.each_with_index {|line, i| draw_text(4, i * line_height, contents_width - 8, line_height, line) }
    @gt_extra_scroll_limit = [needed - contents_height, 0].max
    @gt_extra_scroll_tick = 0
  end
  alias gt_extra_info_update update
  def update
    gt_extra_info_update
    return unless visible && openness > 0 && @gt_extra_scroll_limit && @gt_extra_scroll_limit > 0
    @gt_extra_scroll_tick += 1
    cycle = @gt_extra_scroll_limit * 2 + 180
    tick = @gt_extra_scroll_tick % cycle
    self.oy = [[(tick - 90) / 2, 0].max, @gt_extra_scroll_limit].min
  end
end
