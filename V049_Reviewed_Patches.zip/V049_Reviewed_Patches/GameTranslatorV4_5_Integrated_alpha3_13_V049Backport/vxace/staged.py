"""Gateway first, optional semantic review, bounded official residual repair."""
from copy import copy
import hashlib
from core.completion import complete


def review_signature(unit):
    return hashlib.sha256((unit['source']+'\0'+unit.get('translation','')).encode()).hexdigest()


def fallback_args(args):
    result=copy(args)
    # Never carry the gateway key, model, base or prices into a paid request.
    result.provider='deepseek';result.api_key=None
    result.api_base_url='https://api.deepseek.com';result.api_model='deepseek-flash'
    result.api_thinking='disabled'
    result.api_input_rmb=result.api_output_rmb=result.api_cached_input_rmb=None
    result.max_api_calls=getattr(args,'fallback_max_api_calls',5)
    result.max_cost_rmb=getattr(args,'fallback_max_cost_rmb',1.)
    result.batch_size=min(args.batch_size,5)
    result.repair_rounds=1
    return result


def run_stages(units,audit,request_factory,save,args,state):
    """Only already attempted failed units/rejected reviews may enter the paid stage.

    Unsent units never trigger paid bulk work; attempted failed batches remain bounded.
    """
    workflow={'stages':[], 'primary_stop_reason':None,'paid_eligible':0,
              'paid_selected':0,'selected_remaining':0,'review_attempted':0,'review_passed':0}
    state['workflow']=workflow
    known_bad=set(state.get('rejected_candidates',{}))
    attempted=set(state.get('gateway_attempted_units',[]))
    # Compatibility with alpha4 checkpoints: provider errors identify sent batches.
    for error in state.get('errors',[]):
        message=error.get('error','')
        if 'xianyi HTTP' in message or 'API timed out' in message or 'Model response hit' in message:
            attempted.update(error.get('ids',[]))
    responses=set(state.get('gateway_response_units',[]))
    review_pending=state.setdefault('semantic_review_pending',{})
    reviewed=state.setdefault('semantic_reviews',{})

    def qa(unit):
        result=audit(unit)
        if unit['id'] in review_pending:
            result=dict(result,blocking=list(result['blocking'])+['semantic_review_candidate_rejected'])
        return result

    # Treat a preserved but flagged semantic candidate as repair-only work, not done.
    state['api_session']=None;state['session_spent_rmb']=0.
    if any(qa(u)['blocking'] for u in units):
        request=request_factory(args,'primary',False,responses)
        complete(units,qa,request,save,rounds=args.repair_rounds,batch_size=args.batch_size,
                 stall_rounds=args.stall_rounds,state=state)
    else:state['stop_reason']='clean'
    primary_stop=state['stop_reason'];workflow['primary_stop_reason']=primary_stop
    if state.get('api_session'):
        state['api_session']['stage']='primary'
        workflow['stages'].append(dict(state['api_session'],stop_reason=primary_stop))
    save(units,state)
    if primary_stop.startswith('provider_'):
        print('Primary API stopped:',primary_stop,'— check checkpoint errors. Unsent text will stay queued.',flush=True)

    # Share one gateway accounting session/request cap across initial translation and review.
    limit=getattr(args,'ai_review_units',0)
    review_targets=[u for u in units if not qa(u)['blocking'] and
                    reviewed.get(u['id'],{}).get('signature')!=review_signature(u)][:limit]
    if review_targets and not primary_stop.startswith('provider_') and primary_stop not in ('request_limit','budget_limit'):
        print('Gateway semantic review:',len(review_targets),'units',flush=True)
        request=request_factory(args,'review',True,responses)
        for start in range(0,len(review_targets),args.batch_size):
            batch=review_targets[start:start+args.batch_size]
            try:
                made,_=request(batch,0)
            except (KeyboardInterrupt,SystemExit):save(units,state);raise
            except Exception as exc:
                state.setdefault('errors',[]).append({'stage':'review','ids':[u['id'] for u in batch],'error':str(exc)[:800]})
                workflow['review_stop_reason']=getattr(exc,'reason','review_error')
                # A network or format error does not prove that the saved translation is bad.
                save(units,state);break
            workflow['review_attempted']+=len(batch)
            for u in batch:
                candidate=made.get(u['id'])
                if not isinstance(candidate,str) or not candidate.strip():continue
                reasons=audit(dict(u,translation=candidate))['blocking']
                if reasons:
                    review_pending[u['id']]={'candidate':candidate,'blocking':reasons}
                    continue
                u['translation']=candidate
                u['provenance']={'method':'gateway_semantic_review',
                                 'provider':state['api_session']['provider'],'model':state['api_session']['model']}
                reviewed[u['id']]={'signature':review_signature(u),'model':state['api_session']['model']}
                review_pending.pop(u['id'],None)
                workflow['review_passed']+=1
            save(units,state)
        workflow['review_stop_reason']=workflow.get('review_stop_reason','complete')
        # Gateway accounting includes both primary and review; keep a single aggregate entry.
        session=dict(state['api_session'],stage='gateway_primary_and_review',stop_reason=workflow['review_stop_reason'])
        if workflow['stages'] and workflow['stages'][0]['provider']==args.provider:workflow['stages'][0]=session
        else:workflow['stages'].append(session)

    attempted.update(state.get('gateway_attempted_units',[]))
    eligible=[u for u in units if qa(u)['blocking'] and
              (u['id'] in responses or u['id'] in attempted or u['id'] in known_bad or u['id'] in review_pending)]
    workflow['paid_eligible']=len(eligible)
    if getattr(args,'fallback_deepseek',False) and eligible:
        chosen=eligible[:getattr(args,'fallback_max_units',50)]
        workflow['paid_selected']=len(chosen)
        official=fallback_args(args)
        print('Official DeepSeek residual repair:',len(chosen),'units; max requests:',official.max_api_calls,
              '; estimated RMB limit:',official.max_cost_rmb,flush=True)
        try:request=request_factory(official,'paid_residual',False,set())
        except (ValueError,RuntimeError) as exc:
            workflow['paid_stop_reason']='configuration_error'
            state.setdefault('errors',[]).append({'stage':'paid_residual','error':str(exc)[:800]})
            save(units,state)
        else:
            # complete's primary phase skips nonempty translations: clear only the bounded
            # flagged entries, retain a passing previous value for display if repair fails.
            previous={u['id']:u.get('translation','') for u in chosen}
            for u in chosen:u['translation']=''
            try:
                complete(chosen,qa,request,save,rounds=official.repair_rounds,batch_size=official.batch_size,
                         stall_rounds=official.stall_rounds,state=state)
            finally:
                for u in chosen:
                    if not u.get('translation'):u['translation']=previous[u['id']]
                save(units,state)
            workflow['paid_stop_reason']=state['stop_reason']
            workflow['stages'].append(dict(state['api_session'],stage='paid_residual',stop_reason=state['stop_reason']))
    workflow['selected_remaining']=sum(bool(qa(u)['blocking']) for u in units)
    state['stop_reason']='clean' if workflow['selected_remaining']==0 else 'workflow_partial'
    save(units,state)
    print('Workflow remaining selected units:',workflow['selected_remaining'],
          '; paid selected:',workflow['paid_selected'],flush=True)
    return workflow
