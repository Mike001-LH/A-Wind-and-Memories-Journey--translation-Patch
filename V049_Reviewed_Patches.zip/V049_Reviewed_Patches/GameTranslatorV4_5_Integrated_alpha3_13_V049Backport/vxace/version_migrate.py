"""Offline version migration: recover memory from old patch, prepare new work, restore portable work.
Never copies old maps or database objects into the new version. No API calls.
"""
import argparse
from collections import Counter, defaultdict
from difflib import SequenceMatcher
import hashlib
import json
from pathlib import Path
import re
import shutil
import tempfile
import zlib
from core.completion import atomic_json, fingerprint
from vxace.adapter import extract, collect_file, audit, build_files, decompress, HAN
from vxace.marshal48 import Reader, array, text, patch
from vxace.memory import export

FORMAT='gt-vxace-version-bundle-1'
HERE=Path(__file__).parent

def sha(raw):return hashlib.sha256(raw).hexdigest()
def read(path):return json.loads(Path(path).read_text(encoding='utf-8'))
def hashes(game):return {'Data/'+p.name:sha(p.read_bytes()) for p in sorted((Path(game)/'Data').glob('*.rvdata2'))}
def separate(destination,*inputs):
    p=Path(destination).resolve()
    if p.exists():raise ValueError('Output/work already exists: '+str(p))
    for v in inputs:
        q=Path(v).resolve()
        if p==q or p.is_relative_to(q) or q.is_relative_to(p):raise ValueError('Use separate input, work and output directories')
    return p

def scripts(raw):
    rows=array(Reader(raw).parse())
    return [(text(array(row)[1]),decompress(array(row)[2].value).decode('utf-8-sig')) for row in rows]

def verified_strings(original,translated,units,bindings,reader,other):
    """Reconstruct the entire old file using only allowed string spans.
    Equality proves commands, numeric values, links and every other byte stayed unchanged.
    """
    if len(reader.objects)!=len(other.objects):raise ValueError('Old patch changes object count')
    allowed={n.span for u in units for n in bindings[u['id']]};edits={}
    for a,b in zip(reader.objects,other.objects):
        if (a.kind,a.class_name,a.refs)!=(b.kind,b.class_name,b.refs):raise ValueError('Old patch changes object topology')
        if isinstance(a.value,bytes) and a.value!=b.value:
            if a.span not in allowed:raise ValueError('Old patch changes an unapproved string')
            edits[a.span]=b.value
    if patch(original,edits)!=translated:raise ValueError('Old patch changes non-text data')

def recover(old_game,old_patch,target,output,source_language="Chinese"):
    old_game=Path(old_game);old_patch=Path(old_patch);output=separate(output,old_game,old_patch)
    report=read(old_patch/'build_report.json')
    if report.get('target_language')!=target or report.get('engine')!='vxace':raise ValueError('Patch language/engine mismatch')
    if report.get('source_hashes')!=hashes(old_game):raise ValueError('Old original does not match patch source hashes')
    all_units=[];rejected=[];counts=Counter()
    for path in sorted((old_game/'Data').glob('*.rvdata2')):
        rel='Data/'+path.name;raw=path.read_bytes();other=old_patch/rel
        changed=other.read_bytes() if other.is_file() else raw
        units,bindings,_,r=collect_file(rel,raw);after,_,_,r2=collect_file(rel,changed)
        lookup={u['id']:u for u in after}
        if path.name!='Scripts.rvdata2':verified_strings(raw,changed,units,bindings,r,r2)
        for u in units:
            t=lookup.get(u['id'],{}).get('source','')
            reason=audit(dict(u,translation=t),target)['blocking']
            # Unchanged Chinese is not evidence of a Japanese translation.
            if t==u['source'] and HAN.search(t):reason=['unchanged_han_needs_review']
            if reason:
                rejected.append({'id':u['id'],'file':rel,'source':u['source'],'candidate':t,'reason':reason})
                counts['not_recovered']+=1
            else:
                u['translation']=t;u['provenance']={'method':'old_patch_verified_string','old_patch':old_patch.name}
                counts['recovered_changed' if t!=u['source'] else 'unchanged_non_han']+=1
            all_units.append(u)
    script_issues=[]
    try:script_rows=recover_script_rows(old_game,old_patch,target)
    except ValueError as exc:
        script_rows=[];script_issues.append(str(exc))
    output.mkdir(parents=True)
    atomic_json(output/'translation_memory.json',export(all_units,target,source_language))
    atomic_json(output/'bundle.json',{'format':FORMAT,'target_language':target,'source_language':source_language,
        'old_source_hashes':hashes(old_game),'script_rows':script_rows,'api_calls':0,
        'source_inventory':{u['id']:sha(u['source'].encode()) for u in all_units},'script_transfer_review':script_issues})
    atomic_json(output/'recovery_report.json',{'counts':dict(counts),'rejected':rejected,'script_transfer_review':script_issues,'api_calls':0})
    print('OFFLINE PATCH MEMORY RECOVERY:',dict(counts),'; NO API CALLS',flush=True)
    return output

def recover_script_rows(old_game,old_patch,target):
    """Only the previously reviewed V0.49 literal profiles and Main prefix are exported."""
    from vxace.coverage_fix import language_profile
    from vxace.display_fix import ruby_literal
    _,display=language_profile(target)
    extra=read(HERE/('wind_v049_extra_'+target+'.json'))
    expected=read(HERE/'wind_v049_scripts.json')
    old=scripts((old_game/'Data/Scripts.rvdata2').read_bytes())
    patched=scripts((old_patch/'Data/Scripts.rvdata2').read_bytes())
    if len(old)!=len(patched):raise ValueError('Old patch script count differs')
    transfers=[]
    for i,((name,base),(pname,translated)) in enumerate(zip(old,patched)):
        if name!=pname:raise ValueError('Old patch changes script labels')
        if base==translated or name=='Vocab':continue
        if name=='Main':
            if not translated.endswith(base):raise ValueError('Old Main code was replaced')
            prefix=translated[:-len(base)] if base else ''
            if display.MARKER not in prefix:raise ValueError('Unrecognized old layout prefix')
            if re.search(r'Font\.default_(?:name|size)\s*=',prefix):raise ValueError('Old prefix overrides original font')
            transfers.append({'name':name,'base':base,'prefix':prefix,'method':'layout_prefix'})
            continue
        profile=expected.get(str(i))
        if not profile or profile['name']!=name or profile['sha256']!=sha(base.encode('utf-8')):
            raise ValueError('Old script is outside reviewed V0.49 profile: '+name)
        mapping=dict(display.UI.get(i,{}));mapping.update(extra['script_ui'].get(str(i),{}))
        result=base
        for s,t in mapping.items():result=result.replace(ruby_literal(s),ruby_literal(t))
        if result!=translated:raise ValueError('Old script contains unknown edits: '+name)
        transfers.append({'name':name,'base':base,'mapping':mapping,'method':'literal_profile'})
    return transfers

def owner(row):
    # Empty-context choices/dialogue must not cross unrelated event pages.
    path=row.get('metadata',{}).get('path')
    if path is None:
        try:path=json.loads(row.get('location',''))[1]
        except (ValueError,TypeError,IndexError):return None
    if 'list' in path:return path[:path.index('list')]
    return path

def migrate_strict(units,rows,target,inventory=None):
    exact=defaultdict(list);byid={}
    for r in rows:
        if not audit(r,target)['blocking']:
            exact[(r['source'],r.get('kind'))].append(r);byid[r['id']]=r
    events=[]
    for u in units:
        kind=u['metadata']['kind'];candidates=exact[(u['source'],kind)]
        event_kind=kind in ('dialogue','scroll_text','choice','actor_name','actor_nickname')
        compatible=[r for r in candidates if r.get('file')==u['file'] and r.get('context',[])==u.get('context',[])
                    and (not event_kind or u.get('context') or owner(r)==owner(u))]
        same=[r for r in compatible if r['id']==u['id']]
        pool=same or compatible
        # Long text can move inside a file if the old translation is unambiguous.
        if not pool and len(u['source'])>=12:
            local=[r for r in candidates if r.get('file')==u['file']]
            if len({r['translation'] for r in local})==1:pool=local
        status='new_or_previously_untranslated';chosen=None
        if pool:
            if len({r['translation'] for r in pool})==1:chosen=pool[0]
            else:status='conflict'
        elif candidates:status='context_review'
        if chosen:
            u['translation']=chosen['translation'];u['provenance']={'method':'version_exact_source','old_id':chosen['id']}
            status='reused'
        else:
            old=byid.get(u['id'])
            if old and old['source']!=u['source'] and old.get('kind')==kind:
                ratio=SequenceMatcher(None,old['source'],u['source'],autojunk=False).ratio()
                if ratio>=0.72:
                    u['previous_version_reference']={'source':old['source'],'translation':old['translation']}
                    status='modified_needs_translation'
        if not chosen and status=='new_or_previously_untranslated' and inventory is not None:
            prior=inventory.get(u['id'])
            status=('previously_untranslated' if prior==sha(u['source'].encode()) else 'modified_needs_translation') if prior else 'new'
        event={'id':u['id'],'file':u['file'],'status':status}
        if not chosen:
            event.update(source=u['source'],context=u.get('context',[]))
            if candidates:event['candidates']=[{'id':r['id'],'translation':r['translation']} for r in candidates]
        events.append(event)
    return {'counts':dict(Counter(e['status'] for e in events)),'entries':events,'api_calls':0}

def prepare_recipe(game,bundle,target):
    from vxace.display_fix import ruby_literal
    current=scripts((game/'Data/Scripts.rvdata2').read_bytes());edits=[];issues=[{'reason':x} for x in bundle.get('script_transfer_review',[])]
    profile=read(HERE/'wind_v050_migration.json')
    # Whole source hash pins compatibility review to this supplied 0.50 build.
    pinned=sha((game/'Data/Scripts.rvdata2').read_bytes())==profile['scripts_sha256']
    for r in bundle['script_rows']:
        matches=[(i,c) for i,(n,c) in enumerate(current) if n==r['name']]
        if len(matches)!=1:
            issues.append({'name':r['name'],'reason':'missing_or_duplicate_label'});continue
        i,base=matches[0];result=base
        if r['method']=='layout_prefix':
            if not pinned or base!=r['base'] or not any(marker in r.get('prefix','') for marker in ('# GT English display profile v1','# GT Japanese display profile v1')):
                issues.append({'name':r['name'],'reason':'runtime_compatibility_not_reviewed'});continue
            result=r['prefix']+base
        else:
            if base!=r['base'] and not pinned:
                issues.append({'name':r['name'],'reason':'changed_script_not_reviewed'});continue
            for source,target_text in r.get('mapping',{}).items():
                token=ruby_literal(source)
                if token in result:result=result.replace(token,ruby_literal(target_text))
                else:issues.append({'name':r['name'],'source':source,'reason':'old_literal_not_present'})
            for token,replacement in r.get('literal_tokens',{}).items():
                if token in result:result=result.replace(token,replacement)
                else:issues.append({'name':r['name'],'reason':'old_literal_not_present','token':token})
            if pinned:
                for source,target_text in profile['additional_literals'].get(target,{}).get(r['name'],{}).items():
                    token=ruby_literal(source)
                    if token not in result:
                        if token in base and ruby_literal(target_text) in result:continue
                        raise ValueError('Reviewed new literal missing: '+source)
                    result=result.replace(token,ruby_literal(target_text))
        if result!=base:edits.append({'index':i,'name':r['name'],'base_sha256':sha(base.encode()),'base_code':base,'code':result})
    # Small, manually reviewed new UI strings (not arbitrary script extraction).
    if pinned:
        transferred={r['name'] for r in edits}
        for name,mapping in profile['additional_literals'].get(target,{}).items():
            if name in transferred:continue
            matches=[(i,c) for i,(n,c) in enumerate(current) if n==name]
            if len(matches)!=1:raise ValueError('Reviewed new script missing: '+name)
            i,base=matches[0];result=base
            for source,target_text in mapping.items():
                token=ruby_literal(source)
                if token not in result:raise ValueError('Reviewed literal missing: '+source)
                result=result.replace(token,ruby_literal(target_text))
            if result!=base:edits.append({'index':i,'name':name,'base_sha256':sha(base.encode()),'base_code':base,'code':result})
    return {'format':'gt-vxace-script-transfer-1','target_language':target,'source_hashes':hashes(game),
            'scripts':edits,'reusable_rows':reusable_script_rows(edits),'issues':issues,'font_changed':False,'runtime_test_required':True,'api_calls':0}

def reusable_script_rows(edits):
    rows=[]
    token=re.compile(r'"(?:\\.|[^"\\])*"',re.S)
    for r in edits:
        base=r['base_code'];code=r['code']
        if r['name']=='Main' and base and code.endswith(base):
            rows.append({'name':r['name'],'base':base,'prefix':code[:-len(base)],'method':'layout_prefix'})
            continue
        a=token.findall(base);b=token.findall(code)
        if len(a)!=len(b) or token.sub('""',base)!=token.sub('""',code):continue
        pairs={};conflict=False
        for x,y in zip(a,b):
            if x==y:continue
            if x in pairs and pairs[x]!=y:conflict=True;break
            pairs[x]=y
        if pairs and not conflict:rows.append({'name':r['name'],'base':base,'literal_tokens':pairs,'method':'literal_profile'})
    return rows


def apply_script_recipe(game,raw,recipe,target):
    from vxace.coverage_fix import checked_patch
    if recipe.get('format')!='gt-vxace-script-transfer-1' or recipe.get('target_language')!=target:raise ValueError('Script transfer language/format mismatch')
    if hashes(game)!=recipe['source_hashes']:raise ValueError('Script transfer belongs to a different source version')
    rows=array(Reader(raw).parse());edits={}
    for r in recipe['scripts']:
        if not isinstance(r['index'],int) or not 0<=r['index']<len(rows):raise ValueError('Invalid script transfer index')
        row=array(rows[r['index']]);base=decompress(row[2].value).decode('utf-8-sig')
        if text(row[1])!=r['name'] or sha(base.encode())!=r['base_sha256']:raise ValueError('Script changed before transfer: '+r['name'])
        edits[row[2].span]=zlib.compress(r['code'].encode('utf-8'))
    return checked_patch(raw,edits)

def prepare(game,bundle_path,work,output):
    game=Path(game).resolve();bundle_path=Path(bundle_path).resolve()
    work=separate(work,game,bundle_path);output=separate(output,game,bundle_path,work)
    bundle=read(bundle_path/'bundle.json');memory=read(bundle_path/'translation_memory.json')
    if bundle.get('format')!=FORMAT:raise ValueError('Unrecognized migration bundle')
    target=bundle['target_language']
    source=bundle.get('source_language')
    if target not in ('en','ja','zh') or not isinstance(source,str) or not source or memory.get('target_language')!=target or memory.get('source_language')!=source:raise ValueError('Memory language mismatch')
    units,manifest,reviews=extract(game);sig=fingerprint(units)
    manifest.update(game=str(game),source_language=source,target_language=target)
    untouched=json.loads(json.dumps(units));report=migrate_strict(units,memory['entries'],target,bundle.get('source_inventory'))
    from vxace.choice_support import fill_known,apply_runtime,report as choice_report
    fixed_choices=set(fill_known(game,units,target))
    for event in report['entries']:
        if event['id'] in fixed_choices:event['status']='reviewed_choice_fix'
    report['counts']=dict(Counter(e['status'] for e in report['entries']))
    recipe=prepare_recipe(game,bundle,target)
    changed,unresolved=build_files(game,units,manifest,target,allow_partial=True)
    changed['Data/Scripts.rvdata2']=apply_script_recipe(game,changed.get('Data/Scripts.rvdata2',(game/'Data/Scripts.rvdata2').read_bytes()),recipe,target)
    changed['Data/Scripts.rvdata2'],choice_runtime=apply_runtime(game,changed['Data/Scripts.rvdata2'],units,target)
    state={'input_fingerprint':sig,'source_language':source,'target_language':target,'translations':{u['id']:u['translation'] for u in units if u['translation']},
        'reviewed':[],'provenance':{u['id']:u['provenance'] for u in units if u.get('provenance')},
        'previous_version_references':{u['id']:u['previous_version_reference'] for u in units if u.get('previous_version_reference')},
        'spent_rmb':0.,'stop_reason':'migration_only','duplicate_reuse_schema':1}
    work.mkdir(parents=True);output.mkdir(parents=True)
    for name,value in [('ace_manifest.json',manifest),('ace_units.json',untouched),('ace_checkpoint.json',state),
        ('ace_migration_report.json',report),('version_script_transfer.json',recipe),('translation_memory.json',export(units,target,source)),
        ('ace_excluded_review.json',{'entries':reviews,'counts':dict(Counter(r['reason'] for r in reviews))}),
        ('ace_completion_report.json',{'total':len(units),'blocking_count':len(unresolved),'stop_reason':'migration_only',
          'unresolved':[dict(u,blocking=audit(u,target)['blocking']) for u in units if u['id'] in set(unresolved)],'excluded_review_candidates':len(reviews)})]:atomic_json(work/name,value)
    for rel,raw in changed.items():
        p=output/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
    atomic_json(output/'build_report.json',{'engine':'vxace','target_language':target,'source_hashes':manifest['source_hashes'],
       'changed_files':sorted(changed),'unresolved':len(unresolved),'migration':report['counts'],'api_calls':0,'font_override':None,
       'script_transfer':True,'runtime_test_required':True})
    atomic_json(output/'script_transfer_report.json',{'scripts':[{'index':r['index'],'name':r['name']} for r in recipe['scripts']],
        'issues':recipe['issues'],'font_changed':False,'api_calls':0})
    atomic_json(work/'ace_choice_coverage_report.json',choice_report(units,target,reviews))
    atomic_json(output/'choice_display_report.json',choice_runtime)
    print('OFFLINE VERSION MIGRATION:',report['counts'],'; pending:',len(unresolved),'; NO API CALLS',flush=True)
    return report

def restore(game,portable,work):
    """Rebind a portable prepared work directory only after full source/hash validation."""
    game=Path(game).resolve();portable=Path(portable).resolve();work=separate(work,game,portable)
    saved=read(portable/'ace_manifest.json');state=read(portable/'ace_checkpoint.json')
    if hashes(game)!=saved.get('source_hashes'):raise ValueError('New game Data does not match prepared 0.50 source. Use untouched original Data.')
    units,manifest,_=extract(game);manifest.update(game=str(game),source_language=saved['source_language'],target_language=saved['target_language'])
    if {k:v for k,v in saved.items() if k!='game'}!={k:v for k,v in manifest.items() if k!='game'}:raise ValueError('Prepared manifest differs from extractor')
    if fingerprint(units)!=state.get('input_fingerprint') or state.get('target_language')!=saved['target_language'] or state.get('source_language')!=saved['source_language']:
        raise ValueError('Prepared checkpoint fingerprint/language mismatch')
    shutil.copytree(portable,work);atomic_json(work/'ace_manifest.json',manifest)
    print('OFFLINE WORK RESTORED:',work,'; cached:',len(state['translations']),'; NO API CALLS')

def main():
    p=argparse.ArgumentParser(description=__doc__);sub=p.add_subparsers(dest='command',required=True)
    r=sub.add_parser('recover');r.add_argument('old_game');r.add_argument('--patch',required=True);r.add_argument('--target-language',choices=['en','ja'],required=True);r.add_argument('--output',required=True)
    r=sub.add_parser('prepare');r.add_argument('game');r.add_argument('--bundle',required=True);r.add_argument('--workdir',required=True);r.add_argument('--output',required=True)
    r=sub.add_parser('restore');r.add_argument('game');r.add_argument('--from-work',required=True);r.add_argument('--workdir',required=True)
    a=p.parse_args()
    try:
        if a.command=='recover':recover(a.old_game,a.patch,a.target_language,a.output)
        elif a.command=='prepare':prepare(a.game,a.bundle,a.workdir,a.output)
        else:restore(a.game,a.from_work,a.workdir)
    except (ValueError,OSError,KeyError) as exc:p.exit(2,'STOP: '+str(exc)+'\n')
if __name__=='__main__':main()
