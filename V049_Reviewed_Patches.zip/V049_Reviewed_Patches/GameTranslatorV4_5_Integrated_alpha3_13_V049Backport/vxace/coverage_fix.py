"""Offline V0.49 English/Japanese supplement: boss dialogue, choices, battle and travel UI."""
import argparse
import json
import re
import shutil
import tempfile
import zlib
from pathlib import Path
from vxace.marshal48 import Reader, array, text, patch
from vxace.adapter import collect_file, decompress, canonical, restore_newlines, AUDIT_TOKEN
from vxace.display_fix import HERE, MARKER as DISPLAY_MARKER, sha, read_json, ruby_literal, edit_scripts, speaker_table

MARKER = '# GT English coverage profile v1'
PROFILE = HERE / 'wind_v049_extra_en.json'

def language_profile(target_language):
    if target_language not in ('en','ja'):raise ValueError('Coverage supports en or ja only')
    from vxace import display_fix, display_fix_ja
    display=display_fix_ja if target_language=='ja' else display_fix
    return HERE/('wind_v049_extra_'+target_language+'.json'),display


def checked_patch(raw, edits):
    before=Reader(raw);before.parse()
    result=patch(raw,edits);after=Reader(result);after.parse()
    if len(before.objects)!=len(after.objects):raise ValueError('Marshal object table changed')
    for a,b in zip(before.objects,after.objects):
        if (a.kind,a.class_name,a.refs)!=(b.kind,b.class_name,b.refs):raise ValueError('Marshal reference topology changed')
        if isinstance(a.value,bytes) and b.value!=edits.get(a.span,a.value):raise ValueError('Unintended data mutation')
    return result

def supplement_scripts(raw, target_language='en'):
    profile_path,display=language_profile(target_language)
    rows=array(Reader(raw).parse());profile=read_json(profile_path)
    if len(rows)!=306:raise ValueError('Requires Wind and Memories V0.49 (306 scripts)')
    codes={i:decompress(array(r)[2].value).decode('utf-8-sig') for i,r in enumerate(rows)}
    if any('# GT English coverage profile v1' in s or '# GT Japanese coverage profile v1' in s for s in codes.values()):raise ValueError('Coverage fix already applied; use the earlier patch')
    if not any(display.MARKER in s for s in codes.values()):raise ValueError('Matching language display profile is required')
    expected=read_json(HERE/'wind_v049_scripts.json');edits={};counts={}
    for key,mapping in profile['script_ui'].items():
        i=int(key);row=array(rows[i]);code=codes[i]
        if text(row[1])!=expected[key]['name'] or sha(decompress(row[2].value))!=expected[key]['sha256']:
            raise ValueError('Unsupported/custom-modified coverage script: '+key)
        count=0
        for s,t in mapping.items():
            if s==t:continue
            literal=ruby_literal(s);n=code.count(literal)
            if not n:raise ValueError('Expected UI literal missing: '+s)
            code=code.replace(literal,ruby_literal(t));count+=n
        edits[row[2].span]=zlib.compress(code.encode());counts[key]=count
    main=[i for i,row in enumerate(rows) if text(array(row)[1])=='Main']
    if len(main)!=1:raise ValueError('Expected unique Main script')
    lines={}
    for u in profile['boss']:
        if u['source'].count('\n')!=u['translation'].count('\n'):raise ValueError('Boss newline mismatch')
        if AUDIT_TOKEN.findall(u['source'])!=AUDIT_TOKEN.findall(u['translation']):raise ValueError('Boss control mismatch')
        for s,t in zip(u['source'].split('\n'),u['translation'].split('\n')):
            if s in lines and lines[s]!=t:raise ValueError('Ambiguous boss line')
            lines[s]=t
    def table(name,values):
        return name+' = {\n'+',\n'.join(ruby_literal(s)+' => '+ruby_literal(t) for s,t in values.items())+'\n}\n'
    prefix='GT_JA_EXTRA' if target_language=='ja' else 'GT_EXTRA'
    runtime_file='japanese_coverage.rb' if target_language=='ja' else 'english_coverage.rb'
    runtime=table(prefix+'_BOSS_LINES',lines)+table(prefix+'_CHOICES',profile['choices'])+(HERE/runtime_file).read_text()
    i=main[0]
    # Keep existing layout and speaker code intact; both profiles load before the game loop.
    edits[array(rows[i])[2].span]=zlib.compress((runtime+'\n'+codes[i]).encode())
    return checked_patch(raw,edits),counts

def event_fixes(name, raw, target_language='en'):
    profile=read_json(language_profile(target_language)[0]);units,bindings,review,_=collect_file(name,raw)
    boss={u['id']:u for u in profile['boss']};edits={};fixed=[];unmatched=[]
    for u in units:
        target=None
        if name=='Data/Troops.rvdata2' and u['id'] in boss:
            known=boss[u['id']]
            if u['source']==known['source']:target=known['translation']
            elif u['source']!=known['translation'] and (target_language=='ja' or re.search(r'[\u3400-\u9fff]',u['source'])):
                unmatched.append({'id':u['id'],'current_text':u['source'],'reason':'Existing different text retained; review, not necessarily untranslated'})
        elif u['metadata']['kind']=='choice':target=profile['choices'].get(u['source'])
        if target is None:continue
        nodes=bindings[u['id']]
        if u['metadata'].get('choice_aliases'):
            values=[target]*len(nodes)
        else:
            parts=target.split('\n');values=[];cursor=0
            for node in nodes:
                n=canonical(text(node)).count('\n')+1;values.append('\n'.join(parts[cursor:cursor+n]));cursor+=n
            if cursor!=len(parts):raise ValueError('Line segmentation mismatch')
        for node,value in zip(nodes,values):
            data=restore_newlines(value,text(node)).encode()
            if node.span in edits and edits[node.span]!=data:raise ValueError('Conflicting event edits')
            edits[node.span]=data
        fixed.append({'id':u['id'],'source':u['source'],'translation':target})
    return checked_patch(raw,edits) if edits else raw,fixed,unmatched

def apply(game, translated, output, target_language=None):
    game=Path(game).resolve();translated=Path(translated).resolve();output=Path(output).resolve()
    if output.exists():raise ValueError('Output already exists; choose a new --output')
    if any(output==p or output.is_relative_to(p) or p.is_relative_to(output) for p in (game,translated)):
        raise ValueError('Output must be separate from source game and patch')
    report=read_json(translated/'build_report.json')
    actual_language=report.get('target_language')
    if report.get('engine')!='vxace' or actual_language not in ('en','ja'):raise ValueError('Requires English/Japanese VX Ace patch with build_report.json')
    if target_language and target_language!=actual_language:raise ValueError('Requested language differs from patch build_report.json')
    target_language=actual_language
    _,display=language_profile(target_language)
    hashes={p.relative_to(game).as_posix():sha(p.read_bytes()) for p in (game/'Data').glob('*.rvdata2')}
    if hashes!=report.get('source_hashes'):raise ValueError('Original game differs from translation patch')
    if any(p.is_symlink() for p in translated.rglob('*')):raise ValueError('Symlinks in input patch are unsupported')
    scripts=translated/'Data/Scripts.rvdata2'
    raw=(scripts if scripts.is_file() else game/'Data/Scripts.rvdata2').read_bytes()
    rows=array(Reader(raw).parse())
    layout_added=False
    if not any(display.MARKER in decompress(array(row)[2].value).decode('utf-8-sig') for row in rows):
        raw,_=display.edit_scripts(raw,display.speaker_table(game,translated));layout_added=True
    raw,counts=supplement_scripts(raw,target_language)
    changes={'Data/Scripts.rvdata2':raw};fixed=[];unmatched=[]
    for rel in sorted(hashes):
        if rel=='Data/Scripts.rvdata2':continue
        candidate=translated/rel
        before=(candidate if candidate.is_file() else game/rel).read_bytes()
        after,rows,miss=event_fixes(rel,before,target_language)
        fixed.extend(dict(row,file=rel) for row in rows);unmatched.extend(miss)
        if after!=before:changes[rel]=after
    stage=None
    try:
        output.parent.mkdir(parents=True,exist_ok=True)
        stage=Path(tempfile.mkdtemp(prefix='.gt-coverage-',dir=output.parent))
        shutil.copytree(translated,stage,dirs_exist_ok=True)
        for rel,data in changes.items():
            p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
        details={'profile':'wind-v049-'+target_language+'-extra-v1','target_language':target_language,'api_calls':0,'font_changed':False,
                 'layout_added':layout_added,'script_literal_counts':counts,'event_fixes':fixed,
                 'boss_mixed_text_needs_review':unmatched,'source_patch':str(translated),
                 'inherited_unresolved_count':report.get('unresolved'),
                 'runtime_test_required':True,'travel_destinations':36}
        language_name='japanese' if target_language=='ja' else 'english'
        report[language_name+'_coverage_profile']=details['profile']
        report['changed_files']=sorted(set(report.get('changed_files',[]))|set(changes))
        report[language_name+'_display_profile']='wind-v049-ja-v1' if target_language=='ja' else 'wind-v049-v1'
        (stage/'build_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
        (stage/'coverage_fix_report.json').write_text(json.dumps(details,ensure_ascii=False,indent=2))
        (stage/'INSTALL_COVERAGE.txt').write_text('V0.49 '+language_name+' supplemental patch. Merge Data files into a COPY of the same original game. Keep other Data files. Original font and prior layout retained. Test robot boss troop 701, battle commands, NPC choices, travel names/descriptions and save/load. Travel descriptions scroll automatically. No translation API calls. Prior checkpoint counts are unchanged; this is an additive build-time repair, rerun it after rebuilding the base patch.\n')
        if output.exists():raise ValueError('Output appeared during build')
        stage.rename(output);stage=None
    finally:
        if stage is not None:shutil.rmtree(stage)
    print('OFFLINE VX ACE COVERAGE FIX — NO API CALLS; original font retained')
    print('Event units repaired:',len(fixed),'; travel destinations:',36)
    print('Existing different boss text retained for review:',len(unmatched))
    print('Patch:',output)
    print('Windows playtest required: boss, battle commands, choices, travel and save/load.')

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('game');p.add_argument('--patch',required=True);p.add_argument('--output',required=True)
    p.add_argument('--target-language',choices=['en','ja'],help='Optional assertion; defaults to input patch report language')
    a=p.parse_args()
    try:apply(a.game,a.patch,a.output,a.target_language)
    except (ValueError,OSError,KeyError) as e:p.exit(2,'STOP: '+str(e)+'\n')
if __name__=='__main__':main()
