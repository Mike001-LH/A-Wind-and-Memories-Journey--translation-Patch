"""Language-isolated translation memory; uncertain version matches stay pending."""
from collections import defaultdict,Counter
from difflib import SequenceMatcher
import json
from pathlib import Path
from vxace.adapter import audit


def read_memory(path,target,source):
    p=Path(path)
    if p.is_dir():p=p/'translation_memory.json'
    data=json.loads(p.read_text(encoding='utf-8'))
    if data.get('format')!='gt-memory-1' or data.get('engine')!='vxace':raise ValueError('Expected VX Ace gt-memory-1')
    if data.get('target_language')!=target or data.get('source_language')!=source:
        raise ValueError('Translation memory language mismatch')
    rows=data.get('entries',[])
    if not isinstance(rows,list):raise ValueError('Invalid memory entries')
    for row in rows:
        if not all(isinstance(row.get(k),str) for k in ('id','source','translation')):raise ValueError('Invalid memory row')
    return rows


def migrate(units,rows,target):
    exact=defaultdict(list);byid=defaultdict(list)
    for row in rows:
        if not audit(row,target)['blocking']:
            exact[row['source']].append(row);byid[row['id']].append(row)
    events=[];used=set()
    for u in units:
        if u.get('translation'):continue
        candidates=[r for r in exact[u['source']] if r.get('kind')==u['metadata']['kind']]
        compatible=[r for r in candidates if r.get('context',[])==u.get('context',[])]
        same=[r for r in compatible if r['id']==u['id']]
        pool=same or compatible
        # A unique old occurrence can move to a new location; several meanings need review.
        if not pool and len(candidates)==1:pool=candidates
        verdict='new';chosen=None
        if pool:
            reviewed=[r for r in pool if r.get('reviewed')]
            preferred=reviewed or pool
            translations={r['translation'] for r in preferred}
            if len(translations)==1:chosen=preferred[0]
            else:verdict='conflict'
        elif candidates:verdict='context_conflict'
        if chosen:
            u['translation']=chosen['translation'];u['reviewed']=bool(chosen.get('reviewed'))
            u['provenance']={'method':'exact_source_reuse','old_id':chosen['id']}
            used.add(chosen['id']);verdict='reused'
        elif byid[u['id']]:
            old=byid[u['id']]
            if len(old)==1 and old[0]['source']!=u['source']:
                ratio=SequenceMatcher(None,old[0]['source'],u['source'],autojunk=False).ratio()
                if ratio>=0.72:
                    u['previous_version_reference']={'source':old[0]['source'],'translation':old[0]['translation']}
                    verdict='modified_needs_translation'
        event={'id':u['id'],'status':verdict}
        if verdict in ('conflict','context_conflict'):
            event['candidates']=[{'old_id':r['id'],'translation':r['translation'],'context':r.get('context',[])} for r in candidates]
        events.append(event)
    return {'counts':dict(Counter(x['status'] for x in events)),'entries':events,
            'old_entries_not_reused':sum(r['id'] not in used for r in rows),
            'note':'Not-reused old entries are not necessarily deleted; originals remain in old memory.'}


def export(units,target,source):
    return {'format':'gt-memory-1','engine':'vxace','source_language':source,'target_language':target,
            'entries':[{'id':u['id'],'source':u['source'],'translation':u['translation'],
                'file':u['file'],'location':u['location'],'kind':u['metadata']['kind'],
                'context':u.get('context',[]),'reviewed':bool(u.get('reviewed')),
                'provenance':u.get('provenance',{})} for u in units if not audit(u,target)['blocking']]}


def import_reviewed(units,path,target):
    data=json.loads(Path(path).read_text(encoding='utf-8'))
    if data.get('target_language')!=target:raise ValueError('Review import target language mismatch')
    lookup={u['id']:u for u in units};seen=set();pending=[]
    for row in data.get('entries',[]):
        key=row.get('id')
        if key in seen:raise ValueError('Duplicate reviewed unit')
        seen.add(key);u=lookup.get(key)
        if u is None or row.get('source')!=u['source']:raise ValueError('Reviewed import source mismatch')
        trial=dict(u,translation=row.get('translation',''))
        if audit(trial,target)['blocking']:raise ValueError('Reviewed import failed structural audit: '+str(key))
        pending.append((u,row['translation']))
    for u,tr in pending:
        u.update(translation=tr,reviewed=True,provenance={'method':'manual_import'})
    return len(pending)
