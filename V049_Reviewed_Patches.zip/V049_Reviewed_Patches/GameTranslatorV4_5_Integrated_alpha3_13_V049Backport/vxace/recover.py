"""Recover cached translations and build a VX Ace patch, without an API provider."""
import argparse
from pathlib import Path
from types import SimpleNamespace
from vxace.pipeline import run


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('game');p.add_argument('--target-language',choices=['en','ja','zh'],required=True)
    p.add_argument('--source-language',default='Chinese');p.add_argument('--output',required=True)
    p.add_argument('--workdir');p.add_argument('--allow-partial',action='store_true')
    p.add_argument('--repair-newlines',action='store_true',help='Reflow missing line breaks; verify window layout in game')
    a=p.parse_args();game=Path(a.game).expanduser().resolve()
    work=Path(a.workdir).expanduser().resolve() if a.workdir else game.parent/(game.name+'_GT_Work_'+a.target_language)
    args=SimpleNamespace(target_language=a.target_language,source_language=a.source_language,
        analyze=False,estimate=False,migrate_only=False,reuse_from=None,import_translations=None,glossary=None,
        sample=None,build_only=True,max_cost_rmb=5,price_band='peak',batch_size=10,repair_rounds=3,stall_rounds=2,
        allow_partial=a.allow_partial,vx_font=None,vx_sample_profile='mixed',no_vx_reuse=False,
        vx_recover_cached=True,vx_repair_newlines=a.repair_newlines)
    if not (work/'ace_checkpoint.json').is_file():p.exit(2,'STOP: Existing checkpoint required for offline recovery\n')
    try:run(game,work,Path(a.output).expanduser().resolve(),args)
    except (ValueError,OSError,RuntimeError) as exc:p.exit(2,'STOP: '+str(exc)+'\n')


if __name__=='__main__':main()
