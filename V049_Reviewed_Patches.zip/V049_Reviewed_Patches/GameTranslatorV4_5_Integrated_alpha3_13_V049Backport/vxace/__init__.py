"""VX Ace translation adapter."""
