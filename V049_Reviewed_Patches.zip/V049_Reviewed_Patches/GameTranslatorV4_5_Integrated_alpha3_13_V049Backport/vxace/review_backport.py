"""Offline text-only backport from reviewed translations. Never transplant newer Data."""
import argparse,json,shutil
from collections import defaultdict,Counter
from pathlib import Path
from vxace.adapter import collect_file,canonical,audit,restore_newlines,HAN
from vxace.marshal48 import text
from vxace.coverage_fix import checked_patch
from vxace.version_migrate import hashes,verified_strings,scripts
from vxace.choice_support import apply_runtime,known_term,supported

def read_units(game,patch,target,keep_files=False):
    report=json.loads((patch/'build_report.json').read_text(encoding='utf-8'))
    if report.get('target_language')!=target or report.get('source_hashes')!=hashes(game):
        raise ValueError('Patch language or original source hashes do not match')
    result=[];files={}
    for p in sorted((game/'Data').glob('*.rvdata2')):
        if p.name=='Scripts.rvdata2':continue
        rel='Data/'+p.name;raw=p.read_bytes();other=patch/rel
        translated=other.read_bytes() if other.is_file() else raw
        units,bindings,_,reader=collect_file(rel,raw)
        _,_,_,after=collect_file(rel,translated)
        if p.name=='Scripts.rvdata2':continue
        verified_strings(raw,translated,units,bindings,reader,after)
        indices={id(n):i for i,n in enumerate(reader.objects)}
        for u in units:
            values=[canonical(text(after.objects[indices[id(n)]])) for n in bindings[u['id']]]
            if u['metadata'].get('choice_aliases'):
                if len(set(values))!=1:raise ValueError('Choice and branch display labels differ')
                u['translation']=values[0]
            else:u['translation']='\n'.join(values)
            result.append(u)
        if keep_files:files[rel]=(translated,units,bindings,reader,after)
    return result,files,report

def build(game,old_patch,new_game,new_patch,target,output):
    game,old_patch,new_game,new_patch,output=map(Path,(game,old_patch,new_game,new_patch,output))
    if output.exists():raise ValueError('Output already exists')
    for source in (game,old_patch,new_game,new_patch):
        if output.resolve().is_relative_to(source.resolve()) or source.resolve().is_relative_to(output.resolve()):
            raise ValueError('Output must be separate from every input')
    if not supported(game):raise ValueError('Original scripts do not match reviewed Wind profile')
    old,files,report=read_units(game,old_patch,target,keep_files=True)
    new,_,_=read_units(new_game,new_patch,target)
    byid={u['id']:u for u in new};memory=defaultdict(set)
    for u in new:
        if u['translation']!=u['source'] and not audit(u,target)['blocking']:
            memory[(u['metadata']['kind'],u['source'])].add(u['translation'])
    fixed=[];pending=[];edits_by_file=defaultdict(dict)
    for u in old:
        # Retain every existing translation, including deliberate Kanji names in Japanese.
        if u['translation']!=u['source'] and not audit(u,target)['blocking']:continue
        candidate=None;method=None
        v=byid.get(u['id'])
        if v and v['source']==u['source'] and v['metadata']['kind']==u['metadata']['kind'] and v['translation']!=v['source'] and not audit(v,target)['blocking']:
            candidate=v['translation'];method='same_location_exact_source'
        else:
            values=memory[(u['metadata']['kind'],u['source'])]
            if len(values)==1:candidate=next(iter(values));method='unique_exact_source_same_kind'
        if candidate is None:
            literal_path=Path(__file__).with_name('wind_v049_backport_terms.json')
            literals=json.loads(literal_path.read_text(encoding='utf-8')) if literal_path.is_file() else {}
            item=literals.get(target,{}).get(u['source'])
            if item and item['kind']==u['metadata']['kind']:
                candidate=item['translation'];method='reviewed_v049_literal'
        if candidate is None and u['metadata']['kind']=='choice':
            candidate=known_term(u['source'],target);method='reviewed_choice_label'
        if candidate is not None and not audit(dict(u,translation=candidate),target)['blocking']:
            raw,_,bindings,reader,after=files[u['file']]
            nodes=bindings[u['id']];lines=candidate.split('\n');cursor=0
            indices={id(n):i for i,n in enumerate(reader.objects)}
            for node in nodes:
                count=canonical(text(node)).count('\n')+1
                value=candidate if u['metadata'].get('choice_aliases') else '\n'.join(lines[cursor:cursor+count])
                actual=after.objects[indices[id(node)]]
                encoded=restore_newlines(value,text(actual)).encode('utf-8')
                previous=edits_by_file[u['file']].get(actual.span)
                if previous is not None and previous!=encoded:raise ValueError('Conflicting shared choice edits')
                edits_by_file[u['file']][actual.span]=encoded;cursor+=count
            fixed.append({'id':u['id'],'file':u['file'],'source':u['source'],'translation':candidate,'method':method})
            u['translation']=candidate
        elif audit(u,target)['blocking'] or (u['translation']==u['source'] and HAN.search(u['source'])):
            pending.append({'id':u['id'],'file':u['file'],'source':u['source'],'kind':u['metadata']['kind'],
                'blocking':audit(u,target)['blocking'],'note':'Unchanged Han can be valid Japanese; manual review required.'})
    output.mkdir(parents=True)
    try:
        shutil.copytree(old_patch/'Data',output/'Data')
        for name,edits in edits_by_file.items():
            raw=files[name][0];made=checked_patch(raw,edits)
            dest=output/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(made)
        script=old_patch/'Data/Scripts.rvdata2'
        original=(game/'Data/Scripts.rvdata2').read_bytes()
        before=script.read_bytes() if script.is_file() else original
        made,runtime=apply_runtime(game,before,old,target)
        # Only Main may change; existing coverage, scrolling help and font scripts remain byte-equivalent after decompression.
        prev=scripts(before);now=scripts(made)
        assert len(prev)==len(now)
        for (name,a),(other,b) in zip(prev,now):
            assert name==other
            if name!='Main':assert a==b
        (output/'Data/Scripts.rvdata2').write_bytes(made)
        final,_,_=read_units(game,output_with_report(output,report),target)
        lookup={u['id']:u for u in final}
        for u in fixed:
            if lookup[u['id']]['translation']!=u['translation']:raise ValueError('Re-extracted fix differs: '+u['id'])
        changed_ids={u['id'] for u in fixed}
        for u in old:
            if u['id'] not in changed_ids:assert lookup[u['id']]['translation']==u['translation']
        summary={'version':'0.49','target_language':target,'api_calls':0,'fixed_units':len(fixed),
          'fixed_kinds':dict(Counter(u['metadata']['kind'] for u in old if u['id'] in changed_ids)),
          'structural_blocking':sum(bool(audit(u,target)['blocking']) for u in final),
          'unchanged_han_review_candidates':len(pending),'pending':pending,'fixes':fixed,'runtime':runtime,
          'validation':'All non-script files verified against original permitted string spans; existing translations retained; non-Main scripts retained; no new-version game data copied.',
          'runtime_test_required':True,'font_changed':False}
        (output/'backport_report.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
        report['changed_files']=sorted('Data/'+p.name for p in (output/'Data').glob('*.rvdata2'))
        report['unresolved']=summary['structural_blocking'];report['offline_backport']={k:v for k,v in summary.items() if k not in ('fixes','pending')}
        (output/'build_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
        print(json.dumps({k:v for k,v in summary.items() if k not in ('fixes','pending','runtime')},ensure_ascii=False),flush=True)
        return summary
    except Exception:
        shutil.rmtree(output);raise

def output_with_report(output,report):
    (output/'build_report.json').write_text(json.dumps(report,ensure_ascii=False),encoding='utf-8')
    return output

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('game');p.add_argument('--patch',required=True);p.add_argument('--reviewed-game',required=True)
    p.add_argument('--reviewed-patch',required=True);p.add_argument('--target-language',choices=['en','ja'],required=True)
    p.add_argument('--output',required=True);a=p.parse_args()
    build(a.game,a.patch,a.reviewed_game,a.reviewed_patch,a.target_language,a.output)
if __name__=='__main__':main()
