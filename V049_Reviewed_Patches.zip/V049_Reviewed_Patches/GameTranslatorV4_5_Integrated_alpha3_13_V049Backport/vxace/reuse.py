"""Conservative, run-local duplicate reuse. Never mixes language checkpoints."""
import json
from collections import defaultdict


def key(unit, source_language, target_language):
    kind = unit['metadata']['kind']
    context = unit.get('context', [])
    # Empty-context event text lacks speaker evidence: keep it in its own event/page.
    scope = unit['file']
    if kind in ('dialogue', 'scroll_text', 'choice', 'actor_name', 'actor_nickname') and not context:
        scope = [scope, unit['metadata']['path'][:-2]]
    return json.dumps([source_language, target_language, unit['source'], kind,
                       context, scope, unit.get('protected_tokens', []),
                       unit.get('previous_version_reference')], ensure_ascii=False, sort_keys=True)


class DuplicateReuse:
    def __init__(self, selected, all_units, audit, source_language, target_language, enabled=True):
        self.audit = audit
        self.selected = selected
        self.groups = defaultdict(list)
        self.seeds = defaultdict(list)
        self.stats = {'enabled': enabled, 'selected_units': len(selected),
                      'groups': 0, 'conflict_groups': 0, 'reused_units': 0,
                      'requested_representatives': 0, 'request_units_avoided': 0}
        self.pending = []
        if not enabled:
            self.representatives = selected
            return
        for u in all_units:
            self.seeds[key(u, source_language, target_language)].append(u)
        for u in selected:
            self.groups[key(u, source_language, target_language)].append(u)
        self.stats['groups'] = len(self.groups)
        representatives = []
        for k, group in self.groups.items():
            if any(u.get('reviewed') and audit(u)['blocking'] for u in group):
                raise ValueError('Reviewed translation fails QA; correct it via reviewed import')
            valid = [u for u in self.seeds[k] if not audit(u)['blocking']]
            values = {u['translation'] for u in valid}
            if len(values) > 1:
                self.stats['conflict_groups'] += 1
                representatives.extend(group)
                continue
            unresolved = [u for u in group if audit(u)['blocking']]
            # Never overwrite manually reviewed entries, even if their QA fails.
            locked = [u for u in unresolved if u.get('reviewed')]
            if locked:
                raise ValueError('Reviewed translation fails QA; correct it via reviewed import: '+locked[0]['id'])
            if not unresolved:
                continue
            representative = valid[0] if valid else unresolved[0]
            followers = [u for u in unresolved if u is not representative]
            self.pending.append((representative, followers))
            if not valid:
                representatives.append(representative)
            self.stats['request_units_avoided'] += len(unresolved) - (0 if valid else 1)
        self.representatives = representatives
        self.stats['requested_representatives'] = sum(bool(audit(u)['blocking']) for u in representatives)

    def propagate(self, state):
        pending = []
        for representative, followers in self.pending:
            if self.audit(representative)['blocking']:
                pending.append((representative, followers))
                continue
            for u in followers:
                if not self.audit(u)['blocking']:
                    continue
                value = representative['translation']
                if self.audit(dict(u, translation=value))['blocking']:
                    raise ValueError('Duplicate candidate failed destination QA: '+u['id'])
                u['translation'] = value
                u['provenance'] = {'method': 'duplicate_reuse', 'from_id': representative['id']}
                # Reuse is not a claim that this occurrence was manually reviewed.
                u['reviewed'] = False
                state.setdefault('rejected_candidates', {}).pop(u['id'], None)
                self.stats['reused_units'] += 1
        self.pending = pending
