"""VX Ace cross-version migration. Offline; preserves the new game's non-text data.
Use an old work directory/TM, or an old original plus its translated patch.
"""
import argparse
import json
from pathlib import Path
import tempfile
import shutil
from core.completion import fingerprint, atomic_json
from vxace.adapter import audit
from vxace.memory import export
from vxace.version_migrate import FORMAT, read, sha, recover, prepare, separate


def import_work(path,target,source=None):
    path=Path(path).expanduser().resolve()
    cp=path/'ace_checkpoint.json';up=path/'ace_units.json'
    if path.is_dir() and cp.is_file() and up.is_file():
        state=read(cp);units=read(up)
        if state.get('target_language')!=target:raise ValueError('Old work target language mismatch')
        language=state.get('source_language')
        if source is not None and source!=language:raise ValueError('Old work source language mismatch')
        if fingerprint(units)!=state.get('input_fingerprint'):raise ValueError('Old work units/checkpoint fingerprint mismatch')
        for u in units:
            u['translation']=state.get('translations',{}).get(u['id'],'')
            u['reviewed']=u['id'] in state.get('reviewed',[])
            u['provenance']=state.get('provenance',{}).get(u['id'],{})
        memory=export(units,target,language)
        inventory={u['id']:sha(u['source'].encode()) for u in units}
    else:
        memory=read(path/'translation_memory.json' if path.is_dir() else path)
        if memory.get('format')!='gt-memory-1' or memory.get('engine')!='vxace':raise ValueError('Expected VX Ace work directory or gt-memory-1 memory')
        if memory.get('target_language')!=target:raise ValueError('Old memory target language mismatch')
        language=memory.get('source_language')
        if source is not None and source!=language:raise ValueError('Old memory source language mismatch')
        if not isinstance(memory.get('entries'),list) or not all(isinstance(r.get(k),str) for r in memory['entries'] for k in ('id','source','translation')):
            raise ValueError('Invalid memory entries')
        inventory={r['id']:sha(r['source'].encode()) for r in memory['entries']}
    if not isinstance(language,str) or not language:raise ValueError('Old work/memory has no source language')
    bundle={'format':FORMAT,'target_language':target,'source_language':language,'source_inventory':inventory,
            'script_rows':[],'api_calls':0,'imported_from':str(path)}
    if path.is_dir() and (path/'bundle.json').is_file() and not cp.is_file():
        saved=read(path/'bundle.json')
        if saved.get('format')!=FORMAT or saved.get('target_language')!=target or saved.get('source_language')!=language:
            raise ValueError('Recovered bundle language/format mismatch')
        bundle=saved
    if path.is_dir() and (path/'version_script_transfer.json').is_file():
        # Keep verified literal recipes for future identical scripts. A changed runtime
        # dependency set still needs a new compatibility review, rather than blind reuse.
        recipe=read(path/'version_script_transfer.json')
        if recipe.get('target_language')!=target:raise ValueError('Old script recipe language mismatch')
        bundle['script_rows']=recipe.get('reusable_rows',[])
    return memory,bundle


def run(game,work,output,target,from_work=None,old_game=None,old_patch=None,source=None):
    game=Path(game).expanduser().resolve();work=Path(work).expanduser().resolve();output=Path(output).expanduser().resolve()
    inputs=[game]+[Path(p).expanduser().resolve() for p in (from_work,old_game,old_patch) if p]
    separate(work,*inputs);separate(output,*inputs,work)
    if from_work and (old_game or old_patch):raise ValueError('Choose old work OR old original plus patch')
    if not from_work and not (old_game and old_patch):raise ValueError('Provide --from-work, or both --old-game and --old-patch')
    work.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='.gt-migration-import-',dir=work.parent) as temp:
        bundle_path=Path(temp)/'bundle'
        if from_work:
            memory,bundle=import_work(from_work,target,source)
            bundle_path.mkdir();atomic_json(bundle_path/'translation_memory.json',memory);atomic_json(bundle_path/'bundle.json',bundle)
        else:
            recover(Path(old_game).expanduser().resolve(),Path(old_patch).expanduser().resolve(),target,bundle_path,source or 'Chinese')
        result=prepare(game,bundle_path,work,output)
        shutil.copytree(bundle_path,work/'imported_old_memory')
    print('NEXT: resume unified.py with the SAME --workdir, --source-language and --target-language; choose a new --output.')
    return result


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('game',help='New ORIGINAL game root (contains Data)')
    p.add_argument('--from-work',help='Old VX Ace work directory or translation_memory.json; latest checkpoint preferred')
    p.add_argument('--old-game',help='Old ORIGINAL game root; required when importing a patch')
    p.add_argument('--old-patch',help='Old translated patch with build_report.json')
    p.add_argument('--source-language',help='Optional assertion for old work; defaults to Chinese when importing old patch')
    p.add_argument('--target-language',required=True,choices=['en','ja','zh'])
    p.add_argument('--workdir',required=True,help='New, empty work directory')
    p.add_argument('--output',required=True,help='New, empty migrated patch directory')
    a=p.parse_args()
    try:run(a.game,a.workdir,a.output,a.target_language,a.from_work,a.old_game,a.old_patch,a.source_language)
    except (ValueError,OSError,KeyError,TypeError) as exc:p.exit(2,'STOP: '+str(exc)+'\n')
if __name__=='__main__':main()
