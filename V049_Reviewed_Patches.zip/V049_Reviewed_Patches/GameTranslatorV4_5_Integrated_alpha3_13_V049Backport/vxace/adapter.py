from pathlib import Path
import hashlib
import json
import re
import zlib
from collections import Counter
from vxace.marshal48 import Reader,Node,array,attr,text,patch

FIELDS={'Actors':('name','nickname','description'),'Classes':('name',),
 'Skills':('name','description','message1','message2'),'Items':('name','description'),
 'Weapons':('name','description'),'Armors':('name','description'),'Enemies':('name',),
 'States':('name','message1','message2','message3','message4')}
ESCAPE=re.compile(r'\\(?:[A-Za-z]+(?:\[[^\]\r\n]*\]|<[^>\r\n]*>)?|[\\{}$.|!><^])|%(?:\d+\$)?[-+ #0]*\d*(?:\.\d+)?[sdifgeuxXocp%]|<[^<>\r\n]+>')
# Keep extraction's legacy token metadata stable for existing fingerprints.
# QA distinguishes literal percentages/prose from actual printf placeholders.
AUDIT_TOKEN=re.compile(r'\\(?:[A-Za-z]+(?:\[[^\]\r\n]*\]|<[^>\r\n]*>)?|[\\{}$.|!><^])|(?<![0-9])%(?:\d+\$)?[-+#0]*\d*(?:\.\d+)?[sdifgeuxXocp%]|<[^<>\r\n]+>')
HAN=re.compile('[\u3400-\u9fff]')
CHOICE_CONDITION=re.compile(r'(?:if|en)\([^)]*\)',re.I)
# Restricted to the known Vocab module and simple one-line constant assignments.
VOCAB=re.compile(r'(?m)^(\s*[A-Z][A-Za-z0-9_]*\s*=\s*)([\'"])((?:\\.|[^\r\n\\])*?)\2(?=\s*(?:#.*)?\r?$)')

def canonical(s):return s.replace('\r\n','\n').replace('\r','\n')

def restore_newlines(value,original):
    separators=re.findall(r'\r\n|\r|\n',original)
    lines=value.split('\n')
    if len(lines)!=len(separators)+1:raise ValueError('Original line separator count mismatch')
    return ''.join(line+(separators[i] if i<len(separators) else '') for i,line in enumerate(lines))

def digest(b):return hashlib.sha256(b).hexdigest()
def engine_for(game):
    game=Path(game)
    return (game/'Data'/'System.rvdata2').is_file() and (game/'Data'/'Scripts.rvdata2').is_file()

def decompress(raw):
    dec=zlib.decompressobj();out=dec.decompress(raw,8*1024*1024+1)
    if len(out)>8*1024*1024 or not dec.eof or dec.unconsumed_tail or dec.unused_data:
        raise ValueError('Invalid/oversized compressed RGSS script')
    return out

def decode_literal(s,q):
    if '#{' in s or '#$' in s or '#@' in s:return None
    # Fail closed on special Ruby escape sequences not explicitly represented here.
    mapping={'\\':'\\',q:q,'n':'\n','r':'\r','t':'\t'} if q=='"' else {'\\':'\\',"'":"'"}
    out=[];i=0
    while i<len(s):
        if s[i]=='\\':
            i+=1
            if i==len(s) or s[i] not in mapping:return None
            out.append(mapping[s[i]])
        else:out.append(s[i])
        i+=1
    return ''.join(out)

def encode_literal(s,q):
    s=s.replace('\\','\\\\').replace(q,'\\'+q)
    if q=='"':s=s.replace('#{','\\#{').replace('#$','\\#$').replace('#@','\\#@')
    return s.replace('\n','\\n').replace('\r','\\r').replace('\t','\\t')


def collect_file(name,raw):
    reader=Reader(raw);root=reader.parse();units=[];bindings={};review=[]
    def add(nodes,path,kind,context=(),extra=None):
        sources=[text(n) for n in nodes]
        if not sources or any(s is None for s in sources):return None
        source='\n'.join(canonical(s) for s in sources)
        if not any(c.isalpha() for c in ESCAPE.sub('',source)):return None
        # Shared objects might also serve as resource identifiers: leave for review.
        # Shared choices are checked after all 402 aliases have been collected.
        if kind!='choice' and any(n.refs for n in nodes):
            review.append({'file':name,'location':path,'reason':'shared_string_reference','source':source});return None
        if any(n.attrs.get('E') is False or 'encoding' in n.attrs for n in nodes):
            review.append({'file':name,'location':path,'reason':'non_utf8_encoding_metadata','source':source});return None
        identity=json.dumps([name,path],ensure_ascii=False,separators=(',',':'))
        uid='ace:'+digest(identity.encode())[:24]
        meta={'kind':kind,'path':path,'line_count':source.count('\n')+1}
        if extra:meta.update(extra)
        unit={'id':uid,'engine':'vxace','file':name,'location':identity,'source':source,
              'translation':'','context':list(context),'protected_tokens':ESCAPE.findall(source),'metadata':meta}
        units.append(unit);bindings[uid]=nodes;return unit
    def commands(rows,path):
        rows=array(rows);i=0;context=[];choices={}
        while i<len(rows):
            row=rows[i];code=attr(row,'code');params=array(attr(row,'parameters'));indent=attr(row,'indent')
            if code in (401,405):
                nodes=[];first=i
                while i<len(rows) and attr(rows[i],'code')==code:
                    ps=array(attr(rows[i],'parameters'))
                    if not ps or text(ps[0]) is None:raise ValueError('Unexpected message parameter')
                    nodes.append(ps[0]);i+=1
                u=add(nodes,path+[first,'message'], 'dialogue' if code==401 else 'scroll_text',context[-3:],
                      {'node_line_counts':[canonical(text(n)).count('\n')+1 for n in nodes]})
                if u:context.append(u['source'])
                continue
            if code==102 and params:
                choices[indent]={}
                for k,node in enumerate(array(params[0])):
                    u=add([node],path+[i,'choice',k],'choice',context[-3:])
                    if u:choices[indent][k]=u
            elif code==402 and len(params)>1:
                u=choices.get(indent,{}).get(params[0])
                if u and text(params[1]) is not None and canonical(text(params[1]))==u['source']:
                    # Branch labels are aliases, not separate billable units.
                    bindings[u['id']].append(params[1]);u['metadata']['choice_aliases']=len(bindings[u['id']])-1
            elif code==404:choices.pop(indent,None)
            elif code in (320,324) and len(params)>1:
                add([params[1]],path+[i,'actor_text'], 'actor_name' if code==320 else 'actor_nickname',context[-3:])
            elif code in (355,655,108,408) and params:
                s=text(params[0])
                if s and HAN.search(s):review.append({'file':name,'location':path+[i],
                      'reason':'event_script' if code in (355,655) else 'event_comment','source':s})
            i+=1
    stem=Path(name).stem
    if stem in FIELDS:
        for i,row in enumerate(array(root)):
            for field in FIELDS[stem]:add([attr(row,field)],[i,field],'database_'+field)
            note=text(attr(row,'note'))
            if note and HAN.search(note):review.append({'file':name,'location':[i,'note'],'reason':'note_or_plugin_config','source':note})
    elif stem=='System':
        for field in ('game_title','currency_unit'):add([attr(root,field)],[field],'system')
        for field in ('elements','skill_types','weapon_types','armor_types'):
            for i,node in enumerate(array(attr(root,field))):add([node],[field,i],'system_term')
        terms=attr(root,'terms')
        for field in ('basic','params','etypes','commands'):
            for i,node in enumerate(array(attr(terms,field))):add([node],['terms',field,i],'system_term')
    elif stem=='CommonEvents':
        for i,row in enumerate(array(root)):commands(attr(row,'list'),[i,'list'])
    elif stem=='Troops':
        for i,row in enumerate(array(root)):
            for j,page in enumerate(array(attr(row,'pages'))):commands(attr(page,'list'),[i,'pages',j,'list'])
    elif re.fullmatch(r'Map\d+',stem):
        add([attr(root,'display_name')],['display_name'],'map_display_name')
        events=attr(root,'events')
        if isinstance(events,Node) and events.kind in ('{','}'):
            for key,event in events.value:
                for j,page in enumerate(array(attr(event,'pages'))):commands(attr(page,'list'),['events',key,'pages',j,'list'])
    elif stem=='Scripts':
        for i,row in enumerate(array(root)):
            vals=array(row)
            if len(vals)!=3 or not isinstance(vals[2],Node):raise ValueError('Unexpected Scripts entry')
            code=decompress(vals[2].value).decode('utf-8-sig');label=text(vals[1]) or ''
            approved=set()
            if label=='Vocab' and re.search(r'^module Vocab\s*$',code,re.M):
                for m in VOCAB.finditer(code):
                    value=decode_literal(m[3],m[2])
                    if value is None:continue
                    # Synthetic UTF-8 node; source span is in uncompressed script, never raw Marshal.
                    node=Node('"',value.encode())
                    constant=re.search(r'[A-Z]\w*',m[1])[0]
                    u=add([node],['script',i,constant],'script_vocab',extra={'script_index':i,
                          'script_label':label,'script_span':[m.start(3),m.end(3)],'quote':m[2]})
                    if u:bindings[u['id']]=[vals[2]];approved.add(code.count('\n',0,m.start(3))+1)
            for line_no,line in enumerate(code.splitlines(),1):
                if HAN.search(line) and not line.lstrip().startswith('#') and line_no not in approved:
                    review.append({'file':name,'script_index':i,'script_label':label,'line':line_no,
                                   'reason':'custom_script_review','source':line})
    # Permit a shared choice string only when EVERY serialized reference is
    # accounted for by this choice and its matching branch-label aliases.
    # Shared containers can expose descendants through another, non-display path;
    # fail closed for those descendants even if the apparent counts match.
    def children(node):
        if not isinstance(node,Node):return []
        values=list(node.attrs.values())
        if isinstance(node.value,list):
            for value in node.value:
                values.extend(value if isinstance(value,tuple) else [value])
        elif isinstance(node.value,Node):values.append(node.value)
        return [v for v in values if isinstance(v,Node)]
    shared_descendants=set()
    for container in reader.objects:
        if container.refs and container.kind!='"':
            todo=children(container);seen=set()
            while todo:
                item=todo.pop()
                if item in seen:continue
                seen.add(item);shared_descendants.add(item);todo.extend(children(item))
    owners={}
    for u in units:
        if u['metadata']['kind']=='script_vocab':continue
        for n in bindings[u['id']]:owners.setdefault(n,set()).add(u['id'])
    unsafe=set()
    for u in units:
        if u['metadata']['kind']=='script_vocab':continue
        nodes=bindings[u['id']];counts=Counter(nodes)
        for n in nodes:
            if n in shared_descendants or (n.refs and not (
                u['metadata']['kind']=='choice' and owners[n]=={u['id']} and counts[n]==n.refs+1)):
                unsafe.add(u['id']);break
    for u in units:
        if u['id'] in unsafe:review.append({'file':name,'location':u['metadata']['path'],'reason':'shared_alias','source':u['source']})
    return [u for u in units if u['id'] not in unsafe],bindings,review,reader


def extract(game):
    game=Path(game);units=[];hashes={};reviews=[];counts=Counter()
    paths=sorted((game/'Data').glob('*.rvdata2'))
    if not engine_for(game):raise ValueError('VX Ace requires Data/System.rvdata2 and Data/Scripts.rvdata2')
    for p in paths:
        raw=p.read_bytes();rel=p.relative_to(game).as_posix();hashes[rel]=digest(raw)
        rows,_,review,_=collect_file(rel,raw);units.extend(rows);reviews.extend(review)
        counts.update(u['metadata']['kind'] for u in rows)
    manifest={'engine':'RPG Maker VX Ace','source_hashes':hashes,'files':len(paths),
              'units':len(units),'source_characters':sum(len(u['source']) for u in units),'kinds':dict(counts)}
    return units,manifest,reviews


# Only substitution codes can move within the same physical line.
# Formatting, timing and custom codes keep their original sequence.
MOVABLE_TOKEN=re.compile(r'\\[vVnNpP]\[\d+\]$')

def compatible_tokens(source,translation):
    if AUDIT_TOKEN.findall(source)==AUDIT_TOKEN.findall(translation):return True
    if source.count('\n')!=translation.count('\n'):return False
    for a,b in zip(source.split('\n'),translation.split('\n')):
        left=AUDIT_TOKEN.findall(a);right=AUDIT_TOKEN.findall(b)
        if Counter(left)!=Counter(right):return False
        if [t for t in left if not MOVABLE_TOKEN.fullmatch(t)]!=[t for t in right if not MOVABLE_TOKEN.fullmatch(t)]:return False
    return True


def audit(u,target_language='en'):
    src=u['source'];tr=u.get('translation','');blocking=[];advisory=[]
    if not isinstance(tr,str) or not tr.strip():return {'blocking':['empty'],'advisory':[]}
    if not compatible_tokens(src,tr):blocking.append('control_token_mismatch')
    if u.get('metadata',{}).get('kind',u.get('kind'))=='choice' and CHOICE_CONDITION.findall(src)!=CHOICE_CONDITION.findall(tr):
        blocking.append('choice_condition_mismatch')
    if src.count('\n')!=tr.count('\n'):blocking.append('newline_mismatch')
    if any(c in tr for c in ('\x00','\r','\x1b')):blocking.append('unsafe_control_character')
    visible=AUDIT_TOKEN.sub('',tr)
    if target_language=='en' and HAN.search(visible):blocking.append('chinese_residue_in_english')
    if tr==src and HAN.search(AUDIT_TOKEN.sub('',src)):advisory.append('unchanged_han_text_review')
    if any(len(t)>max(42,len(s)*1.5) for s,t in zip(src.split('\n'),tr.split('\n'))):advisory.append('layout_review')
    return {'blocking':blocking,'advisory':advisory}


def build_files(game,units,manifest,target_language,allow_partial=False,font=None):
    game=Path(game);byfile={};unresolved=[];changed={}
    for u in units:byfile.setdefault(u['file'],{})[u['id']]=u
    if {p.relative_to(game).as_posix():digest(p.read_bytes()) for p in (game/'Data').glob('*.rvdata2')}!=manifest['source_hashes']:
        raise ValueError('Source changed; use a new workspace and --reuse-from')
    for name,wanted in byfile.items():
        raw=(game/name).read_bytes();original,bindings,_,reader=collect_file(name,raw);edits={};script_edits={}
        if set(wanted)!={u['id'] for u in original}:raise ValueError('Unit set mismatch')
        def put(node,value):
            old=edits.get(node.span)
            if old is not None and old!=value:raise ValueError('Conflicting translations for shared string')
            edits[node.span]=value
        for source in original:
            u=wanted[source['id']]
            if any(u[k]!=source[k] for k in ('source','metadata','file','context')):raise ValueError('Unit source/metadata mismatch')
            if audit(u,target_language)['blocking']:
                unresolved.append(u['id']);continue
            if u['translation']==u['source']:continue
            if u['metadata']['kind']=='script_vocab':
                node=bindings[u['id']][0];m=u['metadata'];script_edits.setdefault(node,[]).append(
                    (m['script_span'],encode_literal(u['translation'],m['quote'])))
            else:
                nodes=bindings[u['id']]
                if u['metadata'].get('choice_aliases'):
                    for node in nodes:put(node,restore_newlines(u['translation'],text(node)).encode('utf-8'))
                else:
                    lines=u['translation'].split('\n');cursor=0
                    for node in nodes:
                        count=canonical(text(node)).count('\n')+1
                        put(node,restore_newlines('\n'.join(lines[cursor:cursor+count]),text(node)).encode('utf-8'));cursor+=count
                    if cursor!=len(lines):raise ValueError('Line segmentation mismatch')
        for node,changes in script_edits.items():
            code=decompress(node.value).decode('utf-8-sig')
            for (a,b),value in sorted(changes,reverse=True):code=code[:a]+value+code[b:]
            put(node,zlib.compress(code.encode('utf-8')))
        if font and Path(name).stem=='Scripts':
            # Place font settings immediately before Main, after other font scripts loaded.
            entries=array(reader.objects[0]);found=[]
            for row in entries:
                vals=array(row)
                if len(vals)==3 and text(vals[1])=='Main':found.append(vals[2])
            if len(found)!=1:raise ValueError('Cannot locate unique Main for --vx-font')
            node=found[0];base=decompress(edits.get(node.span,node.value)).decode('utf-8-sig')
            literal='"'+encode_literal(font,'"')+'"'
            put(node,zlib.compress((f'Font.default_name = [{literal}]\n'+base).encode()))
        if edits:
            result=patch(raw,edits);check=Reader(result);check.parse()
            # Every serialized object, including all opaque Table/Color blobs, must stay identical
            # except explicitly edited strings. Link topology is unchanged by byte surgery.
            if len(check.objects)!=len(reader.objects):raise ValueError('Marshal reference table changed')
            for before,after in zip(reader.objects,check.objects):
                if before.kind!=after.kind or before.class_name!=after.class_name or before.refs!=after.refs:
                    raise ValueError('Marshal object structure changed')
                if isinstance(before.value,bytes):
                    if after.value!=edits.get(before.span,before.value):raise ValueError('Unintended binary change')
            changed[name]=result
    if unresolved and not allow_partial:raise ValueError(f'{len(unresolved)} unresolved entries; use --allow-partial or continue translation')
    return changed,unresolved
