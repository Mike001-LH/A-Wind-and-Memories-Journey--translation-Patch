# GT Japanese display profile v1 -- Wind and Memories demo V0.49.
# Loaded immediately before Main. Font family and size are unchanged.
module GTJapaneseLayout
  def gt_wrap_character(c, text, pos)
    return false if ["\n", "\f", "\e"].include?(c)
    left = pos[:new_x] || 0
    limit = contents.width - 4
    # Measure at word boundaries using the currently active RGSS font.
    word = c + (c =~ /[A-Za-z0-9]/ ? (text[/\A[A-Za-z0-9_'-]+/] || "") : "")
    boundary = @gt_word_start || c =~ /\s/
    need = pos[:x] > left && (pos[:x] + text_size(c).width > limit ||
      (boundary && c !~ /\s/ && pos[:x] + text_size(word).width > limit))
    if need
      # Include the current character so a page boundary cannot discard it.
      process_new_line(c + text, pos)
      if c =~ /\s/
        @gt_word_start = true
        return true
      end
    end
    @gt_word_start = !!(c =~ /\s/)
    false
  end
end

class Window_Message
  include GTJapaneseLayout
  alias gt_ja_process_character process_character
  def process_character(c, text, pos)
    @gt_word_start = true if pos[:x] == pos[:new_x]
    return if gt_wrap_character(c, text, pos)
    gt_ja_process_character(c, text, pos)
    @gt_word_start = true if c == "\n" || c == "\f"
  end
  alias gt_ja_process_draw_icon process_draw_icon
  def process_draw_icon(icon_index, pos)
    if pos[:x] > pos[:new_x] && pos[:x] + 24 > contents.width - 4
      process_new_line(" ", pos)
    end
    gt_ja_process_draw_icon(icon_index, pos)
  end
end

# Preserve the two-line help window geometry used by custom scenes. Render
# the complete wrapped description to a taller bitmap and scroll its viewport.
class Window_Help
  include GTJapaneseLayout
  alias gt_ja_help_process_character process_character
  def process_character(c, text, pos)
    @gt_word_start = true if pos[:x] == pos[:new_x]
    return if gt_wrap_character(c, text, pos)
    gt_ja_help_process_character(c, text, pos)
    @gt_word_start = true if c == "\n" || c == "\f"
  end
  alias gt_ja_help_draw_icon process_draw_icon
  def process_draw_icon(icon_index, pos)
    if pos[:x] > pos[:new_x] && pos[:x] + 24 > contents.width - 4
      process_new_line(" ", pos)
    end
    gt_ja_help_draw_icon(icon_index, pos)
  end
  def gt_render_description
    reset_font_settings
    text = convert_escape_characters((@text || "").dup)
    pos = {:x => 4, :y => 0, :new_x => 4, :height => calc_line_height(text)}
    @gt_word_start = true
    process_character(text.slice!(0, 1), text, pos) until text.empty?
    pos[:y] + pos[:height]
  end
  def refresh
    self.oy = 0
    contents.clear
    needed = gt_render_description
    visible = contents_height
    needed = [needed, visible].max
    if contents.height != needed
      contents.dispose
      self.contents = Bitmap.new(contents_width, needed)
    end
    contents.clear
    gt_render_description
    @gt_scroll_limit = [needed - visible, 0].max
    @gt_scroll_tick = 0
  end
  alias gt_ja_help_update update
  def update
    gt_ja_help_update
    return unless visible && openness > 0 && @gt_scroll_limit && @gt_scroll_limit > 0
    @gt_scroll_tick += 1
    # Pause at both ends. No input binding conflicts with item navigation.
    travel = @gt_scroll_limit * 2
    cycle = 180 + travel + 180
    t = @gt_scroll_tick % cycle
    self.oy = t < 180 ? 0 : [((t - 180) / 2), @gt_scroll_limit].min
  end
end

# The small acquisition toast is not an item-description window. Keep its
# compact stack geometry, and direct players to the now-scrollable item help.
if defined?(Window_Getinfo)
  class Window_Getinfo
    def description(data)
      "詳細はアイテム・スキル画面へ"
    end
  end
end

# Translate only the A1 speaker-name display, never actor names or save data.
if defined?(Cache) && Cache.respond_to?(:name_bitmap)
  module Cache
    class << self
      alias gt_ja_name_bitmap name_bitmap
      def name_bitmap(name)
        table = GT_JA_SPEAKERS
        # User-selected actor names must remain exactly as entered.
        actors = $game_actors ? ($game_actors.instance_variable_get(:@data) || []) : []
        player_name = actors.compact.any? {|actor| actor.name == name }
        gt_ja_name_bitmap(player_name ? name : (table[name] || name))
      end
    end
  end
end

if defined?(Window_NameInput_Command)
  class Window_NameInput_Command
    GT_HIRAGANA = "あいうえおかきくけこさしすせそたちつてとなにぬねのはひふへほまみむめもやゆよらりるれろわをんがぎぐげござじずぜぞだぢづでどばびぶべぼぱぴぷぺぽぁぃぅぇぉゃゅょっゔー".split(//)
    GT_KATAKANA = "アイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホマミムメモヤユヨラリルレロワヲンガギグゲゴザジズゼゾダヂヅデドバビブベボパピプペポァィゥェォャュョッヴー".split(//)
    alias gt_ja_name_commands make_command_list
    def make_command_list
      if @kanji_mode
        gt_ja_name_commands
        return
      end
      add_command("ひらがな", :command_ok, true, GT_HIRAGANA)
      add_command("カタカナ", :command_ok, true, GT_KATAKANA)
      add_command("英数字", :command_ok, true, LATIN1)
      add_command("漢字一覧", :command_ok, true, CHINA1)
      add_command("記号", :command_ok, true, SPCHAR)
      add_command("一字削除", :backspace, true)
      add_command("全消去", :clear, true)
      add_command("初期化", :reset, true)
      add_command("決定", :name_ok, true)
    end
  end
end
