"""Choice coverage reporting and narrowly reviewed Wind V0.49/V0.50 display recovery."""
from collections import defaultdict
import hashlib
import json
from pathlib import Path
import re
import zlib
from vxace.adapter import audit,decompress
from vxace.marshal48 import Reader,array,text

MARKER='# GT choice display recovery v1'
END='# END GT choice display recovery v1'
TERMS={
    'en':{'是':'Yes','否':'No','你是谁？':'Who are you?','你是谁?':'Who are you?','你是谁':'Who are you?',
          '询问多萝西':'Ask about Dorothy','侵犯':'Assault','离开':'Leave'},
    'ja':{'是':'はい','否':'いいえ','你是谁？':'あなたは誰？','你是谁?':'あなたは誰？','你是谁':'あなたは誰？',
          '询问多萝西':'ドロシーについて尋ねる','侵犯':'襲う','离开':'立ち去る'}}
COLOR=re.compile(r'^(?P<head>(?:\\[cC]\[\d+\])*)(?P<body>.*?)(?P<tail>(?:\\[cC]\[\d+\])*)$',re.S)

def supported(game):
    p=Path(game)/'Data/Scripts.rvdata2'
    profile=json.loads(Path(__file__).with_name('wind_v050_migration.json').read_text(encoding='utf-8'))
    reviewed = [profile['scripts_sha256']]
    backport = Path(__file__).with_name('wind_v049_choice_profile.json')
    if backport.is_file(): reviewed.append(json.loads(backport.read_text())['scripts_sha256'])
    return p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest() in reviewed

def known_term(source,target):
    match=COLOR.fullmatch(source)
    if not match:return None
    value=TERMS.get(target,{}).get(match['body'])
    return match['head']+value+match['tail'] if value else None

def fill_known(game,units,target):
    if not supported(game):return []
    fixed=[]
    for u in units:
        if u['metadata']['kind']!='choice' or u.get('translation') or u.get('reviewed'):continue
        value=known_term(u['source'],target)
        if value and not audit(dict(u,translation=value),target)['blocking']:
            u['translation']=value;u['provenance']={'method':'reviewed_wind_choice_label'}
            fixed.append(u['id'])
    return fixed

def report(units,target,reviews=()):
    choices=[u for u in units if u['metadata']['kind']=='choice']
    pending=[{'id':u['id'],'file':u['file'],'source':u['source'],'blocking':audit(u,target)['blocking']}
             for u in choices if audit(u,target)['blocking']]
    excluded=[r for r in reviews if r.get('reason') in ('shared_alias','shared_string_reference')]
    return {'choice_units':len(choices),'pending_choices':len(pending),'pending':pending,
            'shared_strings_still_excluded':excluded,'note':'Pending counts cover extracted choices; excluded technical strings are not automatically translated.'}

def apply_runtime(game,raw,units,target):
    """Recover old-save choice display without changing branch indices or saved data.
    Restricted to the reviewed source scripts. Conflicting cached translations are omitted.
    """
    if not supported(game) or target not in TERMS:return raw,{'enabled':False,'reason':'runtime_profile_not_reviewed'}
    from vxace.coverage_fix import checked_patch
    from vxace.display_fix import ruby_literal
    candidates=defaultdict(set)
    for u in units:
        if u['metadata']['kind']=='choice' and not audit(u,target)['blocking']:
            def visible(value):
                for token in ('if','en'):value=re.sub(r'\s*'+token+r'\([^)]*\)','',value,count=1,flags=re.I)
                return value
            candidates[visible(u['source'])].add(visible(u['translation']))
    mapping={s:next(iter(values)) for s,values in candidates.items() if len(values)==1 and s!=next(iter(values))}
    # Exact reviewed labels also handle the screenshot's old-save values.
    for source in candidates:
        known=known_term(source,target)
        if known:mapping[source]=known
    conflicts=[s for s,v in candidates.items() if len(v)>1 and not known_term(s,target)]
    original=array(Reader((Path(game)/'Data/Scripts.rvdata2').read_bytes()).parse())
    rows=array(Reader(raw).parse());main=[i for i,r in enumerate(original) if text(array(r)[1])=='Main']
    if len(main)!=1 or len(rows)!=len(original):raise ValueError('Choice runtime requires original script structure')
    i=main[0];base=decompress(array(original[i])[2].value).decode('utf-8-sig')
    node=array(rows[i])[2];code=decompress(node.value).decode('utf-8-sig')
    if not code.endswith(base):raise ValueError('Original Main suffix changed; choice runtime not applied')
    if MARKER in code:
        pattern=re.compile(r'^'+re.escape(MARKER)+r'\r?\n.*?^'+re.escape(END)+r'\r?\n?',re.S|re.M)
        code,count=pattern.subn('',code)
        if count!=1:raise ValueError('Ambiguous existing choice runtime')
    table='GT_CHOICE_DISPLAY_TRANSLATIONS = {\n'+',\n'.join(ruby_literal(s)+' => '+ruby_literal(t) for s,t in sorted(mapping.items()))+'\n}\n'
    runtime=MARKER+'\n'+table+'''class Window_ChoiceList
  alias gt_choice_display_original_start start
  def start
    $game_message.choices.map! {|label| GT_CHOICE_DISPLAY_TRANSLATIONS[label] || label }
    gt_choice_display_original_start
  end
end
'''+END+'\n'
    prefix=code[:-len(base)] if base else code
    made=checked_patch(raw,{node.span:zlib.compress((prefix+runtime+base).encode('utf-8'))})
    return made,{'enabled':True,'mapped_original_labels':len(mapping),'ambiguous_old_save_labels':conflicts,
                 'branch_indices_changed':False,'font_changed':False,'runtime_test_required':True}
