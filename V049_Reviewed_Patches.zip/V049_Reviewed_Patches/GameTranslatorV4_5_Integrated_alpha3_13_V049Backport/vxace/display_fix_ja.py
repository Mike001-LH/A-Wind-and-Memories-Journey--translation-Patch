"""Offline Japanese display patch for Wind and Memories demo V0.49 only."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import tempfile
import zlib
from vxace.marshal48 import Reader, array, attr, text, patch
from vxace.adapter import decompress, encode_literal

HERE = Path(__file__).parent
MARKER = '# GT Japanese display profile v1'
UI = {
 134: {'获得魂！':'ソウルを獲得！','失去魂…':'ソウルを失った…','获得道具！':'アイテムを入手！','失去道具…':'アイテムを失った…',
       '获得武器！':'武器を入手！','失去武器…':'武器を失った…','获得防具！':'防具を入手！','失去防具…':'防具を失った…',
       '习得技能！':'スキルを習得！','忘却技能…':'スキルを忘れた…','获得EXP！':'経験値を獲得！','失去EXP…':'経験値を失った…'},
 223: {'现在地':'現在地'},226: {'信物':'形見'},
 285: {'英／数':'英数字','希／俄':'ギリシャ／ロシア','特殊字母':'拡張ラテン','特殊字符':'記号','汉字[拼音]':'漢字（拼音）','汉字[快捷]':'漢字一覧',
       '完成':'決定','退格':'一字削除','清空':'全消去','重置':'初期化'},
 291: {'罪业':'罪業','死亡次数':'死亡回数','时空稳定性':'時空安定度'},
 300: {'罪业':'罪業','死亡次数':'死亡回数','时空稳定性':'時空安定度'}
}

def ruby_literal(s):
    return '"'+encode_literal(s, '"')+'"'

def sha(raw): return hashlib.sha256(raw).hexdigest()

def read_json(p): return json.loads(p.read_text(encoding='utf-8'))

def speaker_table(game, translated):
    names = {}
    # Prefer names already translated in the user's database, when unambiguous.
    candidates = {}
    for filename in ('Actors.rvdata2',):
        a=game/'Data'/filename; b=translated/'Data'/filename
        if not a.is_file() or not b.is_file(): continue
        for before,after in zip(array(Reader(a.read_bytes()).parse()),array(Reader(b.read_bytes()).parse())):
            s=text(attr(before,'name')); t=text(attr(after,'name'))
            if s and t and re.search(r'[\u3400-\u9fff]',s) and s != t and all(chr(c) not in t for c in (10,13,92)):
                candidates.setdefault(s,set()).add(t)
    for s,ts in candidates.items():
        if len(ts)==1: names[s]=next(iter(ts))
    for s,t in list(names.items()):
        names[s+'？']=t+'？'; names[s+'【灵魂分身】']=t+'【魂の分身】'
    return names

def edit_scripts(raw, names):
    r=Reader(raw); rows=array(r.parse())
    profile=read_json(HERE/'wind_v049_scripts.json')
    if len(rows)!=306: raise ValueError('This display profile only supports the supplied V0.49 scripts (306 entries)')
    codes={i:decompress(array(row)[2].value).decode('utf-8-sig') for i,row in enumerate(rows)}
    if any(MARKER in code for code in codes.values()): raise ValueError('Display fix already applied; select the earlier Japanese patch')
    for key,expected in profile.items():
        i=int(key); row=array(rows[i])
        if text(row[1])!=expected['name'] or sha(decompress(row[2].value))!=expected['sha256']:
            raise ValueError('Unsupported or modified script at index %d; original data was not changed'%i)
    edits={}; counts={}
    for i,mapping in UI.items():
        code=codes[i]; count=0
        for src,dst in mapping.items():
            token=json.dumps(src,ensure_ascii=False)
            n=code.count(token)
            if not n: raise ValueError('Expected UI literal missing: '+src)
            code=code.replace(token,json.dumps(dst,ensure_ascii=False)); count+=n
        edits[array(rows[i])[2].span]=zlib.compress(code.encode('utf-8'));counts[str(i)]=count
    main=[i for i,row in enumerate(rows) if text(array(row)[1])=='Main']
    if len(main)!=1: raise ValueError('Expected one Main script')
    # Ruby hash literals: JSON values are strings, so no JSON booleans/null.
    ruby_names='GT_JA_SPEAKERS = {\n'+',\n'.join(ruby_literal(k)+' => '+ruby_literal(v) for k,v in sorted(names.items()))+'\n}\n'
    i=main[0]; runtime=(HERE/'japanese_layout.rb').read_text(encoding='utf-8')
    edits[array(rows[i])[2].span]=zlib.compress((ruby_names+runtime+'\n'+codes[i]).encode('utf-8'))
    result=patch(raw,edits); check=Reader(result);check.parse()
    if len(r.objects)!=len(check.objects): raise ValueError('Marshal structure changed')
    for a,b in zip(r.objects,check.objects):
        if (a.kind,a.class_name,a.refs)!=(b.kind,b.class_name,b.refs):raise ValueError('Marshal topology changed')
        if isinstance(a.value,bytes) and b.value!=edits.get(a.span,a.value):raise ValueError('Unintended binary change')
    return result,counts

def apply(game, translated, output):
    game=Path(game).resolve();translated=Path(translated).resolve();output=Path(output).resolve()
    if output.exists():raise ValueError('Output already exists; choose a new --output')
    if any(output==p or output.is_relative_to(p) or p.is_relative_to(output) for p in (game,translated)):
        raise ValueError('Output must be separate from the original game and input patch')
    report=read_json(translated/'build_report.json')
    if report.get('engine')!='vxace' or report.get('target_language')!='ja':raise ValueError('Input must be an Japanese VX Ace patch with build_report.json')
    originals={p.relative_to(game).as_posix():sha(p.read_bytes()) for p in (game/'Data').glob('*.rvdata2')}
    if originals!=report.get('source_hashes'):raise ValueError('Original game does not match the translation patch')
    names=speaker_table(game,translated)
    scripts=translated/'Data/Scripts.rvdata2'
    if not scripts.is_file(): scripts=game/'Data/Scripts.rvdata2'
    raw,counts=edit_scripts(scripts.read_bytes(),names)
    missing=set()
    for p in (game/'Data').glob('*.rvdata2'):
        if p.stem=='Scripts':continue
        reader=Reader(p.read_bytes());reader.parse()
        for node in reader.objects:
            if not isinstance(node.value,bytes):continue
            s=node.value.decode('utf-8',errors='ignore')
            for match in re.finditer(r'NW名前指定\s+([^\r\n]+)',s):
                name=match[1].strip()
                if re.search('[\u3400-\u9fff]',name) and name not in names:missing.add(name)
    stage=None
    try:
        output.parent.mkdir(parents=True,exist_ok=True)
        stage=Path(tempfile.mkdtemp(prefix='.gt-display-',dir=output.parent));(stage/'Data').mkdir()
        for p in (translated/'Data').glob('*.rvdata2'):shutil.copy2(p,stage/'Data'/p.name)
        (stage/'Data/Scripts.rvdata2').write_bytes(raw)
        ini_source=translated/'Game.ini'
        if not ini_source.is_file(): ini_source=game/'Game.ini'
        ini=ini_source.read_bytes()
        ini,n=re.subn(rb'(?m)^Title=[^\r\n]*', b'Title=Wind and Memories - Demo 0.49 (Japanese)', ini)
        if n!=1: raise ValueError('Expected one Game.ini Title entry')
        (stage/'Game.ini').write_bytes(ini)
        report['japanese_display_profile']='wind-v049-ja-v1'
        report['changed_files']=sorted(set(report.get('changed_files',[]))|{'Data/Scripts.rvdata2','Game.ini'})
        (stage/'build_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
        details={'api_calls':0,'font_changed':False,'ui_literal_counts':counts,'speaker_entries':len(names),
                 'unmapped_speakers':sorted(missing),'inherited_unresolved':report.get('unresolved'),
                 'runtime_test_required':True,'source_patch':str(translated)}
        (stage/'display_fix_report.json').write_text(json.dumps(details,ensure_ascii=False,indent=2),encoding='utf-8')
        (stage/'INSTALL.txt').write_text('Japanese display test patch for Wind and Memories demo V0.49\n'
          'Make a separate copy of the original game. Merge the files inside this Data folder into its Data folder.\n'
          'Do not delete/replace the whole Data directory. Also copy Game.ini to the game root. Apply only to the Japanese V0.49 patch.\n'
          'Font family and default size are unchanged. Dialogues wrap and paginate; long item help scrolls automatically.\n'
          'Acquisition toasts show a short hint to view the full description in Items / Skills.\n'
          'Test dialogue with/without faces, icons, color codes, waits, choices, help scrolling, menus, naming and save/load.\n'
          'Existing untranslated extracted entries remain; corrupt/unknown speaker names are listed in display_fix_report.json.\n'
          'Unmapped custom speaker labels remain; check your translated Actors database and rebuild from the previous patch if needed.\n',encoding='utf-8')
        if output.exists():raise ValueError('Output already exists')
        stage.rename(output);stage=None
    finally:
        if stage is not None:shutil.rmtree(stage)
    print('OFFLINE DISPLAY FIX — NO API CALLS; original font retained')
    print('Patch:',output)
    print('Unmapped speaker labels:',len(missing),'(see display_fix_report.json)')
    print('Inherited unresolved extracted entries:',report.get('unresolved'))

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('game');p.add_argument('--patch',required=True);p.add_argument('--output',required=True)
    a=p.parse_args()
    try: apply(a.game,a.patch,a.output)
    except (ValueError,OSError,KeyError) as e:p.exit(2,'STOP: '+str(e)+'\n')
if __name__=='__main__':main()
