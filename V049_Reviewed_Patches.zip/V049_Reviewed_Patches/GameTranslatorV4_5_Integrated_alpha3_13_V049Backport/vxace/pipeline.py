from pathlib import Path
import json
import shutil
import tempfile
from collections import Counter
from datetime import datetime
from core.completion import atomic_json,complete,fingerprint
from core.glossary import load_glossary
from core.safe_output import validate_paths
from providers.config import make_provider, SessionAccounting
from bruns.translate import load_env
from vxace.staged import run_stages
from vxace.adapter import extract,audit,build_files,AUDIT_TOKEN,CHOICE_CONDITION
from vxace.reuse import DuplicateReuse
from vxace.recovery import recover_candidates
from vxace.memory import migrate,read_memory,export,import_reviewed

LANGUAGES={'en':'English','ja':'Japanese','zh':'Simplified Chinese'}

def run(game,work,output,args,provider=None):
    game,work,output=map(Path,(game,work,output));target=args.target_language
    if target not in LANGUAGES:raise ValueError('VX Ace requires --target-language en/ja/zh')
    if game==work or game in work.parents or work in game.parents:raise ValueError('Workspace must be separate from game')
    readonly=args.analyze or args.estimate or args.migrate_only
    if not readonly:validate_paths(game,work,output)
    if any(p.is_symlink() for p in (game/'Data').rglob('*')):raise ValueError('Data contains symlinks; use a regular copy')
    units,manifest,reviews=extract(game)
    manifest.update(game=str(game.resolve()),source_language=args.source_language,target_language=target)
    mp=work/'ace_manifest.json'
    if mp.exists() and json.loads(mp.read_text(encoding='utf-8'))!=manifest:
        raise ValueError('Source/language/extraction changed. Keep this work and use translator.py migrate-vx GAME --from-work OLD_WORKDIR with a NEW --workdir and --output.')
    # Reject incompatible migration supplements before any paid request.
    prepared_transfer=work/'version_script_transfer.json'
    if prepared_transfer.is_file():
        if args.vx_font:raise ValueError('Version-migrated work preserves the original font; omit --vx-font')
        from vxace.version_migrate import apply_script_recipe
        apply_script_recipe(game,(game/'Data/Scripts.rvdata2').read_bytes(),json.loads(prepared_transfer.read_text(encoding='utf-8')),target)
    atomic_json(mp,manifest);atomic_json(work/'ace_units.json',units)
    atomic_json(work/'ace_excluded_review.json',{'counts':dict(Counter(r['reason'] for r in reviews)),
                'entries':reviews,'note':'These are excluded candidates, not a count of untranslated visible lines.'})
    print(f'VX Ace: {len(units)} units; {manifest["files"]} data files; {manifest["source_characters"]} source characters')
    print('Target:',LANGUAGES[target]);print('Excluded/review candidates:',len(reviews),'(see ace_excluded_review.json)')
    cp=work/'ace_checkpoint.json';sig=fingerprint(units)
    state={'input_fingerprint':sig,'target_language':target,'source_language':args.source_language,
           'translations':{},'reviewed':[],'provenance':{},'spent_rmb':0.}
    if cp.exists():
        state=json.loads(cp.read_text(encoding='utf-8'))
        if state.get('input_fingerprint')!=sig or state.get('target_language')!=target or state.get('source_language')!=args.source_language:
            raise ValueError('Checkpoint/source/language mismatch')
        if not readonly and (not state.get('duplicate_reuse_schema') or getattr(args,'vx_recover_cached',False)):
            backup=cp.with_name(cp.name+'.before-reuse-'+datetime.now().strftime('%Y%m%d-%H%M%S-%f'))
            shutil.copy2(cp,backup)
            print('Checkpoint backup:',backup)
        reviewed=set(state.get('reviewed',[]))
        for u in units:
            u['translation']=state.get('translations',{}).get(u['id'],'')
            u['reviewed']=u['id'] in reviewed;u['provenance']=state.get('provenance',{}).get(u['id'],{})
            old=state.get('previous_version_references',{}).get(u['id'])
            if old:u['previous_version_reference']=old
    # Analysis alone never applies glossary or starts translation.
    if args.reuse_from:
        report=migrate(units,read_memory(args.reuse_from,target,args.source_language),target)
        atomic_json(work/'ace_migration_report.json',report);print('Migration:',report['counts'])
    if args.import_translations:print('Reviewed imports:',import_reviewed(units,args.import_translations,target))
    def qa(u):
        result=audit(u,target)
        if u['id'] in state.get('semantic_review_pending',{}):
            result=dict(result,blocking=list(result['blocking'])+['semantic_review_candidate_rejected'])
        return result
    from vxace.choice_support import fill_known,apply_runtime as apply_choice_runtime,report as choice_report
    if not readonly:fill_known(game,units,target)
    glossary=load_glossary(args.glossary)
    if not readonly:
        for u in units:
            term=glossary.get(u['source'])
            if term and not u['translation'] and not qa(dict(u,translation=term['target']))['blocking']:
                u['translation']=term['target'];u['provenance']={'method':'glossary'}
    recovery=None
    if getattr(args,'vx_recover_cached',False):
        recovery=recover_candidates(units,state,target,getattr(args,'vx_repair_newlines',False))
        atomic_json(work/'ace_offline_recovery_report.json',recovery)
        print('OFFLINE RECOVERY — NO API CALLS; recovered:',len(recovery['recovered']))
    reuse=None
    def save(_rows,st):
        if reuse is not None:reuse.propagate(st)
        st['translations']={u['id']:u['translation'] for u in units if u['translation']}
        st['reviewed']=[u['id'] for u in units if u.get('reviewed')]
        st['provenance']={u['id']:u['provenance'] for u in units if u.get('provenance')}
        st['previous_version_references']={u['id']:u['previous_version_reference'] for u in units if u.get('previous_version_reference')}
        atomic_json(cp,st)
        # Full reports/memory are generated at the end; checkpoint after every batch.
    def reports():
        if reuse is not None:atomic_json(work/'ace_reuse_report.json',reuse.stats)
        problems=[];warnings=[]
        for u in units:
            result=qa(u);row={'id':u['id'],'source':u['source'],'translation':u['translation'],**result}
            if result['blocking']:problems.append(row)
            if result['advisory']:warnings.append(row)
        atomic_json(work/'ace_completion_report.json',{'total':len(units),'blocking_count':len(problems),
          'stop_reason':state.get('stop_reason'),'cost_summary':state.get('cost_summary'),'api_session':state.get('api_session'),'workflow':state.get('workflow'),'unresolved':problems,'advisories':warnings,
          'excluded_review_candidates':len(reviews)})
        atomic_json(work/'translation_memory.json',export(units,target,args.source_language))
        atomic_json(work/'ace_choice_coverage_report.json',choice_report(units,target,reviews))
    if readonly:
        reuse=DuplicateReuse(units,units,qa,args.source_language,target,not getattr(args,'no_vx_reuse',False))
        print('Duplicate reuse preview:',reuse.stats)
        # Analysis reports potential reuse without applying translations.
        preview=reuse;reuse=None
        atomic_json(work/'ace_reuse_report.json',preview.stats)
        state['stop_reason']='migration_only' if args.migrate_only else 'analysis_only'
        save(units,state);reports();print('STATUS: ANALYSIS/MIGRATION COMPLETE — NO API CALLS');return
    # Sample profiles make runtime verification intentional instead of depending on file order.
    # mixed keeps the original menu-first behavior; story prioritizes actual event dialogue/choices.
    profile=getattr(args,'vx_sample_profile','mixed')
    def priority(u):
        k=u['metadata']['kind'];path=u['metadata']['path']
        title_menu=(k=='system_term' and path[:2]==['terms','commands'] and path[-1] in (18,19,20))
        menu_term=(k=='system_term' and path[:2]==['terms','commands'])
        if profile=='story':
            rank=0 if k=='dialogue' else 1 if k=='choice' else 2 if k in ('actor_name','actor_nickname','scroll_text') else 3 if title_menu else 4
        elif profile=='menu':
            rank=0 if title_menu else 1 if menu_term else 2 if k=='script_vocab' else 3
        else:
            rank=-1 if title_menu else 0 if menu_term else 1 if k=='script_vocab' else 2 if k=='dialogue' else 3
        return (rank,u['file'],u['location'])
    selected=sorted(units,key=priority)[:args.sample] if args.sample else units
    print('Sample units:',len(selected)) if args.sample else None
    reuse=DuplicateReuse(selected,units,qa,args.source_language,target,not getattr(args,'no_vx_reuse',False))
    state['duplicate_reuse_schema']=1
    reuse.propagate(state)
    print('Duplicate reuse:',reuse.stats)
    save(units,state)
    if getattr(args,'economy',False):print('省钱模式：短 ID / 紧凑 JSON / 共用规则 / 上下文引用；每批最多',args.batch_size,'条、',getattr(args,'batch_chars',3500),'原文字；实际节省以 token 用量为准')
    accounting=None
    active_provider=provider
    def make_request(stage_args,label='primary',review=False,responses=None):
        nonlocal accounting,active_provider
        # Reuse gateway accounting for semantic review; its cap includes all gateway calls.
        if accounting is None or label=='paid_residual':
            if accounting is not None:accounting.finish(state.get('stop_reason','stage_complete'))
            accounting=SessionAccounting(stage_args,state)
            active_provider=provider if label!='paid_residual' and provider is not None else make_provider(stage_args)
        def request(batch,phase):
            accounting.before()
            if label!='paid_residual':
                attempted=set(state.get('gateway_attempted_units',[]));attempted.update(u['id'] for u in batch)
                state['gateway_attempted_units']=sorted(attempted)
            payload=[]
            for u in batch:
                ctx=u['context']+['Keep exactly the same number of physical newlines and preserve ALL protected tokens. '
                                 'Fit concise game dialogue/UI text. Do not alter technical tags. '
                                 'Separate bare backslash letter codes from following English words with a space.']
                if review:
                    ctx+=['Review this existing target-language draft against the source. Correct mistranslation, '
                          'omissions, unnatural phrasing, speaker tone and terminology. Return the complete corrected '
                          'translation, or the same draft if it is already good. Do not output review commentary. '
                          'Existing draft: '+u.get('translation','')]
                pending=state.get('semantic_review_pending',{}).get(u['id'])
                if pending:ctx+=['Previous review failed validation: '+json.dumps(pending,ensure_ascii=False)]
                rejected=state.get('rejected_candidates',{}).get(u['id'])
                if rejected:ctx+=['Previous rejected draft; fix structural problems while preserving meaning: '+rejected]
                if u.get('previous_version_reference'):
                    ctx+=['Previous-version reference only; translate the NEW source accurately: '+json.dumps(u['previous_version_reference'],ensure_ascii=False)]
                conditions=CHOICE_CONDITION.findall(u['source']) if u['metadata']['kind']=='choice' else []
                if conditions:ctx+=['Preserve these choice visibility/enabling formulas verbatim: '+json.dumps(conditions,ensure_ascii=False)]
                payload.append(dict(u,context=ctx,protected_tokens=AUDIT_TOKEN.findall(u['source'])+conditions))
            def record_usage(usage):
                used={'prompt_tokens':usage.prompt_tokens,'completion_tokens':usage.completion_tokens,
                      'prompt_cache_hit_tokens':usage.cache_hit_tokens,'prompt_cache_miss_tokens':usage.cache_miss_tokens,
                      'reasoning_tokens':getattr(usage,'reasoning_tokens',0)}
                if getattr(usage,'reported',True):accounting.record(used)
                else:accounting.missing()
                return used
            try:
                made,usage=active_provider.translate_batch(payload,glossary=glossary,source_language=args.source_language,target_language=LANGUAGES[target])
            except (KeyboardInterrupt,SystemExit):
                accounting.missing()
                raise
            except Exception as exc:
                if getattr(exc,'usage',None) is not None:
                    record_usage(exc.usage)
                    if responses is not None:
                        responses.update(u['id'] for u in batch)
                        if label!='paid_residual':state['gateway_response_units']=sorted(responses)
                else:accounting.missing()
                print('API stopped:',getattr(exc,'reason','request_error'),str(exc),flush=True)
                raise
            used=record_usage(usage)
            if responses is not None:
                responses.update(u['id'] for u in batch)
                if label!='paid_residual':state['gateway_response_units']=sorted(responses)
            if not review:
                for u in batch:
                    if isinstance(made.get(u['id']),str) and not audit(dict(u,translation=made[u['id']]),target)['blocking']:
                        state.get('semantic_review_pending',{}).pop(u['id'],None)
                        u['provenance']={'method':'model_translation','stage':label,
                                         'provider':accounting.config['provider'],'model':accounting.config['model']}
            return made,used
        return request
    if args.build_only:state['stop_reason']='offline_build';save(units,state);reports()
    else:
        load_env()
        staged=getattr(args,'fallback_deepseek',False) or getattr(args,'ai_review_units',0)
        state['api_session']=None;state['session_spent_rmb']=0.
        try:
            if staged:
                # The stage controller uses the base audit; this wrapper exposes flags in reports.
                run_stages(reuse.representatives,lambda u:audit(u,target),make_request,save,args,state)
            else:
                state.pop('workflow',None)
                request=make_request(args) if any(qa(u)['blocking'] for u in reuse.representatives) else None
                complete(reuse.representatives,qa,request,save,rounds=args.repair_rounds,batch_size=args.batch_size,stall_rounds=args.stall_rounds,state=state,max_batch_chars=getattr(args,'batch_chars',3500) if getattr(args,'economy',False) else None)
        finally:
            if accounting is not None:accounting.finish(state.get('stop_reason','interrupted'))
            save(units,state);reports()
    if not any(u['translation'] and not qa(u)['blocking'] for u in selected):raise ValueError('No valid translations; inspect completion report')
    changed,unresolved=build_files(game,units,manifest,target,args.allow_partial or bool(args.sample),args.vx_font)
    # Prepared version migrations retain layout/UI supplements on every rebuild.
    transfer_path=work/'version_script_transfer.json'
    transfer_report=None
    if transfer_path.is_file():
        if args.vx_font:raise ValueError('Version-migrated work preserves the original font; omit --vx-font')
        from vxace.version_migrate import apply_script_recipe
        recipe=json.loads(transfer_path.read_text(encoding='utf-8'))
        raw=changed.get('Data/Scripts.rvdata2',(game/'Data/Scripts.rvdata2').read_bytes())
        changed['Data/Scripts.rvdata2']=apply_script_recipe(game,raw,recipe,target)
        transfer_report={'font_changed':False,'runtime_test_required':True,
                         'scripts':[{'index':r['index'],'name':r['name']} for r in recipe['scripts']],
                         'issues':recipe['issues']}
    choice_raw,choice_runtime=apply_choice_runtime(game,changed.get('Data/Scripts.rvdata2',(game/'Data/Scripts.rvdata2').read_bytes()),units,target)
    if choice_runtime['enabled']:changed['Data/Scripts.rvdata2']=choice_raw
    if not changed:raise ValueError('No changed files to publish')
    output.parent.mkdir(parents=True,exist_ok=True);stage=Path(tempfile.mkdtemp(prefix='.gt-ace-',dir=output.parent))
    try:
        for rel,raw in changed.items():
            p=stage/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
        if transfer_report is not None:atomic_json(stage/'script_transfer_report.json',transfer_report)
        atomic_json(stage/'choice_display_report.json',choice_runtime)
        atomic_json(stage/'build_report.json',{'engine':'vxace','target_language':target,'changed_files':list(changed),
                'unresolved':len(unresolved),'sample':args.sample,'source_hashes':manifest['source_hashes'],
                'excluded_review_candidates':len(reviews),'font_override':args.vx_font,'sample_profile':getattr(args,'vx_sample_profile','mixed'),'duplicate_reuse':reuse.stats,'cost_summary':state.get('cost_summary'),'api_session':state.get('api_session') if not args.build_only else None,'workflow':state.get('workflow') if not args.build_only else None})
        (stage/'INSTALL.txt').write_text('VX Ace translation patch / 实验版翻译补丁\n'
            'Close the game. Make a COPY of the matching ORIGINAL game version for this language.\n'
            'Back up Data in that copy, then merge this patch Data directory into the copy Data directory.\n'
            'Do not replace/delete the whole Data folder. Do not stack English and Japanese patches.\n'
            'Start a NEW game; test menus, dialogue, choices, battle, save/load, font glyphs and layout.\n'
            'Only the exact original source version used to build this patch is supported.\n'
            'Custom script UI, plugin notes and image text may remain in the source language.\n'
            '关闭游戏，为每种语言各复制一份对应版本的原游戏。备份副本 Data，然后合并补丁 Data 中的文件。\n'
            '不要删除整个 Data，不要叠加英文和日文补丁；已有存档可能保留旧名字。\n'
            '本版不自动翻译所有自定义脚本或图片；请查看工作目录中的排版与遗漏报告。\n',encoding='utf-8')
        if output.exists():raise ValueError('Output already exists; choose a new --output')
        stage.rename(output)
    finally:
        if stage.exists():shutil.rmtree(stage)
    if state.get('workflow'):
        atomic_json(output/'workflow_report.json',state['workflow'])
    print('DONE — VX Ace patch:',output)
    if state.get('stop_reason') not in ('clean','offline_build'):print('NOTICE: stopped:',state.get('stop_reason'),'— see ace_checkpoint.json errors and completion report')
    if unresolved:print('WARNING: extracted entries retained in original language:',len(unresolved))
    print('Custom script/note/image coverage and layout still require in-game verification.')
