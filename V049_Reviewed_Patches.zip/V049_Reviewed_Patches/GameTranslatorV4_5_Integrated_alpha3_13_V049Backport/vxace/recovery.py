"""Offline QA recovery. Candidate repairs remain opt-in and reported."""
import re
from vxace.adapter import audit
from vxace.reflow import repair_newlines


def separate_bare_codes(source, candidate):
    # RGSS consumes ASCII letters greedily. Only repair known single-letter
    # codes occurring bare in source, never bracket arguments/custom long codes.
    codes = {m.group(1) for m in re.finditer(r'\\([cCiIvVnNpPgG])(?=[^A-Za-z\[<]|$)', source)}
    if not codes:
        return candidate
    def replace(match):
        code = match.group(1)
        return '\\'+code+' '+match.group(2) if code in codes else match.group(0)
    return re.sub(r'\\([cCiIvVnNpPgG])([A-Za-z]+)(?![A-Za-z\[<])', replace, candidate)


def restore_actor_tokens(source,candidate):
    # A literal backslash-n actor code is sometimes mistaken for a newline.
    # Restore only indices/case explicitly present in source, with exact counts.
    expected=re.findall(r'\\[nN]\[\d+\]',source)
    for token in dict.fromkeys(expected):
        bracket=token[2:]
        wanted=expected.count(token)
        existing=candidate.count(token)
        if existing==wanted:continue
        if existing>wanted:return candidate
        # Bare [index] is considered only if source has no plain occurrence of it.
        stripped=source
        for known in expected:stripped=stripped.replace(known,'')
        if bracket in stripped:return candidate
        pattern=re.compile(r'(?:\n|(?<![\\A-Za-z]))'+re.escape(bracket))
        matches=list(pattern.finditer(candidate))
        if len(matches)!=wanted-existing:return candidate
        for m in reversed(matches):candidate=candidate[:m.start()]+token+candidate[m.end():]
    return candidate


def recover_candidates(units, state, target, repair_lines=False):
    result={'recovered':[], 'repairs':[], 'api_calls':0}
    rejected=state.get('rejected_candidates',{})
    for u in units:
        if u.get('reviewed') or not audit(u,target)['blocking']:
            continue
        candidate=rejected.get(u['id'])
        if not isinstance(candidate,str) or not candidate.strip():
            continue
        original=candidate
        candidate=restore_actor_tokens(u['source'],candidate)
        candidate=separate_bare_codes(u['source'],candidate)
        if repair_lines:
            # Remove only surplus empty terminal lines, never visible text.
            while candidate.endswith('\n') and not u['source'].endswith('\n') and candidate.count('\n')>u['source'].count('\n'):
                candidate=candidate[:-1]
            fixed=repair_newlines(u,candidate,target)
            if fixed is not None:candidate=fixed
        if audit(dict(u,translation=candidate),target)['blocking']:
            continue
        u['translation']=candidate
        u['provenance']={'method':'offline_cached_recovery'}
        result['recovered'].append(u['id'])
        if candidate!=original:
            result['repairs'].append({'id':u['id'],'source':u['source'],'before':original,'after':candidate})
        rejected.pop(u['id'],None)
    return result
