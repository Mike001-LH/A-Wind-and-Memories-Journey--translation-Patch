#!/usr/bin/env python3
"""One launcher for game, file, recovery, display and diagnostic workflows."""
from pathlib import Path
import argparse
import os
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
COMMANDS = {
    'backport-vx': ('-m vxace.review_backport', 'VX Ace 已审校文本回移旧版；精确匹配、离线、保留旧版游戏数据'),
    'game-update': ('-m game_update', '完整游戏跨版本差异包：离线构建、校验并生成更新副本'),
    'migrate-vx': ('-m vxace.migrate_cli', 'VX Ace 跨版本迁移：旧工作目录或原版+补丁；离线生成新进度和补丁'),
    'migration-tools': ('-m vxace.version_migrate', '迁移工具：旧补丁提取翻译记忆、准备迁移、恢复可携带进度'),
    'dxa': ('-m dxa.cli', 'Witch’s Forest DXA8 分析、提取、无 API 重建与分层诊断'),
    'game': ('unified.py', '游戏检测、分析、翻译与补丁；兼容旧 unified.py 参数'),
    'files': ('translatorpp_adapter.py', 'MTool JSON / Translator++ Excel；本地 Ollama 或 DeepSeek'),
    'configure': ('-m providers.configure', '分别配置官方 DeepSeek 和线衣密钥'),
    'recover-vx': ('-m vxace.recover', 'VX Ace 离线恢复、换行修复'),
    'recover-rpg': ('-m rpgmaker.recover', 'MV/MZ 离线恢复、换行修复'),
    'coverage-en': ('-m vxace.coverage_fix', '风与追忆之旅 V0.49 英文漏译增补；离线'),
    'display-en': ('-m vxace.display_fix', '风与追忆之旅 V0.49 英文显示修复'),
    'display-ja': ('-m vxace.display_fix_ja', '风与追忆之旅 V0.49 日文显示修复；保留字体'),
    'renpy-advanced': ('pipeline.py', '保留 Ren’Py 完整旧管线参数'),
    'dxa-diagnostic': ('experimental/WitchForest_Diagnostic_alpha2/build.py', 'Witch’s Forest 专用 DXA 诊断，实验功能'),
    'dxa-menu-legacy': ('experimental/WitchForest_Menu_Probe/build_menu_probe.py', '旧菜单探针（曾闪退，仅兼容保留）'),
}
BRUNS_TOOLS = ('extract', 'translate', 'qa', 'write', 'audit_missed', 'audit_built',
               'repair_pending', 'repair_quality', 'repair_certain', 'repair_certain_local',
               'repair_survivors', 'repair_final120', 'final_audit', 'final_clean')

def command_line(command, rest):
    if command == 'bruns-legacy':
        if not rest or rest[0] not in BRUNS_TOOLS:
            raise ValueError('bruns-legacy 需要工具名：' + ', '.join(BRUNS_TOOLS))
        return [sys.executable, str(ROOT/'legacy/bruns_tools/bruns'/(rest[0]+'.py')), *rest[1:]]
    target = COMMANDS[command][0]
    if target.startswith('-m '):
        return [sys.executable, '-m', target[3:], *rest]
    return [sys.executable, str(ROOT/target), *rest]

def main(argv=None):
    argv=list(sys.argv[1:] if argv is None else argv)
    if not argv or argv[0] in ('-h','--help'):
        print('Game Translator 4.5 Integrated alpha3.13 V049 Backport\n用法：python3 translator.py COMMAND [原有参数]\n')
        for name, (_, description) in COMMANDS.items():print(f'  {name:20} {description}')
        print('  bruns-legacy         早期 Bruns 工作目录专项修复，独立兼容格式')
        print('\n各命令帮助：python3 translator.py COMMAND --help\n旧 unified.py / translatorpp_adapter.py / python3 -m ... 命令仍可用。')
        return 0
    if argv[0]=='bruns-legacy' and (len(argv)==1 or argv[1] in ('-h','--help')):
        print('python3 translator.py bruns-legacy TOOL [参数]\n工具：'+', '.join(BRUNS_TOOLS));return 0
    if argv[0] not in COMMANDS and argv[0]!='bruns-legacy':
        print('未知命令；运行 python3 translator.py --help',file=sys.stderr);return 2
    # Keep user-relative paths relative to the invoking directory. Add modules to
    # PYTHONPATH instead of changing cwd and silently changing input paths.
    env=os.environ.copy()
    env['PYTHONPATH']=str(ROOT)+(os.pathsep+env['PYTHONPATH'] if env.get('PYTHONPATH') else '')
    from bruns.translate import load_env
    load_env()
    for key in ('DEEPSEEK_API_KEY','XIANYI_API_KEY'):
        if key in os.environ:env[key]=os.environ[key]
    try:return subprocess.call(command_line(argv[0],argv[1:]),env=env)
    except (ValueError,OSError) as exc:
        print('STOP:',exc,file=sys.stderr);return 2

if __name__=='__main__':raise SystemExit(main())
