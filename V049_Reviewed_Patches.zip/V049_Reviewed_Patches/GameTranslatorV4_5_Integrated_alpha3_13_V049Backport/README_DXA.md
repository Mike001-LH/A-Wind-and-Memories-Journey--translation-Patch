# Witch's Forest / DXA8：离线工具与分层启动验证

本版本接在 V4.5 Integrated alpha1 上，保留其全部模块。
**目前没有证据证明旧菜单包闪退的原因已解决。** 新包已通过真实数据的离线读写验证，
还需要用户在 Windows 上验证。不要开始付费翻译全文。

## 本次新增

- 纯 Python DXA8 文件读取、加密流处理、LZ / Huffman 解压与编码；Mac/Windows 无需编译 C++。
- 保留原文件的压缩组合和存档属性；未修改文件直接复用原压缩/加密数据。
- 从头重建资源包，重算数据地址和索引，不再把新资源追加到旧完整索引后面。
- 发布前再次解包验证新文本，并逐个比较未修改资源的压缩/加密字节。
- 游戏分析、原始 TXT 提取、可编辑菜单单位导出、受校验的菜单回写。
- 保留老探针供复现，但推荐新的 `translator.py dxa` 命令。

只有用户提供的 **Witch's Forest 1.01 原始 data.dxa** 已建立游戏配置。
CLI 会检查其大小和 SHA256；其他 DxLib 游戏/版本不能自动套用该配置。
DXA 是资源容器，里面的文本格式仍需逐游戏适配。

## 已完成的真实数据检查

| 检查 | 结果 |
|---|---|
| 资源总数 | 1,853 |
| 原始 TXT 文件 | 213，全部与之前独立解包的结果一致 |
| 文本编码检测 | ASCII 109、CP932 64、UTF-8 35、未确定 5 |
| 菜单单位 | 日文与英文菜单共 130 条 |
| 不改内容的重建 | 1,853 个资源的压缩/加密数据全部一致 |
| 英文/中文诊断 | 只改 `data01/wtex_jp.txt` 的第一个菜单标签，另外 1,852 个资源一致 |
| 独立验证 | 新索引和菜单通过原版 DXArchive C++ 解码函数复核 |
| 测试 | 97 项离线回归通过，包含先前 90 项 |
| Windows 游戏运行 | 尚未在本环境验证；需要下面的启动测试 |

未确定编码的 5 个文件为 `data01/tk_dat/teki_mo0.txt` 至 `teki_mo4.txt`，
提取时仍按原字节保存，不猜测编码、不送翻译。

## 第一步：只测试重打包，不改任何文字

把整合包解压到 `~/Documents/local-llm-translator` 后，先进入工具目录：

```bash
cd "$HOME/Documents/local-llm-translator/GameTranslatorV4_5_Integrated_alpha2_DXA"
```

生成完全不改资源内容的重建包：

```bash
python3 translator.py dxa diagnose "/Users/mike/Downloads/淫らで邪悪な魔女の森/Witch's_Forest_1.01/data/data.dxa" --mode repack --output "$HOME/Downloads/WitchForest_Repack_Test/data.dxa"
```

此命令不需要 API Key，不会收费。若提示源包不匹配，先恢复未修改原包。
输出约 614 MB；重建时还会使用临时文件空间，建议有至少 2 GB 空闲空间。
输出已存在时请换一个新目录，工具不会覆盖。

**测试方法：**

1. 在 Windows 上复制一份原版游戏，确认副本原样能启动。
2. 关闭游戏，将刚生成的 `data.dxa` 替换到这个副本的 `data/data.dxa`。
3. 不修改 EXE、字体或系统区域。启动，看标题菜单能否出现、能否进入剧情并推进几句。
4. 游戏表现应与原版相同，因为没有翻译任何资源内容。

若这个包仍闪退，先停在这一步。提供游戏目录中新生成的日志/报错以及
`data.dxa.report.json`，继续查归档兼容或游戏自身检查，暂时不要测试中文字体。
没有日志也可以直接反馈“原包可开，repack 闪退”。

可选 `--mode clone` 会生成 SHA256 与原包完全一致的副本，帮助排查传输或替换路径：

```bash
python3 translator.py dxa diagnose "/Users/mike/Downloads/淫らで邪悪な魔女の森/Witch's_Forest_1.01/data/data.dxa" --mode clone --output "$HOME/Downloads/WitchForest_Clone_Test/data.dxa"
```

## 第二步：repack 正常后，只改一个英文菜单标签

```bash
python3 translator.py dxa diagnose "/Users/mike/Downloads/淫らで邪悪な魔女の森/Witch's_Forest_1.01/data/data.dxa" --mode ascii --output "$HOME/Downloads/WitchForest_ASCII_Test/data.dxa"
```

仍替换同一测试副本中的 `data/data.dxa`。游戏处于日语菜单时，第一个标签应成为
`START`（后面有填充空格）。英文菜单文件完全不变。
若游戏当前使用英语，切到日语菜单再检查；没有变化不等于包没有生效。

这一步保持原菜单文件的字节长度、行数、行尾和所有控制行。

## 第三步：英文标签正常后，测试一个中文标签

```bash
python3 translator.py dxa diagnose "/Users/mike/Downloads/淫らで邪悪な魔女の森/Witch's_Forest_1.01/data/data.dxa" --mode chinese --output "$HOME/Downloads/WitchForest_Chinese_Test/data.dxa"
```

第一个日语菜单标签应显示 `开始新游戏`。其他标签保留原文。
菜单文件仍为原本的 UTF-8、同样字节长度，不修改任何字体。
再确认点击新游戏后能够进入剧情。

| 游戏内结果 | 下一步方向 |
|---|---|
| 原包能开，repack 不能开 | 继续查归档布局/索引/游戏检查；不能认定是字体问题 |
| repack 正常，ASCII 异常 | 查该菜单读取与显示逻辑、是否确实在日语菜单 |
| ASCII 正常，中文异常/缺字 | 查菜单编码、文字渲染或字体覆盖 |
| 三者都正常 | 再适配剧情格式并接翻译管线 |

以上是排查方向，不是已确定的故障结论。

## 分析和原文提取

```bash
python3 translator.py dxa analyze "/Users/mike/Downloads/淫らで邪悪な魔女の森/Witch's_Forest_1.01" --workdir "$HOME/Downloads/WitchForest_DXA_Work"
```

输出 `dxa_analysis.json` 和 `menu_units.json`。分析不会覆盖已经编辑的菜单单位文件。
原游戏 `unified.py ... --analyze` 现在也能识别该 DXA8 容器并调用此分析。

```bash
python3 translator.py dxa extract "/Users/mike/Downloads/淫らで邪悪な魔女の森/Witch's_Forest_1.01" --output "$HOME/Downloads/WitchForest_Extracted_Text"
```

提取 213 个 TXT 的原始字节，并保留资源目录结构。文件可能混用编码，
不要批量用编辑器转换所有文件。

## 审阅后的菜单回写（游戏内诊断通过后使用）

编辑 `menu_units.json` 每条的 `translation`，保留 `id/source/path/line/encoding`。
空译文保留原文；不允许添加新单位、移动行、修改源文或在标签中注入换行。

```bash
python3 translator.py dxa build-menu "/Users/mike/Downloads/淫らで邪悪な魔女の森/Witch's_Forest_1.01" --translations "$HOME/Downloads/WitchForest_DXA_Work/menu_units.json" --allow-partial --output "$HOME/Downloads/WitchForest_Reviewed_Menu/data.dxa"
```

这是**离线菜单回写**，不是已完成的剧情自动翻译器。事件脚本中的控制数字、记录边界、
文字框容量、CP932 可编码性以及图片文字尚未接入自动翻译；不会因为识别到 TXT 就盲目替换。

## 格式依据

离线研究使用 DXArchive 1.08 官方分发源码核对格式与解码行为：
https://dxlib.xsrv.jp/temp/DXArchive_1_08.zip

纯 Python 模块不依赖该 C++ 编译产物；独立 C++ 验证仅用于开发测试。
游戏数据、EXE 和重建后的 600 MB 资源包不包含在工具 ZIP 中，由用户在自己的副本上生成。
