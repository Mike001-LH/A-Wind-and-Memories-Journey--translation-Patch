# alpha3.8 — DKTools locale scope

- MV/MZ --locale selects supported DKTools JSON branches, shared data, dictionary values and allowlisted display fields.
- Analysis is free. Multi-locale translations require explicit scope; unknown language expressions block translation.
- References stay protected, including distinction from escaped font-size braces.
- Separate workspaces and exact-source read-only --reuse-from imports preserve progress.
- Scoped reports and offline recovery preserve intentionally excluded branches.
- 134 offline tests pass. Uploaded fixture passes mock writeback and Node syntax checks; no real API or Windows runtime verification.

Limits: direct locale comparisons only; no generalized variable/call-graph inference, other localization plugins, recursive/CSV dictionary loading or arbitrary script translation. Shared translated data can affect all runtime language slots.
