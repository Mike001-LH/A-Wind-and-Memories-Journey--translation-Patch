# KAG / XP3 汉化工具 4.3.0 alpha4

这是整合工具的实验版扩展，保留 Ren'Py、Bruns、RPG Maker MV/MZ 和之前的离线恢复功能。需要 Python 3.10 或更新版本。使用原有 DeepSeek 配置，未更换模型、接口或计价逻辑。

这次游戏的解包脚本属于 KAG3。KAG3 是脚本系统名称，不能据此认定底层就是 KiriKiri3。本适配器处理可读 KS + 标准 XP3；不声称支持所有 KiriKiri 游戏。

## 先运行免费分析

在本工具目录打开 PowerShell，替换下面的路径：

```powershell
py unified.py "D:\Games\你的游戏" --analyze
```

自动查找顺序：

1. 游戏目录或其直接子目录里已有的 `scenario/*.ks`；也接受单独的 `scenario` 目录。
2. 没有解包目录时，查找含 XP3 的 EXE 或 XP3 文件，自动提取 KS/TJS 到工作目录 `kag_extracted`。不提取图片、音乐、视频，不修改 EXE。
3. 有多个解包目录或多个可能的封包时，不猜测，要求指定来源：

```powershell
py unified.py "D:\Games\你的游戏" --extracted "D:\Extracted\解包后的完整目录" --analyze
py unified.py "D:\Games\你的游戏" --archive "D:\Games\你的游戏\游戏.exe" --analyze
```

`--extracted` 应指向含 scenario 的目录，或者 scenario 本身。完整目录可检查更多原始文件；只给 scenario 也能使用，但不会检查 system 配置。

自动解包支持标准未加密 XP3、zlib 压缩索引/数据、标准分段和 EXE 内嵌 XP3。加密、私有索引、特殊资源映射需先用 GARbro 解包。内置解包不依赖安装 GARbro，也不会调用未知路径的外部程序。若原游戏有官方 patch*.xp3，先确认应翻译的最新资源版本；本版不自动合并多个封包。已有提取目录优先，不会根据 EXE 时间自动覆盖你整理好的目录。

**分析与预检不请求翻译 API。** `--estimate` 目前显示文本统计，不是准确费用报价。

## 少量试译

沿用旧版 `.env`（只在自己的电脑保管）或设置环境变量，然后试译菜单：

```powershell
$env:DEEPSEEK_API_KEY = "你的密钥"
py unified.py "D:\Games\你的游戏" --source-language Japanese --sample 3 --batch-size 3 --repair-rounds 1 --max-cost-rmb 5
```

如果分析时使用了 `--extracted` / `--archive`，后续命令继续附带同一个参数。
默认先选 `first.ks` 中的正文，再按文件和位置选择；这款游戏 first.ks 正好有三个菜单选项。其他文字保留原文。

输出为游戏旁边的 `游戏名_Chinese_Patch_Sample3`，其中有 `patch.xp3` 和安装说明。输出目录已存在时会停止，请加 `--output "D:\Patches\新目录名"`，不会删除旧成果。

关闭游戏，备份并移走上次测试用的 patch.xp3，把新 patch.xp3 放在原游戏 EXE 同级目录，运行原 EXE。已有官方补丁不要直接覆盖；patch2.xp3 等可能优先于 patch.xp3。启动新游戏检查菜单、剧情推进、分支、存读档和排版。卸载时移除本补丁并恢复原备份。

## 全量和续译

```powershell
py unified.py "D:\Games\你的游戏" --source-language Japanese --batch-size 10 --repair-rounds 3 --max-cost-rmb 5 --allow-partial
```

去掉 `--sample` 就是全部已提取正文。每批保存 checkpoint，下次保持同一游戏、来源和工作目录，自动复用已通过的译文。预算耗尽后可以再次运行，只请求剩余条目。默认输出 `游戏名_Chinese_Patch`；再次生成请指定新的 `--output`。

`--max-cost-rmb` 沿用旧版估算，为每次运行的预算；一批完成后才知道用量，可能略超限，API 实际账单为准。这里没有验证或更新供应商当前价格。

`--allow-partial` 允许剩余条目保留原文并出补丁；不加时存在未通过项会停止。未通过候选和原因记录在 `kag_checkpoint.json` / `kag_completion_report.json`。请不要删除工作目录。

## 不调用 API，重新生成补丁

```powershell
py unified.py "D:\Games\你的游戏" --build-only --allow-partial --output "D:\Patches\重新打包"
```

此模式只读取已存译文和术语表，不自动补译。源脚本发生变化时拒绝复用工作区，使用新的 `--workdir` 重新分析。

## 格式和范围

- 自动识别 UTF-8、带 BOM 的 UTF-16、CP932 日文脚本；补丁脚本统一 UTF-16LE + BOM。
- 只翻译可识别的正文/名字/选择文字；保留原始换行、标签参数、跳转、资源名和指令。
- 不翻译 TJS、iscript/macro 块、注释、标签参数、含转义 `[[` 的行或图片文字。宏内正文、动态生成文本需另行适配。
- 拒绝译文新增脚本控制字符或换行；这属于结构检查，不是语义质量保证，也不证明全游戏无遗漏。
- 通过 first.ks 设置字体 `Microsoft YaHei,SimSun`。可用 `--kag-font-face "已安装的字体名"` 更换；字体文件不打包。中文较长时仍需实机检查溢出。
- 使用已验证的根目录脚本名覆盖方式；相同 KS 文件名冲突、没有唯一 first.ks 或自定义入口会停止。自定义 KAG 系统需要单独适配。
- 图形界面可分析和试译自动识别的项目；多封包/外部解包路径等高级选项使用命令行。

## 验证记录

用户此前已实测此游戏的菜单 XP3：中文正常显示，并可进入剧情连续推进。本版完整流程尚未在该游戏 EXE 实机跑完。

本地：对用户提供的 14 个 KS 脚本完成提取，得到 2,486 个文本片段、39,189 个源字符，分布于 10 个含正文脚本；未发送付费 API 请求。21 项自动测试通过，涵盖已有引擎和新增 KAG 的文本/控制分离、命令保留、压缩及内嵌 XP3、错误校验、断点续译和离线出包。自动解包使用合成封包测试，未持有原始游戏 EXE，不能据此承诺它一定能自动解包。
