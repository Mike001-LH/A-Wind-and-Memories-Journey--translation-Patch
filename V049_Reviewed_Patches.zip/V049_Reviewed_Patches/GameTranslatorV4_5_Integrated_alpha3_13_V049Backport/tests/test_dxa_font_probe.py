import struct
import unittest
from dxa.font_probe import checksum,rename_font,patch_exe

class FontProbeTests(unittest.TestCase):
    def test_wrong_exe_fails_closed(self):
        with self.assertRaises(ValueError):patch_exe(b'MZ fake MS Gothic\0')
    def test_sfnt_names_only_and_checksum(self):
        text='MS Gothic'.encode('utf-16be')
        name=struct.pack('>HHH',0,1,18)+struct.pack('>6H',3,1,1033,1,len(text),0)+text
        tabs={b'head':bytes(54),b'name':name,b'cmap':b'unchanged-character-map'}
        raw=bytearray(struct.pack('>IHHHH',0x10000,3,32,1,16)+bytes(48))
        for i,(tag,data) in enumerate(tabs.items()):
            raw.extend(b'\0'*((-len(raw))%4));off=len(raw)
            struct.pack_into('>4sIII',raw,12+i*16,tag,checksum(data),off,len(data));raw.extend(data)
        made=rename_font(bytes(raw));self.assertEqual(checksum(made),0xb1b0afba)
        for i in range(3):
            tag,_,off,size=struct.unpack_from('>4sIII',made,12+i*16)
            if tag==b'cmap':self.assertEqual(made[off:off+size],tabs[tag])
            if tag==b'name':self.assertIn('WFProbe'.encode('utf-16be'),made[off:off+size])
