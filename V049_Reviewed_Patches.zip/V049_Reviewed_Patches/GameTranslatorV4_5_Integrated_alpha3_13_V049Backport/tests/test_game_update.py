import contextlib,io,json,tempfile,unittest,zipfile
from pathlib import Path
from game_update import build,apply,scan
class UpdateTest(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name);self.old=self.root/'old';self.new=self.root/'new'
  for d in (self.old,self.new):
   (d/'Data').mkdir(parents=True);(d/'Game.exe').write_bytes(b'executable');(d/'Game.ini').write_text('[Game]\n')
   for f in ('System.rvdata2','Scripts.rvdata2'):(d/'Data'/f).write_bytes(b'data')
   (d/'Graphics').mkdir();(d/'Graphics/日本語.png').write_bytes(b'old' if d==self.old else b'new')
  (self.old/'removed.txt').write_text('removed');(self.new/'added.txt').write_text('added')
  (self.old/'Save01.rvdata2').write_bytes(b'player progress');(self.new/'Save01.rvdata2').write_bytes(b'author progress')
  (self.new/'Data.zip').write_bytes(b'not game');(self.new/'.DS_Store').write_bytes(b'mac')
 def package(self):
  z=self.root/'update.zip'
  with contextlib.redirect_stdout(io.StringIO()):m=build(self.old,self.new,z,'0.49','0.50')
  pkg=self.root/'package';pkg.mkdir()
  with zipfile.ZipFile(z) as f:f.extractall(pkg)
  return pkg,m
 def test_exact_result_saves_source_untouched(self):
  pkg,m=self.package();before=scan(self.old);out=self.root/'result'
  with contextlib.redirect_stdout(io.StringIO()):apply(self.old,out,pkg)
  self.assertEqual(scan(out),scan(self.new));self.assertEqual(scan(self.old),before);self.assertEqual((out/'Save01.rvdata2').read_bytes(),b'player progress');self.assertFalse((out/'removed.txt').exists());self.assertFalse((out/'Data.zip').exists());self.assertEqual(m['modified'],['Graphics/日本語.png'])
 def test_translated_base_rejected(self):
  pkg,_=self.package();(self.old/'Data/System.rvdata2').write_bytes(b'translation')
  with self.assertRaisesRegex(ValueError,'Base does not match'):apply(self.old,self.root/'out',pkg)
  self.assertFalse((self.root/'out').exists())
 def test_extra_resource_rejected(self):
  pkg,_=self.package();(self.old/'unexpected.dll').write_bytes(b'extra')
  with self.assertRaisesRegex(ValueError,'Base does not match'):apply(self.old,self.root/'out',pkg)
 def test_corrupt_payload_rejected(self):
  pkg,_=self.package();(pkg/'payload/added.txt').write_text('corrupt')
  with self.assertRaisesRegex(ValueError,'payload'):apply(self.old,self.root/'out',pkg)
  self.assertFalse((self.root/'out').exists())
 def test_manifest_traversal_rejected(self):
  pkg,_=self.package();m=json.loads((pkg/'manifest.json').read_text());m['new_files']['../escape']=m['new_files']['added.txt'];(pkg/'manifest.json').write_text(json.dumps(m))
  with self.assertRaisesRegex(ValueError,'path'):apply(self.old,self.root/'out',pkg)
 def test_case_collision_rejected(self):
  (self.new/'game.EXE').write_bytes(b'collision')
  with self.assertRaisesRegex(ValueError,'collision'):self.package()
 def test_case_rename_rejected(self):
  (self.new/'removed.TXT').write_text('removed')
  with self.assertRaisesRegex(ValueError,'rename'):self.package()
 def test_nested_existing_output_rejected(self):
  with self.assertRaisesRegex(ValueError,'separate'):build(self.old,self.new,self.old/'update.zip')
  pkg,_=self.package()
  with self.assertRaisesRegex(ValueError,'already exists'):apply(self.old,self.new,pkg)
 def test_symlink_refused(self):
  pkg,_=self.package();(self.old/'save').symlink_to(self.root,target_is_directory=True)
  with self.assertRaisesRegex(ValueError,'links'):apply(self.old,self.root/'out',pkg)
 def test_unicode_nfc_nfd_same_content_not_an_update(self):
  import unicodedata
  name='やや濡れぐちょぐちょ（５秒）.wav'
  (self.old/'Audio').mkdir();(self.new/'Audio').mkdir()
  oldname=unicodedata.normalize('NFD',name)
  (self.old/'Audio'/oldname).write_bytes(b'same audio')
  (self.new/'Audio'/name).write_bytes(b'same audio')
  pkg,m=self.package()
  self.assertNotIn('Audio/'+name,m['added']);self.assertNotIn('Audio/'+name,m['removed'])
  with contextlib.redirect_stdout(io.StringIO()):apply(self.old,self.root/'out',pkg)
  self.assertEqual(scan(self.root/'out'),scan(self.new))
 def test_unicode_directories_changed_added_removed(self):
  import unicodedata
  folder='ぐちょ';oldfolder=unicodedata.normalize('NFD',folder)
  for game,name in [(self.old,oldfolder),(self.new,folder)]:
   (game/name).mkdir();(game/name/'音.wav').write_bytes(b'old' if game==self.old else b'new')
  (self.old/oldfolder/'削除.wav').write_bytes(b'remove')
  (self.new/folder/'追加.wav').write_bytes(b'add')
  pkg,m=self.package()
  with contextlib.redirect_stdout(io.StringIO()):apply(self.old,self.root/'out',pkg)
  self.assertEqual(scan(self.root/'out'),scan(self.new))
  self.assertFalse((self.root/'out'/oldfolder/'削除.wav').exists())
if __name__=='__main__':unittest.main()
