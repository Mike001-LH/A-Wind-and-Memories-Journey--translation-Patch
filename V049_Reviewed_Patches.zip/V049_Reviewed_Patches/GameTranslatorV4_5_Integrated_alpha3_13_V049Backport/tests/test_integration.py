"""Offline cross-branch regressions. No live provider or personal credentials."""
import contextlib
import io
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch
import translator
import translatorpp_adapter as files
from providers.config import make_provider, SessionAccounting, RequestStop
from providers.economy import EconomyProvider
from providers.base import Usage
from test_gateway import args
from test_vxace import fixture
from vxace.pipeline import run

class IntegratedTests(unittest.TestCase):
    def test_launcher_reaches_every_command_and_keeps_paths_with_spaces(self):
        for name in translator.COMMANDS:
            cmd=translator.command_line(name,['a game with spaces', '--help'])
            self.assertEqual(cmd[-2:],['a game with spaces','--help'])
            if cmd[1]!='-m':self.assertTrue(Path(cmd[1]).is_file(),cmd)
        for name in translator.BRUNS_TOOLS:
            self.assertTrue(Path(translator.command_line('bruns-legacy',[name])[1]).is_file())

    def test_economy_uses_same_provider_selection_and_key(self):
        with patch.dict(os.environ,{'DEEPSEEK_API_KEY':'official-fixture','XIANYI_API_KEY':'gateway-fixture'},clear=True):
            p=make_provider(args(provider='deepseek',economy=True))
            self.assertIsInstance(p,EconomyProvider)
            self.assertEqual(p.api_key,'official-fixture')
            with self.assertRaises(ValueError):make_provider(args(provider='xianyi',economy=True))

    def test_economy_checkpoint_resume_and_cost_counted_once(self):
        class Fake:
            calls=0
            def translate_batch(self,items,**kw):
                self.calls+=1
                return {u['id']:'\n'.join('テキスト %s' if '%s' in line else 'テキスト' for line in u['source'].split('\n')) for u in items},Usage(100,50,20,80)
        with tempfile.TemporaryDirectory() as td,contextlib.redirect_stdout(io.StringIO()):
            root=Path(td);game=root/'game';fixture(game);work=root/'work';p=Fake()
            a=args(provider='deepseek',economy=True,batch_size=30,batch_chars=1,max_api_calls=1,repair_rounds=0)
            run(game,work,root/'first',a,p)
            state=json.loads((work/'ace_checkpoint.json').read_text())
            self.assertEqual(p.calls,1)
            self.assertEqual(state['stop_reason'],'request_limit')
            first=dict(state['translations']);spent=state['spent_rmb']
            self.assertAlmostEqual(spent,(20*.04+80*2+50*8)/1_000_000)
            self.assertEqual(spent,state['cost_summary']['session_recorded_estimated_rmb'])
            # Change provider without losing the old official checkpoint or paying to redo it.
            a.provider='xianyi';a.economy=False;a.max_api_calls=10
            run(game,work,root/'second',a,p)
            second=json.loads((work/'ace_checkpoint.json').read_text())
            self.assertTrue(first.items()<=second['translations'].items())
            self.assertEqual(second['spent_rmb'],spent)
            self.assertTrue(second['api_usage_without_price'])
            calls=p.calls
            run(game,work,root/'third',a,p)
            self.assertEqual(p.calls,calls)

    def test_explicit_rates_budget_and_missing_usage(self):
        with contextlib.redirect_stdout(io.StringIO()):
            state={'spent_rmb':2.}
            a=SessionAccounting(args(api_input_rmb=1,api_output_rmb=2,max_cost_rmb=.0001),state)
            a.before();a.record({'prompt_tokens':100,'completion_tokens':100})
            a.missing()
            self.assertAlmostEqual(state['spent_rmb'],2.0003)
            self.assertTrue(state['cost_summary']['incomplete_records'])
            with self.assertRaises(RequestStop):a.before()

    def test_mtool_offline_glossary_output_and_resume(self):
        with tempfile.TemporaryDirectory() as td,contextlib.redirect_stdout(io.StringIO()):
            root=Path(td);source=root/'input.json';out=root/'output.json';glossary=root/'glossary.json'
            source.write_text(json.dumps({'Hello there!':'','img/a.png':'img/a.png'}))
            glossary.write_text(json.dumps({'Hello there!':'你好！'}))
            argv=['files',str(source),'--output',str(out),'--glossary',str(glossary),'--quality','fast','--source-language','English']
            with patch.object(sys,'argv',argv):self.assertEqual(files.main(),0)
            self.assertEqual(json.loads(out.read_text())['Hello there!'],'你好！')
            self.assertEqual(json.loads(source.read_text())['Hello there!'],'')
            with patch.object(sys,'argv',argv+['--resume']):self.assertEqual(files.main(),0)
            self.assertEqual(json.loads(out.read_text())['img/a.png'],'img/a.png')

    def test_excel_project_dedup_and_exact_glossary_skip_common(self):
        from openpyxl import Workbook,load_workbook
        with tempfile.TemporaryDirectory() as td,contextlib.redirect_stdout(io.StringIO()):
            root=Path(td);source=root/'project';out=root/'translated';glossary=root/'glossary.json'
            for rel in ('game/a.xlsx','game/b.xlsx','renpy/common/ui.xlsx'):
                path=source/rel;path.parent.mkdir(parents=True,exist_ok=True)
                w=Workbook();w.active.append(['Original Text','Best translation']);w.active.append(['Welcome home!','']);w.save(path);w.close()
            ad=files.adapter(source)
            candidates=[x for x in ad.items() if not files.is_renpy_common_item(x,ad)]
            unique,targets,saved=files.deduplicate_excel_candidates(candidates)
            self.assertEqual((len(unique),saved),(1,1))
            glossary.write_text(json.dumps({'Welcome home!':'欢迎回家！'}))
            argv=['files',str(source),'--output',str(out),'--glossary',str(glossary),'--quality','fast','--source-language','English']
            with patch.object(sys,'argv',argv):self.assertEqual(files.main(),0)
            for rel in ('game/a.xlsx','game/b.xlsx'):
                w=load_workbook(out/rel);self.assertEqual(w.active['B2'].value,'欢迎回家！');w.close()
            w=load_workbook(out/'renpy/common/ui.xlsx');self.assertIsNone(w.active['B2'].value);w.close()

    def test_bundled_unrpyc_ready(self):
        from decompilers.unrpyc_backend import UnrpycBackend
        self.assertTrue(UnrpycBackend(None).available()[0])

    def test_dxa_diagnostic_payload_integrity(self):
        import hashlib
        root=translator.ROOT/'experimental/WitchForest_Diagnostic_alpha2'
        manifest=json.loads((root/'manifest.json').read_text())
        for mode,record in manifest['modes'].items():
            self.assertEqual(hashlib.sha256((root/(mode+'.tail')).read_bytes()).hexdigest(),record['tail_sha256'])

    def test_standard_provider_keeps_valid_rows_but_rejects_ambiguous_ids(self):
        p=make_provider(args(api_key='fixture-key'))
        rows=[{'id':'a','translation':'テキスト'},{'id':'b','translation':None},
              {'id':'c','translation':'one'},{'id':'c','translation':'two'},
              {'id':'unknown','translation':'bad'}]
        raw={'choices':[{'message':{'content':json.dumps({'translations':rows})},'finish_reason':'stop'}]}
        with patch.object(p.opener,'open',return_value=io.BytesIO(json.dumps(raw).encode())):
            made,usage=p.translate_batch([{'id':i,'source':'你好'} for i in ('a','b','c')])
        self.assertEqual(made,{'a':'テキスト'})
        self.assertFalse(usage.reported)
