import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch as mock
import zlib
from vxace import display_fix as fix
from vxace.marshal48 import Reader,array,text
from vxace.adapter import decompress
from test_vxace import stream, arr, integer, string, binary, obj

class DisplayFixTests(unittest.TestCase):
    def fixture(self):
        rows=[]; profile={}
        for i in range(306):
            name='Main' if i==298 else ('Vocab' if i==1 else 'Script%d'%i)
            code='RGSSMain.call\n' if name=='Main' else ('module Vocab\n  Shop = "Translated shop"\nend\n' if name=='Vocab' else '# unchanged\n')
            if i in fix.UI:code+='\n'.join('Label%d = %s'%(j,json.dumps(k,ensure_ascii=False)) for j,k in enumerate(fix.UI[i]))+'\n'
            compressed=zlib.compress(code.encode())
            rows.append(arr([integer(i),string(name),binary(compressed)]))
            if name not in ('Main','Vocab'):profile[str(i)]={'name':name,'sha256':hashlib.sha256(code.encode()).hexdigest()}
        return stream(arr(rows)),profile

    def test_preserves_translated_vocab_and_other_scripts(self):
        raw,profile=self.fixture();read=fix.read_json
        with mock.object(fix,'read_json',side_effect=lambda p: profile if p.name=='wind_v049_scripts.json' else read(p)):
            result,counts=fix.edit_scripts(raw,{'少女':'Girl'})
        before=array(Reader(raw).parse());after=array(Reader(result).parse())
        for i,(a,b) in enumerate(zip(before,after)):
            a=array(a);b=array(b)
            self.assertEqual(text(a[1]),text(b[1]))
            if i not in fix.UI and i!=298:self.assertEqual(a[2].value,b[2].value)
        main=decompress(array(after[298])[2].value).decode()
        self.assertIn('"少女" => "Girl"',main)
        self.assertTrue(main.endswith('RGSSMain.call\n'))
        self.assertNotIn('Font.default_name =',main)
        self.assertNotIn('Font.default_size =',main)

    def test_translated_actor_names_and_invalid_names(self):
        with tempfile.TemporaryDirectory() as d:
            g=Path(d)/'original'; t=Path(d)/'translated'
            for p in (g,t):(p/'Data').mkdir(parents=True)
            pairs=[('少女','Maiden'),('少女','Maiden'),('中文残留','Name中'),
                   ('换行姓名','Bad'+chr(10)+'Name'),('控制姓名',chr(92)+'N[1]'),
                   ('回车姓名','Bad'+chr(13)+'Name'),('冲突姓名','One'),('冲突姓名','Two')]
            for p,col in ((g,0),(t,1)):
                raw=stream(arr([b'0']+[obj('RPG::Actor',{'name':string(pair[col])}) for pair in pairs]))
                (p/'Data/Actors.rvdata2').write_bytes(raw)
            names=fix.speaker_table(g,t)
            self.assertEqual(names['少女'],'Maiden')
            self.assertEqual(names['少女【灵魂分身】'],'Maiden (Soul Avatar)')
            for name in ['中文残留','换行姓名','控制姓名','回车姓名','冲突姓名']:
                self.assertNotIn(name,names)

    def test_wrong_profile_rejected(self):
        raw,profile=self.fixture();profile['134']['sha256']='wrong'
        with mock.object(fix,'read_json',return_value=profile):
            with self.assertRaisesRegex(ValueError,'modified script'):fix.edit_scripts(raw,{})

    def test_repeat_rejected(self):
        raw,profile=self.fixture()
        with mock.object(fix,'read_json',return_value=profile):
            result,_=fix.edit_scripts(raw,{})
            with self.assertRaisesRegex(ValueError,'already applied'):fix.edit_scripts(result,{})

    def test_ruby_interpolation_cannot_execute(self):
        for s in ['#{system("anything")}','#$global','#@instance']:
            self.assertIn('\\#',fix.ruby_literal(s))

    def test_unsupported_output_and_language(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);g=root/'g';p=root/'p';g.mkdir();p.mkdir()
            (p/'build_report.json').write_text(json.dumps({'engine':'vxace','target_language':'ja'}))
            with self.assertRaisesRegex(ValueError,'English VX Ace'):fix.apply(g,p,root/'out')
            with self.assertRaisesRegex(ValueError,'already exists'):fix.apply(g,p,g)

if __name__=='__main__':unittest.main()
