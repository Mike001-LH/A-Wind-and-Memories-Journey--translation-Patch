import unittest
from unittest.mock import patch
import test_vxace_display as baseline
from vxace import display_fix_ja as fix
from vxace.marshal48 import Reader,array
from vxace.adapter import decompress

class JapaneseDisplayTests(unittest.TestCase):
    def test_profile_preserves_other_scripts_and_font(self):
        raw,profile=baseline.DisplayFixTests().fixture()
        with patch.object(fix,'read_json',return_value=profile):out,counts=fix.edit_scripts(raw,{})
        before=array(Reader(raw).parse());after=array(Reader(out).parse())
        for i,(a,b) in enumerate(zip(before,after)):
            if i not in fix.UI and i!=298:self.assertEqual(array(a)[2].value,array(b)[2].value)
        code=decompress(array(after[298])[2].value).decode()
        for token in ['GT_JA_SPEAKERS','ひらがな','カタカナ','詳細はアイテム・スキル画面へ']:self.assertIn(token,code)
        self.assertNotIn('Font.default_name =',code);self.assertNotIn('Font.default_size =',code)
        self.assertIn('時空安定度',decompress(array(after[291])[2].value).decode())
        with patch.object(fix,'read_json',return_value=profile):
            with self.assertRaisesRegex(ValueError,'already applied'):fix.edit_scripts(out,{})

    def test_script_hash_mismatch_rejected(self):
        raw,profile=baseline.DisplayFixTests().fixture();profile['285']['sha256']='bad'
        with patch.object(fix,'read_json',return_value=profile):
            with self.assertRaisesRegex(ValueError,'modified script'):fix.edit_scripts(raw,{})
