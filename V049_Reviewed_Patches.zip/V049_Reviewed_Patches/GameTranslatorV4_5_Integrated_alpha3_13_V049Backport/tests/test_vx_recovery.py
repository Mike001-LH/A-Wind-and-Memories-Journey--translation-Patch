import unittest
from vxace.adapter import audit,ESCAPE,AUDIT_TOKEN
from vxace.recovery import recover_candidates,separate_bare_codes
from vxace.reflow import repair_newlines


class RecoveryTests(unittest.TestCase):
    def test_percentages_and_real_placeholders(self):
        s='【攻击15%造成眩晕/眩晕抗性+100%】'
        t='【15% chance to stun on attack / Stun resistance +100%】'
        self.assertEqual(audit({'source':s,'translation':t},'en')['blocking'],[])
        for source in ['Shop %s','Value %02d','%1$s %s','%%']:
            self.assertIn('control_token_mismatch',audit({'source':source,'translation':'Missing'},'en')['blocking'])
        self.assertEqual(AUDIT_TOKEN.findall('%sHello %02d'),['%s','%02d'])
        self.assertEqual(ESCAPE.findall('15% chance'),['% c']) # fingerprint compatibility

    def test_bare_code_must_be_separated_for_actual_rgss_parser(self):
        s='\\c折断的钥匙。';t='\\cA broken key.'
        self.assertIn('control_token_mismatch',audit({'source':s,'translation':t},'en')['blocking'])
        fixed=separate_bare_codes(s,t)
        self.assertEqual(fixed,'\\c A broken key.')
        self.assertEqual(audit({'source':s,'translation':fixed},'en')['blocking'],[])
        self.assertEqual(separate_bare_codes(s,'\\c[2]A key'),'\\c[2]A key')
        self.assertEqual(separate_bare_codes('\\color[2]钥匙','\\color[2]Key'),'\\color[2]Key')
        self.assertIn('control_token_mismatch',audit({'source':'\\V[1]钥匙','translation':'\\V[2]Key'},'en')['blocking'])

    def test_recovery_never_overwrites_valid_or_reviewed_and_keeps_failures(self):
        units=[{'id':str(i),'source':'\\c钥匙','translation':''} for i in range(4)]
        units[1]['translation']='\\c Key';units[2]['reviewed']=True
        state={'rejected_candidates':{'0':'\\cA key','1':'\\cOther','2':'\\cNew','3':'\\V[2]Wrong'}}
        r=recover_candidates(units,state,'en')
        self.assertEqual(r['recovered'],['0']);self.assertEqual(units[1]['translation'],'\\c Key')
        self.assertEqual(units[2]['translation'],'');self.assertIn('3',state['rejected_candidates'])

    def test_opt_in_reflow_preserves_words_and_tokens(self):
        source='第一行\n第二行';candidate='This is a long description with several words.'
        fixed=repair_newlines({'source':source},candidate,'en')
        self.assertIsNotNone(fixed);self.assertEqual(fixed.replace('\n',''),candidate)
        self.assertEqual(fixed.count('\n'),1)
        self.assertIsNone(repair_newlines({'source':source},'OneWord','en'))
        u={'id':'1','source':source,'translation':''};st={'rejected_candidates':{'1':candidate}}
        self.assertEqual(recover_candidates([u],st,'en')['recovered'],[])
        self.assertEqual(recover_candidates([u],st,'en',True)['recovered'],['1'])

    def test_offline_pipeline_recovers_from_checkpoint_without_provider(self):
        import json,tempfile,contextlib,io
        from pathlib import Path
        from types import SimpleNamespace
        from test_vxace import fixture
        from vxace.pipeline import run
        from vxace.adapter import extract
        from core.completion import atomic_json
        args=SimpleNamespace(target_language='en',source_language='Chinese',analyze=True,estimate=False,
            migrate_only=False,reuse_from=None,import_translations=None,glossary=None,sample=None,build_only=True,
            max_cost_rmb=5,price_band='peak',batch_size=10,repair_rounds=3,stall_rounds=2,allow_partial=True,
            vx_font=None,vx_sample_profile='mixed',no_vx_reuse=False,vx_recover_cached=False,vx_repair_newlines=False)
        with tempfile.TemporaryDirectory() as d,contextlib.redirect_stdout(io.StringIO()):
            root=Path(d);game=root/'g';fixture(game,hello='攻击15%造成眩晕');work=root/'w'
            run(game,work,root/'unused',args)
            units,_,_=extract(game);u=next(u for u in units if u['metadata']['kind']=='dialogue')
            cp=work/'ace_checkpoint.json';state=json.loads(cp.read_text())
            state['rejected_candidates']={u['id']:'15% chance to stun on attack\nWelcome back.'};atomic_json(cp,state)
            args.analyze=False;args.vx_recover_cached=True
            run(game,work,root/'recovered',args)
            state=json.loads(cp.read_text());self.assertIn(u['id'],state['translations'])
            self.assertTrue(list(work.glob('ace_checkpoint.json.before-reuse-*')))
            self.assertTrue((root/'recovered/Data/CommonEvents.rvdata2').exists())
            self.assertEqual(json.loads((work/'ace_offline_recovery_report.json').read_text())['api_calls'],0)

    def test_actor_name_code_restores_literal_newline_and_plain_index(self):
        from vxace.recovery import restore_actor_tokens
        source='Hello \\n[1].\nWelcome.'
        for candidate in ['Hello\n[1].\nWelcome.','Hello [1].\nWelcome.']:
            value=restore_actor_tokens(source,candidate)
            self.assertEqual(audit({'source':source,'translation':value},'en')['blocking'],[])
        source='\\n[1] meets \\n[1].'
        candidate='[1] meets\n[1].'
        value=restore_actor_tokens(source,candidate)
        self.assertEqual(value,'\\n[1] meets\\n[1].')
        for source,candidate in [('\\n[1] and [1]','[1] and [1]'),('\\n[1]','[2]'),('\\n[1]','[1] [1]')]:
            self.assertEqual(restore_actor_tokens(source,candidate),candidate)

    def test_variable_reorder_keeps_formatting_and_physical_lines(self):
        source='\\>\\c[1]Blue\\c[0] Souls: \\V[20].'
        candidate='\\>You have \\V[20] \\c[1]Blue\\c[0] Souls.'
        self.assertEqual(audit({'source':source,'translation':candidate},'en')['blocking'],[])
        for candidate in ['\\>You have \\V[21] \\c[1]Blue\\c[0] Souls.',
                          '\\>You have \\V[20] \\c[0]Blue\\c[1] Souls.',
                          '\\>You have \\V[20] \\V[20] \\c[1]Blue\\c[0] Souls.']:
            self.assertIn('control_token_mismatch',audit({'source':source,'translation':candidate},'en')['blocking'])
        self.assertIn('control_token_mismatch',audit({'source':'\\V[1]\n\\V[2]','translation':'\\V[2]\n\\V[1]'},'en')['blocking'])
        self.assertIn('control_token_mismatch',audit({'source':'\\.\\! Text','translation':'\\!\\. Text'},'en')['blocking'])

    def test_surplus_terminal_line_is_optional_and_visible_text_retained(self):
        u={'id':'x','source':'Hello \\n[1]','translation':''}
        state={'rejected_candidates':{'x':'Hello\n[1]\n'}}
        self.assertEqual(recover_candidates([u],state,'en')['recovered'],[])
        result=recover_candidates([u],state,'en',True)
        self.assertEqual(result['recovered'],['x'])
        self.assertEqual(u['translation'],'Hello \\n[1]'.replace('Hello ','Hello'))
