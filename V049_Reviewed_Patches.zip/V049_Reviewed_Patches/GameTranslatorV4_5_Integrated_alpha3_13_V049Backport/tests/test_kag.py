import contextlib
import io
import json
from pathlib import Path
import struct
import tempfile
from types import SimpleNamespace
import unittest
import zlib
from kag.adapter import extract, render, audit
from kag.xp3 import MAGIC, pack, read_scripts, chunk
from kag.source import load, roots
from kag.pipeline import run
from providers.base import Usage

SCRIPT='; comment\r\n*start\r\n@iscript\r\nvar x="hidden";\r\n@endscript\r\n[macro name=m]\r\nhidden\r\n[endmacro]\r\n[link target="*next" exp="f.x=\'a]b\'"]Start[endlink]\\\r\nHello[l]\r\n[cm]\\\r\n[[literal\r\n'

class KAGTests(unittest.TestCase):
    def test_lexer_and_writer(self):
        files={'scenario/first.ks':SCRIPT.encode('cp932')}
        units,_=extract(files)
        self.assertEqual([u['source'] for u in units],['Start','Hello'])
        for u,t in zip(units,['开始','你好']):u['translation']=t
        made,left=render(files,units,False,'SimSun')
        text=made['first.ks'].decode('utf-16')
        self.assertFalse(left)
        self.assertEqual(text.split('\r\n',1)[1],SCRIPT.replace('Start','开始').replace('Hello','你好'))
        for bad in ('Hello\nWorld','[jump target=x]','@iscript','x\\'):
            self.assertTrue(audit({'translation':bad})['blocking'])

    def test_archive_formats(self):
        files={'scenario/first.ks':SCRIPT.encode()}
        raw=pack(files);offset=struct.unpack_from('<Q',raw,11)[0];index=raw[offset+9:]
        compressed=zlib.compress(index)
        variants=[raw,raw[:offset]+b'\x01'+struct.pack('<QQ',len(compressed),len(index))+compressed]
        v2=bytearray(raw[:offset]);struct.pack_into('<Q',v2,11,len(v2))
        v2.extend(b'\x80'+struct.pack('<QQ',0,len(v2)+17));v2.extend(raw[offset:]);variants.append(bytes(v2))
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'game.exe'
            for variant in variants:
                p.write_bytes(b'MZ'+MAGIC+bytes(8)+b'fake constant'+variant)
                self.assertEqual(read_scripts(p),files)
            p.write_bytes(pack({'../escape.ks':b'no'}))
            with self.assertRaises(ValueError):read_scripts(p)
            bad=bytearray(raw);bad[19]^=1;p.write_bytes(bad)
            with self.assertRaises(ValueError):read_scripts(p)
            bad=bytearray(raw);pos=bad.index(b'info',offset)+12;struct.pack_into('<I',bad,pos,0x80000000);p.write_bytes(bad)
            with self.assertRaisesRegex(ValueError,'GARbro'):read_scripts(p)

    def test_extracted_root_not_ambiguous(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);scenario=root/'scenario';scenario.mkdir()
            (scenario/'first.ks').write_text(SCRIPT)
            self.assertEqual(roots(root),[root])
            self.assertEqual(roots(scenario),[scenario])

    def test_compressed_segment(self):
        name='first.ks'.encode('utf-16le');content=SCRIPT.encode();compressed=zlib.compress(content)
        info=struct.pack('<IQQH',0,len(content),len(compressed),len(name)//2)+name
        seg=struct.pack('<IQQQ',1,19,len(content),len(compressed))
        index=chunk(b'File',chunk(b'info',info)+chunk(b'segm',seg)+chunk(b'adlr',struct.pack('<I',zlib.adler32(content))))
        data=MAGIC+struct.pack('<Q',19+len(compressed))+compressed+b'\0'+struct.pack('<Q',len(index))+index
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'data.xp3';p.write_bytes(data)
            self.assertEqual(read_scripts(p),{'first.ks':content})

    def test_pipeline_resume_and_offline(self):
        class Fake:
            calls=0
            def translate_batch(self,items,**kwargs):
                self.calls+=1
                return {u['id']:'测试' for u in items},Usage()
        with tempfile.TemporaryDirectory() as d, contextlib.redirect_stdout(io.StringIO()):
            root=Path(d);game=root/'game';game.mkdir()
            (game/'game.exe').write_bytes(b'MZ'+pack({'scenario/first.ks':SCRIPT.encode()}))
            args=SimpleNamespace(extracted=None,archive=None,analyze=True,estimate=False,glossary=None,
                sample=1,build_only=False,kag_font_face='SimSun',max_cost_rmb=5.,price_band='peak',
                source_language='English',repair_rounds=1,batch_size=5,stall_rounds=2,allow_partial=False)
            fake=Fake();work=root/'work'
            run(game,work,root/'analysis',args,fake);self.assertEqual(fake.calls,0)
            args.analyze=False
            run(game,work,root/'sample',args,fake);self.assertEqual(fake.calls,1)
            args.sample=None
            run(game,work,root/'full',args,fake);self.assertEqual(fake.calls,2)
            args.build_only=True
            run(game,work,root/'offline',args,fake);self.assertEqual(fake.calls,2)
            self.assertEqual((root/'full'/'patch.xp3').read_bytes(),(root/'offline'/'patch.xp3').read_bytes())
            self.assertEqual(json.loads((work/'kag_completion_report.json').read_text())['blocking_count'],0)
            with self.assertRaises(ValueError):run(game,work,root/'full',args,fake)
            (game/'game.exe').write_bytes(b'MZ'+pack({'scenario/first.ks':SCRIPT.replace('Hello','Changed').encode()}))
            with self.assertRaises(ValueError):run(game,work,root/'stale',args,fake)

if __name__=='__main__':unittest.main()
