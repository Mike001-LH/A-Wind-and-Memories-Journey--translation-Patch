# Safe engine-interface simulation. Does not load or execute game scripts.
Size = Struct.new(:width)
class Bitmap
  attr_accessor :width, :height
  def initialize(w,h); @width=w; @height=h; end
  def clear; end
  def dispose; end
end
class Window_Base
  attr_accessor :contents, :oy, :visible, :openness
  attr_reader :drawn, :pauses, :icons, :controls
  def initialize
    @contents=Bitmap.new(120,40); @oy=0; @visible=true; @openness=255
    @drawn=[]; @pauses=0; @icons=[]; @controls=[]
  end
  def contents_width; 120; end
  def contents_height; 40; end
  def text_size(s); Size.new(s.length * 5); end
  def calc_line_height(s); 20; end
  def reset_font_settings; end
  def convert_escape_characters(s); s.gsub('\\', "\e"); end
  def update; end
  def process_character(c,text,pos)
    case c
    when "\n"; process_new_line(text,pos)
    when "\f"; new_page(text,pos)
    when "\e"
      code=text.slice!(/\A[A-Z]+|\A[.|]/i)
      param=text.slice!(/\A\[\d+\]/)
      code=='I' ? process_draw_icon(param,pos) : @controls << [code,param]
    else
      @drawn << [c,pos[:x],pos[:y]]
      pos[:x]+=text_size(c).width
    end
  end
  def process_new_line(text,pos)
    pos[:x]=pos[:new_x];pos[:y]+=pos[:height];pos[:height]=calc_line_height(text)
  end
  def process_draw_icon(i,pos);@icons << [i,pos[:x],pos[:y]];pos[:x]+=24;end
end
class Window_Message < Window_Base
  def process_new_line(text,pos)
    super
    if pos[:y]+pos[:height]>contents.height && !text.empty?
      @pauses+=1;new_page(text,pos)
    end
  end
  def new_page(text,pos)
    pos[:x]=pos[:new_x];pos[:y]=0;pos[:height]=20
  end
end
class Window_Help < Window_Base;end
class Window_Getinfo;end
class Window_NameInput_Command
  LATIN1=['A'];CHINA1=['中']
  attr_reader :list
  def make_command_list
    @list=[{:ext=>CHINA1},{:ext=>LATIN1}]
  end
end
load File.expand_path('../vxace/english_layout.rb',File.dirname(__FILE__))
def check(x,m);raise m unless x;end
w=Window_Message.new
s="Hello friend, this is a long English sentence with \eC[2]color\eC[0] and \eI[4] an icon.\nAnother line. "+('x'*90)+" \e. Done."
rest=s.dup;pos={:x=>20,:y=>0,:new_x=>20,:height=>20}
until rest.empty?;w.process_character(rest.slice!(0,1),rest,pos);end
plain=s.gsub(/\e(?:[A-Z]+(?:\[\d+\])?|[.|])/i,'').gsub(/\s/,'')
check(w.drawn.map{|r|r[0]}.join.gsub(/\s/,'')==plain,'text lost during pagination')
check(w.drawn.all?{|c,x,y| x>=20 && x+5<=116 && y>=0 && y+20<=40},'text outside face/page bounds')
check(w.pauses>2,'no pagination')
check(w.icons.length==1 && w.icons[0][1]+24<=116,'icon clipping')
check(w.controls.length==3,'control sequence lost')
h=Window_Help.new
h.instance_variable_set(:@text,('A complete lengthy item description. '*15))
h.refresh
check(h.contents.height>h.contents_height,'help description not wrapped')
500.times {h.update}
check(h.oy>0,'help failed to scroll')
h.instance_variable_set(:@text,'Short');h.refresh
check(h.oy==0 && h.contents.height==40,'help does not reset for next item')
n=Window_NameInput_Command.new;n.make_command_list
check(n.list.first[:ext].equal?(Window_NameInput_Command::LATIN1),'Latin input not first')
puts 'PASS: word wrap, face margins, long words, page boundaries, controls, icons, help scrolling/reset, Latin input'
