import contextlib, io, json, tempfile, unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from test_alpha3 import mv_fixture
from providers.base import Usage
from providers.deepseek import ProviderError
from rpgmaker.pipeline import run

class MZGatewayTests(unittest.TestCase):
    def args(self, **kw):
        d=dict(provider='xianyi',api_model='gemini-3.8-flash-high',max_api_calls=1,max_cost_rmb=1,
               price_band='peak',source_language='Japanese',analyze=False,estimate=False,
               glossary=None,sample=2,batch_size=1,repair_rounds=1,stall_rounds=2,allow_partial=True)
        d.update(kw);return SimpleNamespace(**d)
    def fixture(self, base, mz=True):
        g=base/'game';g.mkdir();root=mv_fixture(g, www=not mz)
        if mz:(root/'js/rpg_core.js').rename(root/'js/rmmz_core.js')
        return g
    def test_limit_resume_both_engines(self):
        for mz in (True, False):
            with tempfile.TemporaryDirectory() as td, contextlib.redirect_stdout(io.StringIO()):
                b=Path(td);g=self.fixture(b,mz);w=b/'work';seen=[]
                class Fake:
                    def translate_batch(self, items, **kw):
                        seen.extend(u['id'] for u in items)
                        return {u['id']:'你好\\N[1]。\n出发。' if '\n' in u['source'] else '保存。' for u in items},Usage(100,20)
                run(g,w,b/'out1',self.args(),Fake())
                prefix='mz' if mz else 'mv'
                st=json.loads((w/f'{prefix}_checkpoint.json').read_text())
                self.assertEqual(st['stop_reason'],'request_limit')
                self.assertEqual(st['api_session']['attempted_requests'],1)
                self.assertIsNone(st['session_spent_rmb'])
                first=seen[0]
                run(g,w,b/'out2',self.args(max_api_calls=3),Fake())
                self.assertEqual(seen.count(first),1)
                self.assertEqual(json.loads((w/f'{prefix}_checkpoint.json').read_text())['stop_reason'],'clean')
    def test_error_stops_saves_usage(self):
        with tempfile.TemporaryDirectory() as td, contextlib.redirect_stdout(io.StringIO()):
            b=Path(td);g=self.fixture(b);w=b/'work'
            class Fail:
                def translate_batch(self, items, **kw):
                    e=ProviderError('permission denied','provider_http_error');e.usage=Usage(100,20);raise e
            run(g,w,b/'out',self.args(sample=None),Fail())
            st=json.loads((w/'mz_checkpoint.json').read_text())
            self.assertEqual(st['stop_reason'],'provider_http_error')
            self.assertEqual(st['api_session']['attempted_requests'],1)
            self.assertEqual(st['api_session']['tokens']['completion_tokens'],20)
    def test_analyze_no_provider(self):
        with tempfile.TemporaryDirectory() as td, contextlib.redirect_stdout(io.StringIO()), patch('rpgmaker.pipeline.make_provider') as make:
            b=Path(td);g=self.fixture(b)
            run(g,b/'work',b/'out',self.args(analyze=True))
            make.assert_not_called();self.assertFalse((b/'out').exists())
    def test_unknown_price_requires_cap(self):
        with tempfile.TemporaryDirectory() as td, contextlib.redirect_stdout(io.StringIO()):
            b=Path(td);g=self.fixture(b)
            with self.assertRaisesRegex(ValueError,'max-api-calls'):
                run(g,b/'work',b/'out',self.args(max_api_calls=None))
