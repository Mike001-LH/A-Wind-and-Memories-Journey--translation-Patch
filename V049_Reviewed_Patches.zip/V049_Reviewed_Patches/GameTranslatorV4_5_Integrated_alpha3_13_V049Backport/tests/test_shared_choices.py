import json
from pathlib import Path
import tempfile
import unittest
from test_vxace import fixture,string,integer,arr,obj,stream
from vxace.marshal48 import Reader,array,text,attr,length
from vxace.adapter import collect_file,extract,build_files,audit
from vxace.choice_support import known_term


def make_shared(raw,source):
    units,b,_,r=collect_file('Data/CommonEvents.rvdata2',raw)
    u=next(u for u in units if u['source']==source and u['metadata']['kind']=='choice')
    node=b[u['id']][0];index=r.objects.index(node);encoded=string(source);pos=raw.rfind(encoded)
    assert pos>raw.find(encoded)
    return raw[:pos]+b'@'+length(index)+raw[pos+len(encoded):],index

class SharedChoiceTests(unittest.TestCase):
 def test_shared_choice_branch_is_extracted_and_written_once(self):
    with tempfile.TemporaryDirectory() as d:
        game=Path(d);fixture(game);p=game/'Data/CommonEvents.rvdata2';raw,index=make_shared(p.read_bytes(),'是');p.write_bytes(raw)
        units,b,review,_=collect_file('Data/CommonEvents.rvdata2',raw)
        u=next(u for u in units if u['source']=='是');self.assertEqual(len(b[u['id']]),2);self.assertIs(b[u['id']][0],b[u['id']][1])
        all_units,manifest,_=extract(game)
        for x in all_units:
            if x['id']==u['id']:x['translation']='Yes'
        made,left=build_files(game,all_units,manifest,'en',allow_partial=True)
        after,bind,_,r=collect_file('Data/CommonEvents.rvdata2',made['Data/CommonEvents.rvdata2'])
        self.assertEqual(next(x for x in after if x['id']==u['id'])['source'],'Yes')
        self.assertIs(bind[u['id']][0],bind[u['id']][1]);self.assertEqual(bind[u['id']][0].refs,1)
        self.assertFalse(review)
 def test_shared_choice_used_by_non_display_field_stays_excluded(self):
    # A third use in an opaque field is not authorized by the display aliases.
    from test_vxace import sym
    with tempfile.TemporaryDirectory() as d:
        game=Path(d);fixture(game);p=game/'Data/CommonEvents.rvdata2';raw,index=make_shared(p.read_bytes(),'是')
        r=Reader(raw);root=r.parse();event=array(root)[1]
        # Build another top-level reference by extending the root array.
        extended=raw[:3]+length(3)+raw[4:]+b'@'+length(index)
        units,_,review,_=collect_file('Data/CommonEvents.rvdata2',extended)
        self.assertFalse(any(x['source']=='是' for x in units));self.assertTrue(any(x['reason']=='shared_alias' for x in review))
 def test_shared_container_descendants_stay_excluded(self):
    with tempfile.TemporaryDirectory() as d:
        game=Path(d);fixture(game);p=game/'Data/CommonEvents.rvdata2';raw,index=make_shared(p.read_bytes(),'是')
        r=Reader(raw);root=r.parse();event=array(root)[1];commands=array(attr(event,'list'))
        params=attr(commands[3],'parameters');container_index=r.objects.index(params)
        extended=raw[:3]+length(3)+raw[4:]+b'@'+length(container_index)
        units,_,review,_=collect_file('Data/CommonEvents.rvdata2',extended)
        self.assertFalse(any(x['source']=='是' for x in units))
 def test_formula_must_survive_translation(self):
    u={'source':'交谈if(s[1227])','translation':'Talkif(s[1227])','metadata':{'kind':'choice'}}
    self.assertFalse(audit(u,'en')['blocking'])
    self.assertIn('choice_condition_mismatch',audit(dict(u,translation='Talk'),'en')['blocking'])
    self.assertIn('choice_condition_mismatch',audit(dict(u,translation='Talkif(s[1])'),'en')['blocking'])
 def test_color_and_name_labels(self):
    self.assertEqual(known_term('\\c[2]侵犯\\c[0]','en'),'\\c[2]Assault\\c[0]')
    self.assertEqual(known_term('询问多萝西','en'),'Ask about Dorothy')
    self.assertIsNone(known_term('询问多萝西if(s[1])','en'))

if __name__=='__main__':unittest.main()
