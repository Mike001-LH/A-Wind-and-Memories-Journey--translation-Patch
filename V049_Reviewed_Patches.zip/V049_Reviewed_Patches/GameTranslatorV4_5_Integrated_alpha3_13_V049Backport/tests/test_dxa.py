import contextlib
import hashlib
import io
import json
from pathlib import Path
import random
import struct
import tempfile
import unittest
from unittest.mock import patch
from dxa.codec import key_bytes,crypt,lz_encode,lz_decode,huffman_encode,huffman_decode
from dxa.archive import Archive,HEADER,NONE,rebuild,sha256
from dxa.cli import menu_units,build_menu,PROFILE,diagnostic_replacements

def fixture(path,payloads=None):
    payloads=payloads or [(b'a'*100,False,False),(bytes(range(256))*30,False,True),
                          (b'hello'*2000,True,False),(b'world'*2000,True,True)]
    names=bytearray();records=[];body=bytearray();key=b'fixture-key';window=1024
    for i,(raw,use_lz,use_huff) in enumerate(payloads):
        name=f'file{i}.txt'.encode();upper=name.upper();width=((len(name)+1+3)//4)*4;na=len(names)
        names.extend(struct.pack('<HH',width//4,sum(upper))+upper.ljust(width,b'\0')+name.ljust(width,b'\0'))
        packed=lz_encode(raw) if use_lz else raw;lz=len(packed) if use_lz else NONE;huff=NONE
        if use_huff:
            if len(packed)>2*window:
                head=huffman_encode(packed[:window]+packed[-window:]);packed=head+packed[window:-window];huff=len(head)
            else:packed=huffman_encode(packed);huff=len(packed)
        body.extend(b'\0'*((-len(body))%4));address=len(body);body.extend(crypt(packed,key_bytes(key+upper),len(raw)))
        records.append(struct.pack('<9Q',na,0,0,0,0,address,len(raw),lz,huff))
    body.extend(b'\0'*((-len(body))%4));ft=len(names);dt=ft+72*len(records)
    index=bytes(names)+b''.join(records)+struct.pack('<4Q',NONE,NONE,len(records),0)
    header=HEADER.pack(0x5844,8,len(index),64,64+len(body),ft,dt,932,0,1,b'\0'*15)
    path.write_bytes(header+body+crypt(huffman_encode(lz_encode(index)),key_bytes(key)))
    return key,payloads

class DXATests(unittest.TestCase):
    def test_native_reference_huffman_vector(self):
        encoded=huffman_encode(b'abc'*100)
        self.assertEqual(hashlib.sha256(encoded).hexdigest(),'48699dc505a9b515fdbd148c6386fd60287c5f22cf648766d719f45c7c57dba3')
        self.assertEqual(huffman_decode(encoded),b'abc'*100)

    def test_codecs_mixed_data_and_long_overlaps(self):
        samples=[b'',b'a',b'a'*20000,bytes(range(256))*40,random.Random(19).randbytes(32768)]
        for raw in samples:
            self.assertEqual(lz_decode(lz_encode(bytearray(raw))),raw)
            self.assertEqual(huffman_decode(huffman_encode(raw)),raw)
        with self.assertRaises(ValueError):huffman_decode(b'\xff')
        with self.assertRaises(ValueError):lz_decode(struct.pack('<II',999999999,9)+b'a')

    def test_archive_compression_modes_and_verified_rebuild(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);source=root/'source.dxa';key,payloads=fixture(source);before=sha256(source)
            archive=Archive(source,key)
            for i,(data,*_) in enumerate(payloads):self.assertEqual(archive.read(f'file{i}.txt'),data)
            report=rebuild(archive,root/'copy.dxa')
            self.assertEqual(report['unchanged_resources_byte_verified'],4)
            changed=bytes(range(255,-1,-1))*50
            report=rebuild(archive,root/'changed.dxa',{'file1.txt':changed})
            self.assertEqual(report['unchanged_resources_byte_verified'],3)
            self.assertEqual(Archive(root/'changed.dxa',key).read('file1.txt'),changed)
            self.assertEqual(sha256(source),before)
            with self.assertRaises(ValueError):rebuild(archive,source)
            with self.assertRaises(ValueError):rebuild(archive,root/'bad.dxa',{'../evil':b'x'})
            self.assertFalse((root/'bad.dxa').exists())

    def test_wrong_key_and_invalid_archive_fail_closed(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'a.dxa';fixture(p)
            with self.assertRaises(ValueError):Archive(p,b'wrong')
            p.write_bytes(b'DX\x08\0')
            with self.assertRaises(ValueError):Archive(p)

    def test_diagnostic_changes_one_label_same_byte_length(self):
        class Fake:
            def read(self,path):return '001,,,05\r\n-----はじめから\r\n-----つづきから\r\n'.encode()
        a=Fake();old=a.read('')
        for mode in ('ascii','chinese'):
            made=diagnostic_replacements(a,mode)
            self.assertEqual(list(made),['data01/wtex_jp.txt'])
            raw=made['data01/wtex_jp.txt'];self.assertEqual(len(raw),len(old))
            self.assertEqual(raw.splitlines(keepends=True)[2:],old.splitlines(keepends=True)[2:])

    def test_menu_import_rejects_changed_source_and_control_lines(self):
        class Fake:
            def read(self,path):return '001,,,05\r\n-----はじめから\r\n'.encode()
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'units.json';doc=menu_units(Fake())
            doc['units'][0]['source']='tampered';p.write_text(json.dumps(doc))
            with patch('dxa.cli.open_game',return_value=Fake()):
                with self.assertRaises(ValueError):build_menu('unused',p,Path(td)/'bad.dxa',True)
            doc=menu_units(Fake());doc['units'][0]['translation']='text\nINJECT';p.write_text(json.dumps(doc))
            with patch('dxa.cli.open_game',return_value=Fake()):
                with self.assertRaises(ValueError):build_menu('unused',p,Path(td)/'bad.dxa',True)

    def test_menu_import_only_writes_labels_and_preserves_control_rows(self):
        class Fake:
            def read(self,path):return '001,,,05\r\n-----はじめから\r\n//control\r\n'.encode()
        with tempfile.TemporaryDirectory() as td,contextlib.redirect_stdout(io.StringIO()):
            p=Path(td)/'units.json';doc=menu_units(Fake());doc['units'][0]['translation']='開始遊戲';p.write_text(json.dumps(doc))
            with patch('dxa.cli.open_game',return_value=Fake()),patch('dxa.cli.rebuild',return_value={}) as build:
                build_menu('unused',p,Path(td)/'new.dxa',True)
            made=build.call_args.args[2]
            self.assertEqual(made['data01/wtex_jp.txt'],'001,,,05\r\n-----開始遊戲\r\n//control\r\n'.encode())
