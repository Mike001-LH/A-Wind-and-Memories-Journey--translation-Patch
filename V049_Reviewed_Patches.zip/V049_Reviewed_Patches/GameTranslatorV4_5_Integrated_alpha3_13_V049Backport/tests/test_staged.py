import contextlib,io,json,os,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from core.completion import complete
from providers.base import Usage
from providers.config import RequestStop
from providers.deepseek import ProviderError
from vxace.staged import run_stages,fallback_args
from test_gateway import args
from test_vxace import fixture
from vxace.pipeline import run

def rows(count=3):return [{'id':str(i),'source':'源文','translation':'','context':[]} for i in range(count)]
def qa(u):return {'blocking':[] if u.get('translation')=='テキスト' else ['invalid'],'advisory':[]}

class StagedTests(unittest.TestCase):
 def execute(self,units,primary,review=None,paid=None,**settings):
  state={};calls=[]
  def factory(a,label,is_review,responses):
   state['api_session']={'provider':a.provider,'model':getattr(a,'api_model',None),'attempted_requests':0}
   def request(batch,phase):
    calls.append((label,[u['id'] for u in batch]))
    state['api_session']['attempted_requests']+=1
    fn=review if is_review else paid if label=='paid_residual' else primary
    made=fn(batch,phase)
    responses.update(u['id'] for u in batch)
    if not is_review:
     for u in batch:
      if not qa(dict(u,translation=made.get(u['id'],'')))['blocking']:state.get('semantic_review_pending',{}).pop(u['id'],None)
    return made,{}
   return request
  options=dict(fallback_deepseek=True,ai_review_units=0,fallback_max_units=2,fallback_max_api_calls=2,fallback_max_cost_rmb=.5,repair_rounds=0,batch_size=3);options.update(settings)
  a=args(**options)
  with contextlib.redirect_stdout(io.StringIO()):run_stages(units,qa,factory,lambda *_:None,a,state)
  return state,calls
 def test_paid_only_unaccepted_response_units(self):
  units=rows()
  state,calls=self.execute(units,lambda b,p:{b[0]['id']:'テキスト'},paid=lambda b,p:{u['id']:'テキスト' for u in b})
  self.assertEqual(calls,[('primary',['0','1','2']),('paid_residual',['1','2'])])
  self.assertEqual(state['stop_reason'],'clean')
 def test_http_error_does_not_trigger_paid_bulk(self):
  def fail(*_):raise ProviderError('auth missing project_id','provider_http_error')
  state,calls=self.execute(rows(),fail,paid=lambda *_:self.fail('paid request made'))
  self.assertEqual(calls,[('primary',['0','1','2'])]);self.assertEqual(state['workflow']['paid_selected'],0)
 def test_unit_cap_preserves_unsent_residuals(self):
  state,calls=self.execute(rows(5),lambda *_:{},paid=lambda b,p:{u['id']:'テキスト' for u in b})
  self.assertEqual(state['workflow']['paid_selected'],2);self.assertEqual(state['workflow']['selected_remaining'],3)
 def test_review_invalid_candidate_goes_to_paid(self):
  units=rows(1)
  state,calls=self.execute(units,lambda b,p:{'0':'テキスト'},review=lambda *_:{'0':'broken'},paid=lambda b,p:{'0':'テキスト'},ai_review_units=1)
  self.assertIn(('review',['0']),calls)
  self.assertEqual(state['workflow']['paid_selected'],1);self.assertEqual(state['stop_reason'],'clean')
 def test_review_transport_error_preserves_valid_draft(self):
  def fail(*_):raise ProviderError('gateway failure')
  units=rows(1);state,calls=self.execute(units,lambda *_:{'0':'テキスト'},review=fail,paid=lambda *_:self.fail('paid'),ai_review_units=1)
  self.assertEqual(units[0]['translation'],'テキスト');self.assertEqual(state['workflow']['paid_selected'],0)
 def test_official_configuration_does_not_inherit_gateway(self):
  a=fallback_args(args(api_key='gateway-secret',api_base_url='https://gateway.test/v1',api_model='gemini',api_input_rmb=0,api_output_rmb=0))
  self.assertIsNone(a.api_key);self.assertEqual(a.api_base_url,'https://api.deepseek.com');self.assertEqual(a.api_model,'deepseek-flash');self.assertIsNone(a.api_output_rmb)
 def test_integration_real_factory_keys_and_residuals(self):
  with tempfile.TemporaryDirectory() as d,contextlib.redirect_stdout(io.StringIO()),patch.dict(os.environ,{'XIANYI_API_KEY':'gateway-test','DEEPSEEK_API_KEY':'official-test'},clear=True):
   root=Path(d);g=root/'g';fixture(g);keys=[];ids=[]
   class Fake:
    def __init__(self,a):self.a=a
    def translate_batch(self,items,**kw):
     keys.append(self.a.provider);ids.append([u['id'] for u in items])
     if self.a.provider=='xianyi':made={items[0]['id']:'テキスト'}
     else:made={u['id']:'\n'.join('テキスト %s' if '%s' in line else 'テキスト' for line in u['source'].split('\n')) for u in items}
     return made,Usage(10,10)
   def factory(a):return Fake(a)
   a=args(fallback_deepseek=True,ai_review_units=0,fallback_max_units=5,fallback_max_api_calls=2,fallback_max_cost_rmb=1.,repair_rounds=0,batch_size=3)
   with patch('vxace.pipeline.make_provider',side_effect=factory):run(g,root/'w',root/'out',a)
   state=json.loads((root/'w'/'ace_checkpoint.json').read_text())
   self.assertEqual(keys,['xianyi','deepseek']);self.assertNotIn(ids[0][0],ids[1]);self.assertEqual(state['stop_reason'],'clean')
   report=json.loads((root/'out'/'workflow_report.json').read_text())
   self.assertEqual(len(report['stages']),2);self.assertEqual(report['stages'][0]['price_status'],'unknown');self.assertEqual(report['stages'][1]['provider'],'deepseek')
   self.assertNotIn('gateway-test',json.dumps(state));self.assertNotIn('official-test',json.dumps(state))
 def test_review_cache_no_requests_on_second_run(self):
  with tempfile.TemporaryDirectory() as d,contextlib.redirect_stdout(io.StringIO()):
   root=Path(d);g=root/'g';fixture(g)
   class Fake:
    calls=0
    def translate_batch(self,items,**kw):
     self.calls+=1
     return {u['id']:'\n'.join('テキスト %s' if '%s' in line else 'テキスト' for line in u['source'].split('\n')) for u in items},Usage()
   f=Fake();a=args(ai_review_units=3,fallback_deepseek=False,max_api_calls=10,batch_size=3)
   run(g,root/'w',root/'first',a,f);self.assertEqual(f.calls,2)
   run(g,root/'w',root/'second',a,f);self.assertEqual(f.calls,2)
 def test_review_shares_primary_request_cap(self):
  with tempfile.TemporaryDirectory() as d,contextlib.redirect_stdout(io.StringIO()):
   root=Path(d);g=root/'g';fixture(g)
   class Fake:
    calls=0
    def translate_batch(self,items,**kw):
     self.calls+=1;return {u['id']:'テキスト' for u in items},Usage()
   f=Fake();a=args(sample=2,batch_size=2,ai_review_units=2,max_api_calls=1)
   run(g,root/'w',root/'first',a,f)
   state=json.loads((root/'w'/'ace_checkpoint.json').read_text());self.assertEqual(f.calls,1)
   self.assertEqual(state['workflow']['review_stop_reason'],'request_limit')

class StagedLimitsTests(unittest.TestCase):
 def test_gateway_auth_failure_only_hands_attempted_batch_to_official(self):
  with tempfile.TemporaryDirectory() as d,contextlib.redirect_stdout(io.StringIO()):
   root=Path(d);g=root/'g';fixture(g);seen=[]
   class Fake:
    def __init__(self,a):self.a=a
    def translate_batch(self,items,**kw):
     seen.append((self.a.provider,[u['id'] for u in items]))
     if self.a.provider=='xianyi':raise ProviderError('xianyi HTTP 400: missing project_id','provider_http_error')
     return {u['id']:'テキスト' for u in items},Usage(10,10)
   a=args(sample=3,batch_size=1,repair_rounds=0,fallback_deepseek=True,fallback_max_units=50,fallback_max_api_calls=2,fallback_max_cost_rmb=1.,ai_review_units=0)
   with patch('vxace.pipeline.make_provider',side_effect=lambda a:Fake(a)):run(g,root/'w',root/'out',a)
   self.assertEqual([p for p,_ in seen],['xianyi','deepseek']);self.assertEqual(seen[0][1],seen[1][1])
   report=json.loads((root/'out'/'workflow_report.json').read_text());self.assertEqual(report['paid_selected'],1);self.assertEqual(report['selected_remaining'],2)
 def test_paid_budget_stops_next_request(self):
  with tempfile.TemporaryDirectory() as d,contextlib.redirect_stdout(io.StringIO()):
   root=Path(d);g=root/'g';fixture(g);paid_calls=[]
   class Fake:
    def __init__(self,a):self.a=a
    def translate_batch(self,items,**kw):
     if self.a.provider=='xianyi':return {},Usage()
     paid_calls.append(len(items));return {u['id']:'テキスト' for u in items},Usage(1_000_000,1_000_000)
   a=args(sample=3,batch_size=1,max_api_calls=5,repair_rounds=0,fallback_deepseek=True,fallback_max_units=50,fallback_max_api_calls=5,fallback_max_cost_rmb=.01,ai_review_units=0)
   with patch('vxace.pipeline.make_provider',side_effect=lambda a:Fake(a)):run(g,root/'w',root/'out',a)
   report=json.loads((root/'out'/'workflow_report.json').read_text());self.assertEqual(paid_calls,[1]);self.assertEqual(report['paid_stop_reason'],'budget_limit')
 def test_paid_missing_key_keeps_gateway_checkpoint(self):
  with tempfile.TemporaryDirectory() as d,contextlib.redirect_stdout(io.StringIO()),patch.dict(os.environ,{},clear=True):
   root=Path(d);g=root/'g';fixture(g)
   class Fake:
    def translate_batch(self,items,**kw):return {items[0]['id']:'テキスト'},Usage()
   a=args(sample=3,batch_size=3,repair_rounds=0,fallback_deepseek=True,fallback_max_units=50,fallback_max_api_calls=2,fallback_max_cost_rmb=1.,ai_review_units=0)
   run(g,root/'w',root/'out',a,Fake())
   st=json.loads((root/'w'/'ace_checkpoint.json').read_text());self.assertEqual(st['workflow']['paid_stop_reason'],'configuration_error');self.assertEqual(len(st['translations']),1)
 def test_failed_review_repaired_by_official_preserves_untouched_drafts(self):
  with tempfile.TemporaryDirectory() as d,contextlib.redirect_stdout(io.StringIO()):
   root=Path(d);g=root/'g';fixture(g);phases=[]
   class Fake:
    def __init__(self,a):self.a=a
    def translate_batch(self,items,**kw):
     review=any('Review this existing' in ctx for u in items for ctx in u['context'])
     phases.append((self.a.provider,review,len(items)))
     made={u['id']:'\n'.join('テキスト %s' if '%s' in line else 'テキスト' for line in u['source'].split('\n')) for u in items}
     if review:
      for u in items:
       if '%s' in u['source']:made[u['id']]=made[u['id']].replace('%s','')
     return made,Usage()
   a=args(sample=None,batch_size=10,max_api_calls=10,repair_rounds=0,ai_review_units=20,fallback_deepseek=True,fallback_max_units=10,fallback_max_api_calls=3,fallback_max_cost_rmb=1.)
   with patch('vxace.pipeline.make_provider',side_effect=lambda a:Fake(a)):run(g,root/'w',root/'out',a)
   st=json.loads((root/'w'/'ace_checkpoint.json').read_text());self.assertEqual(st['stop_reason'],'clean');self.assertEqual(st['semantic_review_pending'],{})
   self.assertTrue(any(provider=='deepseek' for provider,_,_ in phases));self.assertTrue(st['semantic_reviews'])
