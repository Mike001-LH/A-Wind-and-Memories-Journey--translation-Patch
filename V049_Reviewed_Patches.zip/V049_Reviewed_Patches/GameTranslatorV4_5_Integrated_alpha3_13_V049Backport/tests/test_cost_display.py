import contextlib,io,unittest
from decimal import Decimal
from vxace.costs import CostDisplay
from bruns.translate import cost_cny

class CostDisplayTests(unittest.TestCase):
 def test_batch_session_history_and_resume(self):
  state={'spent_rmb':2.5};usage={'prompt_tokens':2000,'prompt_cache_hit_tokens':500,'prompt_cache_miss_tokens':1500,'completion_tokens':1000}
  text=io.StringIO()
  with contextlib.redirect_stdout(text):
   book=CostDisplay(state,5,'peak');book.record(usage);book.record(usage)
  cost=cost_cny(usage,'peak')
  self.assertAlmostEqual(state['session_spent_rmb'],float(cost*2))
  self.assertAlmostEqual(state['spent_rmb'],float(Decimal('2.5')+cost*2))
  self.assertIn('本批',text.getvalue());self.assertIn('本次预算剩余',text.getvalue())
  with contextlib.redirect_stdout(io.StringIO()):resume=CostDisplay(state,5,'peak')
  self.assertEqual(state['session_spent_rmb'],0);self.assertEqual(resume.total,Decimal(str(state['spent_rmb'])))
 def test_unknown_usage_not_zero_billing(self):
  state={'spent_rmb':1,'api_usage_without_price':True}
  with contextlib.redirect_stdout(io.StringIO()):book=CostDisplay(state,5,'peak');book.missing()
  self.assertTrue(state['cost_summary']['incomplete_records']);self.assertEqual(state['spent_rmb'],1)
 def test_invalid_reply_retains_returned_usage(self):
  import json
  from unittest.mock import patch
  from providers.deepseek import DeepSeekProvider
  raw={'choices':[{'message':{'content':'not JSON'}}],'usage':{'prompt_tokens':125,'completion_tokens':497}}
  provider=DeepSeekProvider(api_key='dummy-test')
  with patch.object(provider.opener,'open',return_value=io.BytesIO(json.dumps(raw).encode())):
   with self.assertRaises(RuntimeError) as caught:provider.translate_batch([])
  self.assertEqual(caught.exception.usage.prompt_tokens,125);self.assertEqual(caught.exception.usage.completion_tokens,497)
