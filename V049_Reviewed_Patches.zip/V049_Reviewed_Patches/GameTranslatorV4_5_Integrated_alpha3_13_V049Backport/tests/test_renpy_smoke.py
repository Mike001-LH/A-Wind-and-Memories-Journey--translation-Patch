import tempfile
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from engines.renpy import RenPyAdapter

def test_parser_safety_and_dynamic_speaker():
    with tempfile.TemporaryDirectory() as td:
        root=Path(td); g=root/'game'; g.mkdir()
        (g/'script.rpy').write_text('''define lily = Character("Lily")\nlabel start:\n    lily "Hello"\n    $ the_person = lily\n    the_person "Dynamic hello"\nscreen x():\n    text "Visible UI"\n    textbutton "Go" action Return()\n    layout "subtitle"\n''',encoding='utf-8')
        r=RenPyAdapter().analyze(root)
        pairs=[(u.metadata['kind'],u.speaker,u.source) for u in r.units]
        assert ('character_name',None,'Lily') in pairs
        assert ('dialogue','lily','Hello') in pairs
        assert ('dialogue','the_person','Dynamic hello') in pairs
        assert not any(u.speaker in {'text','textbutton','layout'} for u in r.units)
        assert any(u.source=='Visible UI' for u in r.units)
        assert any(u.source=='Go' for u in r.units)
