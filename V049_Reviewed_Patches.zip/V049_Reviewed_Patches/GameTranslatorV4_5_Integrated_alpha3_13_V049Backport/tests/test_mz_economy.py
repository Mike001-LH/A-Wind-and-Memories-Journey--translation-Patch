import contextlib,io,json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from providers.economy import EconomyProvider
from providers.base import Usage
from rpgmaker.pipeline import run
from test_mz_gateway import MZGatewayTests

class MZEconomyTests(unittest.TestCase):
 def test_resume_target_rules_and_character_limit(self):
  for mz in (True,False):
   with tempfile.TemporaryDirectory() as td, contextlib.redirect_stdout(io.StringIO()):
    b=Path(td); helper=MZGatewayTests();game=helper.fixture(b,mz);seen=[]
    class Fake:
     def translate_batch(self,items,**kw):
      seen.append((items,kw))
      return {u['id']:'你好\\N[1]。\n出发。' if '\n' in u['source'] else '保存。' for u in items},Usage(100,20)
    args=helper.args(provider='deepseek',api_model='deepseek-flash',economy=True,batch_size=30,batch_chars=1,max_api_calls=1)
    run(game,b/'work',b/'out1',args,Fake())
    first=seen[0][0][0]['id'];args.max_api_calls=5
    run(game,b/'work',b/'out2',args,Fake())
    self.assertEqual(sum(u['id']==first for batch,_ in seen for u in batch),1)
    self.assertTrue(all(len(batch)==1 for batch,_ in seen))
    self.assertTrue(all(kw['target_language']=='Simplified Chinese' for _,kw in seen))
    self.assertTrue(all('shared_rules' in u for batch,_ in seen for u in batch))
    prefix='mz' if mz else 'mv'
    self.assertEqual(json.loads((b/'work'/f'{prefix}_checkpoint.json').read_text())['stop_reason'],'clean')
 def test_shared_rule_once_short_ids_and_malformed_retry_reason(self):
  provider=EconomyProvider(api_key='test-placeholder')
  items=[{'id':'mv:'+str(i)*32,'source':'こんにちは','shared_rules':['Unique engine rule']} for i in range(10)]
  raw={'choices':[{'finish_reason':'stop','message':{'content':json.dumps({'t':[[str(i),'你好'] for i in range(10)]})}}],'usage':{'prompt_tokens':100,'completion_tokens':50}}
  with patch.object(provider.opener,'open',return_value=io.BytesIO(json.dumps(raw).encode())) as opened:
   made,_=provider.translate_batch(items,target_language='Simplified Chinese')
   body=json.loads(opened.call_args.args[0].data)
  self.assertEqual(len(made),10)
  self.assertEqual(json.dumps(body).count('Unique engine rule'),1)
  self.assertIn('Simplified Chinese',body['messages'][0]['content'])
  self.assertNotIn(items[0]['id'],body['messages'][1]['content'])
  raw['choices'][0]['message']['content']='{"t":['
  with patch.object(provider.opener,'open',return_value=io.BytesIO(json.dumps(raw).encode())):
   with self.assertRaises(Exception) as caught:provider.translate_batch(items)
  self.assertEqual(caught.exception.reason,'provider_invalid_json')
  self.assertEqual(caught.exception.usage.prompt_tokens,100)
