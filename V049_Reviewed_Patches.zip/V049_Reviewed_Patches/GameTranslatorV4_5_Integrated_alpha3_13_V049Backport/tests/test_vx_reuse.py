import unittest
from copy import deepcopy
from vxace.reuse import DuplicateReuse
from vxace.adapter import audit
from core.completion import complete


def unit(i, source='你好', context=None, translation=''):
    return {'id':str(i),'source':source,'translation':translation,'file':'Data/Map001.rvdata2',
            'context':['上文'] if context is None else context,'protected_tokens':[],
            'metadata':{'kind':'dialogue','path':['events',i,'pages',0,4,'message']}}


class ReuseTests(unittest.TestCase):
    def test_one_request_fans_out_and_checkpoint_contains_every_id(self):
        rows=[unit(i) for i in range(20)];qa=lambda u:audit(u,'en')
        reuse=DuplicateReuse(rows,rows,qa,'Chinese','en');state={};calls=[];snapshots=[]
        def request(batch,phase):
            calls.append([u['id'] for u in batch]);return {u['id']:'Hello' for u in batch},{}
        def save(_,st):
            reuse.propagate(st);snapshots.append({u['id']:u['translation'] for u in rows})
        complete(reuse.representatives,qa,request,save,state=state)
        self.assertEqual(calls,[['0']]);self.assertEqual(len(snapshots[0]),20)
        self.assertEqual(set(snapshots[0].values()),{'Hello'})
        self.assertEqual(reuse.stats['reused_units'],19)
        resumed=DuplicateReuse(rows,rows,qa,'Chinese','en')
        self.assertEqual(resumed.representatives,[])

    def test_scope_context_tokens_and_conflicts(self):
        qa=lambda u:audit(u,'en')
        a=unit(1,translation='Hello');b=unit(2,translation='Hi');c=unit(3)
        r=DuplicateReuse([c],[a,b,c],qa,'Chinese','en');r.propagate({})
        self.assertEqual(c['translation'],'');self.assertEqual(r.stats['conflict_groups'],1)
        for c in [unit(3,context=['另一人']),unit(3,source='你好\n世界'),unit(3,context=[])]:
            r=DuplicateReuse([c],[a,c],qa,'Chinese','en');r.propagate({})
            self.assertEqual(c['translation'],'')
        rows=[unit(1,context=[]),unit(2,context=[])]
        self.assertEqual(len(DuplicateReuse(rows,rows,qa,'Chinese','en').representatives),2)

    def test_sample_only_reuses_selected_and_existing_seed(self):
        rows=[unit(1,translation='Hello'),unit(2),unit(3)]
        r=DuplicateReuse([rows[1]],rows,lambda u:audit(u,'en'),'Chinese','en')
        r.propagate({});self.assertEqual(rows[1]['translation'],'Hello')
        self.assertEqual(rows[2]['translation'],'');self.assertEqual(r.representatives,[])

    def test_rejected_candidate_never_propagates_and_can_retry(self):
        rows=[unit(i,source='\\C[2]你好') for i in range(2)]
        r=DuplicateReuse(rows,rows,lambda u:audit(u,'en'),'Chinese','en')
        rows[0]['translation']='Hello';r.propagate({});self.assertEqual(rows[1]['translation'],'')
        rows[0]['translation']='\\C[2]Hello';r.propagate({})
        self.assertEqual(rows[1]['translation'],'\\C[2]Hello')

    def test_off_switch_and_reviewed_preservation(self):
        rows=[unit(1,translation='Hello'),unit(2)];rows[0]['reviewed']=True
        r=DuplicateReuse(rows,rows,lambda u:audit(u,'en'),'Chinese','en',False)
        r.propagate({});self.assertEqual(rows[1]['translation'],'')
        r=DuplicateReuse(rows,rows,lambda u:audit(u,'en'),'Chinese','en')
        r.propagate({});self.assertTrue(rows[0]['reviewed']);self.assertFalse(rows[1]['reviewed'])

    def test_budget_stop_keeps_completed_group_for_resume(self):
        from bruns.autocomplete import BudgetStop
        rows=[unit(1),unit(2),unit(3,source='再见'),unit(4,source='再见')]
        qa=lambda u:audit(u,'en');r=DuplicateReuse(rows,rows,qa,'Chinese','en');state={};calls=[]
        def request(batch,phase):
            calls.append(batch)
            if len(calls)>1:raise BudgetStop('budget')
            return {batch[0]['id']:'Hello'},{}
        def save(_,st):r.propagate(st)
        complete(r.representatives,qa,request,save,batch_size=1,state=state)
        self.assertEqual(state['stop_reason'],'budget_limit')
        self.assertEqual([u['translation'] for u in rows],['Hello','Hello','',''])
        resume=DuplicateReuse(rows,rows,qa,'Chinese','en')
        self.assertEqual([u['id'] for u in resume.representatives],['3'])
