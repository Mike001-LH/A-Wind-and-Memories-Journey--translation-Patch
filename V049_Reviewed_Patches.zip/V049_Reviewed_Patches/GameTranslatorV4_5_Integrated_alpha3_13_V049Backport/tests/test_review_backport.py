import json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from test_vxace import fixture
from vxace.adapter import extract,build_files
from vxace.review_backport import build
from vxace.version_migrate import hashes
class BackportTests(unittest.TestCase):
 def setup_patch(self,game,out,target,translated=False):
    out.mkdir();(out/'Data').mkdir()
    units,manifest,_=extract(game)
    for u in units:
      if translated and u['metadata']['kind']=='choice':u['translation']='Yes' if u['source']=='是' else 'No'
    changed,_=build_files(game,units,manifest,target,allow_partial=True)
    for name,raw in changed.items():(out/name).write_bytes(raw)
    (out/'build_report.json').write_text(json.dumps({'source_hashes':hashes(game),'target_language':target,'engine':'vxace'}))
 def test_text_reuse_and_source_validation(self):
    with tempfile.TemporaryDirectory() as d:
      p=Path(d);game=p/'old';new=p/'new';fixture(game);fixture(new)
      self.setup_patch(game,p/'patch','en');self.setup_patch(new,p/'reviewed','en',True)
      with patch('vxace.review_backport.supported',return_value=True),patch('vxace.review_backport.apply_runtime',side_effect=lambda g,r,u,t:(r,{'enabled':False})):
        report=build(game,p/'patch',new,p/'reviewed','en',p/'out')
        self.assertEqual(report['fixed_kinds'].get('choice'),2)
        self.assertEqual((game/'Data/CommonEvents.rvdata2').read_bytes(),(new/'Data/CommonEvents.rvdata2').read_bytes())
        with self.assertRaises(ValueError):build(game,p/'patch',new,p/'reviewed','ja',p/'wrong')
        with self.assertRaises(ValueError):build(game,p/'patch',new,p/'reviewed','en',p/'out')
if __name__=='__main__':unittest.main()
