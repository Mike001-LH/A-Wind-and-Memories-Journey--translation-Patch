import io,json,contextlib,unittest
from unittest.mock import patch
from providers.economy import EconomyProvider
from providers.deepseek import DeepSeekProvider
from core.completion import complete

class EconomyTests(unittest.TestCase):
 def invoke(self,items,pairs,provider=None):
  obj={'choices':[{'finish_reason':'stop','message':{'content':json.dumps(pairs,ensure_ascii=False)}}], 'usage':{'prompt_tokens':100,'completion_tokens':50}}
  provider=provider or EconomyProvider(api_key='test-placeholder')
  with patch.object(provider.opener,'open',return_value=io.BytesIO(json.dumps(obj).encode())) as opened:
   result=provider.translate_batch(items,source_language='Chinese',target_language='Japanese')
   return result,json.loads(opened.call_args.args[0].data)
 def test_ids_context_control_and_languages(self):
  items=[{'id':'ace:long-stable-id-1','source':'你好','context':[]}, {'id':'ace:long-stable-id-2','source':'\\C[2]欢迎\\C[0]\n再见','context':['你好'],'protected_tokens':['\\C[2]','\\C[0]']}]
  (made,usage),body=self.invoke(items,{'t':[['0','こんにちは'],['1','\\C[2]ようこそ\\C[0]\nさようなら']]})
  self.assertEqual(set(made),set(u['id'] for u in items));self.assertEqual(usage.prompt_tokens,100)
  rows=json.loads(body['messages'][1]['content']);self.assertEqual(rows[1]['c'],[{'ref':'0'}]);self.assertEqual(rows[1]['p'],items[1]['protected_tokens'])
  self.assertIn('Chinese to Japanese',body['messages'][0]['content']);self.assertEqual(body['thinking'],{'type':'disabled'})
 def test_partial_rows_do_not_discard_good_results(self):
  items=[{'id':str(i),'source':'text'} for i in range(3)]
  (made,_),_=self.invoke(items,{'t':[['0','good'],['1',None],['2','first'],['2','second'],['unknown','bad']]})
  self.assertEqual(made,{'0':'good'})
 def test_invalid_json_accounts_usage(self):
  items=[{'id':'a','source':'text'}]
  with self.assertRaises(RuntimeError) as caught:self.invoke(items,{'wrong':[]})
  self.assertEqual(caught.exception.usage.completion_tokens,50)
 def test_source_length_batching_does_not_drop_or_reorder_units(self):
  units=[{'id':str(i),'source':'a'*n,'translation':''} for i,n in enumerate([4,4,12,2,2])];calls=[]
  def request(batch,phase):calls.append([u['id'] for u in batch]);return {u['id']:'done' for u in batch},{}
  with contextlib.redirect_stdout(io.StringIO()):complete(units,lambda u:{'blocking':[] if u['translation'] else ['empty'],'advisory':[]},request,lambda *_:None,rounds=0,batch_size=30,max_batch_chars=8)
  self.assertEqual(calls,[['0','1'],['2'],['3','4']]);self.assertTrue(all(u['translation']=='done' for u in units))
 def test_compact_payload_smaller_than_legacy(self):
  items=[{'id':'ace:0123456789abcdef0123456789abcd'+str(i),'source':'欢迎来到旅馆，请在这里休息。','context':['Keep exactly the same number of physical newlines and preserve ALL protected tokens. Fit concise game dialogue/UI text. Do not alter technical tags. Separate bare backslash letter codes from following English words with a space.'],'protected_tokens':[]} for i in range(30)]
  _,new=self.invoke(items,{'t':[[str(i),'宿屋へようこそ。ここでお休みください。'] for i in range(30)]})
  _,old=self.invoke(items,{'translations':[{'id':u['id'],'translation':'宿屋へようこそ。ここでお休みください。'} for u in items]},DeepSeekProvider(api_key='test-placeholder'))
  size=lambda obj:len(json.dumps(obj,ensure_ascii=False).encode())
  self.assertLess(size(new),size(old)*.6)
