import contextlib,io,json,os,tempfile,unittest,urllib.error
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from providers.config import make_provider,SessionAccounting,RequestStop,normalize_base
from providers.deepseek import ProviderError
from providers.configure import store_key
from providers.base import Usage
from test_vxace import fixture
from vxace.pipeline import run

def args(**kw):
 d=dict(provider='xianyi',api_key=None,max_api_calls=2,max_cost_rmb=5,price_band='peak',target_language='ja',source_language='Chinese',analyze=False,estimate=False,migrate_only=False,reuse_from=None,import_translations=None,glossary=None,sample=3,build_only=False,batch_size=1,repair_rounds=1,stall_rounds=2,allow_partial=True,vx_font=None)
 d.update(kw);return SimpleNamespace(**d)

class GatewayTests(unittest.TestCase):
 def test_key_isolation(self):
  with patch.dict(os.environ,{'DEEPSEEK_API_KEY':'official-test','XIANYI_API_KEY':'gateway-test'},clear=True):
   self.assertEqual(make_provider(args()).api_key,'gateway-test')
   self.assertEqual(make_provider(args(provider='deepseek')).api_key,'official-test')
  with patch.dict(os.environ,{'DEEPSEEK_API_KEY':'official-test'},clear=True):
   with self.assertRaisesRegex(RuntimeError,'XIANYI_API_KEY'):make_provider(args())
 def test_https_base(self):
  self.assertEqual(normalize_base('https://example.com/',True),'https://example.com/v1')
  for base in ['http://example.com','https://secret@example.com','https://example.com/v1/chat/completions']:
   with self.assertRaises(ValueError):normalize_base(base,True)
 def reply(self,content,finish='stop'):
  return {'choices':[{'message':{'content':content},'finish_reason':finish}], 'usage':{'prompt_tokens':125,'completion_tokens':497,'completion_tokens_details':{'reasoning_tokens':435}}}
 def invoke(self,reply,thinking=None):
  p=make_provider(args(api_key='dummy-test-key',api_thinking=thinking))
  response=io.BytesIO(json.dumps(reply).encode())
  with patch.object(p.opener,'open',return_value=response) as op:
   result=p.translate_batch([{'id':'1','source':'你好'}],source_language='Chinese',target_language='Japanese')
   req=op.call_args.args[0];body=json.loads(req.data)
   self.assertEqual(req.full_url,'https://noxianyi.zeabur.app/v1/chat/completions')
   self.assertEqual(body['model'],'deepseek-ai/deepseek-v4.1-flash')
   self.assertIn('into Japanese',body['messages'][0]['content'])
   self.assertNotIn('response_format',body)
   if thinking is None:self.assertNotIn('thinking',body)
   else:self.assertEqual(body['thinking'],{'type':'disabled'})
   return result
 def test_japanese_payload_and_reasoning(self):
  result,usage=self.invoke(self.reply('```json\n{"translations":[{"id":"1","translation":"こんにちは"}]}\n```'))
  self.assertEqual(result,{'1':'こんにちは'});self.assertEqual(usage.reasoning_tokens,435)
  self.invoke(self.reply('{"translations":[]}'),thinking='disabled')
 def test_bad_response_stops_and_keeps_usage(self):
  for reply in [self.reply('no JSON'),self.reply('{}','length'),self.reply('{"translations":[{"id":"wrong","translation":"x"}]}'),{'usage':{},'choices':[]}]:
   with self.assertRaises(ProviderError) as caught:self.invoke(reply)
   self.assertTrue(caught.exception.stop_run);self.assertIsInstance(caught.exception.usage,Usage)
 def test_http_error_redacts_key(self):
  p=make_provider(args(api_key='dummy-test-key'))
  error=urllib.error.HTTPError(p.base_url,401,'bad',{},io.BytesIO(b'dummy-test-key'))
  with patch.object(p.opener,'open',side_effect=error):
   with self.assertRaises(ProviderError) as caught:p.translate_batch([])
  self.assertNotIn('dummy-test-key',str(caught.exception))
 def test_unknown_price_and_request_limit(self):
  state={}
  with contextlib.redirect_stdout(io.StringIO()):
   acc=SessionAccounting(args(max_api_calls=1),state);acc.before();acc.record({'completion_tokens':497,'reasoning_tokens':435})
   with self.assertRaises(RequestStop):acc.before()
  self.assertIsNone(state['session_spent_rmb']);self.assertNotIn('spent_rmb',state)
  self.assertEqual(state['api_session']['attempted_requests'],1)
  with self.assertRaises(ValueError):SessionAccounting(args(max_api_calls=None),{})
 def test_explicit_price_does_not_double_count_reasoning(self):
  with contextlib.redirect_stdout(io.StringIO()):
   state={};acc=SessionAccounting(args(api_input_rmb=1,api_output_rmb=2),state)
   acc.before();acc.record({'prompt_tokens':125,'completion_tokens':497,'reasoning_tokens':435})
  self.assertAlmostEqual(state['session_spent_rmb'],(125+497*2)/1000000)
 def test_store_preserves_other_provider(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'.env';store_key(p,'DEEPSEEK_API_KEY','first-test');store_key(p,'XIANYI_API_KEY','second-test')
   self.assertIn('DEEPSEEK_API_KEY=first-test',p.read_text());self.assertEqual(p.stat().st_mode&0o777,0o600)
 def test_japanese_pause_resume_and_cache(self):
  class Fake:
   calls=0
   def translate_batch(self,items,**kw):
    self.calls+=1
    assert kw['target_language']=='Japanese'
    return {u['id']:'\n'.join('テキスト %s' if '%s' in line else 'テキスト' for line in u['source'].split('\n')) for u in items},Usage(1,2)
  with tempfile.TemporaryDirectory() as d,contextlib.redirect_stdout(io.StringIO()):
   root=Path(d);game=root/'game';fixture(game);work=root/'work';f=Fake()
   run(game,work,root/'first',args(max_api_calls=1),f)
   state=json.loads((work/'ace_checkpoint.json').read_text());self.assertEqual(state['stop_reason'],'request_limit');self.assertEqual(f.calls,1)
   run(game,work,root/'second',args(max_api_calls=10),f);calls=f.calls
   run(game,work,root/'third',args(max_api_calls=10),f);self.assertEqual(f.calls,calls)
   report=json.loads((root/'third'/'build_report.json').read_text());self.assertIsNone(report['api_session']);self.assertIsNone(report['font_override'])
