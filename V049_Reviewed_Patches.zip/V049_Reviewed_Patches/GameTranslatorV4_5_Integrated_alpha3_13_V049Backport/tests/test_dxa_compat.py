import unittest
from dxa.compat import unsupported,require_compatible,MENU_SOURCE,MENU_ZH
from dxa.cli import diagnostic_replacements

class CompatTests(unittest.TestCase):
    def test_runtime_regression_truncating_character_blocked(self):
        self.assertEqual(unsupported('A开始B'),[{'character':'开','codepoint':'U+5F00'}])
        with self.assertRaisesRegex(ValueError,r'U\+5F00'):require_compatible('A开始B')
        for t in ['C開始D','E新規F','GはじめH']+MENU_ZH:require_compatible(t)
    def test_probe_preserves_structure_and_tail(self):
        raw=('001,,,05,,0\r\n'+''.join('-----'+x+'\r\n' for x in MENU_SOURCE)+'//tail\r\n-----はい\r\n').encode()
        class Fake:
            def read(self,path):return raw
        made=diagnostic_replacements(Fake(),'compatible-menu')['data01/wtex_jp.txt']
        self.assertEqual(made.decode().splitlines()[1:6],['-----'+x for x in MENU_ZH])
        self.assertEqual(made.splitlines(keepends=True)[6:],raw.splitlines(keepends=True)[6:])
        self.assertEqual(made.splitlines()[0],raw.splitlines()[0])
