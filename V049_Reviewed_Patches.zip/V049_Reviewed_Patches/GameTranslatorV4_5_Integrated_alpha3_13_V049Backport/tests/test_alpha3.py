import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from core.completion import complete, atomic_json
from core.safe_output import validate_paths
from bruns.residual import audit as baudit
from bruns.autocomplete import run as bruns_complete
from bruns.codec import encode, decode
from bruns.write import build as bruns_build
from rpgmaker.mv import extract, audit, patched_documents
from rpgmaker.pipeline import run as mv_run
from providers.base import Usage
from unified import detect_engine


def mv_fixture(game, www=True):
    root=game/'www' if www else game
    (root/'data').mkdir(parents=True);(root/'js').mkdir()
    (root/'js'/'rpg_core.js').write_text('// fixture')
    def write(name,value): atomic_json(root/'data'/name,value)
    write('System.json',{'gameTitle':'冒険','currencyUnit':'金','terms':{'messages':{'victory':'%1の勝利！'}},
                         'switches':['','DO_NOT_TRANSLATE'],'variables':['','FLAG'],'title1Name':'TitleAsset'})
    rows=[{'code':101,'indent':0,'parameters':['ActorFace',0,0,2]},
          {'code':401,'indent':0,'parameters':['こんにちは\\N[1]。']},
          {'code':401,'indent':0,'parameters':['出発します。']},
          {'code':102,'indent':0,'parameters':[['行きます','戻ります'],0,0,2,0]},
          {'code':402,'indent':0,'parameters':[0,'行きます']},
          {'code':355,'indent':1,'parameters':['console.log("こんにちは")']},
          {'code':108,'indent':1,'parameters':['翻訳しないコメント']},
          {'code':402,'indent':0,'parameters':[1,'戻ります']},
          {'code':404,'indent':0,'parameters':[]},
          {'code':320,'indent':0,'parameters':[1,'勇者']},
          {'code':405,'indent':0,'parameters':['昔々']},
          {'code':0,'indent':0,'parameters':[]}]
    write('Map001.json',{'displayName':'学校','note':'<plugin:日本語>', 'events':[None,{'name':'EV001',
          'pages':[{'list':rows}]}], 'data':[1,2,3], 'tilesetId':1})
    write('Actors.json',[None,{'name':'勇者','nickname':'英雄','profile':'人物\n紹介',
                              'characterName':'Asset日本語','note':'<tag:そのまま>'}])
    write('CommonEvents.json',[None,{'name':'InternalName','list':[{'code':401,'indent':0,'parameters':['保存します。']}]}])
    write('Troops.json',[None,{'name':'Troop','pages':[{'list':[{'code':401,'indent':0,'parameters':['戦います。']}]}]}])
    write('MapInfos.json',[None,{'name':'EditorMapName'}])
    (root/'js'/'plugins.js').write_text('var $plugins=[];')
    return root


class CompletionTests(unittest.TestCase):
    def test_residual_classification(self):
        def check(s,t,allow=()):return baudit({'source':s,'translation':t},allow)
        self.assertIn('same_as_japanese_source',check('こんにちは','こんにちは')['blocking'])
        self.assertIn('hiragana_prose_residue',check('ここに来ます','此処に来ます')['blocking'])
        self.assertFalse(check('学校','学校')['blocking'])
        self.assertFalse(check('リロイ','リロイ',['リロイ'])['blocking'])
        self.assertIn('cp932_unencodable',check('こんにちは','你好')['blocking'])
        self.assertIn('control_token_mismatch',check('今日は#R','今日')['blocking'])

    def test_retry_only_residual_and_preserve(self):
        units=[{'id':'a','source':'こんにちは','translation':'こんにちは'},
               {'id':'b','source':'学校','translation':'学校'}]
        calls=[]; saved=[]
        def req(batch,phase):
            calls.append([u['id'] for u in batch])
            return {'a':'你好' if len(calls)==1 else '今日好'},{}
        complete(units,baudit,req,lambda u,s:saved.append(json.dumps(u)),repair_only=True,rounds=3)
        self.assertEqual(calls,[['a'],['a']]);self.assertEqual(units[0]['translation'],'今日好')
        self.assertEqual(json.loads(saved[0])[0]['translation'],'こんにちは')

    def test_stall_and_missing_output(self):
        units=[{'id':'a','source':'こんにちは','translation':''}]
        state=complete(units,baudit,lambda b,p:({},{}),lambda u,s:None,rounds=8,stall_rounds=2)
        self.assertEqual(state['stop_reason'],'no_progress')
        self.assertEqual(len(state['completion_history']),3)

    def test_checkpoint_budget_and_malformed_usage(self):
        with tempfile.TemporaryDirectory() as td:
            ws=Path(td)
            atomic_json(ws/'bruns_units.json',[{'id':'a','kind':'narration','source':'こんにちは','translation':'','occurrences':[]}])
            calls=[]
            def transport(items,mode):
                calls.append(mode)
                return {'choices':[{'message':{'content':'not json'}}],
                        'usage':{'prompt_tokens':1000000,'completion_tokens':1000000}}
            bruns_complete(ws,transport=transport,max_cost=.01,rounds=3)
            st=json.loads((ws/'bruns_alpha9_checkpoint.json').read_text())['state']
            self.assertEqual(len(calls),1);self.assertEqual(st['stop_reason'],'budget_limit')
            self.assertGreater(st['spent_rmb'],0)


    def test_legacy_checkpoint_resume_repair_only(self):
        with tempfile.TemporaryDirectory() as td:
            ws=Path(td)
            unit={'id':'a','source':'こんにちは','kind':'narration','translation':'','occurrences':[]}
            atomic_json(ws/'bruns_units.json',[unit])
            unit['translation']='こんにちは'
            atomic_json(ws/'bruns_alpha9_checkpoint.json',{'state':{},'units':[unit]})
            calls=[]
            def transport(items,mode):
                calls.append(mode)
                return {'choices':[{'message':{'content':json.dumps({'translations':[{'id':'a','text':'今日好'}]})}}]}
            result=bruns_complete(ws,transport=transport,repair_only=True)
            self.assertEqual(result['blocking_count'],0);self.assertEqual(calls,['repair'])
            bruns_complete(ws,transport=transport)
            self.assertEqual(calls,['repair'])



class MVTests(unittest.TestCase):
    def test_reflow_preserves_text_tokens_and_rejects_other_errors(self):
        from rpgmaker.reflow import repair_newlines
        source='説明の前半\n説明の後半\n三行目'
        target='这里是说明的前半部分。接下来是后半部分，还有第三行。'
        result=repair_newlines({'source':source},target)
        self.assertEqual(result.count('\n'),2)
        self.assertEqual(result.replace('\n',''),target)
        self.assertTrue(all(x.strip() for x in result.split('\n')))
        self.assertIsNone(repair_newlines({'source':'前半\\C[1]\n後半'},'译文\\C[2]'))
        self.assertIsNone(repair_newlines({'source':'前半\n\n後半'},'中文说明'))
        self.assertIsNone(repair_newlines({'source':'前半\n後半'},'字'))
        result=repair_newlines({'source':'\\n<カレン>前半\\C[1]\n後半'},
                               '\\n<卡莲>这是一段比较长的中文\\C[1]说明文字。')
        self.assertFalse(audit({'source':'\\n<カレン>前半\\C[1]\n後半','translation':result})['blocking'])
        self.assertIn('\\n<卡莲>', result)

    def test_speaker_tag_translation_keeps_other_controls_strict(self):
        self.assertFalse(audit({'source': r'\n<カレン>こんにちは\C[2]',
                                'translation': r'\n<卡莲>你好\C[2]'})['blocking'])
        for target in (r'\n<卡莲>你好\C[3]', r'\N<卡莲>你好\C[2]',
                       r'\n<>你好\C[2]', r'\n< >你好\C[2]', '你好\\C[2]'):
            self.assertTrue(audit({'source': r'\n<カレン>こんにちは\C[2]', 'translation': target})['blocking'])
        self.assertTrue(audit({'source': r'\asset<abc>hello', 'translation': r'\asset<xyz>你好'})['blocking'])
        self.assertTrue(audit({'source': r'\N[1]hello', 'translation': r'\N[2]你好'})['blocking'])

    def test_offline_recovery_preserves_checkpoint_and_source(self):
        from core.completion import fingerprint
        from rpgmaker.pipeline import prepare
        from rpgmaker.recover import recover
        from rpgmaker.mv import TOKEN
        with tempfile.TemporaryDirectory() as td:
            p=Path(td); game=p/'game'; root=mv_fixture(game)
            path=root/'data'/'CommonEvents.json'
            atomic_json(path,[None,{'list':[{'code':401,'parameters':[r'\n<カレン>こんにちは']}]}])
            units,_=prepare(game,p/'work')
            uid=next(u['id'] for u in units if u['source']==r'\n<カレン>こんにちは')
            translations={u['id']:'\n'.join('译文'+''.join(TOKEN.findall(line))
                          for line in u['source'].split('\n')) for u in units}
            translations[uid]=''
            state={'input_fingerprint':fingerprint(units),'translations':translations,
                   'rejected_candidates':{uid:r'\n<卡莲>你好'},'spent_rmb':1.25}
            cp=p/'work'/'mv_checkpoint.json'; atomic_json(cp,state); before=cp.read_bytes()
            self.assertEqual(recover(game,p/'work',p/'out'),(1,0))
            self.assertEqual(next((p/'work').glob('*.backup-*')).read_bytes(),before)
            self.assertEqual(json.loads(cp.read_text())['spent_rmb'],1.25)
            self.assertEqual(json.loads(path.read_text())[1]['list'][0]['parameters'][0],r'\n<カレン>こんにちは')
            self.assertEqual(json.loads((p/'out'/'www'/'data'/'CommonEvents.json').read_text())
                             [1]['list'][0]['parameters'][0],r'\n<卡莲>你好')
            with self.assertRaises(ValueError):recover(game,p/'work',p/'out')

    def test_mz_detect_extract_sample_and_isolated_checkpoint(self):
        class Fake:
            def translate_batch(self, items, **kwargs):
                from rpgmaker.mv import TOKEN
                return {u['id']: '\n'.join('译文'+''.join(TOKEN.findall(line))
                        for line in u['source'].split('\n')) for u in items}, Usage(10,10,0,10)
        with tempfile.TemporaryDirectory() as td:
            p=Path(td); game=p/'game'; root=mv_fixture(game, www=False)
            (root/'js'/'rpg_core.js').rename(root/'js'/'rmmz_core.js')
            path=root/'data'/'Map001.json'; data=json.loads(path.read_text())
            data['events'][1]['pages'][0]['list'].insert(0,{'code':357,'indent':0,
                'parameters':['Plugin','run','run',{'text':'プラグイン'}]})
            atomic_json(path,data)
            self.assertEqual(detect_engine(game)[0], 'RPG Maker MZ')
            units,manifest=extract(game)
            self.assertEqual(manifest['engine'], 'RPG Maker MZ')
            self.assertTrue(all(u['id'].startswith('mz:') for u in units))
            self.assertFalse(any('プラグイン' in u['source'] for u in units))
            self.assertIn('こんにちは\\N[1]。\n出発します。',[u['source'] for u in units])
            args=SimpleNamespace(analyze=False,estimate=False,glossary=None,max_cost_rmb=5,
                price_band='peak',source_language='Japanese',repair_rounds=1,batch_size=5,
                stall_rounds=2,allow_partial=False,sample=2)
            mv_run(game,p/'work',p/'sample',args,provider=Fake())
            self.assertTrue((p/'work'/'mz_checkpoint.json').exists())
            self.assertFalse((p/'work'/'mv_checkpoint.json').exists())
            self.assertEqual(json.loads((p/'work'/'mz_build_report.json').read_text())['sample_units'],2)
            self.assertEqual(json.loads((p/'sample'/'data'/'Map001.json').read_text())
                             ['events'][1]['pages'][0]['list'][0]['parameters'][3]['text'],'プラグイン')

    def test_extract_coverage_and_patch_invariants(self):
        with tempfile.TemporaryDirectory() as td:
            game=Path(td)/'game'; root=mv_fixture(game)
            before={p.relative_to(game).as_posix():p.read_bytes() for p in game.rglob('*') if p.is_file()}
            units,manifest=extract(game)
            self.assertEqual(detect_engine(game)[0],'RPG Maker MV')
            sources=[u['source'] for u in units]
            self.assertIn('こんにちは\\N[1]。\n出発します。',sources)
            self.assertIn('保存します。',sources);self.assertIn('戦います。',sources)
            self.assertNotIn('EditorMapName',sources);self.assertNotIn('EV001',sources)
            self.assertFalse(any('console.log' in s or '<plugin:' in s for s in sources))
            for u in units:
                u['translation']=u['source'].replace('こんにちは','您好').replace('出発します','出发').replace('の勝利','获胜').replace('行きます','前进').replace('戻ります','返回').replace('保存します','保存').replace('戦います','战斗')
            docs,left=patched_documents(game,units,manifest)
            self.assertFalse(left)
            events=docs['www/data/Map001.json']['events'][1]['pages'][0]['list']
            self.assertEqual(events[3]['parameters'][0][0],events[4]['parameters'][1])
            self.assertEqual(events[5]['parameters'][0],'console.log("こんにちは")')
            self.assertEqual(events[0]['parameters'][0],'ActorFace')
            self.assertEqual({p.relative_to(game).as_posix():p.read_bytes() for p in game.rglob('*') if p.is_file()},before)

    def test_guard_tokens_newlines_source_changes(self):
        self.assertIn('escape_token_mismatch',audit({'source':'\\C[2] hi %1','translation':'hi'})['blocking'])
        self.assertIn('newline_mismatch',audit({'source':'a\nb','translation':'合并'})['blocking'])
        with tempfile.TemporaryDirectory() as td:
            game=Path(td)/'game'; root=mv_fixture(game,False)
            units,m=extract(game)
            self.assertEqual(detect_engine(game)[0],'RPG Maker MV')
            (root/'data'/'Actors.json').write_text('[]')
            with self.assertRaisesRegex(ValueError,'changed'):patched_documents(game,units,m)

    def test_pipeline_fake_provider_resume_and_output(self):
        class Fake:
            def __init__(self):self.calls=0
            def translate_batch(self,items,**kwargs):
                self.calls+=1
                from rpgmaker.mv import TOKEN
                return {u['id']:'\n'.join('译文'+''.join(TOKEN.findall(line)) for line in u['source'].split('\n')) for u in items},Usage(10,10,0,10)
        with tempfile.TemporaryDirectory() as td:
            p=Path(td);game=p/'game';root=mv_fixture(game)
            args=SimpleNamespace(analyze=False,estimate=False,glossary=None,max_cost_rmb=5,price_band='peak',
                 source_language='Japanese',repair_rounds=3,batch_size=4,stall_rounds=2,allow_partial=False)
            fake=Fake();mv_run(game,p/'work',p/'out',args,provider=fake)
            self.assertTrue((p/'out'/'www'/'data'/'Map001.json').exists())
            self.assertEqual((p/'out'/'www'/'js'/'plugins.js').read_bytes(),(root/'js'/'plugins.js').read_bytes())
            count=fake.calls
            mv_run(game,p/'work',p/'out2',args,provider=fake)
            self.assertEqual(fake.calls,count)
            with self.assertRaises(ValueError):validate_paths(game,p/'work',p/'out')
            with self.assertRaises(ValueError):validate_paths(game,game/'work',p/'new')

    def test_sample_limits_api_and_builds_partial_copy(self):
        class Fake:
            def __init__(self): self.requested=[]
            def translate_batch(self,items,**kwargs):
                self.requested.extend(u['id'] for u in items)
                from rpgmaker.mv import TOKEN
                return {u['id']:'\n'.join('译文'+''.join(TOKEN.findall(line))
                    for line in u['source'].split('\n')) for u in items},Usage(10,10,0,10)
        with tempfile.TemporaryDirectory() as td:
            p=Path(td);game=p/'game';mv_fixture(game)
            args=SimpleNamespace(analyze=False,estimate=False,glossary=None,max_cost_rmb=5,
                price_band='peak',source_language='Japanese',repair_rounds=1,batch_size=10,
                stall_rounds=2,allow_partial=False,sample=2)
            fake=Fake();mv_run(game,p/'work',p/'sample',args,provider=fake)
            self.assertEqual(len(fake.requested),2)
            report=json.loads((p/'work'/'mv_build_report.json').read_text())
            self.assertEqual(report['status'],'partial')
            self.assertEqual(report['sample_units'],2)
            self.assertTrue((p/'sample'/'www'/'data'/'System.json').exists())
            mv_run(game,p/'work',p/'sample2',args,provider=fake)
            self.assertEqual(len(fake.requested),2)


    def test_nested_choice_aliases_and_partial_build(self):
        with tempfile.TemporaryDirectory() as td:
            game=Path(td)/'game';root=mv_fixture(game)
            path=root/'data'/'Map001.json';data=json.loads(path.read_text())
            data['events'][1]['pages'][0]['list']=[
                {'code':102,'indent':0,'parameters':[['外側'],0,0,0,0]},
                {'code':402,'indent':0,'parameters':[0,'外側']},
                {'code':102,'indent':1,'parameters':[['内側'],0,0,0,0]},
                {'code':402,'indent':1,'parameters':[0,'内側']},
                {'code':404,'indent':1,'parameters':[]},
                {'code':404,'indent':0,'parameters':[]}]
            atomic_json(path,data)
            units,manifest=extract(game)
            for u in units:
                if u['source'] in ('外側','内側'):u['translation']={'外側':'外部','内側':'内部'}[u['source']]
            docs,left=patched_documents(game,units,manifest,allow_partial=True)
            rows=docs['www/data/Map001.json']['events'][1]['pages'][0]['list']
            self.assertEqual(rows[1]['parameters'][1],'外部')
            self.assertEqual(rows[3]['parameters'][1],'内部')
            self.assertTrue(left)
            with self.assertRaises(ValueError):patched_documents(game,units,manifest)

    def test_manifest_path_tampering_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            game=Path(td)/'game';mv_fixture(game)
            units,manifest=extract(game)
            units[0]['file']='../outside.json'
            with self.assertRaisesRegex(ValueError,'modified'):patched_documents(game,units,manifest)



class BrunsWriterTests(unittest.TestCase):
    def test_arbitrary_count_roundtrip_and_changed_source(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td);game=p/'game';(game/'scene').mkdir(parents=True);ws=p/'work';ws.mkdir()
            text='こんにちは'; raw=('(a3:send-string "'+text+'" 0)').encode('cp932')
            (game/'scene'/'a.bso').write_bytes(encode(raw))
            st=raw.index(text.encode('cp932')); en=st+len(text.encode('cp932'))
            unit={'id':'bruns:0','kind':'narration','source':text,'translation':'',
                  'occurrences':[{'file':'scene/a.bso','start':st,'end':en,'raw_string':text}]}
            atomic_json(ws/'bruns_units.json',[unit]);unit['translation']='今日好'
            atomic_json(ws/'bruns_units_translated.json',[unit])
            result=bruns_build(game,ws,p/'out')
            self.assertEqual(result['occurrences_written'],1)
            self.assertIn('今日好'.encode('cp932'),decode((p/'out'/'scene'/'a.bso').read_bytes()))
            self.assertEqual(decode((game/'scene'/'a.bso').read_bytes()),raw)
            with self.assertRaises(ValueError):bruns_build(game,ws,p/'out')
            (game/'scene'/'a.bso').write_bytes(encode(raw.replace(text.encode('cp932'),b'changed')))
            with self.assertRaises(ValueError):bruns_build(game,ws,p/'out2')
            self.assertFalse((p/'out2').exists())

if __name__=='__main__':unittest.main()
