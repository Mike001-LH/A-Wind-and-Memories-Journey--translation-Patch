import copy
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch as mock_patch
from vxace.version_migrate import migrate_strict, apply_script_recipe, verified_strings, separate
from vxace.marshal48 import Reader, Node, length


def unit(source='欢迎来到这个全新的村庄。',uid='id1',kind='dialogue',context=None,file='Data/Map001.rvdata2'):
    path=['events',1,'pages',0,'list',1,'message']
    return dict(id=uid,source=source,translation='',file=file,context=context or [],
        location=json.dumps([file,path]),metadata={'kind':kind,'path':path})
def row(u,translation='Welcome to this new village.'):
    return dict(u,kind=u['metadata']['kind'],translation=translation)

class MigrationTests(unittest.TestCase):
    def test_exact_source(self):
        u=unit();r=migrate_strict([u],[row(u)],'en');self.assertEqual(r['counts'],{'reused':1})
    def test_changed_source_is_not_overwritten(self):
        old=unit();u=unit('欢迎来到这个古老的村庄。');r=migrate_strict([u],[row(old)],'en')
        self.assertFalse(u['translation']);self.assertEqual(r['counts'],{'modified_needs_translation':1})
    def test_short_empty_context_not_cross_page(self):
        old=unit('你好');u=unit('你好',uid='id2');u['metadata']['path'][1]=2
        r=migrate_strict([u],[row(old,'Hello')],'en');self.assertFalse(u['translation'])
    def test_conflicting_old_translations_stay_pending(self):
        old=unit();u=unit(uid='id3');a=row(old);b=row(unit(uid='id2'),'Good day!')
        r=migrate_strict([u],[a,b],'en');self.assertFalse(u['translation']);self.assertEqual(r['counts'],{'conflict':1})
    def test_no_cross_file_fallback(self):
        old=unit();u=unit(uid='id2',file='Data/Map002.rvdata2');migrate_strict([u],[row(old)],'en');self.assertFalse(u['translation'])
    def test_control_tokens_are_checked(self):
        u=unit('\\C[2]你好');r=migrate_strict([u],[row(u,'Hello')],'en');self.assertFalse(u['translation'])
    def test_existing_destination_refused(self):
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(ValueError):separate(d)
    def test_language_recipe_rejected(self):
        with self.assertRaisesRegex(ValueError,'language'):
            apply_script_recipe(Path('.'),b'',{'format':'gt-vxace-script-transfer-1','target_language':'ja'},'en')
    def test_version_recipe_rejected(self):
        with mock_patch('vxace.version_migrate.hashes',return_value={'a':'new'}):
            with self.assertRaisesRegex(ValueError,'different source'):
                apply_script_recipe(Path('.'),b'',{'format':'gt-vxace-script-transfer-1','target_language':'en','source_hashes':{'a':'old'}},'en')
    def test_nontext_change_refused(self):
        # [string, integer]; only string can change.
        original=b'\x04\x08['+length(2)+b'"'+length(3)+b'abc'+b'i\x06'
        translated=b'\x04\x08['+length(2)+b'"'+length(3)+b'def'+b'i\x07'
        a=Reader(original);ar=a.parse();b=Reader(translated);b.parse()
        with self.assertRaisesRegex(ValueError,'non-text'):
            verified_strings(original,translated,[{'id':'u'}],{'u':[ar.value[0]]},a,b)

if __name__=='__main__':unittest.main()

class WorkImportTests(unittest.TestCase):
    def test_latest_checkpoint_over_stale_memory(self):
        from vxace.migrate_cli import import_work
        from core.completion import fingerprint
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);u=unit();(p/'ace_units.json').write_text(json.dumps([u]))
            (p/'ace_checkpoint.json').write_text(json.dumps({'input_fingerprint':fingerprint([u]),'target_language':'en','source_language':'Chinese','translations':{u['id']:'Latest translation'}}))
            (p/'translation_memory.json').write_text('{}')
            memory,bundle=import_work(p,'en');self.assertEqual(memory['entries'][0]['translation'],'Latest translation')
            with self.assertRaisesRegex(ValueError,'language'):import_work(p,'ja')
    def test_corrupt_checkpoint_fails_closed(self):
        from vxace.migrate_cli import import_work
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);(p/'ace_units.json').write_text(json.dumps([unit()]));(p/'ace_checkpoint.json').write_text(json.dumps({'target_language':'en','source_language':'Chinese','input_fingerprint':'wrong'}))
            with self.assertRaisesRegex(ValueError,'fingerprint'):import_work(p,'en')
    def test_reusable_literals_do_not_copy_numeric_changes(self):
        from vxace.version_migrate import reusable_script_rows
        self.assertEqual(reusable_script_rows([{'name':'x','base_code':'id = 1; label = "你好"','code':'id = 2; label = "Hello"'}]),[])
        rows=reusable_script_rows([{'name':'x','base_code':'id = 1; label = "你好"','code':'id = 1; label = "Hello"'}])
        self.assertEqual(rows[0]['literal_tokens'],{'"你好"':'"Hello"'})
