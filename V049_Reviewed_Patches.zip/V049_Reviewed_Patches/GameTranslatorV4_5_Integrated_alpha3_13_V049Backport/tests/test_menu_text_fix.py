import copy,json,unittest
from rpgmaker.menu_text_fix import translate_parameters,FIELDS
class MenuTextFixTests(unittest.TestCase):
 def test_preserves_code_and_options_and_idempotent(self):
  items=[]
  for (name,param),fields in FIELDS.items():
   obj={k:v[0] for k,v in fields.items()};obj['Code:func']='return "Select";';obj['Enabled:eval']='true'
   items.append({'name':name,'status':True,'parameters':{param:json.dumps(obj),'Other':'unchanged'}})
  before=copy.deepcopy(items);out,changes=translate_parameters(items)
  self.assertEqual(items,before);self.assertEqual(len(changes),8)
  for old,new in zip(before,out):
   for param,raw in old['parameters'].items():
    if param=='Other':self.assertEqual(raw,new['parameters'][param]);continue
    a,b=json.loads(raw),json.loads(new['parameters'][param])
    self.assertEqual(a['Code:func'],b['Code:func']);self.assertEqual(a['Enabled:eval'],b['Enabled:eval'])
  self.assertEqual(translate_parameters(out),(out,[]))
 def test_customized_text_rejected(self):
  item={'name':'VisuMZ_1_MainMenuCore','status':True,'parameters':{'Playtime:struct':json.dumps({'Time:str':'Custom'})}}
  with self.assertRaises(ValueError):translate_parameters([item])
 def test_disabled_plugin_untouched(self):
  item={'name':'VisuMZ_1_MainMenuCore','status':False,'parameters':{'Playtime:struct':json.dumps({'Time:str':'Time'})}}
  self.assertEqual(translate_parameters([item]),([item],[]))
