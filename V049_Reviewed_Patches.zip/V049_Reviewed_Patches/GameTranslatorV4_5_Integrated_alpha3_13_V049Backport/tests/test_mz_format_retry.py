import contextlib,io,json,tempfile,unittest
from pathlib import Path
import test_mz_gateway as fixtures
from providers.deepseek import ProviderError
from providers.base import Usage
from rpgmaker.pipeline import run

class FormatRetryTests(unittest.TestCase):
 def setup_run(self, factory, **kw):
  helper=fixtures.MZGatewayTests();td=tempfile.TemporaryDirectory();self.addCleanup(td.cleanup)
  b=Path(td.name);g=helper.fixture(b);w=b/'work';fake=factory()
  with contextlib.redirect_stdout(io.StringIO()):run(g,w,b/'out',helper.args(**kw),fake)
  return fake,json.loads((w/'mz_checkpoint.json').read_text())
 def good(self,items):
  return {u['id']:'你好\\N[1]。\n出发。' if '\n' in u['source'] else '保存。' for u in items},Usage(100,20)
 def error(self,reason='provider_invalid_json'):
  e=ProviderError('test format error',reason);e.usage=Usage(50,10);return e
 def test_split_then_accept(self):
  owner=self
  class Fake:
   calls=0
   def translate_batch(self,items,**kw):
    self.calls+=1
    if self.calls==1:raise owner.error()
    return owner.good(items)
  fake,state=self.setup_run(Fake,batch_size=2,max_api_calls=3,repair_rounds=0)
  self.assertEqual(fake.calls,3);self.assertEqual(state['stop_reason'],'clean')
  self.assertEqual(state['api_session']['tokens']['completion_tokens'],50)
  self.assertEqual(len([v for v in state['translations'].values() if v]),2)
 def test_cap_mid_split_keeps_first_child(self):
  owner=self
  class Fake:
   calls=0
   def translate_batch(self,items,**kw):
    self.calls+=1
    if self.calls==1:raise owner.error()
    return owner.good(items)
  fake,state=self.setup_run(Fake,batch_size=2,max_api_calls=2,repair_rounds=0)
  self.assertEqual(fake.calls,2);self.assertEqual(state['stop_reason'],'request_limit')
  self.assertEqual(len([v for v in state['translations'].values() if v]),1)
 def test_failed_singleton_skips_to_next_batch(self):
  owner=self
  class Fake:
   calls=0
   def translate_batch(self,items,**kw):
    self.calls+=1
    if self.calls<=2:raise owner.error()
    return owner.good(items)
  fake,state=self.setup_run(Fake,batch_size=1,max_api_calls=10,repair_rounds=0)
  self.assertEqual(fake.calls,3);self.assertEqual(state['stop_reason'],'round_limit')
  self.assertEqual(len(state['format_errors']),2)
  self.assertEqual(len([v for v in state['translations'].values() if v]),1)
 def test_timeout_not_retried(self):
  owner=self
  class Fake:
   calls=0
   def translate_batch(self,items,**kw):
    self.calls+=1;raise owner.error('provider_timeout')
  fake,state=self.setup_run(Fake,batch_size=2,max_api_calls=10,repair_rounds=0,sample=None)
  self.assertEqual(fake.calls,1);self.assertEqual(state['stop_reason'],'provider_timeout')
