import unittest,zlib
from unittest.mock import patch as mock
from vxace import coverage_fix as fix
from vxace.marshal48 import Reader,array,text
from vxace.adapter import decompress,AUDIT_TOKEN
from test_vxace import stream,arr,integer,string,binary,obj
class CoverageTests(unittest.TestCase):
 def fixture(self):
  profile=fix.read_json(fix.PROFILE);rows=[];expected={}
  for i in range(306):
   name='Main' if i==305 else 'Script%d'%i
   code=fix.DISPLAY_MARKER+'\nRGSSMain.call\n' if i==305 else '# unchanged\n'
   if str(i) in profile['script_ui']:
    code+='\n'.join('Label%d = %s'%(j,fix.ruby_literal(k)) for j,k in enumerate(profile['script_ui'][str(i)]))+'\n'
    expected[str(i)]={'name':name,'sha256':fix.sha(code.encode())}
   rows.append(arr([integer(i),string(name),binary(zlib.compress(code.encode()))]))
  return stream(arr(rows)),expected
 def test_boss_controls(self):
  for u in fix.read_json(fix.PROFILE)['boss']:
   self.assertEqual(AUDIT_TOKEN.findall(u['source']),AUDIT_TOKEN.findall(u['translation']))
   self.assertEqual(u['source'].count('\n'),u['translation'].count('\n'))
 def test_only_approved_scripts_change(self):
  raw,expected=self.fixture();read=fix.read_json
  with mock.object(fix,'read_json',side_effect=lambda p:expected if p.name=='wind_v049_scripts.json' else read(p)):
   result,_=fix.supplement_scripts(raw)
   with self.assertRaisesRegex(ValueError,'already applied'):fix.supplement_scripts(result)
  before=array(Reader(raw).parse());after=array(Reader(result).parse())
  for i,(a,b) in enumerate(zip(before,after)):
   if i not in (172,173,193,305):self.assertEqual(array(a)[2].value,array(b)[2].value)
  code=decompress(array(after[305])[2].value).decode()
  self.assertIn(fix.MARKER,code);self.assertIn(fix.DISPLAY_MARKER,code)
  self.assertNotIn('Font.default_',code);self.assertTrue(code.endswith('RGSSMain.call\n'))
 def test_unsupported_rejected(self):
  raw,expected=self.fixture();expected['193']['sha256']='wrong';read=fix.read_json
  with mock.object(fix,'read_json',side_effect=lambda p:expected if p.name=='wind_v049_scripts.json' else read(p)):
   with self.assertRaisesRegex(ValueError,'modified coverage script'):fix.supplement_scripts(raw)
 def test_choice_aliases_and_resume(self):
  def cmd(code,params):return obj('RPG::EventCommand',{'code':integer(code),'indent':integer(0),'parameters':arr(params)})
  rows=[cmd(102,[arr([string('摸摸'),string('离开')]),integer(0)]),cmd(402,[integer(0),string('摸摸')]),cmd(402,[integer(1),string('离开')]),cmd(404,[])]
  raw=stream(arr([b'0',obj('RPG::CommonEvent',{'list':arr(rows)})]))
  result,fixed,missing=fix.event_fixes('Data/CommonEvents.rvdata2',raw)
  self.assertEqual(len(fixed),2);self.assertEqual(missing,[])
  reader=Reader(result);reader.parse();values=[text(n) for n in reader.objects]
  self.assertEqual(values.count('Pet'),2);self.assertEqual(values.count('Leave'),2)
  again,changed,_=fix.event_fixes('Data/CommonEvents.rvdata2',result)
  self.assertEqual(again,result);self.assertEqual(changed,[])
