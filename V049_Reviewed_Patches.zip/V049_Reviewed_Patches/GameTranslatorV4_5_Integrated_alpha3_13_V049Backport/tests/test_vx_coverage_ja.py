import json,unittest,zlib
from unittest.mock import patch as mock
from vxace import coverage_fix as fix
from vxace.marshal48 import Reader,array,text
from vxace.adapter import decompress,AUDIT_TOKEN
from test_vxace import stream,arr,integer,string,binary,obj
import test_vx_coverage as english_tests
class JapaneseCoverageTests(unittest.TestCase):
 def test_profile_complete_and_controls(self):
  en=fix.read_json(fix.PROFILE);ja=fix.read_json(fix.language_profile('ja')[0])
  for key in en['script_ui']:self.assertEqual(set(en['script_ui'][key]),set(ja['script_ui'][key]))
  self.assertEqual(len(ja['move_names']),36);self.assertEqual(len(ja['boss']),7)
  for u in ja['boss']:
   self.assertEqual(AUDIT_TOKEN.findall(u['source']),AUDIT_TOKEN.findall(u['translation']))
   self.assertEqual(u['source'].count('\n'),u['translation'].count('\n'))
  for row in ja['move_names']:self.assertEqual(row['translation'],ja['script_ui']['193'][row['source']])
  for row in ja['move_descriptions']:self.assertEqual(row['translation'],[ja['script_ui']['193'][s] for s in row['source']])
 def japanese_fixture(self):
  raw,expected=english_tests.CoverageTests().fixture();reader=Reader(raw);rows=array(reader.parse())
  node=array(rows[305])[2];code=decompress(node.value).decode().replace(fix.DISPLAY_MARKER,fix.language_profile('ja')[1].MARKER)
  return fix.checked_patch(raw,{node.span:zlib.compress(code.encode())}),expected
 def test_japanese_scripts_preserve_layout_and_logic(self):
  raw,expected=self.japanese_fixture();read=fix.read_json
  with mock.object(fix,'read_json',side_effect=lambda p:expected if p.name=='wind_v049_scripts.json' else read(p)):
   result,_=fix.supplement_scripts(raw,'ja')
   with self.assertRaisesRegex(ValueError,'already applied'):fix.supplement_scripts(result,'ja')
  a=array(Reader(raw).parse());b=array(Reader(result).parse())
  for i in range(306):
   if i not in (172,173,193,305):self.assertEqual(array(a[i])[2].value,array(b[i])[2].value)
  original=decompress(array(a[305])[2].value).decode();current=decompress(array(b[305])[2].value).decode()
  self.assertTrue(current.endswith(original));self.assertIn('GT_JA_EXTRA_BOSS_LINES',current)
  self.assertIn('なでる',current);self.assertNotIn('Font.default_',current)
  self.assertIn('ステータス',decompress(array(b[172])[2].value).decode())
 def test_wrong_display_language_rejected(self):
  raw,_=english_tests.CoverageTests().fixture()
  with self.assertRaisesRegex(ValueError,'Matching language'):fix.supplement_scripts(raw,'ja')
 def test_choice_aliases_japanese(self):
  def cmd(code,params):return obj('RPG::EventCommand',{'code':integer(code),'indent':integer(0),'parameters':arr(params)})
  rows=[cmd(102,[arr([string('摸摸'),string('离开')]),integer(0)]),cmd(402,[integer(0),string('摸摸')]),cmd(402,[integer(1),string('离开')]),cmd(404,[])]
  raw=stream(arr([b'0',obj('RPG::CommonEvent',{'list':arr(rows)})]))
  result,changes,missing=fix.event_fixes('Data/CommonEvents.rvdata2',raw,'ja')
  reader=Reader(result);reader.parse();values=[text(n) for n in reader.objects]
  self.assertEqual(values.count('なでる'),2);self.assertEqual(values.count('立ち去る'),2)
  self.assertEqual(fix.event_fixes('Data/CommonEvents.rvdata2',result,'ja'),(result,[],[]))
