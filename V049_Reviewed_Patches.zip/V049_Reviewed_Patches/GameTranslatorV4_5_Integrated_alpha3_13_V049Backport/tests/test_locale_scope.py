import contextlib,copy,io,json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import test_mz_gateway as helper
from providers.base import Usage
from rpgmaker.mv import extract,patched_documents,get,audit
from rpgmaker.pipeline import run
from rpgmaker.locale_scope import command_scopes,read_document,write_document
from rpgmaker.recover import recover

def row(code,indent=0,*parameters):return {'code':code,'indent':indent,'parameters':list(parameters)}
def fixture(base,mz=True):
 g=helper.MZGatewayTests().fixture(base,mz);root=g if mz else g/'www'
 langs=[json.dumps({'Locale':x,'Language':x,'Primary':x=='ja'}) for x in ('ja','ko','en')]
 items=[{'name':'DKTools_Localization','status':True,'parameters':{'Languages':json.dumps(langs),'Languages Source':'json','Localization Extension':'.json','Localization Folder':'locales/','Check Subfolders':'false','Show Button':'true','Show Command':'false'}},
 {'name':'VisuMZ_0_CoreEngine','status':True,'parameters':{'ButtonAssist:struct':json.dumps({'OkText:str':'Select','CancelText:str':'Back','Code:func':'return "Select";'})}}]
 (root/'js/plugins.js').write_text('var $plugins = '+json.dumps(items)+';')
 for lang in ('ja','ko','en'):
  p=root/'locales'/lang;p.mkdir(parents=True)
  (p/'main.json').write_text(json.dumps({'hello':'こんにちは' if lang=='ja' else lang,'ref':'{hello}',lang:lang,'parse_depth1':'{hello}'}))
 rows=[row(401,0,'shared'),row(111,0,12,"DKTools.Localization.locale === 'ja'"),row(401,1,'japanese'),
 row(102,1,['YesJA','NoJA'],0),row(402,1,0,'YesJA'),row(404,1),
 row(411,0),row(111,1,12,"DKTools.Localization.locale === 'ko'"),row(401,2,'korean'),
 row(411,1),row(401,2,'english'),row(412,1),row(412,0),row(401,0,'after'),row(0)]
 (root/'data/CommonEvents.json').write_text(json.dumps([None,{'id':1,'list':rows}]))
 return g,root

class LocaleScopeTests(unittest.TestCase):
 def test_nested_and_unknown_gameplay_arms(self):
  rows=[row(111,0,12,"DKTools.Localization.locale !== 'ja'"),row(401,1,'x'),row(411,0),row(111,1,0,1,0),row(401,2,'a'),row(411,1),row(401,2,'b'),row(412,1),row(412,0),row(401,0,'all')]
  scopes,unknown,count=command_scopes(rows,['ja','ko','en'])
  self.assertEqual(scopes[1],{'ko','en'});self.assertEqual(scopes[4],{'ja'});self.assertEqual(scopes[6],{'ja'})
  self.assertEqual(scopes[-1],{'ja','ko','en'});self.assertEqual(unknown,[]);self.assertEqual(count,1)
 def test_extract_and_write_preserves_other_branches_and_keys(self):
  for mz in (True,False):
   with tempfile.TemporaryDirectory() as td:
    g,root=fixture(Path(td),mz);units,m=extract(g,locale='ja')
    sources={u['source'] for u in units};self.assertIn('japanese',sources);self.assertNotIn('korean',sources);self.assertNotIn('english',sources)
    self.assertIn('shared',sources);self.assertIn('after',sources);self.assertNotIn('{hello}',sources)
    before=json.loads((root/'data/CommonEvents.json').read_text())
    for u in units:u['translation']='译文\n出发。' if '\n' in u['source'] else '译文'
    # Preserve escape sequences in fixture data.
    for u in units:
     if '\\N[1]' in u['source']:u['translation']='译文\\N[1]。\n出发。'
    docs,unresolved=patched_documents(g,units,m,True)
    rel=(root/'data/CommonEvents.json').relative_to(g).as_posix();out=docs[rel]
    self.assertEqual(out[1]['list'][8],before[1]['list'][8]);self.assertEqual(out[1]['list'][10],before[1]['list'][10])
    self.assertEqual(out[1]['list'][4]['parameters'][1],'译文')
    for rel,obj in docs.items():
     self.assertNotIn('/en/',rel);self.assertNotIn('/ko/',rel)
     target=Path(td)/'stage'/rel;write_document(target,obj);self.assertEqual(read_document(Path(td)/'stage',rel),obj)
    pdoc=next(v for k,v in docs.items() if k.endswith('/plugins.js'))
    self.assertEqual(pdoc[1]['parameters']['ButtonAssist:struct']['Code:func'],'return "Select";')
 def test_missing_selection_stops_before_api(self):
  with tempfile.TemporaryDirectory() as td,contextlib.redirect_stdout(io.StringIO()),patch('rpgmaker.pipeline.make_provider') as make:
   b=Path(td);g,_=fixture(b)
   with self.assertRaisesRegex(ValueError,'Multiple DKTools'):run(g,b/'work',b/'out',helper.MZGatewayTests().args())
   make.assert_not_called()
 def test_unsupported_condition_report_blocks_api(self):
  with tempfile.TemporaryDirectory() as td,contextlib.redirect_stdout(io.StringIO()),patch('rpgmaker.pipeline.make_provider') as make:
   b=Path(td);g,root=fixture(b);p=root/'data/CommonEvents.json';s=p.read_text().replace("DKTools.Localization.locale === 'ja'","DKTools.Localization.locale.startsWith('ja')");p.write_text(s)
   u,m=extract(g,locale='ja');self.assertTrue(m['locale_report']['translation_blocked'])
   with self.assertRaisesRegex(ValueError,'Unsupported language condition'):run(g,b/'work',b/'out',helper.MZGatewayTests().args(locale='ja'))
   make.assert_not_called()
 def test_scoped_resume_and_offline_recovery(self):
  with tempfile.TemporaryDirectory() as td,contextlib.redirect_stdout(io.StringIO()):
   b=Path(td);g,root=fixture(b);seen=[]
   class Fake:
    def translate_batch(self,items,**kw):
     seen.extend(u['id'] for u in items)
     return {u['id']:'译文'+''.join(__import__('rpgmaker.mv',fromlist=['TOKEN']).TOKEN.findall(u['source']))+'\n译文'*u['source'].count('\n') for u in items},Usage(100,20)
   args=helper.MZGatewayTests().args(locale='ja',sample=None,batch_size=1,max_api_calls=1)
   run(g,b/'work',b/'out1',args,Fake());first=seen[0];args.max_api_calls=100
   run(g,b/'work',b/'out2',args,Fake());self.assertEqual(seen.count(first),1)
   self.assertEqual(json.loads((b/'work/mz_checkpoint.json').read_text())['stop_reason'],'clean')
   recover(g,b/'work',b/'recovered')
   self.assertEqual((b/'out2/js/plugins.js').read_bytes(),(b/'recovered/js/plugins.js').read_bytes())
   for lang in ('ko','en'):self.assertEqual((root/f'locales/{lang}/main.json').read_bytes(),(b/f'out2/locales/{lang}/main.json').read_bytes())
   with self.assertRaisesRegex(ValueError,'mismatch'):run(g,b/'work',b/'out3',helper.MZGatewayTests().args(locale='ko'),Fake())
 def test_hash_guard_and_reference_audit(self):
  with tempfile.TemporaryDirectory() as td:
   b=Path(td);g,root=fixture(b);units,m=extract(g,locale='ja')
   (root/'locales/ja/main.json').write_text('{"changed":"x"}')
   with self.assertRaisesRegex(ValueError,'changed'):patched_documents(g,units,m,True)
  self.assertIn('localization_tag_mismatch',audit({'source':'hello {name}','translation':'你好 {名字}','metadata':{'locale_scope':'ja'}})['blocking'])
 def test_analysis_has_no_api_and_no_game_output(self):
  with tempfile.TemporaryDirectory() as td,contextlib.redirect_stdout(io.StringIO()),patch('rpgmaker.pipeline.make_provider') as make:
   b=Path(td);g,_=fixture(b);run(g,b/'work',b/'out',helper.MZGatewayTests().args(locale='ja',analyze=True))
   make.assert_not_called();self.assertFalse((b/'out').exists());self.assertTrue((b/'work/mz_locale_report.json').exists())
 def test_cache_reuse_exact_source_only(self):
  from core.completion import fingerprint
  from rpgmaker.locale_scope import reuse_checkpoint
  with tempfile.TemporaryDirectory() as td:
   b=Path(td);g,_=fixture(b);original,_=extract(g);selected,_=extract(g,locale='ja');work=b/'old';work.mkdir()
   translations={u['id']:'缓存译文' for u in original if u['source'] in ('shared','japanese','korean','english')}
   (work/'mz_units.json').write_text(json.dumps(original));(work/'mz_checkpoint.json').write_text(json.dumps({'input_fingerprint':fingerprint(original),'translations':translations}))
   saved=(work/'mz_checkpoint.json').read_bytes();result=reuse_checkpoint(selected,work,'mz')
   self.assertEqual(result['reused'],2);self.assertEqual((work/'mz_checkpoint.json').read_bytes(),saved)
   self.assertNotIn('korean',[u['source'] for u in selected]);self.assertNotIn('english',[u['source'] for u in selected])
 def test_escaped_font_braces_are_not_locale_keys(self):
  from rpgmaker.locale_scope import REF,has_prose
  self.assertEqual(REF.findall(r'\{大字\} {name}'),['{name}'])
  self.assertTrue(has_prose(r'\{こんにちは\}'))
  self.assertEqual(audit({'source':r'\{こんにちは\} {name}','translation':r'\{你好\} {name}','metadata':{'locale_scope':'ja'}})['blocking'],[])
