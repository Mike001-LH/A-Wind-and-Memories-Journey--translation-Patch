import contextlib
import io
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
import zlib
from vxace.marshal48 import Reader,Node,length,patch,text,array
from vxace.adapter import collect_file,audit,build_files,extract,decode_literal,encode_literal,restore_newlines
from vxace.memory import migrate,export,read_memory,import_reviewed
from vxace.pipeline import run
from providers.base import Usage

# Independent fixture encoder for the subset used here, with no reference optimization.
def sym(s):
 b=s.encode();return b':'+length(len(b))+b
def string(s):
 b=s.encode();return b'I"'+length(len(b))+b+length(1)+sym('E')+b'T'
def binary(b):return b'"'+length(len(b))+b
def integer(n):
 if n==0:return b'i\0'
 if 0<n<123:return b'i'+bytes([n+5])
 if -124<n<0:return b'i'+bytes([(n-5)&255])
 if n>=0:return b'i'+length(n)
 return b'i\xfc'+(n&0xffffffff).to_bytes(4,'little')
def arr(items):return b'['+length(len(items))+b''.join(items)
def obj(name,attrs):return b'o'+sym(name)+length(len(attrs))+b''.join(sym('@'+k)+v for k,v in attrs.items())
def stream(v):return b'\x04\x08'+v

def fixture(game,hello='你好。',extra=False):
 data=game/'Data';data.mkdir(parents=True)
 system=obj('RPG::System',{'terms':obj('RPG::System::Terms',{'commands':arr([string('开始游戏'),string('继续游戏')])})})
 (data/'System.rvdata2').write_bytes(stream(system))
 def command(code,params):return obj('RPG::EventCommand',{'code':integer(code),'indent':integer(0),'parameters':arr(params)})
 rows=[command(101,[]),command(401,[string(hello)]),command(401,[string('欢迎回来。')]),
       command(102,[arr([string('是'),string('否')])]),command(402,[integer(0),string('是')]),command(0,[])]
 if extra:rows.insert(0,command(108,[string('新增备注')]))
 (data/'CommonEvents.rvdata2').write_bytes(stream(arr([b'0',obj('RPG::CommonEvent',{'list':arr(rows)})])))
 scripts=arr([arr([integer(1),string('Vocab'),binary(zlib.compress(b'module Vocab\n  Test = "Shop %s"\nend\n'))]),
              arr([integer(2),string('Main'),binary(zlib.compress(b'rgss_main { SceneManager.run }\n'))])])
 (data/'Scripts.rvdata2').write_bytes(stream(scripts))
 # Opaque Table and float objects must never change.
 (data/'Animations.rvdata2').write_bytes(stream(arr([b'u'+sym('Table')+length(4)+b'abcd',b'f'+length(3)+b'1.5'])))

class AceTests(unittest.TestCase):
 def test_known_marshal_streams(self):
  r=Reader(b'\x04\x08[\x07"\x0ahello@\x06');root=r.parse()
  self.assertIs(array(root)[0],array(root)[1]);self.assertEqual(array(root)[0].refs,1)
  self.assertEqual(text(array(root)[0]),'hello')
  cycle=Reader(b'\x04\x08[\x06@\0').parse();self.assertIs(array(cycle)[0],cycle)
  for n in (-123,-1,0,1,122,123,256,65536):self.assertEqual(Reader(stream(integer(n))).parse(),n)
  with self.assertRaises(ValueError):Reader(b'\x04\x08"\x04\xff\xff\xff\xff').parse()
  with self.assertRaises(ValueError):Reader(b'\x04\x08@\0').parse()
  with self.assertRaises(ValueError):Reader(b'\x04\x08!').parse()

 def test_original_line_endings(self):
  raw=stream(arr([b'0',obj('RPG::Item',{'description':string('第一行\r\n第二行\r第三行')})]))
  units,_,_,_=collect_file('Data/Items.rvdata2',raw)
  self.assertEqual(units[0]['source'],'第一行\n第二行\n第三行')
  self.assertEqual(restore_newlines('One\nTwo\nThree','第一行\r\n第二行\r第三行'),'One\r\nTwo\rThree')

 def test_surgical_unicode_edit(self):
  raw=stream(arr([string('中文'),b'u'+sym('Table')+length(4)+b'ABCD',integer(19)]))
  reader=Reader(raw);root=reader.parse();node=array(root)[0]
  patched=patch(raw,{node.span:'日本語'.encode()});parsed=Reader(patched).parse()
  self.assertEqual(text(array(parsed)[0]),'日本語');self.assertEqual(array(parsed)[1].value,b'ABCD')
  self.assertEqual(patch(raw,{}),raw)

 def test_controls_and_literals(self):
  u={'source':'\\C[2]你好 %s\n世界','translation':'\\C[2]Hello %s\nWorld'}
  self.assertFalse(audit(u,'en')['blocking'])
  self.assertTrue(audit(dict(u,translation='Hello World'),'en')['blocking'])
  self.assertFalse(audit({'source':'你好','translation':'こんにちは'},'ja')['blocking'])
  self.assertTrue(audit({'source':'你好','translation':'你好'},'en')['blocking'])
  self.assertIsNone(decode_literal('#{execute}', '"'))
  self.assertIn('\\#{',encode_literal('#{danger}', '"'))

 def test_alias_and_nontext_bytes(self):
  with tempfile.TemporaryDirectory() as d:
   game=Path(d)/'g';fixture(game);units,manifest,_=extract(game)
   for u in units:
    lines=u['source'].split('\n');u['translation']='\n'.join('Text %s' if '%s' in l else 'Text' for l in lines)
   made,left=build_files(game,units,manifest,'en',font='Arial')
   self.assertFalse(left);self.assertNotIn('Data/Animations.rvdata2',made)
   rows,_,_,reader=collect_file('Data/CommonEvents.rvdata2',made['Data/CommonEvents.rvdata2'])
   choice=next(u for u in rows if u['metadata']['kind']=='choice')
   self.assertEqual(choice['metadata']['choice_aliases'],1)
   self.assertEqual(choice['source'],'Text')
   scripts=Reader(made['Data/Scripts.rvdata2']).parse()
   main=zlib.decompress(array(array(scripts)[1])[2].value).decode()
   self.assertTrue(main.startswith('Font.default_name = ["Arial"]'))

 def test_default_build_preserves_original_font_scripts(self):
  with tempfile.TemporaryDirectory() as d:
   game=Path(d)/'g';fixture(game);units,manifest,_=extract(game)
   for u in units:
    if u['metadata']['kind']=='script_vocab':
     continue
    u['translation']='\n'.join('Text %s' if '%s' in line else 'Text' for line in u['source'].split('\n'))
   made,left=build_files(game,units,manifest,'ja',allow_partial=True)
   self.assertIn('Data/System.rvdata2',made)
   self.assertNotIn('Data/Scripts.rvdata2',made)
   original=(game/'Data/Scripts.rvdata2').read_bytes()
   for u in units:
    if u['metadata']['kind']=='script_vocab':u['translation']='Text %s'
   made,left=build_files(game,units,manifest,'ja',allow_partial=True)
   before=Reader(original);before.parse()
   after=Reader(made['Data/Scripts.rvdata2']);after.parse()
   main_before=array(array(before.objects[0])[1])[2].value
   main_after=array(array(after.objects[0])[1])[2].value
   self.assertEqual(main_before,main_after)

 def test_migration_conflicts_and_language(self):
  def unit(key,src,ctx):return {'id':key,'source':src,'translation':'','metadata':{'kind':'dialogue'},'context':ctx,'file':'a','location':key}
  old=[{'id':'a','source':'你好','translation':'Hello','kind':'dialogue','context':['前文'],'reviewed':True},
       {'id':'b','source':'再见朋友','translation':'Goodbye friend','kind':'dialogue','context':[]}]
  new=[unit('moved','你好',['不同前文']),unit('b','再见朋友！',[]),unit('new','新增',[])]
  report=migrate(new,old,'en');self.assertEqual(new[0]['translation'],'Hello');self.assertTrue(new[0]['reviewed'])
  self.assertFalse(new[1]['translation']);self.assertIn('previous_version_reference',new[1])
  self.assertEqual(report['counts']['new'],1)
  conflict=[dict(old[0],translation='Hi',id='another'),old[0]]
  u=unit('x','你好',['前文']);migrate([u],conflict,'en');self.assertFalse(u['translation'])
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'m.json';p.write_text(json.dumps(export(new,'en','Chinese')))
   with self.assertRaises(ValueError):read_memory(p,'ja','Chinese')
   p.write_text(json.dumps({'target_language':'en','entries':[{'id':'new','source':'WRONG','translation':'New'}]}))
   with self.assertRaises(ValueError):import_reviewed(new,p,'en')

 def test_pipeline_sample_resume_offline_and_revision(self):
  class Fake:
   calls=0;langs=[]
   def translate_batch(self,items,**kwargs):
    self.calls+=1;self.langs.append(kwargs['target_language'])
    return {u['id']:'\n'.join('Text %s' if '%s' in l else 'Text' for l in u['source'].split('\n')) for u in items},Usage()
  args=SimpleNamespace(target_language='en',source_language='Chinese',analyze=False,estimate=False,migrate_only=False,
      reuse_from=None,import_translations=None,glossary=None,sample=2,build_only=False,max_cost_rmb=5.,price_band='peak',
      batch_size=3,repair_rounds=1,stall_rounds=2,allow_partial=False,vx_font=None)
  with tempfile.TemporaryDirectory() as d,contextlib.redirect_stdout(io.StringIO()):
   root=Path(d);game=root/'g';fixture(game);work=root/'w';fake=Fake()
   run(game,work,root/'sample',args,fake);self.assertEqual(fake.calls,1)
   args.sample=None;run(game,work,root/'full',args,fake);calls=fake.calls
   args.build_only=True;run(game,work,root/'offline',args,fake);self.assertEqual(calls,fake.calls)
   self.assertEqual(fake.langs,['English']*calls)
   game2=root/'v2';fixture(game2,extra=True);args.migrate_only=True;args.reuse_from=str(work)
   run(game2,root/'w2',root/'unused',args,fake);self.assertEqual(calls,fake.calls)
   rep=json.loads((root/'w2'/'ace_migration_report.json').read_text());self.assertGreater(rep['counts']['reused'],0)
   args.target_language='ja'
   with self.assertRaises(ValueError):run(game2,root/'w3',root/'bad',args,fake)

if __name__=='__main__':unittest.main()
