import unittest,json,re
from pathlib import Path
from rpgmaker.dk_locale_fix import residual_audit,remaining_text,PROFILE
class DKLocaleTests(unittest.TestCase):
 def test_mixed_residue_and_tokens(self):
  self.assertTrue(remaining_text('中文加한국어'))
  self.assertTrue(remaining_text('だ、中文'))
  self.assertFalse(remaining_text('{日本語鍵}中文\\C[2]'))
  u={'source':'{yes}こんにちは','translation':'{是}你好'}
  self.assertIn('localization_tag_mismatch',residual_audit(u)['blocking'])
 def test_dictionary_ui(self):
  p=json.loads(PROFILE.read_text());merged={}
  for obj in p['files'].values():
   if isinstance(obj,dict):merged.update(obj)
  self.assertEqual(merged['new_game'],'开始游戏')
  self.assertEqual(merged['yes'],'是');self.assertEqual(merged['no'],'否')
  self.assertEqual(merged['Secilia'],'赛希莉亚')
  for key,value in merged.items():
   if not key.startswith('parse_depth'):self.assertFalse(remaining_text(value),(key,value))
 def test_format_placeholders(self):
  p=json.loads(PROFILE.read_text());d=p['files']['locales/ja/ja_main.json']
  self.assertEqual(set(re.findall(r'%[123]',d['%1 recovered %2 %3!'])),{'%1','%2','%3'})
  self.assertIn('%1',d['Current']);self.assertIn('%1',d['To Next'])
