# VX Ace alpha2 变更

- 日文默认不再建议/强制 Meiryo；保留游戏原字体和字号。`--vx-font` 只保留为显式兼容选项。
- 新增 `--vx-sample-profile mixed|menu|story`。
- `story` 样本优先真实事件对话、选项、滚动文本和角色改名文本，便于下一阶段实机验证剧情窗口。
- build_report.json 记录 sample_profile，便于区分测试补丁来源。
- 继续保持 Marshal 外科式写回、控制符/换行 QA、checkpoint 与跨版本 translation memory。
