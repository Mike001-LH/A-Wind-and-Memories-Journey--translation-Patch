# alpha3.9 — VX Ace Japanese coverage supplement

Add the Japanese counterpart of the V0.49 English boss/choice/battle/travel supplement.
The shared coverage command reads the patch language and accepts an optional language assertion.
Preserve prior Japanese layout, font family and size. Refuse mismatched game/script hashes and existing outputs.
Existing differing boss translations are retained and reported for review.
Includes seven boss blocks, 36 travel destinations and their descriptions, battle commands and two NPC choices.
138 offline tests pass. Windows/Ruby runtime verification remains required. No real API calls.
