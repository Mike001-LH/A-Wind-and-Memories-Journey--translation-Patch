#!/usr/bin/env python3
import argparse, json, os, shlex, subprocess, sys
from pathlib import Path

VERSION = "4.0.0-alpha8.2"
ROOT = Path(__file__).resolve().parent

def qcmd(cmd):
    return " ".join(shlex.quote(str(x)) for x in cmd)

def run(cmd, plan=False):
    print("\n$", qcmd(cmd), flush=True)
    if plan:
        return
    subprocess.run([str(x) for x in cmd], check=True)

def main():
    p = argparse.ArgumentParser(description="Game Translator V4 alpha8 - one-command Ren'Py localization pipeline")
    p.add_argument("game", help="Original Ren'Py game root (never modified)")
    p.add_argument("--output", required=True, help="Final patch folder")
    p.add_argument("--workdir", help="Pipeline state/work folder; defaults beside output")
    p.add_argument("--font", help="User-supplied CJK .ttf/.otf; required for final font patch")
    p.add_argument("--unrpyc", help="Path to unrpyc.py; needed when source exists only as RPYC/RPA")
    p.add_argument("--glossary", help="User glossary JSON")
    p.add_argument("--source-language", default="English")
    p.add_argument("--batch-size", type=int, default=10)
    p.add_argument("--attempts", type=int, default=3)
    p.add_argument("--try-harder", action="store_true")
    p.add_argument("--translated", help="Reuse an existing translated-units JSON; skips Character Pass + translation API")
    p.add_argument("--character-glossary", help="Reuse an existing character glossary with --translated")
    p.add_argument("--skip-font", action="store_true", help="Generate script patch only")
    p.add_argument("--plan", action="store_true", help="Print the pipeline without executing it or calling APIs")
    p.add_argument("--extract-only", action="store_true", help="Run detection/decompile/extraction + semantic audit only; never calls translation APIs")
    p.add_argument("--strict-preflight", action="store_true", help="Stop when semantic audit finds blocked/review items")
    a = p.parse_args()

    game = Path(a.game).expanduser().resolve()
    out = Path(a.output).expanduser().resolve()
    work = Path(a.workdir).expanduser().resolve() if a.workdir else out.parent / (out.name + "_work")
    workspace = work / "workspace"
    units = work / "units.json"
    extract_qa = work / "extract_qa.json"
    char_state = work / "character.state.json"
    char_glossary = Path(a.character_glossary).expanduser().resolve() if a.character_glossary else work / "character_glossary.json"
    trans_state = work / "translation.state.json"
    translated = Path(a.translated).expanduser().resolve() if a.translated else work / "translated.json"
    trans_qa = work / "translation_qa.json"
    writer_report = work / "writer_report.json"
    font_report = work / "font_patch_report.json"
    preflight_report = work / "preflight_audit.json"

    if a.extract_only and a.translated:
        raise SystemExit("--extract-only cannot be combined with --translated")
    if not a.plan and not game.is_dir():
        raise SystemExit(f"Game directory not found: {game}")
    if not a.plan:
        work.mkdir(parents=True, exist_ok=True)

    py = sys.executable
    print(f"Game Translator V{VERSION}")
    print(f"Original game : {game}")
    print(f"Work/state    : {work}")
    print(f"Final patch   : {out}")
    print("Original game is read-only; generated files go to work/output folders.")

    if not a.translated:
        cmd = [py, ROOT/"main.py", game, "--analyze", "--decompile", "--workspace", workspace,
               "--dump-units", units, "--dump-qa", extract_qa]
        if a.unrpyc:
            cmd += ["--unrpyc", Path(a.unrpyc).expanduser().resolve()]
        if a.try_harder:
            cmd += ["--try-harder"]
        run(cmd, a.plan)

        audit_cmd=[py, ROOT/"preflight_audit.py", units, "--report", preflight_report, "--workspace", workspace]
        if a.strict_preflight: audit_cmd += ["--strict"]
        run(audit_cmd, a.plan)
        if a.extract_only:
            if not a.plan:
                print("\n============================================================")
                print("EXTRACT-ONLY PASSED - no translation API was called")
                print("Units:", units)
                print("Semantic audit:", preflight_report)
            return

        cmd = [py, ROOT/"character_pass.py", units, "--checkpoint", char_state,
               "--output", char_glossary, "--batch-size", a.batch_size,
               "--source-language", a.source_language, "--attempts", a.attempts]
        if a.glossary:
            cmd += ["--glossary", Path(a.glossary).expanduser().resolve()]
        run(cmd, a.plan)

        cmd = [py, ROOT/"translate_units.py", units, "--checkpoint", trans_state,
               "--output", translated, "--qa", trans_qa, "--character-glossary", char_glossary,
               "--batch-size", a.batch_size, "--source-language", a.source_language,
               "--attempts", a.attempts]
        if a.glossary:
            cmd += ["--glossary", Path(a.glossary).expanduser().resolve()]
        run(cmd, a.plan)
    else:
        # Writer still needs a decompiled/source workspace. Build it if the caller didn't preserve one.
        if not workspace.exists():
            cmd = [py, ROOT/"main.py", game, "--analyze", "--decompile", "--workspace", workspace,
                   "--dump-units", units, "--dump-qa", extract_qa]
            if a.unrpyc:
                cmd += ["--unrpyc", Path(a.unrpyc).expanduser().resolve()]
            if a.try_harder:
                cmd += ["--try-harder"]
            run(cmd, a.plan)
        print(f"\nReusing translated units: {translated}")

    run([py, ROOT/"renpy_writer.py", translated, "--workspace", workspace,
         "--output", out, "--report", writer_report], a.plan)

    if not a.skip_font:
        if not a.font:
            raise SystemExit("\nScript patch is configured, but --font is required for the CJK font patch. Use --skip-font to omit it.")
        run([py, ROOT/"font_patch.py", "--patch", out, "--workspace", workspace,
             "--font", Path(a.font).expanduser().resolve(), "--report", font_report], a.plan)

    if not a.plan:
        manifest = {
            "version": VERSION, "game": str(game), "workdir": str(work), "patch": str(out),
            "translated": str(translated), "font": str(Path(a.font).expanduser().resolve()) if a.font else None,
            "reports": {"extract": str(extract_qa), "preflight": str(preflight_report), "translation": str(trans_qa),
                        "writer": str(writer_report), "font": str(font_report) if not a.skip_font else None}
        }
        (work/"pipeline_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
        print("\n============================================================")
        print("PIPELINE PASSED")
        print("Final patch:", out)
        print("State/manifest:", work/"pipeline_manifest.json")
        print("Copy the CONTENTS of final patch/game into the target game's game/ folder for testing.")

if __name__ == "__main__":
    main()
