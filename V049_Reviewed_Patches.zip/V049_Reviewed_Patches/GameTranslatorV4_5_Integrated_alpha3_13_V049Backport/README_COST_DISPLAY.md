# VX Ace 费用显示版 alpha3_3_2

以未接入线衣 API 的 alpha3_3_1 为基础，保留原翻译、复用、修补、日语字体及英文显示修复功能。新增 VX Ace 每批费用显示。

每次 API 返回后显示：本批估算、本次运行累计、该工作目录历史已记录累计、本次预算剩余。开始时显示本轮预算与旧版费率档位，结束时显示累计与停止原因。换行恢复、重复复用和检查点缓存本身不增加 API 费用。

费用沿用已有 cost_cny/--price-band 估算，不读取账户真实扣款，不宣称采用最新单价。实际扣费以官方 API 账户为准。预算按返回用量统计，一次请求可能超过剩余估算预算。

如果翻译响应格式错误但含用量，仍记录其估算费用。网络错误或中断未取得用量时标记未知，不当作免费。既有 api_usage_without_price 会保留，线衣未知费用不加到历史已记录金额中。旧版没有记录的历史格式错误费用无法追溯补算。

每次续跑本次累计归零，历史已记录累计保留。ace_checkpoint.json、ace_completion_report.json、build_report.json 增加 cost_summary，方便事后查看。数据格式兼容旧工作目录；不需要重翻已有有效译文。

下载后：

```bash
unzip -oq "$HOME/Downloads/GameTranslatorV4_4_VXAce_alpha3_3_2_CostDisplay.zip" -d "$HOME/Documents/local-llm-translator"
cd "$HOME/Documents/local-llm-translator/GameTranslatorV4_4_VXAce_alpha3_3_2_CostDisplay"
```

此版本只用官方 DeepSeek。若密钥仅在旧版 .env，将旧版本机 .env 复制到本版（不要共享密钥文件）；共享配置目录或 shell 已配置密钥时可直接运行。

```bash
python3 unified.py "/Users/mike/Downloads/A风与追忆之旅 - demoV0.49/备用原版" --source-language Chinese --target-language ja --batch-size 10 --repair-rounds 3 --max-cost-rmb 5 --allow-partial --output "/Users/mike/Downloads/V049_Japanese_DeepSeek_Cost_Full_4"
```

默认继续原游戏的 `_GT_Work_ja`。输出目录必须尚不存在。不要同时让两个进程写同一工作目录，当前翻译仍运行时等它结束或中断保存后再续跑。

52 项离线测试通过：旧引擎回归、费用累计/恢复、未知费用标记以及无效响应保留返回用量。未调用用户 API。
