from dataclasses import dataclass, field
from typing import Any, Optional

@dataclass
class TranslationUnit:
    id: str
    source: str
    engine: str
    file: str
    location: str
    translation: Optional[str] = None
    speaker: Optional[str] = None
    context: list[str] = field(default_factory=list)
    protected_tokens: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

@dataclass
class Detection:
    engine: str
    score: int
    confidence: str
    evidence: list[str] = field(default_factory=list)
    platforms: list[str] = field(default_factory=list)

@dataclass
class AnalysisResult:
    detection: Detection
    units: list[TranslationUnit]
    scripts_scanned: int
    skipped_files: list[str] = field(default_factory=list)
    compiled_scripts: int = 0
    archives: int = 0
    archive_members: int = 0
    archived_compiled_scripts: int = 0
