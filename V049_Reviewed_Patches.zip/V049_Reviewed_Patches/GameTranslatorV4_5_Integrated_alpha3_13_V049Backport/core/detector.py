from engines.renpy import RenPyAdapter
class EngineDetector:
    def __init__(self): self.adapters=[RenPyAdapter()]
    def best_adapter(self,root):
        ranked=sorted(((a.detect(root),a) for a in self.adapters),key=lambda x:x[0].score,reverse=True)
        d,a=ranked[0]
        return d,(a if d.score>=45 else None)
