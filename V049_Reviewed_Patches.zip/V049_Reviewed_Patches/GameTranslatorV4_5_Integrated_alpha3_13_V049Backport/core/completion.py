"""Bounded audit/retry controller. Transport and text rules are engine-owned."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path


def atomic_json(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + '.tmp')
    temp.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding='utf-8')
    temp.replace(path)


def fingerprint(units):
    rows = [{k: v for k, v in u.items() if k != 'translation'} for u in units]
    return hashlib.sha256(json.dumps(rows, ensure_ascii=False, sort_keys=True).encode()).hexdigest()


def complete(units, audit, request, save, *, rounds=3, batch_size=15, stall_rounds=2,
             target_coverage=1.0, repair_only=False, state=None, max_batch_chars=None):
    """Primary pass then up to rounds residual passes. Save after every request.

    request returns (id->candidate, usage dict). Audit returns blocking and advisory
    evidence separately. Never discard an existing candidate until replacement passes.
    """
    if rounds < 0 or batch_size < 1 or stall_rounds < 1 or not 0 < target_coverage <= 1:
        raise ValueError('Invalid completion limits')
    state = state if state is not None else {}
    history = state.setdefault('completion_history', [])
    state.setdefault('errors', [])
    ids = [u['id'] for u in units]
    if len(ids) != len(set(ids)):
        raise ValueError('Duplicate unit IDs')
    state['stop_reason'] = 'running'
    initial = [u for u in units if not u.get('translation', '').strip()]
    stalled = 0
    stop = 'round_limit'
    for phase in range(0 if not repair_only else 1, rounds + 1):
        targets = initial if phase == 0 else [u for u in units if audit(u)['blocking']]
        blocking = sum(bool(audit(u)['blocking']) for u in units)
        if not targets:
            if blocking == 0:
                stop = 'clean'; break
            continue
        if phase and not any(not u.get('translation', '').strip() for u in units):
            if 1 - blocking / max(1, len(units)) >= target_coverage:
                stop = 'coverage_target'; break
        accepted = 0
        batches=[];batch=[];characters=0
        for unit in targets:
            size=len(unit['source'])
            if batch and (len(batch)>=batch_size or (max_batch_chars and characters+size>max_batch_chars)):
                batches.append(batch);batch=[];characters=0
            batch.append(unit);characters+=size
        if batch:batches.append(batch)
        for batch_index,batch in enumerate(batches,1):
            try:
                made, usage = request(batch, phase)
                for u in batch:
                    value = made.get(u['id'])
                    if not isinstance(value, str) or not value.strip():
                        continue
                    trial = dict(u, translation=value)
                    # Only fully passing candidates replace existing work.
                    if not audit(trial)['blocking']:
                        u['translation'] = value
                        accepted += 1
                        state.setdefault('rejected_candidates', {}).pop(u['id'], None)
                    else:
                        state.setdefault('rejected_candidates', {})[u['id']] = value
                state['last_usage'] = usage
            except (KeyboardInterrupt, SystemExit):
                save(units, state); raise
            except Exception as exc:
                state['errors'].append({'phase': phase, 'ids': [u['id'] for u in batch],
                                        'error': str(exc)[:800]})
                if getattr(exc, 'stop_run', False):
                    state['stop_reason'] = getattr(exc, 'reason', 'request_stopped')
                    save(units, state)
                    return state
            save(units, state)
            print(f'Pass {phase} batch {batch_index}: accepted so far {accepted}/{len(targets)}', flush=True)
        remaining = sum(bool(audit(u)['blocking']) for u in units)
        history.append({'phase': phase, 'requested': len(targets), 'accepted': accepted,
                        'remaining': remaining})
        print(f'Pass {phase}: residual {blocking} -> {remaining}', flush=True)
        if remaining == 0:
            stop = 'clean'; break
        if phase:
            stalled = stalled + 1 if remaining >= blocking else 0
            if stalled >= stall_rounds:
                stop = 'no_progress'; break
    state['stop_reason'] = stop
    save(units, state)
    return state
