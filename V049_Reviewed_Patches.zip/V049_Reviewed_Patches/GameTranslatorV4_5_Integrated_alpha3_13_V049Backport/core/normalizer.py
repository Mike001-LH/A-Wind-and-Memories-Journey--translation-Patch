from __future__ import annotations
import re
from dataclasses import dataclass, field
from collections import Counter, defaultdict
from core.models import TranslationUnit

TOKEN_PATTERNS = [
    re.compile(r'\[[^\]\n]+\]'), re.compile(r'\{[^{}\n]+\}'),
    re.compile(r'%\([A-Za-z_]\w*\)[#0 +\-]?\d*(?:\.\d+)?[diouxXeEfFgGcrs%]'),
    re.compile(r'%(?:[#0 +\-]?\d*(?:\.\d+)?[diouxXeEfFgGcrs%])'),
]
RESOURCE = re.compile(r'(?i)^[\w./@:+\- ]+\.(png|jpe?g|webp|gif|ogg|mp3|wav|flac|mp4|webm|rpyc?|rpymc?|ttf|otf)$')
IDENT = re.compile(r'^[A-Za-z_][A-Za-z0-9_.:-]*$')
URL = re.compile(r'(?i)^(?:https?://|www\.)\S+$')
HEX = re.compile(r'^#?[0-9a-fA-F]{6,8}$')

@dataclass
class NormalizationReport:
    extracted: int = 0; technical_skipped: int = 0; duplicate_occurrences: int = 0
    unique_translatable: int = 0; safe: int = 0; caution: int = 0; protected_token_units: int = 0
    context_split_groups: int = 0
    by_kind: dict = field(default_factory=dict); technical_examples: list = field(default_factory=list)

def protected_tokens(text: str):
    found=[]
    for pat in TOKEN_PATTERNS:
        for m in pat.finditer(text):
            if m.group(0) not in found: found.append(m.group(0))
    return found

def is_technical(u: TranslationUnit):
    s=u.source.strip()
    if not s: return True, "blank"
    if RESOURCE.fullmatch(s): return True, "resource"
    if URL.fullmatch(s): return True, "url"
    if HEX.fullmatch(s): return True, "hex"
    if IDENT.fullmatch(s) and u.metadata.get("kind") not in {"dialogue","menu","character_name","screen_text","ui_string"}: return True,"identifier"
    if not re.search(r'[A-Za-z\u3040-\u30ff\u3400-\u9fff]',s): return True,"no_language_text"
    return False,None

def risk_for(u,tokens):
    return "safe" if u.metadata.get("kind") in {"dialogue","menu","character_name"} else "caution"

def semantic_kind(u: TranslationUnit):
    """Dedup only where the same source is likely to need the same rendering.
    Character names, choices, prose, and UI are deliberately separate.
    """
    kind=u.metadata.get("kind","unknown")
    if kind in {"ui_string","screen_text"}: return "ui"
    return kind

def normalize_units(units: list[TranslationUnit]):
    report=NormalizationReport(extracted=len(units)); cleaned=[]; seen_occurrence=set()
    for u in units:
        loc_key=(u.file,u.metadata.get("line"),u.source,u.metadata.get("kind"))
        if loc_key in seen_occurrence:
            report.duplicate_occurrences += 1; continue
        seen_occurrence.add(loc_key)
        tech,reason=is_technical(u)
        if tech:
            report.technical_skipped += 1
            if len(report.technical_examples)<20: report.technical_examples.append({"file":u.file,"line":u.metadata.get("line"),"source":u.source,"reason":reason})
            continue
        toks=protected_tokens(u.source); u.protected_tokens=toks
        u.metadata["risk"]=risk_for(u,toks); u.metadata["technical"]=False
        cleaned.append(u)

    # alpha6.4: source + semantic kind, rather than source-only project-wide dedup.
    groups=defaultdict(list); source_kinds=defaultdict(set)
    for u in cleaned:
        sk=semantic_kind(u); groups[(u.source,sk)].append(u); source_kinds[u.source].add(sk)
    report.context_split_groups=sum(len(v)>1 for v in source_kinds.values())

    unique=[]
    for (source,sk),occs in groups.items():
        rep=occs[0]; rep.metadata["dedup_kind"]=sk; rep.metadata["occurrence_count"]=len(occs)
        rep.metadata["occurrences"]=[{"id":x.id,"file":x.file,"line":x.metadata.get("line"),"kind":x.metadata.get("kind")} for x in occs]
        unique.append(rep)
    report.unique_translatable=len(unique); report.duplicate_occurrences += len(cleaned)-len(unique)
    report.safe=sum(u.metadata.get("risk")=="safe" for u in unique); report.caution=sum(u.metadata.get("risk")=="caution" for u in unique)
    report.protected_token_units=sum(bool(u.protected_tokens) for u in unique); report.by_kind=dict(Counter(u.metadata.get("kind","unknown") for u in unique))
    return unique,report
