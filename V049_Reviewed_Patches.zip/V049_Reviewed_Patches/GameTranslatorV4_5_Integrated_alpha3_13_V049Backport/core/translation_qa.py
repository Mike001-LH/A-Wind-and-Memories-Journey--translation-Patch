import re
CJK=re.compile(r'[\u3400-\u9fff]')

def _term_present(source,term):
    if term.isascii() and term and term[0].isalnum() and term[-1].isalnum():
        return re.search(r'(?<![A-Za-z0-9_])'+re.escape(term)+r'(?![A-Za-z0-9_])',source,re.I) is not None
    return term.lower() in source.lower()

def validate(source,translation,tokens,glossary=None,kind=None):
    issues=[]
    if not translation or not translation.strip(): issues.append("blank")
    for t in tokens:
        if translation.count(t)!=source.count(t): issues.append("protected_token_mismatch:"+t)
    if source.strip()==(translation or "").strip(): issues.append("unchanged")
    if translation and not CJK.search(translation): issues.append("no_cjk")
    if translation:
        hard=[]
        for term,entry in (glossary or {}).items():
            if entry.get("mode")=="hard" and _term_present(source,term): hard.append((term,entry.get("target","")))
        hard.sort(key=lambda x:len(x[0]),reverse=True); covered=[]
        for term,target in hard:
            low=term.lower()
            if any(low in longer.lower() for longer in covered): continue
            covered.append(term)
            if target and target not in translation: issues.append(f"hard_glossary_mismatch:{term}=>{target}")
        # Soft terms are advisory: flag inconsistency for human review, never block output.
        for term,entry in (glossary or {}).items():
            target=entry.get("target","")
            if entry.get("mode")!="hard" and target and _term_present(source,term) and target not in translation:
                issues.append(f"soft_glossary_review:{term}=>{target}")
    # A few high-value generic quality signals; advisory only.
    if translation and kind in {"dialogue","menu","ui_string","screen_text"}:
        if re.search(r'\bKoto\b',source,re.I) and not re.search(r'[筝箏]',translation): issues.append("term_review:Koto=>筝")
        if source.count('!')>=2 and '！' not in translation and '!' not in translation: issues.append("punctuation_tone_review:exclamation")
    return issues
