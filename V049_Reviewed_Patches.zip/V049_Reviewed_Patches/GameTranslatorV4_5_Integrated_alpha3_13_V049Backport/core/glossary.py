import json
from pathlib import Path

def load_glossary(path):
    """Load legacy {source: target} or structured glossary entries.

    Structured form:
      {"Manyuu": {"target": "魔乳", "mode": "hard"}}
    Legacy string entries remain soft for backwards compatibility.
    """
    if not path:
        return {}
    p=Path(path).expanduser()
    data=json.loads(p.read_text(encoding="utf-8"))
    if not isinstance(data,dict):
        raise ValueError("Glossary must be a JSON object")
    out={}
    for source,value in data.items():
        source=str(source)
        if isinstance(value,str):
            out[source]={"target":value,"mode":"soft"}
        elif isinstance(value,dict) and "target" in value:
            mode=str(value.get("mode","soft")).lower()
            if mode not in {"soft","hard"}:
                raise ValueError(f"Invalid glossary mode for {source}: {mode}")
            out[source]={"target":str(value["target"]),"mode":mode}
        else:
            raise ValueError(f"Invalid glossary entry for {source}")
    return out

def relevant_glossary(glossary,text):
    low=text.lower()
    # Longest terms first so Manyuu Hikenchou is presented before Manyuu.
    items=[]
    for source,entry in glossary.items():
        if source.lower() in low:
            items.append((source,entry))
    return dict(sorted(items,key=lambda kv:len(kv[0]),reverse=True))
