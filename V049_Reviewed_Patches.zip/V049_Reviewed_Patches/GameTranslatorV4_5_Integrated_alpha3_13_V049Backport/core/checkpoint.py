import json
from pathlib import Path
def load(path):
    p=Path(path)
    if not p.exists():
        return {"translations":{},"usage":{"prompt_tokens":0,"completion_tokens":0,"cache_hit_tokens":0,"cache_miss_tokens":0}}
    return json.loads(p.read_text(encoding="utf-8"))
def save(path,state):
    p=Path(path); p.parent.mkdir(parents=True,exist_ok=True)
    tmp=p.with_suffix(p.suffix+".tmp")
    tmp.write_text(json.dumps(state,ensure_ascii=False,indent=2),encoding="utf-8")
    tmp.replace(p)
