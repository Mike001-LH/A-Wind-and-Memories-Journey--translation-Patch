from __future__ import annotations
import json,re
from pathlib import Path

SOURCE_PREFIXES = re.compile(r'^(?:Mr\.?|Mrs\.?|Ms\.?|Miss|Lady|Lord|Sir|Dame)\s+', re.I)
TARGET_SUFFIXES = ("先生", "女士", "小姐", "夫人", "大人", "阁下")

def _strip_source_title(text: str) -> str:
    return SOURCE_PREFIXES.sub('', (text or '').strip()).strip()

def _strip_target_title(text: str) -> str:
    out=(text or '').strip()
    for suffix in TARGET_SUFFIXES:
        if out.endswith(suffix) and len(out) > len(suffix):
            return out[:-len(suffix)].strip()
    return out

def build_character_glossary(units_by_id, translations):
    """Build a stable hard glossary from an explicit Character Pass."""
    learned={}
    for uid, rec in translations.items():
        unit=units_by_id.get(uid)
        if not unit or unit.metadata.get("kind") != "character_name":
            continue
        tr=(rec.get("translation") or "").strip()
        src=(unit.source or "").strip()
        if not src or not tr or rec.get("issues"):
            continue
        learned[src]={"target":tr,"mode":"hard","origin":"character_pass"}
        alias=_strip_source_title(src)
        alias_target=_strip_target_title(tr)
        if alias and alias.lower()!=src.lower() and alias_target:
            learned[alias]={"target":alias_target,"mode":"hard","origin":"character_pass"}
    return learned

def save_character_glossary(path, glossary):
    Path(path).expanduser().write_text(json.dumps(glossary,ensure_ascii=False,indent=2),encoding="utf-8")

def load_character_glossary(path):
    if not path: return {}
    p=Path(path).expanduser()
    data=json.loads(p.read_text(encoding="utf-8"))
    if not isinstance(data,dict): raise ValueError("Character glossary must be a JSON object")
    out={}
    for src,val in data.items():
        if isinstance(val,str): out[str(src)]={"target":val,"mode":"hard","origin":"character_pass"}
        elif isinstance(val,dict) and "target" in val:
            out[str(src)]={"target":str(val["target"]),"mode":"hard","origin":val.get("origin","character_pass")}
        else: raise ValueError(f"Invalid character glossary entry for {src}")
    return out

def merge_glossaries(user_glossary, character_glossary):
    """Character pass is hard; explicit user glossary wins on conflicts."""
    out=dict(character_glossary or {})
    out.update(user_glossary or {})
    return out
