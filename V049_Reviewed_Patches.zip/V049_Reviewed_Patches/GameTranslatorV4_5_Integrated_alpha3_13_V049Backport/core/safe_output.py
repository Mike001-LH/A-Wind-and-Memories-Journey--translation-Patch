"""Never remove an existing game/output. Publish only a completely prepared copy."""
import shutil
import tempfile
from pathlib import Path


def validate_paths(game, work, output):
    game, work, output = (Path(p).resolve() for p in (game, work, output))
    for a, b in ((game,work),(game,output),(work,output)):
        if a == b or a in b.parents or b in a.parents:
            raise ValueError('Game, workspace and output must be separate non-nested directories')
    if output.exists(): raise ValueError('Output already exists; choose a new --output (nothing was deleted)')


def publish_copy(game, output, patch):
    game, output = Path(game).resolve(), Path(output).resolve()
    if output.exists() or game == output or game in output.parents or output in game.parents:
        raise ValueError('Output must be a new non-nested directory')
    output.parent.mkdir(parents=True, exist_ok=True)
    # Refuse symlinks rather than copy files outside the selected game.
    if any(p.is_symlink() for p in game.rglob('*')):
        raise ValueError('Game contains symlinks; use a regular extracted copy')
    stage = Path(tempfile.mkdtemp(prefix='.gt-build-', dir=output.parent))
    try:
        shutil.copytree(game, stage, dirs_exist_ok=True)
        result = patch(stage)
        if output.exists(): raise ValueError('Output appeared during build')
        stage.rename(output)
        return result
    finally:
        if stage.exists(): shutil.rmtree(stage)
