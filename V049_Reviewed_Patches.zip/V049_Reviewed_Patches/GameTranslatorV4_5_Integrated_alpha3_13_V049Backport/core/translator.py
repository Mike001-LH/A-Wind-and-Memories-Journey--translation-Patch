from __future__ import annotations
import time
from dataclasses import asdict
from providers.base import Usage
from core.translation_qa import validate
from core.checkpoint import load,save

def batches(seq,n):
    for i in range(0,len(seq),n): yield seq[i:i+n]

def _add_usage(total,usage):
    for k in total: total[k]+=getattr(usage,k,0)

def _merge_usage(a,b):
    return Usage(a.prompt_tokens+b.prompt_tokens,a.completion_tokens+b.completion_tokens,a.cache_hit_tokens+b.cache_hit_tokens,a.cache_miss_tokens+b.cache_miss_tokens)

def _exact_hard(source,glossary):
    """Longest exact hard term. Used locally so Character Pass names cost zero in Stage B."""
    matches=[]
    for term,entry in (glossary or {}).items():
        if entry.get("mode")=="hard" and term.casefold()==source.strip().casefold(): matches.append((len(term),entry.get("target","")))
    return max(matches,default=(0,""))[1]

def _translate_resilient(provider,batch,glossary,source_language,attempts=3,depth=0):
    total=Usage(0,0,0,0); last_error=None; raw=[asdict(u) for u in batch]
    for attempt in range(1,attempts+1):
        try:
            result,usage=provider.translate_batch(raw,glossary=glossary,source_language=source_language); total=_merge_usage(total,usage)
            missing=[u.id for u in batch if u.id not in result or not isinstance(result[u.id],str)]
            if not missing: return result,total,{}
            last_error=RuntimeError(f"missing/invalid IDs: {missing[:5]}")
        except Exception as e: last_error=e
        if attempt<attempts: time.sleep(min(2**(attempt-1),4))
    if len(batch)>1:
        mid=len(batch)//2
        left,lu,lf=_translate_resilient(provider,batch[:mid],glossary,source_language,attempts,depth+1)
        right,ru,rf=_translate_resilient(provider,batch[mid:],glossary,source_language,attempts,depth+1)
        return {**left,**right},_merge_usage(total,_merge_usage(lu,ru)),{**lf,**rf}
    u=batch[0]; return {},total,{u.id:str(last_error) if last_error else "unknown translation failure"}

def translate_units(units,provider,checkpoint,glossary=None,batch_size=10,limit=None,source_language="English",attempts=3):
    state=load(checkpoint); done=state.setdefault("translations",{}); state.setdefault("failures",{})
    total_usage=state.setdefault("usage",{"prompt_tokens":0,"completion_tokens":0,"cache_hit_tokens":0,"cache_miss_tokens":0})
    active_glossary=glossary or {}; local_filled=0
    # --limit means total newly completed units in this invocation, including zero-token local fills.
    remaining_quota = None if limit is None else max(0, limit)

    # Fill exact hard terms first, but never exceed the per-run completion quota.
    for u in units:
        if remaining_quota is not None and local_filled >= remaining_quota: break
        if u.id in done: continue
        target=_exact_hard(u.source,active_glossary)
        if target:
            issues=validate(u.source,target,u.protected_tokens,active_glossary,u.metadata.get("kind"))
            done[u.id]={"translation":target,"issues":issues,"origin":"local_hard_glossary"}; state["failures"].pop(u.id,None); local_filled+=1
    if local_filled: save(checkpoint,state); print(f"  local hard-glossary fill: {local_filled} (0 API tokens)")

    pending=[u for u in units if u.id not in done]
    if remaining_quota is not None:
        api_quota=max(0, remaining_quota-local_filled)
        pending=pending[:api_quota]
    completed_this_run=local_filled
    for bi,batch in enumerate(batches(pending,batch_size),1):
        result,usage,failures=_translate_resilient(provider,batch,active_glossary,source_language,attempts); _add_usage(total_usage,usage)
        for u in batch:
            if u.id in result:
                tr=result[u.id]; issues=validate(u.source,tr,u.protected_tokens,active_glossary,u.metadata.get("kind"))
                done[u.id]={"translation":tr,"issues":issues,"origin":"api"}; state["failures"].pop(u.id,None); completed_this_run+=1
            elif u.id in failures: state["failures"][u.id]={"error":failures[u.id],"source":u.source}
        save(checkpoint,state); suffix=f"; {len(failures)} failed/manual" if failures else ""
        print(f"  batch {bi}: {len(result)} translated{suffix}; checkpoint saved")
    state["last_run"]={"local_hard_glossary":local_filled,"api_requested":len(pending)}; save(checkpoint,state)
    return state,completed_this_run
