> 4.3.0 新增 KAG/XP3，详见 README_KAG.md。以下保留旧引擎说明。

# Game Translator V4 — Unified alpha3.4 / 4.2.4 测试版

本版基于你保存的 `GameTranslatorV4_Unified_alpha2.zip` 开发。
本次新增 Bruns 自动残留检查与补译、RPG Maker MV/MZ 标准 JSON 内嵌汉化。
保留原 Ren'Py 流程；没有修改你单独保存的 translatorpp_adapter_v3_6_5.py。

## 启动

使用 Python 3.10 或更新版本。图形界面需要 Python 自带的 tkinter。

- macOS：解压到新目录，双击 `run_mac.command`；如双击打不开，在该目录执行 `python3 app.py`。
- Windows：双击 `run_windows.bat`，或执行 `py app.py`。
- 选择原版游戏目录，点击“分析游戏”。分析/预检不会请求翻译 API。
- 确认引擎和提取数量后，对于 MV/MZ 先保留默认的“MV/MZ 试译条数 = 10”，设置批次与费用保护，再填写自己的 DeepSeek API Key 并点“开始汉化”。
 试译会优先选择剧情对话；只向 API 请求这 10 个单元（质量补译仍只针对这 10 个）。其他 21,172 条之类的原文保持不变。
 试译输出另存为 `游戏名_Chinese_Sample10`，工作目录仍保留 checkpoint。重复运行相同样本会复用合格的译文；要继续全量时清空试译条数。
- 可设置原文 Japanese / English，以及补译轮数（默认 3）。
- 模型与接口沿用整合版原有配置，本包没有附带 API Key，也没有进行付费 API 实测。
- 这是 Python 源码测试版，不是已经打包的独立 .app/.exe。

命令行也可使用（在解压目录运行）：

```bash
python3 unified.py "/路径/原版游戏" --analyze
python3 unified.py "/路径/原版游戏" --sample 10 --batch-size 5 --repair-rounds 1
```

命令行可通过 `DEEPSEEK_API_KEY` 环境变量提供密钥，也兼容原项目 `.env` 读取方式。
图形界面把密钥通过子进程环境变量传递。

## Bruns：一遍翻译后继续查漏补缺

流程：主译 → 检查每个单元 → 只补译有阻断问题的条目 → 再检查。

检查空译、与原日文相同、明显平假名语句残留、较长原文片段残留、CP932 无法编码字符、控制符变化和脚本不安全字符。
共享汉字（例如“学校”）不会仅因与原文相同就反复重译；孤立片假名及可疑单字进入提示清单。
日繁是一种编码约束，不代表任何含日文字形的句子都是漏译。

- 默认最多 **3 轮补译**（不含主译）。
- 连续 **2 轮没有减少问题条目**就停止。
- 每批保存 checkpoint；下一次运行恢复已通过的结果，仅处理剩余问题。
- 被拒绝的候选译文只记录为重试参考，不覆盖原有译文。
- `bruns_completion_report.json` 包含剩余条目、原因、每轮数量和停止原因。
- 检查通过率只是规则覆盖率，不是语义准确率，无法保证所有漏译都被发现。
- 回写已去掉旧版固定 2,733 条的限制，逐个检查源文本、偏移和重新编码结果。
- 支持既有 EENZ 容器和当前提取规则可识别的明文 BSO；自定义 Bruns 方言仍需样本。

合法保留的人名可用术语表，或显式允许：

```bash
python3 unified.py "/路径/Bruns游戏" --allow-kana "リロイ" --repair-rounds 5
```

默认剩余阻断问题会停止生成游戏，保留翻译进度和报告。若明确接受保留少量原文：

```bash
python3 unified.py "/路径/Bruns游戏" --target-coverage 0.98 --allow-partial
```

这里的 98% 按规则通过的**翻译单元**计数。`--allow-partial` 会保留问题单元的原文，并在构建报告标记 partial；不会把损坏控制符或无法编码的候选写进游戏。

### 已经翻译过的旧 Bruns 工作目录

不要为了补译而删除已有翻译。先备份旧工作目录，再在新程序目录执行：

```bash
python3 -m bruns.autocomplete "/路径/旧工作目录" --audit-only
python3 -m bruns.autocomplete "/路径/旧工作目录" --repair-only --rounds 3
python3 -m bruns.write "/路径/原版游戏" "/路径/旧工作目录" --output "/路径/新汉化游戏" --build
```

要求旧目录保留 `bruns_units.json` 及 `bruns_alpha9_checkpoint.json` 或 `bruns_units_translated.json`。
仍有合法保留人名时，在检查、补译及回写命令中使用相同的 `--allow-kana`。
新统一入口需要源文件清单；没有该清单的旧工作目录应走上述迁移命令，或为新任务指定新工作目录。

## RPG Maker MV/MZ：直接提取和回写

选择游戏根目录即可；识别根目录或 `www/` 下的 `data/System.json` + `js/rpg_core.js`（MV）或 `js/rmmz_core.js`（MZ）。
可处理：

- 地图事件、公共事件、战斗事件里的显示文字和滚动文字。
- 显示选项，并同步对应 402 分支标签；保留分支编号和事件结构。
- 事件里的角色改名、昵称、简介。
- 角色名称/昵称/简介、职业名、技能/物品/武器/防具名称与说明、技能和状态消息、敌人名称。
- 地图显示名、游戏标题、货币、系统类型名及菜单/战斗术语。

相邻对话行组成一个翻译单元并携带前文。译文必须保留换行数量和控制符（如 `\V[1]`、`\N[1]`、`\C[2]`、`%1`），通过后拆回各行。
输出是一个包含修改后 UTF-8 JSON 数据的完整游戏副本，可直接启动该副本；不是运行时外挂翻译。

当前**不自动翻译**：插件 JS/参数、插件命令、脚本事件、备注标签、注释、资源文件名、图片内文字、编辑器内部名称。
这些内容可能包含程序逻辑，提取覆盖范围记录在 `mv_manifest.json` 或 `mz_manifest.json`。自定义打包/加密 JSON 需要另外适配。
本版不支持 VX Ace、VX 或 XP；MZ 的插件命令 357/657 与插件参数保留原样。
MV/MZ 未添加专用字体替换功能，实际中文字形和窗口排版需要在游戏里检查。

针对本次 DEATH PENALTY，若只想做第一轮小样本测试，建议在 GUI 保留试译条数 10、把 Batch 设为 5、补译轮数设为 1。`--sample` 适用于 MV/MZ，试译副本会自动保留未处理原文并在报告标记 partial。
估价/分析不代表支付授权；真实翻译调用会按 API 实际计费，费用保护是请求之间检查，单次请求仍可能超过阈值。

MV/MZ 输出文件：`mv_units.json`、`mv_checkpoint.json`、`mv_units_translated.json`、`mv_completion_report.json`、`mv_build_report.json`（MZ 用 `mz_` 前缀）。
规则不通过的条目会有限补译；仍有问题时默认停止构建，可显式用 `--allow-partial` 保留原文生成测试副本。

## 文件与费用

新 Bruns/MV/MZ 流程不覆盖原游戏，不删除已有输出。源游戏、工作目录、输出目录必须彼此独立，不能嵌套。
默认工作目录在游戏旁边的 `游戏名_GT_Work`，输出在 `游戏名_Chinese`。
若输出已经存在，使用新的 `--output` 路径。源文件变动会拒绝复用旧偏移/checkpoint，需新工作目录。
构建先在临时副本完成校验，再发布为输出目录。

Bruns/MV/MZ `--max-cost-rmb` 是按旧配置价格和 API usage 估算的**每次运行请求间停止阈值**；默认 ¥5，主译和补译共用。
单个正在执行的请求可能跨过阈值，它不是服务商硬消费上限；重启会开始新的会话额度。
价格表沿用旧版且本次未验证，账单以服务商为准。Ren'Py 原流程的费用行为未在本次重写。

## 验证与已知边界

新增 12 项离线自动化测试已通过：Bruns 残留分类、只重试剩余项、错误候选不覆盖、停止条件、付费响应解析失败的用量记账、旧 checkpoint 恢复、BSO 编码往返；MV 提取覆盖、控制符/换行保护、选项与嵌套分支关联、源数据变化与路径改动拒绝、模拟模型端到端构建及续跑。
旧 Ren'Py parser smoke test 也通过（总计 12 项检查）；全部 Python 文件已做语法检查。

```bash
python3 -m unittest discover -s tests -v
```

尚未验证：真实 DeepSeek 返回、真实游戏内字体/排版/剧情运行、GUI 在 macOS/Windows 的实际操作。
下一个实测应先选一个 Bruns 旧工作目录运行 audit-only，再选一个 MV 游戏运行 --analyze，查看覆盖数量后进行翻译与游戏启动验证。

MV 格式参考：
- https://github.com/rpgtkoolmv/corescript
- https://rpgmakerofficial.com/product/MV_Help/page/01_11_03.html

### Sisterfantasy0.5（MZ）命令行

先运行 `python3 unified.py "/Users/mike/Downloads/Sisterfantasy0.5/Sisterfantasy0.5" --analyze`；分析不调用翻译 API。确认提取数量和原文语言后，可以用 `--sample 10 --batch-size 5 --repair-rounds 1` 生成少量试译副本。当前没有该游戏的实际文件，需在 Mac 上检查分析结果及试译副本中的字体和窗口显示。

## alpha3.3 姓名标签修复与离线恢复

允许翻译字面量 `\n<角色名>` 内的名字；其他控制符及换行检查保持严格。兼容 alpha3.2 原有进度，不更改提取单元或指纹。

已结束翻译的游戏可运行 `python3 -m rpgmaker.recover "/路径/原游戏" --output "/路径/新汉化副本"`，自动读取游戏旁的工作目录，重新检查被拒绝的候选译文，恢复合格候选并生成新副本。无需密钥，不调用 API。备份 checkpoint；默认仍有不合格条目时停止，可显式添加 `--allow-partial` 保留原文。不要对仍在翻译的同一个工作目录运行恢复。

测试：15 项自动测试通过，包含姓名标签、其他控制符保护、旧进度指纹、离线恢复、备份及输出保护；真实游戏字体和插件显示仍需本机验证。

## alpha3.4 离线补换行

对只因 newline_mismatch 被拒绝的已保存候选，可运行 `python3 -m rpgmaker.recover "/路径/原游戏" --output "/路径/新副本" --repair-newlines --allow-partial`。无需密钥，不调用 API。按原文行数将中文重新分行，按字符宽度大致平衡行长并优先邻近标点；不改文字、不拆控制符，重新经过完整检查及原版数据校验再写入。仅支持候选比原文换行少的情况，源文含空白行等不确定情况保留未解决。

工作目录内 `mv_newline_repair_report.json` 或 `mz_newline_repair_report.json` 保存分行前后对照。该功能只修结构，不校对语义，分行位置为启发式推算，不能保证字体像素宽度、窗口排版或台词节奏；应实际测试游戏。进度自动备份，不要与同一个游戏的翻译任务同时运行。16 项自动测试及模拟 MZ 离线恢复/构建验证通过。
