# Witch’s Forest 字體身分隔離測試

本版保留全部整合功能。執行：
python3 -m dxa.font_probe ORIGINAL_GAME_FOLDER --output NEW_PATCH_FOLDER

輸入須為未修改的 Witch’s Forest 1.01 EXE 與 data/data.dxa；版本雜湊不符即停止。
原始文件不修改。自動在遊戲目錄辨認原始 EXE；也可 --exe 指定路徑。
輸出為診斷補丁，並非完整遊戲。Windows 完整遊戲副本必須同時替換 Witch's_Forest_1.01.exe 與 data/data.dxa。
直接運行該副本 EXE；保留日語系統區域及遊戲日語模式。切勿混用前一版 data.dxa。
預期五項：開始遊戲、繼續遊戲、回想畫廊、設定、結束遊戲。
撤回時同時恢復原始 EXE 和原始 data.dxa。

實驗目的：驗證 Windows 執行時的同名字體選擇是否造成錯字。尚未證實原因，這不是已完成的修復。
改動：原 MS Gothic 附帶字體的名稱變為 WFProbe，原 EXE 唯一 MS Gothic 字串改為 WFProbe。
原字形、cmap、字寬、字號保持；未改 EXE 指令或新增網路功能；無 API。
DXA 另外修改日語標題五項，與上版菜單文字相同，方便對照。英文分支文字不修改，但所有使用 MS Gothic 的繪製可能選用重新命名的附帶字體。
HGMinchoB 保持原樣。若菜單仍錯字，不代表完整排除所有字體問題，需要追蹤實際繪製及轉碼路徑。

離線依據：原附帶 MSGOTHIC.TTF 經獨立渲染可正確顯示五項；EXE 靜態檢查找到 MS Gothic 多次字體建立引用及附帶字體註冊。
生成新字體後以 fontTools 獨立核對名稱、所有非 name/head 表位元一致、整體 checksum 正確。
101 項離線測試通過；Windows 結果待使用者確認。
