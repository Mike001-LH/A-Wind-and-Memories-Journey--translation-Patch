"""Offline full-game differential update packages. Never edits input games.
Run generated apply_update.py with Python 3.9+ on Windows or macOS.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import tempfile
import unicodedata
import zipfile

FORMAT = 'gt-game-update-1'
ARCHIVES = ('.zip', '.rar', '.7z', '.tar', '.gz', '.bz2', '.xz')
RUNTIME_DIRS = {'save', 'saves', 'savedata', 'logs', '__macosx', '__pycache__', '.git'}
RESERVED = re.compile(r'^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\.|$)', re.I)

def excluded(relative):
    parts = PurePosixPath(relative).parts
    if any(p.lower() in RUNTIME_DIRS or p.startswith('.') or p.startswith('._') for p in parts):return True
    name = parts[-1].lower()
    return name.endswith(ARCHIVES) or bool(re.fullmatch(r'save\d+\.rvdata2', name)) or name in {'thumbs.db', 'desktop.ini', 'game.log', 'error.log'}

def safe_path(value):
    p = PurePosixPath(value)
    if not value or p.is_absolute() or p.as_posix() != value or any(x in ('', '.', '..') for x in p.parts):raise ValueError('Invalid package path: '+value)
    for x in p.parts:
        if any(ord(c)<32 or c in '\\:<>"|?*' for c in x) or x.endswith((' ', '.')) or RESERVED.match(x):raise ValueError('Not a portable Windows path: '+value)
    return value

def key(value):return unicodedata.normalize('NFC', value).casefold()

def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024), b''):h.update(chunk)
    return h.hexdigest()

def scan(root, paths=None):
    root=Path(root);result={};seen={}
    if not root.is_dir() or root.is_symlink():raise ValueError('Game must be a real directory: '+str(root))
    def walk(folder):
        for p in sorted(folder.iterdir()):
            rel=unicodedata.normalize('NFC',p.relative_to(root).as_posix())
            if p.is_symlink():raise ValueError('Symbolic links are unsupported: '+rel)
            if excluded(rel):continue
            safe_path(rel);folded=key(rel)
            if folded in seen:raise ValueError('Case/Unicode filename collision: '+rel+' / '+seen[folded])
            seen[folded]=rel
            if p.is_dir():walk(p)
            elif p.is_file():
                result[rel]={'sha256':digest(p),'size':p.stat().st_size}
                if paths is not None:paths[rel]=p
            else:raise ValueError('Unsupported file type: '+rel)
    walk(root)
    if not result:raise ValueError('No managed game files found')
    return result

def separate(destination, *inputs):
    dst=Path(destination).expanduser().absolute()
    if dst.exists():raise ValueError('Output already exists: '+str(dst))
    for source in inputs:
        source=Path(source).resolve();resolved=dst.resolve()
        if resolved==source or source in resolved.parents or resolved in source.parents:raise ValueError('Output must be separate from input directories')
    dst.parent.mkdir(parents=True,exist_ok=True)
    return dst

def require_vx(root):
    for name in ('Game.exe','Game.ini','Data/System.rvdata2','Data/Scripts.rvdata2'):
        if not (root/name).is_file():raise ValueError('Select complete unpacked VX Ace game root; missing '+name)

def manifest_plan(old,new):
    added=sorted(set(new)-set(old));removed=sorted(set(old)-set(new))
    modified=sorted(p for p in set(old)&set(new) if old[p]!=new[p])
    # Refuse casing/normalization renames and file/directory transitions on Windows.
    for path in removed:
        if any(key(path)==key(p) for p in added):raise ValueError('Case/Unicode-only rename needs manual review: '+path)
    for p in old:
        if any('/'.join(PurePosixPath(p).parts[:i]) in new for i in range(1,len(PurePosixPath(p).parts))):raise ValueError('File/directory transition needs manual review: '+p)
    for p in new:
        if any('/'.join(PurePosixPath(p).parts[:i]) in old for i in range(1,len(PurePosixPath(p).parts))):raise ValueError('File/directory transition needs manual review: '+p)
    return added,modified,removed

def build(old_game,new_game,output,old_version='old',new_version='new'):
    old_game=Path(old_game).resolve();new_game=Path(new_game).resolve()
    if old_game==new_game or old_game in new_game.parents or new_game in old_game.parents:raise ValueError('Use two separate complete original games')
    require_vx(old_game);require_vx(new_game)
    output=separate(output,old_game,new_game)
    if output.suffix.lower()!='.zip':raise ValueError('Output must end in .zip')
    print('Hashing old game (NO API CALLS)...',flush=True);old=scan(old_game)
    print('Hashing new game...',flush=True);new_paths={};new=scan(new_game,new_paths)
    added,modified,removed=manifest_plan(old,new)
    manifest={'format':FORMAT,'engine':'vxace','old_version':old_version,'new_version':new_version,'old_files':old,'new_files':new,'added':added,'modified':modified,'removed':removed,'payload_bytes':sum(new[p]['size'] for p in added+modified),'api_calls':0,'save_compatibility_verified':False,'excluded':'Archives, hidden/Mac metadata, save folders/SaveNN.rvdata2 and logs. Root Game.ini is included.'}
    fd,tmp=tempfile.mkstemp(dir=output.parent,suffix='.zip');os.close(fd)
    try:
        with zipfile.ZipFile(tmp,'w',zipfile.ZIP_DEFLATED,allowZip64=True) as z:
            z.writestr('manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2))
            z.write(Path(__file__),'apply_update.py')
            z.writestr('INSTALL.txt','Extract this update ZIP to a separate folder. Requires Python 3.9+.\nRun: python apply_update.py apply "OLD_GAME_FOLDER" --output "NEW_GAME_COPY"\nOn macOS use python3. On Windows use py -3.\nThe complete clean base is verified; originals remain untouched. Saves are copied unchanged, but compatibility is not guaranteed.\nInstall the translation patch only AFTER this update. Do not mix 0.49 and 0.50 Data files.\n')
            for p in added+modified:
                z.write(new_paths[p],'payload/'+p)
                with z.open('payload/'+p) as f:
                    h=hashlib.sha256();size=0
                    for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk);size+=len(chunk)
                if {'sha256':h.hexdigest(),'size':size}!=new[p]:raise ValueError('New file changed while packaging: '+p)
        if scan(old_game)!=old or scan(new_game)!=new:raise ValueError('Source changed while packaging; no package published')
        os.replace(tmp,output)
    finally:
        if os.path.exists(tmp):os.unlink(tmp)
    print('OFFLINE UPDATE PACKAGE:',output,flush=True)
    print('Added:',len(added),'Modified:',len(modified),'Removed:',len(removed),'Payload bytes:',manifest['payload_bytes'])
    print('Run installer against a clean old game to verify; Windows/save compatibility still needs playtesting.')
    return manifest

def validate_manifest(m):
    if m.get('format')!=FORMAT:raise ValueError('Unknown update format')
    for name in ('old_files','new_files'):
        if not isinstance(m.get(name),dict) or not m[name]:raise ValueError('Invalid file inventory')
        seen=set()
        for p,v in m[name].items():
            safe_path(p)
            if excluded(p) or key(p) in seen:raise ValueError('Excluded/colliding path in manifest: '+p)
            seen.add(key(p))
            if not isinstance(v,dict) or not re.fullmatch('[0-9a-f]{64}',v.get('sha256','')) or type(v.get('size')) is not int or v['size']<0:raise ValueError('Invalid file digest: '+p)
    added,modified,removed=manifest_plan(m['old_files'],m['new_files'])
    if [added,modified,removed]!=[m.get('added'),m.get('modified'),m.get('removed')]:raise ValueError('Inconsistent change lists')

def ignore_copy(folder,names):
    return [n for n in names if n.startswith('.') or n.startswith('._') or n.lower()=='__macosx' or n.lower().endswith(ARCHIVES)]

def portable_destination(root,relative):
    # Reuse folders whose Unicode spelling is equivalent, including on Linux.
    current=root
    parts=PurePosixPath(relative).parts
    for part in parts[:-1]:
        matches=[p for p in current.iterdir() if unicodedata.normalize('NFC',p.name)==part] if current.is_dir() else []
        if len(matches)>1:raise ValueError('Ambiguous Unicode directory')
        current=matches[0] if matches else current/part
    return current/parts[-1]

def apply(game,output,package=None):
    package=Path(package).resolve() if package else Path(__file__).resolve().parent
    game=Path(game).resolve();output=separate(output,game,package)
    m=json.loads((package/'manifest.json').read_text(encoding='utf-8'));validate_manifest(m)
    print('Verifying complete clean base (NO API CALLS)...',flush=True)
    actual=scan(game)
    if actual!=m['old_files']:
        differences=sorted(p for p in set(actual)|set(m['old_files']) if actual.get(p)!=m['old_files'].get(p))
        raise ValueError('Base does not match clean '+m['old_version']+'; nothing changed. First mismatches: '+', '.join(differences[:12]))
    for p in m['added']+m['modified']:
        f=package/'payload'/p
        # Reject symlinks anywhere inside package paths.
        if any(x.is_symlink() for x in [f,*f.parents]) or not f.is_file() or {'sha256':digest(f),'size':f.stat().st_size}!=m['new_files'][p]:raise ValueError('Corrupt/missing payload: '+p)
    # Validate ignored files too before copying, so symlinks cannot escape input tree.
    for folder,dirs,files in os.walk(game,followlinks=False):
        for name in dirs+files:
            if (Path(folder)/name).is_symlink():raise ValueError('Cannot copy symbolic links; nothing changed')
    staging=Path(tempfile.mkdtemp(dir=output.parent,prefix='.gt-update-'))
    try:
        shutil.copytree(game,staging/'game',ignore=ignore_copy);dest=staging/'game'
        dest_paths={};scan(dest,dest_paths)
        for p in m['removed']:dest_paths[p].unlink()
        for p in m['added']+m['modified']:
            target=dest_paths.get(p) or portable_destination(dest,p)
            target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(package/'payload'/p,target)
        if scan(dest)!=m['new_files']:raise ValueError('Post-install verification failed; no output published')
        if scan(game)!=m['old_files']:raise ValueError('Base changed while installing; no output published')
        if output.exists():raise ValueError('Output appeared during install; nothing overwritten')
        os.rename(dest,output)
    finally:shutil.rmtree(staging,ignore_errors=True)
    print('VERIFIED UPDATE COPY:',output,flush=True)
    print('Original game untouched. Save files copied; test their compatibility in game.')
    return output

def main():
    p=argparse.ArgumentParser(description=__doc__);sub=p.add_subparsers(dest='command',required=True)
    b=sub.add_parser('build');b.add_argument('old_game');b.add_argument('new_game');b.add_argument('--output',required=True);b.add_argument('--old-version',default='old');b.add_argument('--new-version',default='new')
    a=sub.add_parser('apply');a.add_argument('game');a.add_argument('--output',required=True);a.add_argument('--package')
    args=p.parse_args()
    try:
        if args.command=='build':build(args.old_game,args.new_game,args.output,args.old_version,args.new_version)
        else:apply(args.game,args.output,args.package)
    except (ValueError,OSError,zipfile.BadZipFile) as e:print('STOP:',e,flush=True);return 2
    return 0
if __name__=='__main__':raise SystemExit(main())
