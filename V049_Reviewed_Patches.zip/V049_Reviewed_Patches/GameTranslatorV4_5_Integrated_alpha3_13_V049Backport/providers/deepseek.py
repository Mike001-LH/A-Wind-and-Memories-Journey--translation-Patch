from __future__ import annotations
import json, os, ssl, socket, urllib.request, urllib.error
from providers.base import TranslationProvider, Usage
from core.glossary import relevant_glossary

class ProviderError(RuntimeError):
    stop_run=True
    def __init__(self,message,reason='provider_error'):
        super().__init__(message);self.reason=reason

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,req,fp,code,msg,headers,newurl):
        raise ProviderError('API redirect refused; configure the final HTTPS API address', 'provider_redirect')

class DeepSeekProvider(TranslationProvider):
    def __init__(self, api_key=None, base_url="https://api.deepseek.com", model="deepseek-flash", thinking="disabled", json_mode=True, label="deepseek"):
        self.api_key=api_key or os.getenv("DEEPSEEK_API_KEY")
        self.base_url=base_url.rstrip("/")
        self.model=model
        self.thinking=thinking
        self.json_mode=json_mode
        self.label=label
        if not self.api_key:
            raise RuntimeError("DEEPSEEK_API_KEY is not set. Put it in .env or export it in the shell.")
        self.ssl_context=self._ssl_context()
        self.opener=urllib.request.build_opener(NoRedirect(),urllib.request.HTTPSHandler(context=self.ssl_context))

    @staticmethod
    def _ssl_context():
        try:
            import certifi
            return ssl.create_default_context(cafile=certifi.where())
        except ImportError:
            return ssl.create_default_context()

    def translate_batch(self, items, glossary=None, source_language="English", target_language="Simplified Chinese"):
        glossary=glossary or {}
        payload_items=[]
        batch_text="\n".join(x["source"] for x in items)
        relevant=relevant_glossary(glossary,batch_text)
        for x in items:
            payload_items.append({
                "id":x["id"],"text":x["source"],
                "speaker":x.get("speaker"),
                "context":x.get("context",[]),
                "protected_tokens":x.get("protected_tokens",[])
            })
        hard={k:v["target"] for k,v in relevant.items() if v.get("mode")=="hard"}
        soft={k:v["target"] for k,v in relevant.items() if v.get("mode")!="hard"}
        system=f"""You are a professional game localization translator.
Translate {source_language} into {target_language}.
Return JSON only, exactly in this shape:
{{"translations":[{{"id":"...","translation":"..."}}]}}
Rules:
- Preserve every protected token EXACTLY.
- Preserve meaning, tone, speaker voice, and natural game-localization style.
- Do not translate IDs.
- Do not add explanations.
- HARD glossary entries are canonical names/terms. If the source contains one, its target form MUST appear in the translation. Never invent an alternate translation, transliteration, or synonym for it.
- Prefer the longest matching glossary term when terms overlap. Example: a full title rule overrides a shorter word contained inside it.
- SOFT glossary entries are preferred terminology, but may be adjusted only when grammar/context genuinely requires it.
- The output must contain one result for every input id.
HARD glossary JSON: {json.dumps(hard,ensure_ascii=False)}
SOFT glossary JSON: {json.dumps(soft,ensure_ascii=False)}"""
        user="Translate this JSON batch:\n"+json.dumps({"items":payload_items},ensure_ascii=False)
        body={
            "model":self.model,
            "messages":[{"role":"system","content":system},{"role":"user","content":user}],
            "max_tokens":4096
        }
        if self.json_mode: body["response_format"]={"type":"json_object"}
        if self.thinking!="omit": body["thinking"]={"type":"disabled"}
        req=urllib.request.Request(self.base_url+"/chat/completions",
            data=json.dumps(body,ensure_ascii=False).encode(),
            headers={"Authorization":"Bearer "+self.api_key,"Content-Type":"application/json"},method="POST")
        try:
            with self.opener.open(req,timeout=180) as r:
                raw=json.loads(r.read().decode())
        except (ValueError,UnicodeError) as e:
            raise ProviderError("API returned invalid response JSON", "provider_invalid_json") from e
        except urllib.error.HTTPError as e:
            detail=e.read(2000).decode("utf-8","replace").replace(self.api_key,"[REDACTED]")
            if self.thinking=="disabled" and e.code==400:
                detail += " If the gateway rejects thinking, retry explicitly with --api-thinking omit."
            raise ProviderError(f"{self.label} HTTP {e.code}: {detail[:1000]}","provider_http_error") from e
        except urllib.error.URLError as e:
            if isinstance(e.reason,ssl.SSLCertVerificationError):
                raise ProviderError("SSL certificate verification failed. On python.org macOS Python, run the bundled 'Install Certificates.command'; installing certifi in the venv is also supported.") from e
            raise ProviderError(f"{self.label} connection failed: {str(e.reason).replace(self.api_key, chr(91)+chr(93))}","provider_connection_error") from e
        except (TimeoutError,socket.timeout) as e:
            raise ProviderError("API timed out; request may have reached the server. Check Usage Logs before resuming.","provider_timeout") from e
        if not isinstance(raw,dict):raise ProviderError("Invalid API response structure", "provider_invalid_json")
        usage_raw=raw.get("usage") or {}
        details=usage_raw.get("prompt_tokens_details") or {}
        cache_hit=details.get("cached_tokens",usage_raw.get("prompt_cache_hit_tokens",0)) or 0
        prompt=usage_raw.get("prompt_tokens",0) or 0
        cache_miss=usage_raw.get("prompt_cache_miss_tokens")
        if cache_miss is None: cache_miss=max(0,prompt-cache_hit)
        reasoning=(usage_raw.get("completion_tokens_details") or {}).get("reasoning_tokens",0) or 0
        usage=Usage(prompt,usage_raw.get("completion_tokens",0) or 0,cache_hit,cache_miss,reasoning,
                    isinstance(raw.get('usage'),dict) and 'prompt_tokens' in usage_raw and 'completion_tokens' in usage_raw)
        try:
            choice=raw["choices"][0]
            content=choice["message"].get("content")
            if choice.get("finish_reason")=="length":
                raise ProviderError("Model response hit the output limit; reduce --batch-size", "provider_truncated")
            # Accept a complete JSON code fence, never arbitrary prose or partial JSON.
            if not isinstance(content,str):raise ProviderError("Model returned no text content")
            clean=content.strip()
            if clean.startswith("```") and clean.endswith("```"):
                first=clean.find("\n");clean=clean[first+1:-3].strip()
            try:obj=json.loads(clean)
            except ValueError as e:raise ProviderError("Model returned invalid JSON; no candidate accepted", "provider_invalid_json") from e
            rows=obj.get("translations") if isinstance(obj,dict) else None
            if not isinstance(rows,list):raise ProviderError("Response lacks translations array", "provider_invalid_json")
            result={};allowed={x['id'] for x in items};seen=set();duplicates=set()
            for x in rows:
                if not isinstance(x,dict) or not isinstance(x.get('id'),str) or not isinstance(x.get('translation'),str):
                    continue
                if x['id'] not in allowed:continue
                if x['id'] in seen:
                    duplicates.add(x['id']);result.pop(x['id'],None);continue
                seen.add(x['id'])
                result[x['id']]=x['translation']
            for key in duplicates:result.pop(key,None)
            if rows and not result:raise ProviderError('Response contains no usable translation rows','provider_invalid_json')
        except (ProviderError,KeyError,IndexError,TypeError) as exc:
            error=exc if isinstance(exc,ProviderError) else ProviderError("Invalid API response structure", "provider_invalid_json")
            error.usage=usage
            raise error
        return result,usage
