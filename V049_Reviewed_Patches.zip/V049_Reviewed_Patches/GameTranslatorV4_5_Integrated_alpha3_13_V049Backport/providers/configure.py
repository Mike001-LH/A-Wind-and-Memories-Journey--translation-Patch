"""Store one provider's key locally without echoing it or altering the other key."""
import argparse
import getpass
import os
from pathlib import Path
import tempfile

KEYS={'deepseek':'DEEPSEEK_API_KEY','xianyi':'XIANYI_API_KEY'}

def store_key(path,name,key):
    path=Path(path)
    if path.is_symlink():raise ValueError('Refusing to replace a symlink .env')
    if not key or any(c.isspace() or c in "'\"" for c in key):raise ValueError('Key must be one nonempty token without whitespace or quotes')
    before=path.read_text(encoding='utf-8').splitlines() if path.exists() else []
    lines=[line for line in before if line.strip().split('=',1)[0].strip()!=name]
    lines.append(name+'='+key)
    path.parent.mkdir(parents=True,exist_ok=True)
    fd,tmp=tempfile.mkstemp(prefix='.gt-env-',dir=path.parent)
    try:
        os.chmod(tmp,0o600)
        with os.fdopen(fd,'w',encoding='utf-8') as stream:stream.write('\n'.join(lines)+'\n')
        os.replace(tmp,path)
    finally:
        if os.path.exists(tmp):os.unlink(tmp)

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--provider',choices=KEYS,required=True)
    p.add_argument('--env-file',default=str(Path(__file__).resolve().parent.parent/'.env'))
    p.add_argument('--import-env',type=Path,help='Import only the selected provider key from an existing .env; never prints it')
    a=p.parse_args()
    try:
        if a.import_env:
            from dotenv import dotenv_values
            if not a.import_env.expanduser().is_file():raise ValueError('Import file does not exist')
            key=dotenv_values(a.import_env.expanduser(),interpolate=False).get(KEYS[a.provider]) or ''
        else:key=getpass.getpass(a.provider+' API Key (hidden input): ').strip()
        store_key(Path(a.env_file).expanduser(),KEYS[a.provider],key)
    except (OSError,ValueError) as e:p.exit(2,'STOP: '+str(e)+'\n')
    print('Saved',KEYS[a.provider],'locally. Other provider keys retained. NO API CALLS.')
if __name__=='__main__':main()
