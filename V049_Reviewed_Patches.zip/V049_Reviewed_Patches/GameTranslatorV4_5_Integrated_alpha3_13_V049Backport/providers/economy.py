"""Compact official requests, retaining source/context and engine-owned QA."""
import json,urllib.request,urllib.error
from providers.deepseek import DeepSeekProvider, ProviderError
from providers.base import Usage
from core.glossary import relevant_glossary

class EconomyProvider(DeepSeekProvider):
    def translate_batch(self,items,glossary=None,source_language='Chinese',target_language='Japanese'):
        aliases={str(i):u['id'] for i,u in enumerate(items)}
        index={u['source']:str(i) for i,u in enumerate(items)}
        rows=[]
        shared_rules=list(dict.fromkeys(rule for u in items for rule in u.get("shared_rules",[])))
        for i,u in enumerate(items):
            row={'i':str(i),'s':u['source']}
            context=[]
            for c in u.get('context',[]):
                if c.startswith('Keep exactly the same number of physical newlines and preserve ALL protected tokens.'):continue
                context.append({'ref':index[c]} if c in index else c)
            if context:row['c']=context
            if u.get('speaker'):row['speaker']=u['speaker']
            if u.get('protected_tokens'):row['p']=u['protected_tokens']
            rows.append(row)
        relevant=relevant_glossary(glossary or {},'\n'.join(u['source'] for u in items))
        hard={k:v['target'] for k,v in relevant.items() if v.get('mode')=='hard'}
        soft={k:v['target'] for k,v in relevant.items() if v.get('mode')!='hard'}
        system=(f'Localize game text from {source_language} to {target_language}. Preserve meaning, speaker voice, tone and natural phrasing. '
                'Each row: i=ID, s=source, c=preceding context, p=protected tokens. Context ref refers to another input row source. '
                'Return JSON only: {"t":[["ID","complete translation"],...]}, one pair per input ID. '
                'Preserve ALL protected/control tokens exactly and the EXACT number of physical newlines. '
                'Use concise game text. Never alter technical tags. Separate bare backslash letter codes from following English words with a space. '
                'Do not translate IDs or output commentary. HARD glossary is mandatory; prefer longest matching term. SOFT glossary is preferred. '
                'ENGINE RULES='+json.dumps(shared_rules,ensure_ascii=False,separators=(',',':'))+' '
                'HARD='+json.dumps(hard,ensure_ascii=False,separators=(',',':'))+' SOFT='+json.dumps(soft,ensure_ascii=False,separators=(',',':')))
        body={'model':self.model,'messages':[{'role':'system','content':system},{'role':'user','content':json.dumps(rows,ensure_ascii=False,separators=(',',':'))}],
              'max_tokens':8192}
        if self.json_mode:body['response_format']={'type':'json_object'}
        if self.thinking!='omit':body['thinking']={'type':'disabled'}
        request=urllib.request.Request(self.base_url+'/chat/completions',data=json.dumps(body,ensure_ascii=False,separators=(',',':')).encode(),
                   headers={'Authorization':'Bearer '+self.api_key,'Content-Type':'application/json'},method='POST')
        try:
            with self.opener.open(request,timeout=180) as response:raw=json.loads(response.read().decode())
        except urllib.error.HTTPError as exc:
            detail=exc.read(2000).decode('utf-8','replace').replace(self.api_key,'[REDACTED]')
            raise ProviderError(f'DeepSeek HTTP {exc.code}: {detail[:800]}','provider_http_error') from exc
        usage_raw=raw.get('usage') or {};details=usage_raw.get('prompt_tokens_details') or {}
        prompt=usage_raw.get('prompt_tokens',0) or 0;hit=details.get('cached_tokens',usage_raw.get('prompt_cache_hit_tokens',0)) or 0
        miss=usage_raw.get('prompt_cache_miss_tokens');miss=max(0,prompt-hit) if miss is None else miss
        reasoning=(usage_raw.get('completion_tokens_details') or {}).get('reasoning_tokens',0) or 0
        usage=Usage(prompt,usage_raw.get('completion_tokens',0) or 0,hit,miss,reasoning,
                    isinstance(raw.get('usage'),dict) and 'prompt_tokens' in usage_raw and 'completion_tokens' in usage_raw)
        try:
            choice=raw['choices'][0]
            if choice.get('finish_reason')=='length':raise ValueError('output truncated; reduce batch size/characters')
            obj=json.loads(choice['message']['content']);pairs=obj.get('t')
            if not isinstance(pairs,list):raise ValueError('missing t array')
            result={};seen=set();duplicates=set()
            for pair in pairs:
                if not isinstance(pair,list) or len(pair)!=2 or not all(isinstance(v,str) for v in pair):continue
                alias,value=pair
                if alias not in aliases:continue
                if alias in seen:duplicates.add(alias);result.pop(aliases[alias],None);continue
                seen.add(alias);result[aliases[alias]]=value
            for alias in duplicates:result.pop(aliases[alias],None)
        except (ValueError,KeyError,IndexError,TypeError) as exc:
            error=ProviderError('Economy response format error: '+str(exc),
                'provider_truncated' if 'truncated' in str(exc) else 'provider_invalid_json');error.usage=usage;raise error from exc
        return result,usage
