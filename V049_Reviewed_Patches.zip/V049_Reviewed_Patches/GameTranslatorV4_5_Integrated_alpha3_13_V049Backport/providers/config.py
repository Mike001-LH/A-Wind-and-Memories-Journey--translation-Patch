"""Provider selection and per-run accounting; never stores credentials in reports."""
import math
import os
from urllib.parse import urlsplit, urlunsplit
from providers.deepseek import DeepSeekProvider
from bruns.translate import cost_cny
from vxace.costs import CostDisplay

class RequestStop(RuntimeError):
    stop_run=True
    def __init__(self, message, reason='request_stopped'):
        super().__init__(message);self.reason=reason

def provider_name(args):return getattr(args,'provider','deepseek')

def normalize_base(url, gateway=False):
    parts=urlsplit(url.strip())
    if parts.scheme!='https' or not parts.hostname or parts.username or parts.password or parts.query or parts.fragment:
        raise ValueError('API base URL must be an HTTPS address without credentials, query or fragment')
    path=parts.path.rstrip('/')
    if gateway and not path:path='/v1'
    if path not in ('','/v1'):raise ValueError('API base URL must end at the host or /v1, not /chat/completions')
    return urlunsplit((parts.scheme,parts.netloc,path,'',''))

def configuration(args):
    name=provider_name(args)
    if name not in ('deepseek','xianyi'):raise ValueError('Unknown API provider')
    gateway=name=='xianyi'
    prefix='XIANYI' if gateway else 'DEEPSEEK'
    base=getattr(args,'api_base_url',None) or os.getenv(prefix+'_BASE_URL') or ('https://noxianyi.zeabur.app/v1' if gateway else 'https://api.deepseek.com')
    model=getattr(args,'api_model',None) or os.getenv(prefix+'_MODEL') or ('deepseek-ai/deepseek-v4.1-flash' if gateway else 'deepseek-flash')
    thinking=getattr(args,'api_thinking',None) or os.getenv(prefix+'_THINKING') or ('omit' if gateway else 'disabled')
    if thinking not in ('omit','disabled'):raise ValueError('API thinking must be omit or disabled')
    if not model.strip():raise ValueError('API model cannot be empty')
    return {'provider':name,'base_url':normalize_base(base,gateway),'model':model.strip(),
            'thinking':thinking,'key_env':prefix+'_API_KEY','json_mode':not gateway}

def make_provider(args):
    config=configuration(args)
    key=getattr(args,'api_key',None) or os.getenv(config['key_env'])
    if not key:raise RuntimeError(config['key_env']+' is not set. Run python3 -m providers.configure --provider '+config['provider'])
    provider_class=DeepSeekProvider
    if getattr(args,'economy',False):
        if config['provider']!='deepseek':raise ValueError('Economy mode requires official DeepSeek')
        from providers.economy import EconomyProvider
        provider_class=EconomyProvider
    return provider_class(api_key=key,base_url=config['base_url'],model=config['model'],
                            thinking=config['thinking'],json_mode=config['json_mode'],label=config['provider'])

class SessionAccounting:
    """Counts requests before sending, including failures; unknown price is not zero."""
    def __init__(self,args,state):
        self.args=args;self.state=state;self.calls=0;self.spent=0.;self.tokens={}
        self.config=configuration(args)
        self.limit=getattr(args,'max_api_calls',None)
        if not math.isfinite(args.max_cost_rmb) or args.max_cost_rmb<=0:raise ValueError('Budget must be finite and positive')
        rates=[getattr(args,n,None) for n in ('api_input_rmb','api_output_rmb','api_cached_input_rmb')]
        if any(r is not None for r in rates):
            if rates[0] is None or rates[1] is None:raise ValueError('Supply both --api-input-rmb and --api-output-rmb (per million tokens)')
            if rates[2] is None:rates[2]=rates[0]
            if any(not math.isfinite(r) or r<0 for r in rates):raise ValueError('API prices must be finite nonnegative RMB amounts per million tokens')
            self.rates=rates
        else:self.rates=None
        self.known=self.rates is not None or (self.config['provider']=='deepseek' and self.config['base_url'] in ('https://api.deepseek.com','https://api.deepseek.com/v1') and self.config['model']=='deepseek-flash')
        if self.limit is not None and self.limit<1:raise ValueError('--max-api-calls must be positive')
        if not self.known and self.limit is None:
            raise ValueError('Xianyi price is unknown: set --max-api-calls, or supply its input/output RMB rates. No request sent.')
        self.state['api_session']={**{k:v for k,v in self.config.items() if k!='key_env'},
            'attempted_requests':0,'successful_responses':0,'max_api_calls':self.limit,
            'price_status':'user_supplied' if self.rates else 'legacy_deepseek_estimate' if self.known else 'unknown',
            'rates_rmb_per_million':self.rates,'estimated_spent_rmb':0. if self.known else None,'tokens':{}}
        self.state['session_spent_rmb']=0. if self.known else None
        self.costs=CostDisplay(state,args.max_cost_rmb,args.price_band,rates=self.rates) if self.known else None
        if not self.known:
            self.state['api_usage_without_price']=True
            self.state['cost_summary']={'actual_billing':False,'incomplete_records':True,
                'session_recorded_estimated_rmb':None,'historical_recorded_estimated_rmb':state.get('spent_rmb'),
                'price_status':'unknown','last_batch_estimated_rmb':None}
        print('API:',self.config['provider'],self.config['model'],'thinking='+self.config['thinking'],flush=True)
        if not self.known:print('API price UNKNOWN — request limit:',self.limit,'; verify actual charges in Usage Logs.',flush=True)
    def before(self):
        if self.limit is not None and self.calls>=self.limit:raise RequestStop('API request limit reached','request_limit')
        if self.known and self.spent>=self.args.max_cost_rmb:raise RequestStop('Estimated session budget reached','budget_limit')
        self.calls+=1;self.state['api_session']['attempted_requests']=self.calls
        print('Sending API request',self.calls,'(waiting for response)...',flush=True)
    def record(self,usage):
        self.state['api_session']['successful_responses']+=1
        for k,v in usage.items():self.tokens[k]=self.tokens.get(k,0)+v
        self.state['api_session']['tokens']=dict(self.tokens)
        if self.known:
            self.costs.record(usage)
            self.spent=float(self.costs.session)
            self.state['api_session']['estimated_spent_rmb']=self.spent
        else:self.state['api_usage_without_price']=True
        print('API response received; tokens:',usage.get('prompt_tokens',0),'input,',usage.get('completion_tokens',0),
              'output (reasoning:',usage.get('reasoning_tokens',0),')',flush=True)
    def missing(self):
        self.state['cost_usage_missing']=True
        self.state['api_session']['usage_missing']=True
        if self.costs:self.costs.missing()
    def finish(self,reason):
        if self.costs:self.costs.finish(reason)
