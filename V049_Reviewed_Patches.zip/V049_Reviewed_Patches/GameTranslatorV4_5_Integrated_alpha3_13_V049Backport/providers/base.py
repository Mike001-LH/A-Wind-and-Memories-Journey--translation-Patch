from dataclasses import dataclass
@dataclass
class Usage:
    prompt_tokens:int=0
    completion_tokens:int=0
    cache_hit_tokens:int=0
    cache_miss_tokens:int=0
    reasoning_tokens:int=0
    reported:bool=True
class TranslationProvider:
    def translate_batch(self, items, **kwargs):
        raise NotImplementedError
