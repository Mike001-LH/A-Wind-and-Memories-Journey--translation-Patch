# Wind V0.49 offline choice backport

Original V0.49 scripts are explicitly hash-guarded. This version retains integrated engine and file adapters, cost display, economy, migration, and game updates.

`python3 translator.py backport-vx OLD_GAME --patch OLD_PATCH --reviewed-game NEW_ORIGINAL --reviewed-patch NEW_REVIEWED_PATCH --target-language en --output NEW_PATCH`

Use `ja` for Japanese. All original Data hashes and language are checked. Non-script files are reconstructed using allowed text spans only. Shared code102/402 strings remain linked; existing valid translations are retained. Matching reviewed translations use exact source+kind; conflicting memory is not silently selected. Same-location exact matches have priority. This is translation text reuse, not a game update.

The Wind choice display runtime accepts reviewed V0.49 and V0.50 original Scripts hashes only. It retains all other scripts, the original Main suffix and existing display/coverage prefixes. No font replacement, no API calls. Test choices, branch progression, dialogue and item descriptions on a game copy; old cached choice windows should be closed and reopened.

Unchanged Han in Japanese can be valid Japanese names or genuine residual Chinese. See pending review candidates; zero structural blockers does not imply full semantic coverage. Source exclusions (custom scripts/notes/image text) remain excluded unless already handled by prior reviewed profiles.
