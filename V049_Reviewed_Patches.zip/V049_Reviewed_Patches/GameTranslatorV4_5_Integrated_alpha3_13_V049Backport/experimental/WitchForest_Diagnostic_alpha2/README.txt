Witch Forest 1.01 闪退诊断 alpha2

上一版闪退原因尚未确认。本版是诊断包，不是已验证修复。
上一版改为未压缩索引/菜单；本版保留索引 Huffman+LZ、菜单 LZ 和加密标志。
使用有效的 literal-only LZ 流。改变存放位置但保留其他资源数据。
三种模式：original 原文重打包；ascii 英文标题；chinese 中文标题。
先测试 original，用于判断不修改文字的重打包是否能启动。

请先恢复原包，确认原游戏仍能启动。生成器只接受原版哈希，拒绝 alpha1 包。
python3 build.py "/原游戏/data/data.dxa" --mode original --output "$HOME/Downloads/WitchForest_Diagnostic_Original/data.dxa"
把输出复制到完整游戏测试副本的 data/data.dxa，替换后运行。
若原文重打包成功，再生成 ascii 模式（使用另一个新输出路径）测试。
不要在同一个游戏目录存放多份名为 data.dxa 的测试结果而混淆实际替换文件。
如果失败，请查看 EXE 旁有无新生成的 Log.txt/错误窗口，提供给开发者。

无 API 调用，不修改原包，不需要编译器。Mac/Windows Python 3 标准库。
每个输出约 614 MB。已有输出拒绝覆盖。
文件级验证：三套压缩索引及六个菜单成功解码；original 菜单与原文逐字节一致。
运行时验证：待用户测试。既有 Game Translator 未改动。
