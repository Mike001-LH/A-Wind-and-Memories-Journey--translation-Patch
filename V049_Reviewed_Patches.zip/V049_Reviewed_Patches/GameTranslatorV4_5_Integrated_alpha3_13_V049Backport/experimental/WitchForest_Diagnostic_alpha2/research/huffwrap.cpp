#include "Huffman.h"
extern "C" u64 decode(void *src,void *dst) {return Huffman_Decode(src,dst);}
extern "C" u64 encode(void *src,u64 size,void *dst) {return Huffman_Encode(src,size,dst);}
