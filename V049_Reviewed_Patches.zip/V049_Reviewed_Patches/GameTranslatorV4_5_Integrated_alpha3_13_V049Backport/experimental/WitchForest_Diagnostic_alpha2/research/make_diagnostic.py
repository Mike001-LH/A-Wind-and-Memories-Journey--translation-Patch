from pathlib import Path
import ctypes,struct,json,sys,hashlib
sys.path.insert(0,'WitchForest_Menu_Probe');import build_menu_probe as m
R=Path('witch_research');OUT=Path('WitchForest_Diagnostic_alpha2')
lib=ctypes.CDLL(str((R/'huff_probe.so').resolve()));lib.encode.argtypes=[ctypes.c_void_p,ctypes.c_uint64,ctypes.c_void_p];lib.encode.restype=ctypes.c_uint64
lib.decode.argtypes=[ctypes.c_void_p,ctypes.c_void_p];lib.decode.restype=ctypes.c_uint64
# Literal-only valid DXA LZ streams preserve the LZ decoding path.
def lz(b):
 k=min(range(256),key=b.count);body=b.replace(bytes([k]),bytes([k,k]));return struct.pack('<II',len(b),len(body)+9)+bytes([k])+body

def huff(b):
 src=ctypes.create_string_buffer(b);n=lib.encode(src,len(b),None);out=ctypes.create_string_buffer(n);assert lib.encode(src,len(b),out)==n
 check=ctypes.create_string_buffer(len(b));assert lib.decode(out,check)==len(b) and check.raw==b
 return out.raw
meta=json.loads(Path('WitchForest_Menu_Probe/probe.json').read_text());secret=bytes.fromhex(meta['archive_key_string_hex']);orig=(R/'data/data.dxa');size=orig.stat().st_size
with orig.open('rb') as f:header=f.read(64)
manifest={'source_sha256':m.EXPECTED,'source_size':size,'modes':{}}
for mode in ['original','ascii','chinese']:
 idx=bytearray((R/'index.bin').read_bytes());tail=bytearray();expected={}
 for row in meta['changes']:
  b=(R/'extracted'/row['path']).read_bytes()
  if mode=='chinese':b=(Path('WitchForest_Menu_Probe')/row['payload']).read_bytes()
  elif mode=='ascii':
   lines=b.splitlines(keepends=True);count=0
   for j,line in enumerate(lines):
    if line.startswith(b'-----') and not line.startswith(b'------') and count<5:
     lines[j]=b'-----'+[b'New Game',b'Continue',b'Gallery',b'Options',b'Exit'][count]+b'\r\n';count+=1
   b=b''.join(lines)
  packed=lz(b)
  while (size+len(tail))%4:tail.append(0)
  addr=size+len(tail)-64;tail.extend(m.xor(packed,m.key(secret+bytes.fromhex(row['key_suffix_hex'])),len(b)))
  struct.pack_into('<4Q',idx,56672+row['record_offset']+40,addr,len(b),len(packed),2**64-1)
  expected[row['path']]=hashlib.sha256(b).hexdigest()
 index_at=size+len(tail);tail.extend(m.xor(huff(lz(idx)),m.key(secret)))
 h=bytearray(header);struct.pack_into('<Q',h,16,index_at)
 (OUT/(mode+'.tail')).write_bytes(tail)
 manifest['modes'][mode]={'header_hex':h.hex(),'tail_sha256':hashlib.sha256(tail).hexdigest(),'text_sha256':expected}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2))
print('prepared and Huffman roundtrip verified:',list(manifest['modes']))
