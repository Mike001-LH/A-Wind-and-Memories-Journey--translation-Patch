import argparse,hashlib,json,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()

def main():
 p=argparse.ArgumentParser();p.add_argument('archive');p.add_argument('--mode',choices=['original','ascii','chinese'],default='original');p.add_argument('--output',required=True);a=p.parse_args()
 src=Path(a.archive);dst=Path(a.output);manifest=json.loads((ROOT/'manifest.json').read_text());row=manifest['modes'][a.mode]
 if dst.exists():p.exit(1,'STOP: 输出已存在，请换新输出名\n')
 if not src.is_file() or src.stat().st_size!=manifest['source_size'] or digest(src)!=manifest['source_sha256']:p.exit(1,'STOP: 请选择未修改的 1.01 原版 data.dxa\n')
 tail=ROOT/(a.mode+'.tail')
 if digest(tail)!=row['tail_sha256']:p.exit(1,'STOP: 工具数据校验失败\n')
 dst.parent.mkdir(parents=True,exist_ok=True)
 with dst.open('xb') as out,src.open('rb') as inp,tail.open('rb') as extra:
  shutil.copyfileobj(inp,out,1024*1024);shutil.copyfileobj(extra,out);out.seek(0);out.write(bytes.fromhex(row['header_hex']))
 print('OFFLINE DIAGNOSTIC — NO API CALLS')
 print('Mode:',a.mode,'Output:',dst)
 print('原包未修改；请在游戏副本中实测启动。')
if __name__=='__main__':main()
