#include "Huffman.h"
extern "C" u64 decode(void *src,void *dst) {return Huffman_Decode(src,dst);}
