from pathlib import Path
import struct,zlib,ctypes,json
ROOT=Path(__file__).resolve().parent
f=open(ROOT/'data/data.dxa','rb');head=struct.unpack('<HHIQQQQIIB15s',f.read(64));_,ver,hs,base,idx,ft,dt,cp,flags,hkb,_=head
secret=(ROOT/'key_candidate.txt').read_bytes()
def key(s):
 if len(s)<4:s+=b'DXBDXARC'
 return struct.pack('<I',zlib.crc32(s[::2]))+struct.pack('<I',zlib.crc32(s[1::2]))[:3]
def xor(b,k,pos=0):return bytes(v^k[(i+pos)%7] for i,v in enumerate(b))
lib=ctypes.CDLL(str(ROOT/'huff.so'));lib.decode.argtypes=[ctypes.c_void_p,ctypes.c_void_p];lib.decode.restype=ctypes.c_uint64
def huff(b):
 src=ctypes.create_string_buffer(b);n=lib.decode(src,None);assert n<20000000,n
 out=ctypes.create_string_buffer(n);assert lib.decode(src,out)==n;return out.raw

def lz(b):
 n,total=struct.unpack_from('<II',b);assert total==len(b) and n<20000000
 marker=b[8];p=9;out=bytearray()
 while p<total:
  v=b[p];p+=1
  if v!=marker:out.append(v);continue
  c=b[p];p+=1
  if c==marker:out.append(c);continue
  if c>marker:c-=1
  length=c>>3
  if c&4:length|=b[p]<<5;p+=1
  length+=4
  k=(c&3)+1;assert k<=3
  off=int.from_bytes(b[p:p+k],'little')+1;p+=k;assert off<=len(out)
  for _ in range(length):out.append(out[-off])
  assert len(out)<=n
 assert len(out)==n,(len(out),n)
 return bytes(out)
f.seek(idx);index=lz(huff(xor(f.read(),key(secret))));assert len(index)==hs
(ROOT/'index.bin').write_bytes(index)
entries=[];NONE=2**64-1

def walk(at=0,path='',parents=[]):
 own,parent,count,start=struct.unpack_from('<4Q',index,dt+at)
 assert count<10000
 for i in range(count):
  rec=struct.unpack_from('<9Q',index,ft+start+i*72);na,attr,_,_,_,addr,size,press,hp=rec
  nw=struct.unpack_from('<H',index,na)[0]*4
  upper=index[na+4:na+4+nw].split(b'\0')[0]
  name=index[na+4+nw:].split(b'\0')[0].decode('cp932')
  rel=path+name
  if attr&16:walk(addr,rel+'/',[upper]+parents);continue
  entries.append(dict(path=rel,size=size,press=press,huff=hp,offset=base+addr))
  if not name.lower().endswith('.txt'):continue
  packed=hp if hp!=NONE else press if press!=NONE else size
  f.seek(base+addr);b=xor(f.read(packed),key(secret+upper+b''.join(parents)),size)
  if hp!=NONE:
   assert (press if press!=NONE else size)<=hkb*1024*2
   b=huff(b)
  if press!=NONE:b=lz(b)
  assert len(b)==size,(rel,len(b),size)
  dst=ROOT/'extracted'/rel;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(b)
walk()
(ROOT/'inventory.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2))
print('entries',len(entries),'texts',sum(x['path'].endswith('.txt') for x in entries))
for e in entries:
 if '_jp.txt' in e['path'] or '_en.txt' in e['path']:print(e)
