# Witch's Forest 1.01 研究记录

输入：用户提供 data(1).zip、Witch's_Forest_1.01(1).exe。
ZIP 包含 data/data.dxa，原包 613690089 字节。
DXA header：Version=8，CodePage=932，Flags=0，HuffmanEncodeKB=10。
索引压缩为 Huffman + LZ；索引与文件均有 DXA 自身的资源加密。
已从用户提供的 EXE 静态字符串与目录解压校验中确认资源密钥。
未执行游戏 EXE。没有调用翻译 API。

目录解析成功：1853 个文件；全部 213 个 TXT 已成功提取并校验长度。
路径包括 data01/mes_jp.txt、wmes_jp.txt、omes_jp.txt、wtex_jp.txt、wind_jp.txt
及对应 _en 文件；event/JP、event/EN 各有 12 个事件 TXT。
不能把所有 TXT 当剧情：大量文件是地图、动作、敌人和音效数据。

编码混用：mes_jp、mes_en、omes_jp 为 CP932 可解码（不通过 UTF-8 解码）；
wmes_jp、wtex_jp 为有效 UTF-8，wind_jp 为 ASCII，不能因 ASCII 可解码就推断整个引擎编码。
event/JP/eve001 为 CP932，EN 对应文件有效 UTF-8（其中 ASCII 部分本身不证明运行时编码）。

菜单格式：数字与计数的控制行、以五个连字符起始的菜单文字、分隔行。
消息格式：sizeXY、坐标、图标指令与 ,,,,Mes_N,文字 行混排。
事件格式：//-No.xxx 标记、数字逗号分隔指令、固定行槽中的文本。
后续必须保留指令和空行，用事件级结构解析，不能全文件字符串替换。

本测试只替换原本 UTF-8 的 wtex_jp/wtex_en 标题五项，以最小改动验证中文渲染。
保留原加密资源数据，通过追加新文件数据和未压缩、仍加密的新索引完成写回。
使用给定版本的已解析索引快照；不是通用 DXA 解包/打包器。
统一适配还需要：实机测试、编码分支确认、事件文本提取/写回、字体覆盖与布局检查。
既有统一翻译程序没有被更改。

研究参考源码：
https://dxlib.xsrv.jp/temp/DXArchive_1_08.zip
https://dxlib.xsrv.jp/dxtec.html
官方 DARC_HEAD / DARC_FILEHEAD / DARC_DIRECTORY、KeyCreate、Huffman 和 LZ 实现。
research 目录保留研究脚本、文件清单和官方工具原包内容，用于后续开发复现。
research 脚本是本工作环境的研究辅助，不是给玩家直接运行的程序。
