"""Version-specific DXA8 title-menu probe. Python 3 standard library only."""
import argparse, hashlib, json, shutil, struct, zlib
from pathlib import Path
ROOT=Path(__file__).resolve().parent
EXPECTED='46196e7471dfff6ae9a34e3861baa16da896e1b72f5ba232d8877443b56148aa'
NONE=(1<<64)-1

def digest(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()

def key(s):
 if len(s)<4:s+=b'DXBDXARC'
 return struct.pack('<I',zlib.crc32(s[::2]))+struct.pack('<I',zlib.crc32(s[1::2]))[:3]

def xor(b,k,pos=0):return bytes(v^k[(i+pos)%7] for i,v in enumerate(b))

def build(source,output):
 source=Path(source);output=Path(output)
 if not source.is_file():raise ValueError('找不到输入 data.dxa')
 if output.exists():raise ValueError('输出已存在，请换一个输出文件名')
 if digest(source)!=EXPECTED:raise ValueError('原包校验不匹配；本测试仅支持你提供的 Witch Forest 1.01 原包')
 index=bytearray(zlib.decompress((ROOT/'index.zlib').read_bytes()))
 meta=json.loads((ROOT/'probe.json').read_text(encoding='utf-8'))
 secret=bytes.fromhex(meta['archive_key_string_hex'])
 with source.open('rb') as f:header=bytearray(f.read(64))
 base=struct.unpack_from('<Q',header,8)[0];ft=struct.unpack_from('<Q',header,24)[0]
 output.parent.mkdir(parents=True,exist_ok=True)
 try:
  with output.open('xb') as dst,source.open('rb') as src:
   shutil.copyfileobj(src,dst,1024*1024)
   for row in meta['changes']:
    data=(ROOT/row['payload']).read_bytes()
    while dst.tell()%4:dst.write(b'\0')
    address=dst.tell()-base
    dst.write(xor(data,key(secret+bytes.fromhex(row['key_suffix_hex'])),len(data)))
    struct.pack_into('<4Q',index,ft+row['record_offset']+40,address,len(data),NONE,NONE)
   index_start=dst.tell();dst.write(xor(index,key(secret)))
   struct.pack_into('<Q',header,16,index_start)
   flags=struct.unpack_from('<I',header,44)[0]
   struct.pack_into('<I',header,44,flags|2) # uncompressed index; encryption retained
   dst.seek(0);dst.write(header)
  # Re-open and verify new index and both translated payloads before success.
  with output.open('rb') as f:
   f.seek(index_start);assert xor(f.read(len(index)),key(secret))==index
   for row in meta['changes']:
    addr,size,press,huff=struct.unpack_from('<4Q',index,ft+row['record_offset']+40)
    f.seek(base+addr);actual=xor(f.read(size),key(secret+bytes.fromhex(row['key_suffix_hex'])),size)
    assert actual==(ROOT/row['payload']).read_bytes() and press==huff==NONE
 except Exception:
  # Preserve the failed output for diagnosis; never modify the source.
  raise
 print('OFFLINE MENU PROBE — NO API CALLS')
 print('两套菜单各修改五项；原资源包未修改。')
 print('新资源包：',output)
 print('尚需在 Windows 游戏内验证中文字体、菜单和进入游戏。')

if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('archive');p.add_argument('--output',required=True);a=p.parse_args()
 try:build(a.archive,a.output)
 except (OSError,ValueError,AssertionError) as e:p.exit(1,'STOP: '+str(e)+'\n')
