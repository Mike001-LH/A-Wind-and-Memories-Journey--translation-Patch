from __future__ import annotations
import argparse, json, re, shutil
from collections import defaultdict
from pathlib import Path

VERSION='V4.0.0-alpha8.1'
QSTR = re.compile(r'(?P<q>["\'])(?P<body>(?:\\.|(?!\1).)*?)(?P=q)')
SCREEN_ATTR = re.compile(r'^\s*(?:size|xalign|yalign|color|text_size|text_color|action|at|style)\b')
NON_SAY_PREFIXES = {
    'layout','style','image','scene','show','hide','play','queue','stop','voice',
    'camera','jump','call','use','key','timer','define','default','window','pause',
    'with','extend','nvl','layeredimage','transform','screen','label','translate',
    'python','init','return'
}
SAYLIKE_PREFIX = re.compile(r'^\s*(?P<prefix>[A-Za-z_]\w*)\s+[\"\']')

def semantic_guard_reason(line:str, kind):
    """Protect old alpha6/7 JSON from writing translations into Ren'Py control syntax."""
    if kind != 'dialogue':
        return None
    m=SAYLIKE_PREFIX.match(line)
    if m and m.group('prefix').lower() in NON_SAY_PREFIXES:
        return 'protected_renpy_control_string:' + m.group('prefix').lower()
    return None

DICTISH = re.compile(r'^(?P<key>[^"\n]+)"\s*:\s*"(?P<value>.*)$', re.S)

def load_units(path: Path):
    data=json.loads(path.read_text(encoding='utf-8'))
    if isinstance(data,dict):
        for key in ('units','translations','items'):
            if isinstance(data.get(key),list): return data[key]
    if isinstance(data,list): return data
    raise ValueError('Expected a JSON list of TranslationUnit objects')

def decode_body(body:str)->str:
    # Compatibility with alpha7.1 extraction. Do not decode \\n/\\r/\\t here:
    # normalized units intentionally preserve Ren'Py escape sequences.
    return body.replace('\\"','"').replace("\\'", "'").replace('\\\\','\\')

def escape_logical(text:str, quote:str)->str:
    text=text.replace('\\','\\\\').replace('\n','\\n').replace('\r','\\r').replace('\t','\\t')
    return text.replace(quote,'\\'+quote)

def escape_preserving_renpy(text:str, quote:str)->str:
    # Text coming from the normalized JSON can already contain Ren'Py escapes
    # such as \\n. Preserve those instead of turning them into \\\\n.
    out=[]; i=0
    while i < len(text):
        c=text[i]
        if c=='\\' and i+1 < len(text):
            out.append(text[i:i+2]); i+=2; continue
        if c==quote: out.append('\\'+quote)
        elif c=='\n': out.append('\\n')
        elif c=='\r': out.append('\\r')
        elif c=='\t': out.append('\\t')
        else: out.append(c)
        i+=1
    return ''.join(out)

def literal_candidates(line:str):
    return list(QSTR.finditer(line))

def replace_match(line,m,translation,raw_mode=False):
    q=m.group('q')
    body=escape_preserving_renpy(translation,q) if raw_mode else escape_logical(translation,q)
    return line[:m.start('body')] + body + line[m.end('body'):]

def replace_one_literal(line:str, source:str, translation:str):
    ms=literal_candidates(line)
    # 1) Raw body match. Important for \\n and escaped quote strings.
    raw=[m for m in ms if m.group('body')==source]
    if len(raw)==1: return replace_match(line,raw[0],translation,True),1,'exact_raw'
    # 2) Logical compatibility match.
    logical=[m for m in ms if decode_body(m.group('body'))==source]
    if len(logical)==1: return replace_match(line,logical[0],translation,False),1,'exact_logical'

    # 3) alpha6 parser false-positive: screen-language text followed by attrs
    # became: Select Difficulty Mode\" size ... . Only translate the real literal.
    if '"' in source and '"' in translation:
        s_head,s_tail=source.split('"',1); t_head,t_tail=translation.split('"',1)
        if s_tail==t_tail and SCREEN_ATTR.match(s_tail):
            cand=[m for m in ms if m.group('body')==s_head or decode_body(m.group('body'))==s_head]
            if len(cand)==1:
                return replace_match(line,cand[0],t_head,m.group('body')==s_head if (m:=cand[0]) else False),1,'screen_attr_recovery'

    # 4) alpha6 parser false-positive: dictionary key and value were merged as
    # key\": \"value. Keep the key untouched and replace only the value literal.
    sd=DICTISH.match(source); td=DICTISH.match(translation)
    if sd and td and sd.group('key')==td.group('key'):
        sv,tv=sd.group('value'),td.group('value')
        cand=[m for m in ms if m.group('body')==sv or decode_body(m.group('body'))==sv]
        if len(cand)==1:
            m=cand[0]
            return replace_match(line,m,tv,m.group('body')==sv),1,'dict_value_recovery'

    return None,0,'not_found'

def resolve_source(workspace:Path, rel:str):
    candidates=[workspace/'virtual_game'/rel,workspace/'decompiled'/Path(rel).name,workspace/rel]
    found=[p for p in candidates if p.exists() and p.is_file()]
    return (found[0] if found else None),[str(p) for p in candidates]

def main():
    ap=argparse.ArgumentParser(description='Game Translator V4 alpha7.4 - syntax-aware safe RenPy source writer')
    ap.add_argument('translated_json',type=Path); ap.add_argument('--workspace',type=Path,required=True)
    ap.add_argument('--output',type=Path,required=True); ap.add_argument('--report',type=Path,required=True)
    ap.add_argument('--include-unchanged',action='store_true'); args=ap.parse_args()
    units=load_units(args.translated_json); by_file=defaultdict(list); missing=[]

    # alpha7.3: remember locations that have a real screen_text extraction.
    # Older alpha6 extraction could also create a bogus dialogue unit from the
    # same Screen Language line (for example: Evidence Found\" size 18 ...).
    # The screen_text unit is the syntax-aware/canonical one and must win.
    screen_text_locs=set()
    for u in units:
        meta=u.get('metadata') or {}
        occs=meta.get('occurrences') or [{'file':u.get('file'),'line':meta.get('line'),'kind':meta.get('kind')}]
        for o in occs:
            if o.get('file') and o.get('line') and o.get('kind')=='screen_text':
                screen_text_locs.add((o['file'],int(o['line'])))

    suppressed_false_dialogue=0
    for u in units:
        tr=u.get('translation'); src=u.get('source','')
        if tr is None or tr=='': missing.append(u.get('id')); continue
        occs=(u.get('metadata') or {}).get('occurrences') or [{'file':u.get('file'),'line':(u.get('metadata') or {}).get('line'),'kind':(u.get('metadata') or {}).get('kind')}]
        for o in occs:
            if not (o.get('file') and o.get('line')): continue
            loc=(o['file'],int(o['line']))
            kind=o.get('kind')
            # Prefer the dedicated screen_text unit over the legacy malformed
            # dialogue duplicate at exactly the same source location. This also
            # safely suppresses dynamic text whose canonical screen_text is
            # intentionally unchanged (e.g. an interpolation-only bullet).
            if kind=='dialogue' and loc in screen_text_locs:
                suppressed_false_dialogue += 1
                continue
            if tr==src and not args.include_unchanged: continue
            by_file[o['file']].append((int(o['line']),src,tr,u.get('id'),kind))
    if args.output.exists(): shutil.rmtree(args.output)
    args.output.mkdir(parents=True)
    report={'version':VERSION,'input_units':len(units),'missing_translation':missing,'files':{},'patched_occurrences':0,'already_translated':0,'recovery_modes':{},'suppressed_false_dialogue':suppressed_false_dialogue,'semantic_safety_suppressed':[],'unresolved':[],'conflicts':[]}
    modes=defaultdict(int)
    for rel,ops in sorted(by_file.items()):
        src_path,tried=resolve_source(args.workspace,rel)
        if src_path is None:
            report['unresolved'].append({'file':rel,'reason':'source_file_missing','count':len(ops),'tried':tried}); continue
        try: lines=src_path.read_text(encoding='utf-8-sig').splitlines(keepends=True)
        except UnicodeDecodeError:
            report['unresolved'].append({'file':rel,'reason':'non_utf8_source','count':len(ops)}); continue
        patched=unresolved=0
        for lineno,src,tr,uid,kind in sorted(ops,key=lambda x:x[0]):
            if not (1<=lineno<=len(lines)):
                report['unresolved'].append({'id':uid,'file':rel,'line':lineno,'kind':kind,'reason':'line_out_of_range'}); unresolved+=1; continue
            old=lines[lineno-1]
            guard=semantic_guard_reason(old,kind)
            if guard:
                report['semantic_safety_suppressed'].append({'id':uid,'file':rel,'line':lineno,'kind':kind,'source':src,'translation':tr,'reason':guard})
                continue
            new,n,mode=replace_one_literal(old,src,tr)
            if n==1:
                lines[lineno-1]=new; patched+=1; report['patched_occurrences']+=1; modes[mode]+=1
            elif tr in old and src not in old: report['already_translated']+=1
            else:
                report['unresolved'].append({'id':uid,'file':rel,'line':lineno,'kind':kind,'reason':'literal_not_safely_resolved','source':src}); unresolved+=1
        dst=args.output/rel; dst.parent.mkdir(parents=True,exist_ok=True); dst.write_text(''.join(lines),encoding='utf-8')
        report['files'][rel]={'requested':len(ops),'patched':patched,'unresolved':unresolved,'source':str(src_path),'output':str(dst)}
    report['recovery_modes']=dict(sorted(modes.items()))
    (args.output/'README_PATCH.txt').write_text('Game Translator V4 alpha7.5 RenPy patch\n\nGenerated .rpy source scripts only. Test on a COPY of the game. Do not install unless the writer reports PREFLIGHT PASSED.\n',encoding='utf-8')
    args.report.parent.mkdir(parents=True,exist_ok=True); args.report.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(f'Game Translator {VERSION} - RenPy Writer'); print(f'Input units: {len(units)}'); print(f'Files written: {len(report["files"])}'); print(f'Patched occurrences: {report["patched_occurrences"]}'); print(f'Missing translations: {len(missing)}'); print(f'Unresolved writes: {len(report["unresolved"])}'); print(f'Recovery modes: {report["recovery_modes"]}'); print(f'Suppressed false dialogue duplicates: {suppressed_false_dialogue}'); print(f'Semantic safety suppressions: {len(report["semantic_safety_suppressed"])}'); print(f'Output patch: {args.output}'); print(f'Report: {args.report}')
    if report['unresolved'] or missing:
        print('STATUS: REVIEW REQUIRED - do not install yet'); raise SystemExit(2)
    print('STATUS: WRITER PREFLIGHT PASSED')
if __name__=='__main__': main()
