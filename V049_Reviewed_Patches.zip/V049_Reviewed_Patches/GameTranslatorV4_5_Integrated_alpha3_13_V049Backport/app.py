#!/usr/bin/env python3
import os,sys,json,threading,subprocess,queue
from pathlib import Path
import tkinter as tk
from tkinter import ttk,filedialog,messagebox

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from unified import detect_engine
CFG=Path.home()/".game_translator_v4.json"

class App(tk.Tk):
    def __init__(self):
        super().__init__(); self.title("Game Translator V4"); self.geometry("920x720"); self.minsize(780,600)
        self.q=queue.Queue(); self.proc=None; self.last_output=None
        self.game=tk.StringVar(); self.engine=tk.StringVar(value="请选择游戏文件夹")
        self.api=tk.StringVar(); self.cost=tk.StringVar(value="5.00"); self.batch=tk.StringVar(value="15")
        self.rounds=tk.StringVar(value="3"); self.language=tk.StringVar(value="Japanese")
        self.sample=tk.StringVar(value="10")
        self.font=tk.StringVar(); self.unrpyc=tk.StringVar(); self.glossary=tk.StringVar()
        self.save_key=tk.BooleanVar(value=False); self.stage=tk.StringVar(value="就绪")
        self.progress=tk.DoubleVar(value=0)
        self._load(); self._ui(); self.after(100,self._pump)
    def _load(self):
        if not CFG.exists(): return
        try:
            d=json.loads(CFG.read_text())
            self.cost.set(str(d.get("cost","5.00"))); self.batch.set(str(d.get("batch","15")))
            self.font.set(d.get("font","")); self.unrpyc.set(d.get("unrpyc","")); self.glossary.set(d.get("glossary",""))
            if d.get("save_key"): self.api.set(d.get("api","")); self.save_key.set(True)
        except Exception: pass
    def _save(self):
        d={"cost":self.cost.get(),"batch":self.batch.get(),"font":self.font.get(),
           "unrpyc":self.unrpyc.get(),"glossary":self.glossary.get(),"save_key":self.save_key.get()}
        if self.save_key.get(): d["api"]=self.api.get()
        try: CFG.write_text(json.dumps(d,ensure_ascii=False,indent=2))
        except Exception: pass
    def row(self,p,label,var,browse=None,secret=False):
        f=ttk.Frame(p); f.pack(fill="x",pady=4); ttk.Label(f,text=label,width=16).pack(side="left")
        ttk.Entry(f,textvariable=var,show="*" if secret else "").pack(side="left",fill="x",expand=True)
        if browse: ttk.Button(f,text="选择…",command=browse).pack(side="left",padx=(6,0))
    def _ui(self):
        p=ttk.Frame(self,padding=14); p.pack(fill="both",expand=True)
        ttk.Label(p,text="Game Translator V4",font=("",20,"bold")).pack(anchor="w")
        ttk.Label(p,text="Ren'Py + Bruns + MV/MZ + KAG 自动汉化").pack(anchor="w",pady=(0,10))
        self.row(p,"游戏文件夹",self.game,self.pick_game)
        ttk.Label(p,textvariable=self.engine,font=("",12,"bold")).pack(anchor="w",pady=(0,8))
        self.row(p,"DeepSeek API Key",self.api,secret=True)
        ttk.Checkbutton(p,text="在本机保存 API Key",variable=self.save_key).pack(anchor="w",padx=132)
        f=ttk.Frame(p); f.pack(fill="x",pady=4)
        ttk.Label(f,text="费用保护",width=16).pack(side="left"); ttk.Label(f,text="¥").pack(side="left")
        ttk.Entry(f,textvariable=self.cost,width=8).pack(side="left"); ttk.Label(f,text="   Batch").pack(side="left")
        ttk.Entry(f,textvariable=self.batch,width=7).pack(side="left")
        ttk.Label(f,text="   补译轮数").pack(side="left")
        ttk.Spinbox(f,from_=0,to=10,textvariable=self.rounds,width=4).pack(side="left")
        ttk.Label(f,text="   原文").pack(side="left")
        ttk.Combobox(f,textvariable=self.language,values=["Japanese","English"],state="readonly",width=9).pack(side="left")
        self.row(p,"MV/MZ/KAG 试译条数",self.sample)
        ttk.Label(p,text="MV/MZ 首次试译填 10；留空才运行完整汉化。试译生成单独的游戏副本。",foreground="#555").pack(anchor="w")
        adv=ttk.LabelFrame(p,text="可选设置",padding=8); adv.pack(fill="x",pady=8)
        self.row(adv,"术语表",self.glossary,lambda:self.file(self.glossary,[("JSON","*.json")]))
        self.row(adv,"Ren'Py 中文字体",self.font,lambda:self.file(self.font,[("Fonts","*.ttf *.otf")]))
        self.row(adv,"unrpyc.py",self.unrpyc,lambda:self.file(self.unrpyc,[("Python","*.py")]))
        b=ttk.Frame(p); b.pack(fill="x",pady=8)
        ttk.Button(b,text="分析游戏",command=lambda:self.start("analyze")).pack(side="left")
        ttk.Button(b,text="免费预检",command=lambda:self.start("estimate")).pack(side="left",padx=6)
        ttk.Button(b,text="开始汉化",command=lambda:self.start("run")).pack(side="left")
        ttk.Button(b,text="停止",command=self.stop).pack(side="left",padx=6)
        ttk.Button(b,text="打开输出文件夹",command=self.reveal).pack(side="right")
        ttk.Progressbar(p,variable=self.progress,maximum=100).pack(fill="x",pady=(4,2))
        ttk.Label(p,textvariable=self.stage).pack(anchor="w")
        self.log=tk.Text(p,height=22,wrap="word"); self.log.pack(fill="both",expand=True,pady=(6,0))
        self.log.insert("end","选择游戏目录即可。分析和预检不会产生翻译 API 费用。\n")
    def pick_game(self):
        x=filedialog.askdirectory()
        if not x:return
        self.game.set(x); eng,score,ev=detect_engine(Path(x)); self.engine.set(f"引擎：{eng}  ·  置信度 {score}%")
        self.last_output=Path(x).parent/(Path(x).name+("_Chinese" if eng in {"Bruns","RPG Maker MV","RPG Maker MZ"} else "_Chinese_Patch"))
        self.log.insert("end","检测： "+"; ".join(ev)+"\n"); self.log.see("end")
    def file(self,var,types):
        x=filedialog.askopenfilename(filetypes=types)
        if x:var.set(x)
    def validate(self,mode):
        if not self.game.get() or not Path(self.game.get()).is_dir(): return "请选择有效游戏文件夹。"
        eng,_,_=detect_engine(Path(self.game.get()))
        if eng=="Unknown": return "暂不支持这个游戏引擎。"
        if eng=="RPG Maker VX Ace": return "VX Ace 本测试版请使用命令行并指定 --target-language en 或 ja；详见 README_VXACE.md。"
        if mode=="run" and not (self.api.get().strip() or os.getenv("DEEPSEEK_API_KEY")): return "开始汉化前需要 DeepSeek API Key。"
        try:
            if float(self.cost.get())<=0:return "费用上限必须大于 0。"
            if int(self.batch.get())<=0:return "Batch 必须大于 0。"
            if int(self.rounds.get())<0:return "补译轮数不能为负数。"
            if eng in {"RPG Maker MV","RPG Maker MZ","KAG / XP3"} and self.sample.get().strip() and int(self.sample.get())<1:return "试译条数必须大于 0。"
        except:return "费用上限或 Batch 格式不正确。"
    def start(self,mode):
        if self.proc:return
        err=self.validate(mode)
        if err:messagebox.showerror("无法开始",err);return
        self._save(); g=self.game.get(); eng,_,_=detect_engine(Path(g))
        cmd=[sys.executable,str(ROOT/"unified.py"),g,"--batch-size",self.batch.get(),
             "--max-cost-rmb",self.cost.get(),"--repair-rounds",self.rounds.get(),
             "--source-language",self.language.get()]
        env=os.environ.copy()
        env["PYTHONIOENCODING"]="utf-8"
        if self.api.get().strip():env["DEEPSEEK_API_KEY"]=self.api.get().strip()
        if self.font.get().strip():cmd+=["--font",self.font.get().strip()]
        if self.unrpyc.get().strip():cmd+=["--unrpyc",self.unrpyc.get().strip()]
        if self.glossary.get().strip():cmd+=["--glossary",self.glossary.get().strip()]
        if eng in {"RPG Maker MV","RPG Maker MZ","KAG / XP3"} and self.sample.get().strip():
            cmd+=["--sample",self.sample.get().strip()]
            if mode=="run": self.last_output=Path(g).parent/(Path(g).name+("_Chinese_Patch" if eng=="KAG / XP3" else "_Chinese")+f"_Sample{self.sample.get().strip()}")
        if mode=="analyze":cmd+=["--analyze"]
        elif mode=="estimate":cmd+=["--estimate"]
        self.progress.set(3); self.stage.set({"analyze":"正在分析…","estimate":"正在预检…","run":"正在汉化…"}[mode])
        self.log.insert("end","\n=== "+self.stage.get()+" ===\n")
        def w():
            try:
                self.proc=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding="utf-8",bufsize=1,env=env)
                for line in self.proc.stdout:self.q.put(("log",line))
                self.q.put(("done",self.proc.wait()))
            except Exception as e:self.q.put(("err",str(e)))
        threading.Thread(target=w,daemon=True).start()
    def stop(self):
        if self.proc:self.proc.terminate();self.stage.set("正在停止…")
    def reveal(self):
        p=self.last_output
        if not p or not p.exists():messagebox.showinfo("输出","还没有生成输出文件夹。");return
        if sys.platform=="darwin":subprocess.Popen(["open",str(p)])
        elif os.name=="nt":os.startfile(str(p))
        else:subprocess.Popen(["xdg-open",str(p)])
    def _parse(self,line):
        m=re_search(r'(?:Translated total:|Translation units:)\s*(\d+)\s*/?\s*(\d+)?',line)
        if m and m[1]:
            self.progress.set(min(98,int(m[0])*100/max(1,int(m[1]))))
        elif "STATUS:" in line and ("PASSED" in line or "COMPLETE" in line): self.progress.set(max(self.progress.get(),90))
    def _pump(self):
        try:
            while True:
                typ,val=self.q.get_nowait()
                if typ=="log":self.log.insert("end",val);self.log.see("end");self._parse(val)
                elif typ=="done":
                    self.progress.set(100 if val==0 else self.progress.get());self.stage.set("完成" if val==0 else "已停止 / 发生错误")
                    self.proc=None
                else:self.log.insert("end","ERROR: "+val+"\n");self.stage.set("错误");self.proc=None
        except queue.Empty:pass
        self.after(100,self._pump)

def re_search(p,s):
    import re
    m=re.search(p,s); return m.groups() if m else None
if __name__=="__main__":App().mainloop()
