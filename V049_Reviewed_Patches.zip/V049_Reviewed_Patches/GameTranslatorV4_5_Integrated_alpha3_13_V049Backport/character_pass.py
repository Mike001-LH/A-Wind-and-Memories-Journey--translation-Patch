"""Alpha6.3 Character Pass: translate character_name units first and freeze them."""
import argparse,json,os
from pathlib import Path
from core.models import TranslationUnit
from core.glossary import load_glossary
from core.translator import translate_units
from core.character_glossary import build_character_glossary,save_character_glossary
from providers.deepseek import DeepSeekProvider

def unit(x):
    return TranslationUnit(id=x["id"],source=x["source"],engine=x["engine"],file=x["file"],location=x["location"],
        translation=x.get("translation"),speaker=x.get("speaker"),context=x.get("context",[]),
        protected_tokens=x.get("protected_tokens",[]),metadata=x.get("metadata",{}))

def load_dotenv():
    for env in [Path.cwd()/".env",Path(__file__).resolve().parent.parent/".env"]:
        if not env.exists(): continue
        for line in env.read_text(encoding="utf-8").splitlines():
            line=line.strip()
            if not line or line.startswith("#") or "=" not in line: continue
            k,v=line.split("=",1); k=k.strip(); v=v.strip()
            if len(v)>=2 and v[0]==v[-1] and v[0] in "\"'": v=v[1:-1]
            os.environ.setdefault(k,v)
        break

def main():
    load_dotenv()
    p=argparse.ArgumentParser(description="Translate all character_name units first and create a stable hard glossary")
    p.add_argument("units")
    p.add_argument("--checkpoint",required=True)
    p.add_argument("--output",required=True,help="character_glossary.json to review/edit before dialogue translation")
    p.add_argument("--glossary",help="User glossary; explicit user terms win")
    p.add_argument("--batch-size",type=int,default=20)
    p.add_argument("--source-language",default="English")
    p.add_argument("--attempts",type=int,default=3)
    a=p.parse_args()
    data=json.loads(Path(a.units).read_text(encoding="utf-8"))
    chars=[unit(x) for x in data if x.get("metadata",{}).get("kind")=="character_name"]
    provider=DeepSeekProvider()
    state,n=translate_units(chars,provider,a.checkpoint,load_glossary(a.glossary),a.batch_size,None,a.source_language,a.attempts)
    byid={u.id:u for u in chars}
    cg=build_character_glossary(byid,state["translations"])
    # Explicit user glossary is intentionally NOT copied into this file; translate_units merges it later.
    save_character_glossary(a.output,cg)
    print(f"Character units: {len(chars)}")
    print(f"Translated this run: {n}")
    print(f"Character glossary entries (including aliases): {len(cg)}")
    print("Review/edit this file before translating dialogue:",Path(a.output).resolve())

if __name__=="__main__": main()
