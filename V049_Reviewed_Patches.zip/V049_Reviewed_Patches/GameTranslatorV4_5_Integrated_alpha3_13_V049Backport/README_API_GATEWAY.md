新版分阶段省钱流程请先阅读 README_STAGED_TRANSLATION.md。以下保留 Gateway 基础用法。

# 线衣 API 与日语 VX Ace 翻译

本版在原 alpha3_3_1 上加入 VX Ace 的可切换 API。原有引擎及英文显示修复保留；新 API 参数目前仅用于 VX Ace。日语默认保留游戏原字体和字号，不添加英文显示修复脚本。

## 保存密钥

在本工具目录运行：

```bash
python3 -m providers.configure --provider xianyi
```

粘贴线衣密钥并回车。隐藏输入不显示星号。它保存为本机 `.env` 中的 `XIANYI_API_KEY`，不会覆盖 `DEEPSEEK_API_KEY`。如果原来的官方密钥只放在旧版工具目录，另运行：

```bash
python3 -m providers.configure --provider deepseek
```

两把密钥分别配置。不要把 `.env` 分享出去。已有 shell 环境变量优先于 `.env`。

## 先测 30 条日语剧情

```bash
python3 unified.py "/Users/mike/Downloads/A风与追忆之旅 - demoV0.49/备用原版" --provider xianyi --source-language Chinese --target-language ja --sample 30 --vx-sample-profile story --batch-size 10 --repair-rounds 1 --max-api-calls 6 --allow-partial --workdir "/Users/mike/Downloads/V049_Japanese_Xianyi_Test_Work" --output "/Users/mike/Downloads/V049_Japanese_Xianyi_Story_Test"
```

单独测试工作目录确保原来已翻译的日语样本不会跳过接口测试。输出是 Data 补丁，不是完整游戏。复制匹配版本的原游戏，将补丁 Data 中的文件合并到该副本 Data；不要删除整个 Data，不叠加英文补丁。样本之外保持中文，属于正常现象。测试对白、字体、控制码和窗口显示。

默认：`https://noxianyi.zeabur.app/v1`，模型 ID `deepseek-ai/deepseek-v4.1-flash`。这是用户网关列出的 ID。请求格式沿用用户已验证的英语测试：不发送 response_format 和 thinking 字段。日语提示已接入，但本次开发没有用用户密钥发真实日语请求，需要以上实测。

可选 `--api-thinking disabled` 会发送关闭思考参数；该站是否支持尚未确认。遇到不支持参数的 HTTP 错误会暂停，明确改回 `--api-thinking omit` 再续跑。不会自动换官方接口。模型和地址可通过 `--api-model`、`--api-base-url` 覆盖。

## 费用和请求控制

该站真实计费尚未确认。未知价格记为 null/unknown，不套用官方 DeepSeek 价格，不宣称免费。未知价格必须设置 `--max-api-calls`。上限包括失败的发送尝试；每次运行重新计数。请求上限不是人民币费用保证。官方默认计价仍是旧版本估算，实际费用以服务商为准。

每次显示输入、输出和 reasoning tokens。思考 tokens 已包含在输出 tokens 内，不重复计算。有效用量会在模型返回无效翻译时仍记录；网络超时或服务未提供用量时无法估算，请查 Usage Logs。

若确认站点单价，可设 `--api-input-rmb`、`--api-output-rmb`，单位均为人民币/百万 tokens，可另设 `--api-cached-input-rmb`（默认等于输入价格）。此时 `--max-cost-rmb` 才用于网关费用估算；单次请求可能超过剩余估算预算，实际费用仍以站点为准。

## 正式续跑与翻译复用

测试通过后，复用原日语工作目录和测试记忆：

```bash
python3 unified.py "/Users/mike/Downloads/A风与追忆之旅 - demoV0.49/备用原版" --provider xianyi --source-language Chinese --target-language ja --batch-size 10 --repair-rounds 3 --max-api-calls 50 --allow-partial --reuse-from "/Users/mike/Downloads/V049_Japanese_Xianyi_Test_Work" --output "/Users/mike/Downloads/V049_Japanese_Xianyi_Full_1"
```

默认工作目录为原游戏路径加 `_GT_Work_ja`，与英文 `_GT_Work_en` 分离。已通过审计的同语言翻译会复用；切换服务商也不会重翻这些条目。重复文本复用和旧版本迁移保留。每批保存检查点；达到请求上限产生部分补丁。继续时保留工作目录，换一个尚不存在的输出路径，例如 Full_2。不得把英文记忆用于日语。

回到官方：`--provider deepseek`，使用 DEEPSEEK_API_KEY。其余目标语言、工作目录、复用方式不变。

## 验证

58 项离线 Python 测试通过：原引擎回归、密钥隔离、日语请求、JSON 验证、用量计数、错误暂停、请求上限、续跑和缓存。未执行真实网关收费请求，未在 Windows 启动新日语补丁；请先做样本测试。
