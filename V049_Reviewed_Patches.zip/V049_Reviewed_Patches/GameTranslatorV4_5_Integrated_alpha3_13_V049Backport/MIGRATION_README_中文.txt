跨版本翻译迁移：正式命令

入口：python3 translator.py migrate-vx --help
本次正式新增的是 VX Ace 跨版本迁移；其他引擎保留已有功能，不声明共用本命令。
此命令永远不调用翻译 API。它生成新版本的可续翻工作目录和部分翻译补丁。

功能：
1. 读取旧工作目录时，优先读取最新checkpoint，避免只使用可能滞后的translation_memory。
2. 没有旧工作目录时，可从“旧版原始Data + 对应旧补丁”核对并恢复翻译记忆。
3. 对新版本重新提取文本，按原文、类型、文件和上下文匹配；不是按序号盲目覆盖。
4. 新增、改写、冲突和上下文待核对条目进入报告；相似文本只作旧译参考，不直接视为完成。
5. 英文、日文、中文目标分别校验，不能串用缓存。
6. 新版地图、事件指令、数值和脚本逻辑保留；旧工作目录和旧补丁只读。
7. 新进度可通过原有 unified.py 的省钱模式/断点续翻继续处理，只请求剩余条目。
8. 风与追忆0.50另有经过核对的脚本/布局迁移配置。未来脚本有变化时需要重新检查；不承诺任意脚本自动兼容。

A. 有旧工作目录：
python3 translator.py migrate-vx "/新版本游戏" --from-work "/旧工作目录" --target-language en --workdir "/新英文工作目录" --output "/新英文迁移补丁"

B. 只有旧补丁，同时还有对应旧原版：
python3 translator.py migrate-vx "/新版本游戏" --old-game "/旧版本原版游戏" --old-patch "/旧英文补丁" --source-language Chinese --target-language en --workdir "/新英文工作目录" --output "/新英文迁移补丁"

只有译文补丁、没有旧原文或翻译记忆时，无法可靠反推原文；不能强行做“准确迁移”。
这次已利用现存0.49原始数据，从你提供的两份旧补丁恢复了 Bundle_en/Bundle_ja，所以你不必重新找0.49原版。

C. 这次0.49→0.50，自己运行迁移：
解压整个 V050_Migration_Package 到 ~/Documents/local-llm-translator 后：

cd "$HOME/Documents/local-llm-translator/V050_Migration_Package/GameTranslatorV4_5_Integrated_alpha3_10_VXMigration"

python3 translator.py migrate-vx "/Users/mike/Downloads/A风与追忆之旅 - demoV0.5" --from-work "../Bundle_en" --source-language Chinese --target-language en --workdir "$HOME/Documents/local-llm-translator/V050_Migrate_EN_Work" --output "$HOME/Downloads/V050_English_Migrated_Local"

python3 translator.py migrate-vx "/Users/mike/Downloads/A风与追忆之旅 - demoV0.5" --from-work "../Bundle_ja" --source-language Chinese --target-language ja --workdir "$HOME/Documents/local-llm-translator/V050_Migrate_JA_Work" --output "$HOME/Downloads/V050_Japanese_Migrated_Local"

以上均不付费、不需要密钥。工作目录/output必须是新的空路径。不要改动原版游戏Data。
也可直接使用包内已生成的补丁与restore_progress.py恢复其进度，无需重复执行C。

D. 后续续翻：
仍指向同一个新版原游戏，source/target语言不变，--workdir 指向C生成的对应工作目录；
--output 使用新的目录（例如V050_English_Translated_1），不再加--from-work。
示例：
python3 unified.py "/Users/mike/Downloads/A风与追忆之旅 - demoV0.5" --provider deepseek --source-language Chinese --target-language en --economy --batch-size 20 --batch-chars 3500 --repair-rounds 2 --max-api-calls 150 --max-cost-rmb 1 --allow-partial --workdir "$HOME/Documents/local-llm-translator/V050_Migrate_EN_Work" --output "$HOME/Downloads/V050_English_Translated_1"
D才会产生API调用；实际金额以服务商账单为准。每次重建会保留本次通过核对的脚本排版修复。

报告：ace_migration_report.json、ace_completion_report.json、ace_excluded_review.json。
保留完整工作目录，特别是 checkpoint、units、manifest、translation_memory 和 version_script_transfer。
未来0.51：以0.50最终工作目录作为--from-work，将0.51原版作为game，并新建工作目录；原来的0.50缓存不会被改写。
新脚本布局兼容性若未经核对会列入待检查，不会强行回滚成旧脚本。
