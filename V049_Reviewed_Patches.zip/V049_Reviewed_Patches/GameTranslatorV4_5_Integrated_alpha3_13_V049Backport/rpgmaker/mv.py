from __future__ import annotations
import copy
import hashlib
import json
import re
from collections import Counter
from pathlib import Path
from core.completion import atomic_json

# MV/MZ escape codes, including plugin-style named codes. Order/multiplicity preserved.
TOKEN = re.compile(r'\\(?:[A-Za-z]+(?:\[[^\]\r\n]*\]|<[^>\r\n]*>)?|[\\{}$.|!><^])|%\d+')
LOCALE_REF = re.compile(r'(?<!\\)\{[^{}\r\n]*(?<!\\)\}')
FIELDS = {
    'Actors': ('name', 'nickname', 'profile'), 'Classes': ('name',),
    'Skills': ('name', 'description', 'message1', 'message2'),
    'Items': ('name', 'description'), 'Weapons': ('name', 'description'),
    'Armors': ('name', 'description'), 'Enemies': ('name',),
    'States': ('name', 'message1', 'message2', 'message3', 'message4'),
}

# Only the literal lowercase name-window tag has a translatable argument.
# Keep all other plugin arguments and ordinary engine escape codes exact.
NAME_TAG = re.compile(r'\\n<[^<>\\\r\n]+>')


def structural_tokens(text):
    return ['\\n<NAME>' if NAME_TAG.fullmatch(token) else token
            for token in TOKEN.findall(text)]


def engine_for(game):
    game = Path(game).resolve()
    for root in (game, game/'www'):
        if not (root/'data'/'System.json').is_file(): continue
        for core, name in (('rmmz_core.js', 'RPG Maker MZ'), ('rpg_core.js', 'RPG Maker MV')):
            if (root/'js'/core).is_file(): return root, name, core
    raise ValueError('RPG Maker MV/MZ requires data/System.json and js/rpg_core.js or rmmz_core.js (root or www/)')


def root_for(game):
    return engine_for(game)[0]


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def get(obj, path):
    for key in path: obj = obj[key]
    return obj


def put(obj, path, value):
    parent = get(obj, path[:-1])
    parent[path[-1]] = value


def extract(game, locale=None):
    game = Path(game).resolve()
    root, engine, _ = engine_for(game)
    prefix = 'mz' if engine == 'RPG Maker MZ' else 'mv'
    units, hashes, skipped = [], {}, []
    def add(rel, obj, paths, kind, context=(), aliases=None):
        texts = [get(obj, path) for path in paths]
        if not all(isinstance(t, str) for t in texts): return
        source = '\n'.join(texts)
        if not any(c.isalpha() for c in TOKEN.sub('', source)): return
        identity = json.dumps([rel, paths], ensure_ascii=False, separators=(',', ':'))
        units.append({'id': prefix + ':' + hashlib.sha256(identity.encode()).hexdigest()[:24],
                      'engine': 'rpgmaker_' + prefix, 'file': rel, 'location': identity,
                      'source': source, 'translation': '', 'context': list(context),
                      'protected_tokens': TOKEN.findall(source),
                      'metadata': {'kind': kind, 'paths': paths, 'aliases': aliases or [],
                                   'line_count': len(paths)}})
    def commands(rel, obj, path):
        rows = get(obj, path)
        if not isinstance(rows, list): return
        index = 0
        context = []
        # Link branch labels (402) to the actual choice (102) at the same indent.
        choices = {}
        while index < len(rows):
            row = rows[index]
            if not isinstance(row, dict): index += 1; continue
            code, params, indent = row.get('code'), row.get('parameters', []), row.get('indent', 0)
            if code in (401, 405):
                paths = []
                while index < len(rows) and rows[index].get('code') == code:
                    if rows[index].get('parameters') and isinstance(rows[index]['parameters'][0], str):
                        paths.append(path+[index, 'parameters', 0])
                    index += 1
                if paths:
                    add(rel, obj, paths, 'dialogue' if code == 401 else 'scroll_text', context[-3:])
                    context.append('\n'.join(get(obj, q) for q in paths))
                continue
            if code == 102 and params and isinstance(params[0], list):
                choices[indent] = {}
                for number, label in enumerate(params[0]):
                    if not isinstance(label, str): continue
                    before = len(units)
                    add(rel, obj, [path+[index,'parameters',0,number]], 'choice', context[-3:])
                    if len(units) > before: choices[indent][number] = units[-1]
            elif code == 402 and len(params) >= 2:
                unit = choices.get(indent, {}).get(params[0])
                if unit and params[1] == unit['source']:
                    unit['metadata']['aliases'].append(path+[index,'parameters',1])
            elif code == 404:
                choices.pop(indent, None)
            elif code in (320, 324, 325) and len(params) >= 2:
                add(rel, obj, [path+[index,'parameters',1]],
                    {320:'actor_name',324:'actor_nickname',325:'actor_profile'}[code], context[-3:])
            index += 1
    for file in sorted((root/'data').glob('*.json')):
        name = file.stem
        supported = name in FIELDS or name in ('System','CommonEvents','Troops') or re.fullmatch(r'Map\d+', name)
        if not supported:
            skipped.append(file.name); continue
        obj = json.loads(file.read_text(encoding='utf-8-sig'))
        rel = file.relative_to(game).as_posix()
        hashes[rel] = digest(file)
        if name in FIELDS:
            for i, row in enumerate(obj):
                if not isinstance(row, dict): continue
                for field in FIELDS[name]:
                    if isinstance(row.get(field), str): add(rel, obj, [[i, field]], 'database_'+field)
        elif name == 'System':
            for field in ('gameTitle', 'currencyUnit'):
                if isinstance(obj.get(field), str): add(rel, obj, [[field]], 'system')
            for field in ('armorTypes','weaponTypes','equipTypes','skillTypes','elements'):
                for i, value in enumerate(obj.get(field, [])):
                    if isinstance(value, str): add(rel, obj, [[field,i]], 'system_term')
            def terms(value, path):
                if isinstance(value, str): add(rel, obj, [path], 'system_term')
                elif isinstance(value, list):
                    for i, item in enumerate(value): terms(item, path+[i])
                elif isinstance(value, dict):
                    for key, item in value.items(): terms(item, path+[key])
            terms(obj.get('terms', {}), ['terms'])
        elif name == 'CommonEvents':
            for i, event in enumerate(obj):
                if isinstance(event, dict) and isinstance(event.get('list'), list): commands(rel, obj, [i,'list'])
        elif name == 'Troops':
            for i, troop in enumerate(obj):
                if not isinstance(troop, dict): continue
                for j, page in enumerate(troop.get('pages', [])):
                    commands(rel, obj, [i,'pages',j,'list'])
        else:
            if isinstance(obj.get('displayName'), str): add(rel, obj, [['displayName']], 'map_display_name')
            for i, event in enumerate(obj.get('events', [])):
                if not isinstance(event, dict): continue
                for j, page in enumerate(event.get('pages', [])):
                    commands(rel, obj, ['events',i,'pages',j,'list'])
    manifest = {'engine': engine, 'game': str(game), 'web_root': root.relative_to(game).as_posix(),
                'source_hashes': hashes, 'units': len(units), 'skipped_data_files': skipped,
                'excluded': ['Plugin JS/parameters and commands (including MZ 357/657)', 'script commands 355/655',
                             'notes/comments', 'resource filenames', 'image-embedded text',
                             'editor-only event/map names', 'encrypted/custom packed JSON']}
    if locale and locale != "all":
        from rpgmaker.locale_scope import scoped_extract
        return scoped_extract(game, locale, units, manifest)
    return units, manifest


def audit(unit):
    source, target = unit['source'], unit.get('translation') or ''
    blocking, advisory = [], []
    if not target.strip(): return {'blocking': ['empty'], 'advisory': []}
    if structural_tokens(source) != structural_tokens(target): blocking.append('escape_token_mismatch')
    if any(not token[3:-1].strip() for token in TOKEN.findall(target) if NAME_TAG.fullmatch(token)):
        blocking.append('empty_speaker_name')
    if source.count('\n') != target.count('\n'): blocking.append('newline_mismatch')
    if '\x00' in target: blocking.append('nul_character')
    if unit.get('metadata',{}).get('locale_scope') and LOCALE_REF.findall(source) != LOCALE_REF.findall(target):
        blocking.append('localization_tag_mismatch')
    visible = TOKEN.sub('', LOCALE_REF.sub('',target) if unit.get('metadata',{}).get('locale_scope') else target)
    if re.search(r'[\u3041-\u3096]{2,}', visible): blocking.append('hiragana_prose_residue')
    if target == source and re.search(r'[\u3041-\u3096]', source): blocking.append('same_as_japanese_source')
    elif target == source: advisory.append('unchanged_name_or_source')
    return {'blocking': list(dict.fromkeys(blocking)), 'advisory': advisory}


def patched_documents(game, units, manifest, allow_partial=False):
    game = Path(game).resolve()
    expected, current = extract(game, locale=manifest.get("locale_scope"))
    if manifest['source_hashes'] != current['source_hashes']:
        raise ValueError('Game data changed since extraction; start a new workspace')
    byid = {u['id']: u for u in units}
    if len(byid) != len(units) or set(byid) != {u['id'] for u in expected}:
        raise ValueError('Translation unit IDs/count do not match current game')
    docs, unresolved = {}, []
    for original in expected:
        u = byid[original['id']]
        if any(u[k] != original[k] for k in ('source','file','metadata')):
            raise ValueError('Translation locations/source were modified: '+u['id'])
        issues = audit(u)['blocking']
        if manifest.get('locale_scope') and LOCALE_REF.findall(u['source']) != LOCALE_REF.findall(u.get('translation') or ''):
            issues.append('localization_tag_mismatch')
        if issues:
            unresolved.append({'id':u['id'], 'issues':issues})
            if allow_partial: continue
            raise ValueError('Unresolved unit: '+u['id']+' '+','.join(issues))
        rel = u['file']
        if rel not in docs:
            from rpgmaker.locale_scope import read_document
            docs[rel] = read_document(game,rel)
        paths = u['metadata']['paths']
        values = u['translation'].split('\n') if len(paths) > 1 else [u['translation']]
        if len(values) != len(paths): raise ValueError('Message line count changed')
        for path, value in zip(paths, values): put(docs[rel], path, value)
        for path in u['metadata']['aliases']: put(docs[rel], path, u['translation'])
    return docs, unresolved
