from __future__ import annotations
import json
from pathlib import Path
from core.completion import atomic_json, complete, fingerprint
from core.safe_output import publish_copy
from core.glossary import load_glossary
from providers.config import make_provider, SessionAccounting, RequestStop
from bruns.translate import load_env
from rpgmaker.mv import extract, audit, patched_documents, NAME_TAG, LOCALE_REF


def prepare(game, work, locale=None):
    work = Path(work); work.mkdir(parents=True, exist_ok=True)
    units, manifest = extract(game, locale=locale)
    prefix = 'mz' if manifest['engine'] == 'RPG Maker MZ' else 'mv'
    path = work/f'{prefix}_manifest.json'
    if path.exists():
        old = json.loads(path.read_text(encoding='utf-8'))
        if old['source_hashes'] != manifest['source_hashes'] or old['game'] != manifest['game'] or old.get('locale_scope') != manifest.get('locale_scope'):
            raise ValueError('Game/workspace mismatch; select a new --workdir')
    atomic_json(path, manifest)
    atomic_json(work/f'{prefix}_units.json', units)
    return units, manifest


def run(game, work, output, args, provider=None):
    work = Path(work)
    units, manifest = prepare(game, work, getattr(args,'locale',None))
    prefix = 'mz' if manifest['engine'] == 'RPG Maker MZ' else 'mv'
    print(f'{manifest["engine"]}: {len(units)} text units; {len(manifest["source_hashes"])} data files')
    from rpgmaker.dk_locale_fix import detect
    from rpgmaker.mv import engine_for
    locale_parameters = detect(engine_for(game)[0])
    if locale_parameters and not manifest.get('locale_scope'):
        print('WARNING: DKTools localization active; standard data coverage does NOT include locale dictionaries:', locale_parameters.get('Localization Folder'))
        print('Available locale slots:', ', '.join(json.loads(x)['Locale'] for x in json.loads(locale_parameters['Languages'])))
        print('Choose --locale to include its dictionaries and branch scope; clean means extracted scope only.')
    if manifest.get('locale_report'):
        report=manifest['locale_report'];atomic_json(work/f'{prefix}_locale_report.json',report)
        print('Locale:', report['selected_locale'], '| shared:', report['shared_units'], '| selected branch:', report['selected_branch_units'], '| other branch skipped:', report['other_branch_units'], '| dictionary:',report['dictionary_units'], '| plugin labels:',report['plugin_display_units'])
        if report['translation_blocked']:print('BLOCKED: unknown language conditions; inspect locale report before translation')
    if not units: raise ValueError('No supported RPG Maker text found; check encrypted/custom data')
    if args.analyze or args.estimate:
        print('Source characters:', sum(len(u['source']) for u in units))
        print('Excluded:', '; '.join(manifest['excluded']))
        print('STATUS: ANALYSIS COMPLETE — NO API CALLS'); return
    if locale_parameters and len(json.loads(locale_parameters.get('Languages','[]')))>1 and not getattr(args,'locale',None):
        raise ValueError('Multiple DKTools locales detected. Choose --locale ja/en/ko from analysis, or --locale all for legacy data-only all-branch translation. No API calls made.')
    if manifest.get('locale_report',{}).get('translation_blocked'):
        raise ValueError('Unsupported language condition: see locale report. No API calls made.')
    cp = work/f'{prefix}_checkpoint.json'
    sig = fingerprint(units)
    state = {'input_fingerprint': sig, 'translations': {}, 'spent_rmb': 0.}
    if cp.exists():
        state = json.loads(cp.read_text(encoding='utf-8'))
        if state.get('input_fingerprint') != sig: raise ValueError('Checkpoint source mismatch')
        for u in units: u['translation'] = state.get('translations', {}).get(u['id'], '')
    if getattr(args,'reuse_from',None):
        from rpgmaker.locale_scope import reuse_checkpoint
        migration=reuse_checkpoint(units,args.reuse_from,prefix)
        atomic_json(work/f'{prefix}_reuse_report.json',migration);print('Read-only cache reuse:',migration['reused'])
    if manifest.get('locale_scope'):
        from rpgmaker.menu_text_fix import FIELDS
        for u in units:
            if u['metadata']['kind']=='plugin_display' and not u.get('translation'):
                path=u['metadata']['paths'][0]
                for (name,param),fields in FIELDS.items():
                    pair=fields.get(path[-1]) if param==path[-2] else None
                    if pair and u['source'] in pair:u['translation']=pair[1]
            if u['metadata']['kind']=='locale_dictionary' and u['metadata']['paths']==[[manifest['locale_scope']]]:
                u['translation']='简体中文'
    glossary = load_glossary(args.glossary)
    # Exact glossary fills reuse the V4 glossary format and still pass MV structural QA.
    for u in units:
        term = glossary.get(u['source'])
        if term and not u.get('translation') and not audit(dict(u,translation=term['target']))['blocking']:
            u['translation'] = term['target']
    sample = getattr(args, 'sample', None)
    if sample:
        # Choose dialogue first so a small test checks actual story text.
        selected = sorted(units, key=lambda u: (u['metadata']['kind'] != 'dialogue', u['file'], u['location']))[:sample]
        print(f'Sample mode: {len(selected)} story-first units; the rest stay in the original language')
    else:
        selected = units
    base_audit = audit
    def active_audit(u):
        result = base_audit(u)
        if locale_parameters:
            import re
            if LOCALE_REF.findall(u['source']) != LOCALE_REF.findall(u.get('translation') or ''):
                result['blocking'].append('localization_tag_mismatch')
        return result
    def save(rows, st):
        st['translations'] = {u['id']: u.get('translation','') for u in rows}
        atomic_json(cp, st)
        atomic_json(work/f'{prefix}_units_translated.json', rows)
        issues = [dict(id=u['id'], source=u['source'], translation=u.get('translation',''), **active_audit(u)) for u in rows]
        atomic_json(work/f'{prefix}_completion_report.json', {'total':len(rows),
                    'blocking_count':sum(bool(r['blocking']) for r in issues),
                    'stop_reason':st.get('stop_reason','running'),
                    'history':st.get('completion_history',[]),
                    'unresolved':[r for r in issues if r['blocking']],
                    'advisories':[r for r in issues if r['advisory']],
                    'coverage_scope':manifest.get('locale_report',{'scope':'standard extracted data only'})})
    if getattr(args, 'economy', False):
        print('省钱模式：短 ID / 紧凑 JSON / 共用规则 / 上下文引用；每批最多', args.batch_size, '条、', getattr(args, 'batch_chars', 3500), '原文字；实际节省以 token 用量为准')
    load_env()
    accounting = SessionAccounting(args, state)
    def send(batch, phase):
        nonlocal accounting, provider
        if provider is None:
            try: provider = make_provider(args)
            except (ValueError, RuntimeError) as exc:
                raise RequestStop(str(exc), 'provider_configuration_error') from exc
        accounting.before()
        payload = []
        for u in batch:
            item = dict(u)
            item['protected_tokens'] = [t for t in u.get('protected_tokens', []) if not NAME_TAG.fullmatch(t)]
            rules = ('Keep physical newline count and ALL backslash escape codes exactly. '
                'For literal lowercase backslash-n<speaker> name-window tags, translate only the speaker name '
                'inside the angle brackets; preserve the backslash, lowercase n, and brackets. '
                'Never turn that tag into a physical newline. Other escape arguments stay exact. '
                'Translate completely into Simplified Chinese, including Japanese residue. '
                'Preserve every {localization_reference} exactly; translate dictionary VALUES, never keys.')
            if getattr(args, 'economy', False):
                item['shared_rules'] = [rules]
            else:
                item['context'] = u.get('context', []) + [rules]
            if locale_parameters:
                import re
                item['protected_tokens'] += LOCALE_REF.findall(u['source'])
            payload.append(item)
        def record_usage(usage):
            used = {'prompt_tokens':usage.prompt_tokens, 'completion_tokens':usage.completion_tokens,
                    'prompt_cache_hit_tokens':usage.cache_hit_tokens, 'prompt_cache_miss_tokens':usage.cache_miss_tokens,
                    'reasoning_tokens':getattr(usage, 'reasoning_tokens', 0)}
            if getattr(usage, 'reported', True): accounting.record(used)
            else: accounting.missing()
            return used
        try:
            options = dict(glossary=glossary, source_language=args.source_language)
            if getattr(args, 'economy', False): options['target_language'] = 'Simplified Chinese'
            made, usage = provider.translate_batch(payload, **options)
        except (KeyboardInterrupt, SystemExit):
            accounting.missing()
            raise
        except Exception as exc:
            if getattr(exc, 'usage', None) is not None: record_usage(exc.usage)
            else: accounting.missing()
            print('API request error:', getattr(exc, 'reason', 'request_error'), str(exc), flush=True)
            raise
        return made, record_usage(usage)
    def request(batch, phase):
        # At most one split (or one retry for a singleton) per failed batch.
        # Transport/auth failures never enter this path.
        recoverable = {'provider_invalid_json', 'provider_truncated'}
        def failure(exc, rows, retry):
            state.setdefault('format_errors', []).append({
                'phase': phase, 'ids': [u['id'] for u in rows],
                'reason': getattr(exc, 'reason', 'provider_error'),
                'retry': retry})
            save(units, state)
        try:
            return send(batch, phase)
        except Exception as exc:
            if getattr(exc, 'reason', None) not in recoverable: raise
            failure(exc, batch, False)
            print('Invalid response format; retrying smaller batch (counts toward request cap).', flush=True)
        midpoint = max(1, len(batch) // 2)
        parts = [batch[:midpoint], batch[midpoint:]] if len(batch) > 1 else [batch]
        result = {}; last_usage = {}
        for part in parts:
            try:
                made, usage = send(part, phase)
            except Exception as exc:
                if getattr(exc, 'reason', None) not in recoverable: raise
                failure(exc, part, True)
                print('Format retry failed; queued', len(part), 'units for later repair. Continuing.', flush=True)
                continue
            # Persist passing child results immediately. If the next child hits
            # a cap/error/interruption, these translations must still survive.
            for u in part:
                value = made.get(u['id'])
                if isinstance(value, str) and value.strip():
                    if not active_audit(dict(u, translation=value))['blocking']:
                        u['translation'] = value
                        state.setdefault('rejected_candidates', {}).pop(u['id'], None)
                    else:
                        state.setdefault('rejected_candidates', {})[u['id']] = value
            save(units, state)
            result.update(made); last_usage = usage
        return result, last_usage
    try:
        complete(selected, active_audit, request, lambda _rows, st: save(units, st), rounds=args.repair_rounds, batch_size=args.batch_size,
                 stall_rounds=args.stall_rounds, state=state,
                 max_batch_chars=getattr(args, 'batch_chars', 3500) if getattr(args, 'economy', False) else None)
    finally:
        if accounting is not None:
            accounting.finish(state.get('stop_reason', 'interrupted'))
            save(units, state)
    if sample and not any(u.get('translation') and not audit(u)['blocking'] for u in selected):
        raise ValueError(f'Sample produced no valid translated units; inspect {prefix}_checkpoint.json and {prefix}_completion_report.json')
    docs, unresolved = patched_documents(game, units, manifest, args.allow_partial or bool(sample))
    def patch(stage):
        from rpgmaker.locale_scope import write_document,read_document,label_chinese_slot
        if manifest.get('locale_scope'):
            rel=(Path(manifest['web_root'])/'js/plugins.js').as_posix()
            if rel not in docs:docs[rel]=read_document(game,rel)
            label_chinese_slot(docs[rel],manifest['locale_scope'])
        for rel, data in docs.items():
            target = stage/rel
            write_document(target, data)
            if read_document(stage,rel) != data: raise ValueError('Document verification failed')
    publish_copy(game, output, patch)
    atomic_json(work/f'{prefix}_build_report.json', {'output':str(output),'changed_files':list(docs),
                'unresolved':unresolved,'sample_units':len(selected) if sample else None,
                'status':'partial' if unresolved else 'passed',
                'coverage_scope':manifest.get('locale_report',{'scope':'standard extracted data only'}),
                'runtime_verification_required':True})
    print(f'DONE — {manifest["engine"]} translated game:', output)
    if state.get('stop_reason') not in ('clean', 'coverage_target'):
        print('NOTICE: stopped:', state.get('stop_reason'), '— see checkpoint errors and completion report')
    if unresolved: print('WARNING: partial build; untranslated entries retained:',len(unresolved))
