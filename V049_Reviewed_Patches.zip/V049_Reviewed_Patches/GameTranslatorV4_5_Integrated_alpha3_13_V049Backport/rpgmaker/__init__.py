"""RPG Maker MV/MZ standard JSON adapter; custom plugins are excluded."""
