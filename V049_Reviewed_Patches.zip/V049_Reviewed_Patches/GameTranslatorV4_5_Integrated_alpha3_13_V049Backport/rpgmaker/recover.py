"""Recover validated cached candidates and build a fresh copy without API calls."""
from __future__ import annotations
import argparse
import json
import shutil
from datetime import datetime
from pathlib import Path
from core.completion import atomic_json, fingerprint
from core.safe_output import validate_paths, publish_copy
from rpgmaker.mv import extract, audit, patched_documents, engine_for
from rpgmaker.reflow import repair_newlines as reflow_candidate


def recover(game, work, output, allow_partial=False, repair_newlines=False):
    game, work, output = (Path(p).expanduser().resolve() for p in (game, work, output))
    validate_paths(game, work, output)
    prefix = 'mz' if engine_for(game)[1] == 'RPG Maker MZ' else 'mv'
    previous = json.loads((work/f'{prefix}_manifest.json').read_text(encoding='utf-8'))
    units, manifest = extract(game,locale=previous.get('locale_scope'))
    if previous['game'] != manifest['game'] or previous['source_hashes'] != manifest['source_hashes']:
        raise ValueError('Source game changed or workspace does not match')
    cp = work/f'{prefix}_checkpoint.json'
    state = json.loads(cp.read_text(encoding='utf-8'))
    if state.get('input_fingerprint') != fingerprint(units):
        raise ValueError('Checkpoint source mismatch')
    recovered = []
    reflowed = []
    rejected = state.get('rejected_candidates', {})
    for unit in units:
        unit['translation'] = state.get('translations', {}).get(unit['id'], '')
        if not audit(unit)['blocking']: continue
        candidate = rejected.get(unit['id'])
        if repair_newlines:
            repaired = reflow_candidate(unit, candidate)
            if repaired is not None:
                reflowed.append({'id': unit['id'], 'before': candidate, 'after': repaired})
                candidate = repaired
        if isinstance(candidate, str) and not audit(dict(unit, translation=candidate))['blocking']:
            unit['translation'] = candidate
            recovered.append(unit['id'])
    docs, unresolved = patched_documents(game, units, manifest, allow_partial=allow_partial)
    backup = cp.with_name(cp.name + '.backup-' + datetime.now().strftime('%Y%m%d-%H%M%S-%f'))
    shutil.copy2(cp, backup)
    def patch(stage):
        from rpgmaker.locale_scope import write_document, read_document, label_chinese_slot
        if manifest.get('locale_scope'):
            rel=(Path(manifest['web_root'])/'js/plugins.js').as_posix()
            if rel not in docs:docs[rel]=read_document(game,rel)
            label_chinese_slot(docs[rel],manifest['locale_scope'])
        for rel, data in docs.items():
            write_document(stage/rel,data)
            if read_document(stage,rel)!=data:raise ValueError('Document verification failed')
    publish_copy(game, output, patch)
    state['translations'] = {u['id']: u['translation'] for u in units}
    for uid in recovered: rejected.pop(uid, None)
    state['previous_stop_reason'] = state.get('stop_reason')
    state['stop_reason'] = 'offline_recovery_partial' if unresolved else 'clean'
    state['offline_recovered_ids'] = recovered
    atomic_json(cp, state)
    atomic_json(work/f'{prefix}_units_translated.json', units)
    atomic_json(work/f'{prefix}_newline_repair_report.json', {'repaired': reflowed,
                'count': len(reflowed), 'note': 'Heuristic wrapping; check window layout in game.'})
    issues = [dict(id=u['id'], source=u['source'], translation=u['translation'], **audit(u)) for u in units]
    atomic_json(work/f'{prefix}_completion_report.json', {
        'total': len(units), 'blocking_count': len(unresolved),
        'stop_reason': state['stop_reason'], 'history': state.get('completion_history', []),
        'offline_recovered': len(recovered),
        'unresolved': [r for r in issues if r['blocking']],
        'advisories': [r for r in issues if r['advisory']]})
    atomic_json(work/f'{prefix}_build_report.json', {
        'output': str(output), 'changed_files': list(docs), 'unresolved': unresolved,
        'sample_units': None, 'status': 'partial' if unresolved else 'passed',
        'offline_recovered': len(recovered), 'api_calls': 0})
    print(f'OFFLINE RECOVERY — NO API CALLS; recovered: {len(recovered)}; unresolved: {len(unresolved)}')
    if reflowed: print(f'Newline repairs: {len(reflowed)}; verify text layout in game.')
    print('Game copy:', output)
    print('Checkpoint backup:', backup)
    return len(recovered), len(unresolved)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('game')
    parser.add_argument('--workdir')
    parser.add_argument('--output', required=True)
    parser.add_argument('--allow-partial', action='store_true')
    parser.add_argument('--repair-newlines', action='store_true',
                        help='Rewrap cached candidates rejected only for missing newlines; no API calls')
    args = parser.parse_args()
    game = Path(args.game).expanduser().resolve()
    work = Path(args.workdir).expanduser().resolve() if args.workdir else game.parent/(game.name+'_GT_Work')
    try:
        recover(game, work, args.output, args.allow_partial, args.repair_newlines)
    except (ValueError, OSError) as exc:
        parser.exit(2, f'STOP: {exc}\n')


if __name__ == '__main__':
    main()
