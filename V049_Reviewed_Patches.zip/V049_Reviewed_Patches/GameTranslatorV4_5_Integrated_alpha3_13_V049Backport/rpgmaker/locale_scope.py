"""DKTools JSON locale scope. Never executes JavaScript or guesses from alphabets."""
from __future__ import annotations
import copy
import hashlib
import json
import re
from collections import Counter
from pathlib import Path
from rpgmaker.mv import TOKEN, LOCALE_REF, get, digest
from rpgmaker.dk_locale_fix import detect, plugins
from rpgmaker.menu_text_fix import FIELDS, serialize

COND = re.compile(r'''\s*DKTools\s*\.\s*Localization\s*\.\s*locale\s*(===|==|!==|!=)\s*(['"])([A-Za-z0-9_-]+)\2\s*;?\s*''')
REF = LOCALE_REF

def configuration(root):
    params = detect(root)
    if not params:
        return None
    langs = [json.loads(x) if isinstance(x,str) else x for x in json.loads(params['Languages'])]
    return params, langs

def command_scopes(rows, locales):
    """Possible locale sets per command; unknown gameplay conditions retain both arms."""
    stack = {}; result = []; unsupported = []; recognized = 0
    all_locales = frozenset(locales)
    for index, row in enumerate(rows):
        code, indent, p = row.get('code'), row.get('indent',0), row.get('parameters',[])
        if code == 411:
            for k in list(stack):
                if k > indent: del stack[k]
            if indent in stack:
                condition, _ = stack[indent]; stack[indent] = (condition, False)
        elif code == 412:
            for k in list(stack):
                if k >= indent: del stack[k]
        elif code == 111:
            for k in list(stack):
                if k >= indent: del stack[k]
        active = all_locales
        for condition, arm in stack.values():
            if condition is not None: active = active & (condition if arm else all_locales-condition)
        result.append(active)
        if code == 111:
            condition = None
            if len(p)>1 and p[0]==12 and isinstance(p[1],str):
                m = COND.fullmatch(p[1])
                if m:
                    equal = frozenset([m[3]]) & all_locales
                    condition = equal if m[1] in ('==','===') else all_locales-equal
                    recognized += 1
                elif re.search(r'DKTools\s*\.\s*Localization|\blocale\b|\blanguage\b',p[1],re.I):
                    unsupported.append({'index':index,'expression':p[1]})
            stack[indent] = (condition, True)
    return result, unsupported, recognized

def has_prose(text):
    return any(c.isalpha() for c in TOKEN.sub('',REF.sub('',text)))

def scoped_extract(game, locale, base_units, manifest):
    game = Path(game).resolve(); root = game / manifest['web_root']
    cfg = configuration(root)
    if not cfg: raise ValueError('--locale requires active DKTools_Localization (JSON mode)')
    params, langs = cfg; locales = [x['Locale'] for x in langs]
    if locale not in locales: raise ValueError('Unknown --locale; choose: '+', '.join(locales))
    if params.get('Languages Source')!='json' or params.get('Localization Extension','.json')!='.json':
        raise ValueError('Locale selection currently supports DKTools JSON dictionaries only')
    if params.get('Check Subfolders','false')!='false':
        raise ValueError('DKTools recursive dictionary folders need review; refusing guessed load order')
    report = {'selected_locale':locale,'available_locales':langs,'data_units_before':len(base_units),
              'other_branch_units':0,'reference_only_units':0,'selected_branch_units':0,'shared_units':0,
              'dictionary_units':0,'plugin_display_units':0,'unsupported_conditions':[],
              'recognized_conditions':0,'excluded_other_branch_ids':[],
              'scope_note':'Shared data + selected DKTools event branches + selected dictionary values + allowlisted VisuMZ labels. Other scripts/plugins/images not covered.'}
    docs = {}; scopes = {}; selected = []
    for u in base_units:
        paths = u['metadata']['paths']; path = paths[0]
        if 'list' in path:
            pos=path.index('list'); list_path=path[:pos+1]; key=(u['file'],json.dumps(list_path))
            if key not in scopes:
                if u['file'] not in docs: docs[u['file']]=json.loads((game/u['file']).read_text(encoding='utf-8-sig'))
                doc=docs[u['file']]
                scope, unknown, count=command_scopes(get(doc,list_path),locales)
                scopes[key]=scope; report['recognized_conditions']+=count
                report['unsupported_conditions'] += [dict(file=u['file'],list_path=list_path,**x) for x in unknown]
            allowed = scopes[key][path[pos+1]]
            if locale not in allowed:
                report['other_branch_units']+=1;report['excluded_other_branch_ids'].append(u['id']);continue
            bucket='shared_units' if set(allowed)==set(locales) else 'selected_branch_units'
        else: bucket='shared_units'
        if not has_prose(u['source']):report['reference_only_units']+=1;continue
        # Do not leak English/Korean sibling dialogue into model context.
        u=copy.deepcopy(u);u['context']=[];selected.append(u);report[bucket]+=1
    # Inspect even command lists with no extracted text so unsupported tests are visible.
    def inspect_lists(value, rel, path):
        if isinstance(value,dict):
            for k,v in value.items():
                if k=='list' and isinstance(v,list) and all(isinstance(r,dict) and 'code' in r for r in v):
                    key=(rel,json.dumps(path+[k]))
                    if key not in scopes:
                        scope,unknown,count=command_scopes(v,locales);scopes[key]=scope
                        report['recognized_conditions']+=count
                        report['unsupported_conditions'] += [dict(file=rel,list_path=path+[k],**x) for x in unknown]
                else:inspect_lists(v,rel,path+[k])
        elif isinstance(value,list):
            for i,v in enumerate(value):inspect_lists(v,rel,path+[i])
    for rel in manifest['source_hashes']:
        inspect_lists(json.loads((game/rel).read_text(encoding='utf-8-sig')),rel,[])
    def add(rel,path,text,kind):
        if not isinstance(text,str) or not has_prose(text):return
        identity=json.dumps([rel,path],ensure_ascii=False,separators=(',',':'))
        selected.append({'id':'locale:'+hashlib.sha256(identity.encode()).hexdigest()[:24],
            'engine':'rpgmaker_locale','file':rel,'location':identity,'source':text,'translation':'',
            'context':[], 'protected_tokens':TOKEN.findall(text)+REF.findall(text),
            'metadata':{'kind':kind,'paths':[path],'aliases':[],'line_count':1}})
        report['dictionary_units' if kind=='locale_dictionary' else 'plugin_display_units']+=1
    folder=(root/params.get('Localization Folder','locales')/locale).resolve()
    if not folder.is_relative_to(root.resolve()):raise ValueError('Locale folder escapes game root')
    files=sorted(folder.glob('*.json'))
    if not files:raise ValueError('No selected locale JSON dictionaries: '+str(folder))
    # Preserve dictionary keys. Duplicate top-level keys require a load-order review.
    seen={}
    def walk(value,rel,path):
        if isinstance(value,str):add(rel,path,value,'locale_dictionary')
        elif isinstance(value,list):
            for i,v in enumerate(value):walk(v,rel,path+[i])
        elif isinstance(value,dict):
            for k,v in value.items():
                if not k.startswith('parse_depth'):walk(v,rel,path+[k])
    for file in files:
        obj=json.loads(file.read_text(encoding='utf-8-sig'));rel=file.relative_to(game).as_posix()
        keys=set(obj) if isinstance(obj,dict) else {file.stem}
        values=obj if isinstance(obj,dict) else {file.stem:obj}
        for key,value in values.items():
            if key in seen and seen[key]!=value:raise ValueError('Conflicting locale key needs load-order review: '+key)
            seen[key]=value
        walk(obj,rel,[]);manifest['source_hashes'][rel]=digest(file)
    plugin_rel=(root/'js/plugins.js').relative_to(game).as_posix()
    manifest['source_hashes'][plugin_rel]=digest(game/plugin_rel)
    items=read_document(game,plugin_rel)
    for i,item in enumerate(items):
        if not item.get('status'):continue
        for (name,param),fields in FIELDS.items():
            if item.get('name')!=name or param not in item.get('parameters',{}):continue
            obj=item['parameters'][param]
            for field in fields:
                if field in obj:add(plugin_rel,[i,'parameters',param,field],obj[field],'plugin_display')
    for u in selected:u['metadata']['locale_scope']=locale
    manifest['locale_scope']=locale;manifest['units']=len(selected)
    report['selected_units']=len(selected);report['selected_source_characters']=sum(len(u['source']) for u in selected)
    report['translation_blocked']=bool(report['unsupported_conditions'])
    manifest['locale_report']=report
    manifest['excluded'] = [x for x in manifest['excluded'] if not x.startswith('Plugin JS/parameters')]
    manifest['excluded'] += ['Other locale event branches and dictionaries intentionally retained',
        'Plugin JS, commands and parameters except eight allowlisted VisuMZ display fields', 'DKTools parse_depth demonstration keys']
    return selected,manifest

def read_document(game, rel):
    p=Path(game)/rel
    if not rel.endswith('/plugins.js'):
        return json.loads(p.read_text(encoding='utf-8-sig'))
    text=p.read_text(encoding='utf-8-sig');items=json.loads(text[text.index('['):].strip().removesuffix(';'))
    for item in items:
        for name,param in FIELDS:
            if item.get('name')==name and param in item.get('parameters',{}):
                item['parameters'][param]=json.loads(item['parameters'][param])
    return items

def write_document(target, data):
    from core.completion import atomic_json
    target=Path(target)
    if target.name!='plugins.js':atomic_json(target,data);return
    items=copy.deepcopy(data)
    for item in items:
        for name,param in FIELDS:
            if item.get('name')==name and param in item.get('parameters',{}) and isinstance(item['parameters'][param],dict):
                item['parameters'][param]=json.dumps(item['parameters'][param],ensure_ascii=False,separators=(',',':'))
    target.parent.mkdir(parents=True,exist_ok=True);target.write_text(serialize(items),encoding='utf-8')

def label_chinese_slot(items, locale):
    for item in items:
        if item.get('name')!='DKTools_Localization' or not item.get('status'):continue
        p=item['parameters'];rows=[json.loads(x) for x in json.loads(p['Languages'])]
        for row in rows:
            if row['Locale']==locale:row['Language']='简体中文'
        p['Languages']=json.dumps([json.dumps(x,ensure_ascii=False) for x in rows],ensure_ascii=False)
        p['Show Button']='false';p['Show Command']='true'
    return items

def reuse_checkpoint(units, source_work, prefix):
    """Read-only import by ID, exact source and exact write locations; re-audit every value."""
    from core.completion import fingerprint
    from rpgmaker.mv import audit
    source_work=Path(source_work).expanduser().resolve()
    originals=json.loads((source_work/f'{prefix}_units.json').read_text(encoding='utf-8'))
    state=json.loads((source_work/f'{prefix}_checkpoint.json').read_text(encoding='utf-8'))
    if state.get('input_fingerprint')!=fingerprint(originals):
        raise ValueError('Reuse checkpoint does not match its source units')
    old={u['id']:u for u in originals};reused=0;rejected=0
    for u in units:
        prior=old.get(u['id'])
        if not prior or u.get('translation'):continue
        if any(u[k]!=prior[k] for k in ('source','file','location')):continue
        if any(u['metadata'].get(k)!=prior['metadata'].get(k) for k in ('paths','aliases')):continue
        candidate=state.get('translations',{}).get(u['id'])
        if not candidate:continue
        if audit(dict(u,translation=candidate))['blocking']:rejected+=1;continue
        u['translation']=candidate;reused+=1
    return {'source_work':str(source_work),'reused':reused,'rejected_by_current_audit':rejected,'api_calls':0}
