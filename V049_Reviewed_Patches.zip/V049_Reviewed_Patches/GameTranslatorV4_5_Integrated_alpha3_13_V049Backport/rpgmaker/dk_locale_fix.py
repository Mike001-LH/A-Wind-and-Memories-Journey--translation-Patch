"""Offline, hash-guarded repair for the supplied Fans v2 DKTools game.
Optional paid residual pass only selects remaining Japanese/Korean visible units.
"""
import argparse, collections, hashlib, json, re, zipfile
from pathlib import Path
from core.completion import atomic_json, complete, fingerprint
from providers.config import make_provider, SessionAccounting
from bruns.translate import load_env
from rpgmaker.mv import extract, audit, get, put, NAME_TAG, TOKEN, LOCALE_REF

PROFILE = Path(__file__).with_name('fans_v2_zh_profile.json')
SCRIPT = 'js/plugins.js'

def plugins(game):
    text=(Path(game)/SCRIPT).read_text(encoding='utf-8-sig')
    return json.loads(text[text.index('['):].strip().removesuffix(';'))

def detect(game):
    p=Path(game)/SCRIPT
    if not p.exists(): return None
    for item in plugins(game):
        if item.get('status') and item.get('name')=='DKTools_Localization':
            return item.get('parameters',{})
    return None

def remaining_text(text):
    # Locale references, escape codes and ruby technical keys are not prose.
    return bool(re.search('[ぁ-ゖァ-ヺ가-힣]', TOKEN.sub('', LOCALE_REF.sub('',text))))

def residual_audit(unit):
    result=audit(unit)
    if remaining_text(unit.get('translation') or ''):
        result['blocking'].append('japanese_or_korean_residue')
    if LOCALE_REF.findall(unit['source']) != LOCALE_REF.findall(unit.get('translation') or ''):
        result['blocking'].append('localization_tag_mismatch')
    return result

def prepare_patch(game):
    game=Path(game); profile=json.loads(PROFILE.read_text(encoding='utf-8'))
    if not detect(game):raise ValueError('Active DKTools_Localization required')
    expected=dict(profile['source_hashes']);expected[SCRIPT]=profile['script_sha256']
    for rel,digest in expected.items():
        p=game/rel
        if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=digest:
            raise ValueError('Game profile differs; refusing blind overwrite: '+rel)
    docs=profile['files']
    items=plugins(game)
    for item in items:
        if item['name']=='DKTools_Localization' and item['status']:
            params=item['parameters'];langs=[json.loads(x) for x in json.loads(params['Languages'])]
            for lang in langs:
                if lang['Locale']=='ja':lang['Language']='简体中文'
            params['Languages']=json.dumps([json.dumps(x,ensure_ascii=False) for x in langs],ensure_ascii=False)
            helptexts=[json.loads(x) for x in json.loads(params['Help Text'])]
            for row in helptexts:
                if row['Locale']=='ja':row['Text']='选择语言'
            params['Help Text']=json.dumps([json.dumps(x,ensure_ascii=False) for x in helptexts],ensure_ascii=False)
            # Replace the Japanese-text flag image entry point with a text menu.
            params['Show Button']='false';params['Show Command']='true'
    from rpgmaker.menu_text_fix import translate_parameters
    items, _menu_changes = translate_parameters(items)
    script='// Generated DKTools Chinese locale repair\nvar $plugins =\n'+json.dumps(items,ensure_ascii=False,indent=2)+';\n'
    # Repair placeholders damaged in previously translated System messages.
    system=json.loads((game/'data/System.json').read_text(encoding='utf-8'))
    messages=system['terms']['messages']
    keys={'alwaysDash':'always_dash','commandRemember':'remember_command','touchUI':'Touch UI','bgmVolume':'bgm_volume','bgsVolume':'bgs_volume','meVolume':'me_volume','seVolume':'se_volume','possession':'Possession','expTotal':'Current','expNext':'To Next','saveMessage':'Which file would you like to save to?','loadMessage':'Which file would you like to load?','file':'File','autosave':'Autosave','partyName':'%1’s Party','emerge':'%1 emerged!','preemptive':'%1 got the upper hand!','surprise':'%1 was surprised!','escapeStart':'%1 has started to escape!','escapeFailure':'However, it was unable to escape!','victory':'%1 was victorious!','defeat':'%1 was defeated.','obtainExp':'%1 %2 received!','obtainGold':'G found!','obtainItem':'%1 found!','levelUp':'%1 is now %2 %3!','obtainSkill':'%1 learned!','useItem':'%1 uses %2!','criticalToEnemy':'An excellent hit!!','criticalToActor':'A painful blow!!','evasion':'%1 evaded the attack!','magicEvasion':'%1 nullified the magic!','magicReflection':'%1 reflected the magic!','counterAttack':'%1 made a counterattack!','substitute':'%1 protected %2!','buffAdd':'%1’s %2 went up!','debuffAdd':'%1’s %2 went down!','buffRemove':'%1’s %2 returned to normal!','actionFailure':'There was no effect on %1!'}
    for prefix in ('actor','enemy'):
        for suffix,key in {'Damage':'%1 took %2 damage!','Recovery':'%1 recovered %2 %3!','Gain':'%1 gained %2 %3!','Loss':'%1 lost %2 %3!','Drain':'%1 was drained of %2 %3!','NoDamage':'%1 took no damage!','NoHit':'Miss! %1 took no damage!'}.items(): keys[prefix+suffix]=key
    for field,key in keys.items():
        if field in messages:messages[field]='{'+key+'}'
    docs['data/System.json']=system
    return docs,script

def build(game,output,args):
    game=Path(game).expanduser().resolve();output=Path(output).expanduser().resolve()
    if output.exists():raise ValueError('Output exists; choose a new output')
    docs,script=prepare_patch(game)
    all_units,_=extract(game)
    selected=[dict(u) for u in all_units if remaining_text(u['source'])]
    initial=len(selected)
    work=Path(args.workdir).expanduser().resolve() if args.workdir else game.with_name(game.name+'_DK_Repair_Work')
    if args.translate_residual:
        work.mkdir(parents=True,exist_ok=True);cp=work/'dk_residual_checkpoint.json'
        state={'input_fingerprint':fingerprint(selected),'translations':{},'spent_rmb':0.}
        if cp.exists():
            old=json.loads(cp.read_text())
            if old['input_fingerprint']!=state['input_fingerprint']:raise ValueError('Residual work source changed')
            state=old
        for u in selected:u['translation']=state.get('translations',{}).get(u['id'],'')
        def save(rows,st):
            st['translations']={u['id']:u.get('translation','') for u in rows};atomic_json(cp,st)
        load_env();accounting=SessionAccounting(args,state);provider=make_provider(args)
        def send(batch,phase):
            accounting.before();payload=[]
            for u in batch:
                item=dict(u);item['protected_tokens']=[t for t in u.get('protected_tokens',[]) if not NAME_TAG.fullmatch(t)]+LOCALE_REF.findall(u['source'])
                item['shared_rules']=['Preserve {locale references}, escape codes and newline counts exactly. Retain correct existing Chinese. Translate the remaining Japanese and Korean into Simplified Chinese.']
                payload.append(item)
            try:
                made,usage=provider.translate_batch(payload,source_language='Japanese and Korean, mixed with Chinese',target_language='Simplified Chinese')
            except Exception as exc:
                usage=getattr(exc,'usage',None)
                if usage:record(usage)
                else:accounting.missing()
                raise
            return made,record(usage)
        def record(u):
            v={'prompt_tokens':u.prompt_tokens,'completion_tokens':u.completion_tokens,'prompt_cache_hit_tokens':u.cache_hit_tokens,'prompt_cache_miss_tokens':u.cache_miss_tokens,'reasoning_tokens':u.reasoning_tokens}
            if getattr(u,'reported',True):accounting.record(v)
            else:accounting.missing()
            return v
        def request(batch,phase):
            try:return send(batch,phase)
            except Exception as exc:
                if getattr(exc,'reason',None) not in ('provider_invalid_json','provider_truncated'):raise
            middle=max(1,len(batch)//2);parts=[batch[:middle],batch[middle:]] if len(batch)>1 else [batch]
            result={};usage={}
            for part in parts:
                try:made,usage=send(part,phase)
                except Exception as exc:
                    if getattr(exc,'reason',None) not in ('provider_invalid_json','provider_truncated'):raise
                    continue
                for u in part:
                    candidate=made.get(u['id'])
                    if isinstance(candidate,str) and not residual_audit(dict(u,translation=candidate))['blocking']:
                        u['translation']=candidate
                save(selected,state);result.update(made)
            return result,usage
        try:complete(selected,residual_audit,request,save,rounds=args.repair_rounds,batch_size=args.batch_size, state=state,max_batch_chars=args.batch_chars)
        finally:accounting.finish(state.get('stop_reason','interrupted'));save(selected,state)
        for u in selected:
            if residual_audit(u)['blocking']:continue
            rel=u['file']
            if rel not in docs:docs[rel]=json.loads((game/rel).read_text())
            parts=u['translation'].split('\n') if len(u['metadata']['paths'])>1 else [u['translation']]
            if len(parts)!=len(u['metadata']['paths']):raise ValueError('Line segmentation differs')
            for p,t in zip(u['metadata']['paths'],parts):put(docs[rel],p,t)
            for p in u['metadata'].get('aliases',[]):put(docs[rel],p,u['translation'])
    unresolved=[{'id':u['id'],'file':u['file'],'source':u['source']} for u in selected if not u.get('translation') or residual_audit(u)['blocking']]
    report={'profile':'Fans v2 DKTools','replaced_locale':'ja','locale_label':'简体中文','english_korean_dictionaries_unchanged':True,'locale_json_files':12,'locale_top_level_entries':209,'technical_demo_keys_unchanged':6,'residual_units_before':initial,'residual_units_after':len(unresolved),'residual_units':unresolved,'api_requested':bool(args.translate_residual),'runtime_verification_required':True,'changed_files':sorted([*docs,SCRIPT])}
    output.mkdir(parents=True)
    for rel,obj in docs.items():atomic_json(output/rel,obj)
    (output/'js').mkdir(exist_ok=True);(output/SCRIPT).write_text(script,encoding='utf-8')
    atomic_json(output/'repair_report.json',report)
    (output/'安装说明.txt').write_text('适用于本次上传的 Game_for_fans_ver2 中文成品 Full12。关闭游戏，将 data、js、locales 文件夹合并覆盖到成品游戏根目录，不要删除原文件夹。\n日语 ja 槽位改为简体中文；语言菜单选择“简体中文”。原英文和韩文字典保留，但基础 data 已由之前流程翻译，不能保证切换后是纯英韩版。\n标题语言按钮改成文字菜单，避免原图上“日本語”造成误导。不要覆盖或删除 save。\n本补丁修复词典和系统格式占位符；剩余混合语言对白数量见 repair_report.json。不能把词典修复视作所有剧情与插件已验收。\n',encoding='utf-8')
    print('PATCH:',output,'; residual units:',len(unresolved),'; API:',bool(args.translate_residual))
    return report

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('game');p.add_argument('--output',required=True);p.add_argument('--workdir');p.add_argument('--translate-residual',action='store_true')
    p.add_argument('--batch-size',type=int,default=10);p.add_argument('--batch-chars',type=int,default=2000);p.add_argument('--repair-rounds',type=int,default=2);p.add_argument('--max-cost-rmb',type=float,default=1);p.add_argument('--max-api-calls',type=int,default=40);p.add_argument('--price-band',choices=['peak','offpeak'],default='peak')
    a=p.parse_args();a.provider='deepseek';a.api_model='deepseek-flash';a.api_thinking='disabled';a.economy=True
    if a.batch_size<1 or a.batch_chars<1 or a.repair_rounds<0:p.error('Invalid batch/round settings')
    try:build(a.game,a.output,a)
    except (ValueError,RuntimeError) as e:raise SystemExit('STOP: '+str(e))
if __name__=='__main__':main()
