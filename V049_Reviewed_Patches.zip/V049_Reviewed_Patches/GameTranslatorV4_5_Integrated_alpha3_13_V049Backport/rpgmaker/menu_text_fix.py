"""Offline allowlisted VisuMZ display-parameter translation; never edits scripts or saves."""
import argparse
import copy
import json
from pathlib import Path

# Plugin, structured parameter, leaf: (expected source, approved translation).
FIELDS = {
    ('VisuMZ_0_CoreEngine', 'ButtonAssist:struct'): {
        'OkText:str': ('Select', '选择'),
        'CancelText:str': ('Back', '返回'),
        'SwitchActorText:str': ('Switch Ally', '切换队友'),
    },
    ('VisuMZ_1_MainMenuCore', 'Playtime:struct'): {
        'Time:str': ('Time', '时间'),
    },
    ('VisuMZ_1_SaveCore', 'SaveConfirm:struct'): {
        'VocabSaveSuccess:str': ('Save Successful!', '保存成功！'),
        'VocabSaveFailure:str': ('Could not save!', '保存失败！'),
        'VocabLoadFailure:str': ('Could not load save file!', '读取存档失败！'),
    },
    ('VisuMZ_1_SaveCore', 'SaveMenu:struct'): {
        'LatestText:str': ('NEW!', '最新'),
    },
}

def translate_parameters(items):
    """Copy and edit known display leaves only. Fail on customized values."""
    result = copy.deepcopy(items)
    changes = []
    for plugin in result:
        if not plugin.get('status'):
            continue
        for (name, parameter), fields in FIELDS.items():
            if plugin.get('name') != name or parameter not in plugin.get('parameters', {}):
                continue
            obj = json.loads(plugin['parameters'][parameter])
            if not isinstance(obj, dict):
                raise ValueError('Expected structured parameter: ' + name + '/' + parameter)
            changed = False
            for key, (source, target) in fields.items():
                if key not in obj:
                    continue
                if obj[key] not in (source, target):
                    raise ValueError('Customized display field; review required: ' + name + '/' + parameter + '/' + key)
                if obj[key] == target:
                    continue
                obj[key] = target
                changed = True
                changes.append({'plugin': name, 'parameter': parameter, 'field': key,
                                'source': source, 'translation': target})
            if changed:
                plugin['parameters'][parameter] = json.dumps(obj, ensure_ascii=False, separators=(',', ':'))
    return result, changes

def serialize(items):
    return '// Generated offline menu text repair\nvar $plugins =\n' + json.dumps(items, ensure_ascii=False, indent=2) + ';\n'

def build(game, output):
    from rpgmaker.dk_locale_fix import plugins
    game, output = Path(game).expanduser().resolve(), Path(output).expanduser().resolve()
    if output.exists():
        raise ValueError('Output exists; choose a new --output')
    items, changes = translate_parameters(plugins(game))
    if not changes:
        raise ValueError('No matching untranslated menu fields; no output written')
    (output / 'js').mkdir(parents=True)
    (output / 'js/plugins.js').write_text(serialize(items), encoding='utf-8')
    report = {'api_calls': 0, 'changed_files': ['js/plugins.js'], 'changes': changes,
              'runtime_verification_required': True,
              'scope': 'Chinese build; display labels apply to all language slots'}
    (output / 'menu_fix_report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    (output / '安装说明.txt').write_text('关闭游戏，先备份游戏中的 js/plugins.js，再将本补丁的 js/plugins.js 覆盖到当前已修好的中文游戏。不要覆盖 data、locales 或 save。完全退出并重启游戏。此修复面向中文成品，插件提示在所有语言槽位都会显示中文。\n', encoding='utf-8')
    print('OFFLINE MENU FIX — NO API CALLS; labels:', len(changes), '; patch:', output)
    return report

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('game', help='Current repaired game or patch folder containing js/plugins.js')
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    try:
        build(args.game, args.output)
    except (ValueError, OSError) as exc:
        raise SystemExit('STOP: ' + str(exc))

if __name__ == '__main__':
    main()
