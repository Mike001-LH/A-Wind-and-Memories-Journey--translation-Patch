from __future__ import annotations
import argparse, json, re, shutil
from pathlib import Path

VERSION = "V4.0.0-alpha8.1"
GUI_KEYS = ("text_font", "name_text_font", "interface_text_font")
CJK = re.compile(r"[\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff]")
FONT_SPAN = re.compile(r"\{font=([^}]+)\}(.*?)\{/font\}", re.S)

def resolve_workspace_file(workspace: Path, rel: str):
    candidates = [workspace / "virtual_game" / rel, workspace / "decompiled" / Path(rel).name, workspace / rel]
    for p in candidates:
        if p.is_file(): return p
    return None

def patch_gui(text: str, font_ref: str):
    changed=[]
    for key in GUI_KEYS:
        pat=re.compile(rf'(^\s*define\s+gui\.{re.escape(key)}\s*=\s*)(["\'])(.*?)(\2)', re.M)
        text,n=pat.subn(lambda m: m.group(1)+m.group(2)+font_ref+m.group(2), text, count=1)
        if n: changed.append(key)
    return text, changed

def patch_inline_cjk_fonts(text: str, font_ref: str):
    count=0
    def repl(m):
        nonlocal count
        if CJK.search(m.group(2)):
            count += 1
            return "{font="+font_ref+"}"+m.group(2)+"{/font}"
        return m.group(0)
    return FONT_SPAN.sub(repl,text),count

def main():
    ap=argparse.ArgumentParser(description="Game Translator V4 alpha7.5 - Ren'Py CJK font patch")
    ap.add_argument('--patch', type=Path, required=True, help='Writer output folder, e.g. manyuu_alpha74_patch')
    ap.add_argument('--workspace', type=Path, required=True, help='Extraction/decompile workspace')
    ap.add_argument('--font', type=Path, required=True, help='User-supplied licensed .ttf/.otf font')
    ap.add_argument('--font-name', default=None, help='Destination filename; defaults to source filename')
    ap.add_argument('--report', type=Path, default=None)
    args=ap.parse_args()
    if not args.patch.is_dir(): raise SystemExit(f"Patch folder not found: {args.patch}")
    if not args.font.is_file() or args.font.suffix.lower() not in ('.ttf','.otf'):
        raise SystemExit('--font must point to an existing .ttf or .otf file')
    name=args.font_name or args.font.name
    if Path(name).name != name or Path(name).suffix.lower() not in ('.ttf','.otf'):
        raise SystemExit('--font-name must be a simple .ttf/.otf filename')
    font_ref=f"fonts/{name}"
    fonts_dir=args.patch/'game'/'fonts'; fonts_dir.mkdir(parents=True,exist_ok=True)
    dst_font=fonts_dir/name; shutil.copy2(args.font,dst_font)

    gui_dst=args.patch/'game'/'gui.rpy'
    if gui_dst.exists(): gui_text=gui_dst.read_text(encoding='utf-8-sig')
    else:
        gui_src=resolve_workspace_file(args.workspace,'game/gui.rpy')
        if not gui_src: raise SystemExit('Could not find game/gui.rpy in workspace')
        gui_text=gui_src.read_text(encoding='utf-8-sig')
    gui_text,gui_changed=patch_gui(gui_text,font_ref)
    if len(gui_changed)!=3:
        raise SystemExit(f"Safety stop: expected 3 GUI font definitions, found {gui_changed}")
    gui_dst.parent.mkdir(parents=True,exist_ok=True); gui_dst.write_text(gui_text,encoding='utf-8')

    inline=0; files=[]
    for p in sorted((args.patch/'game').rglob('*.rpy')):
        text=p.read_text(encoding='utf-8-sig')
        new,n=patch_inline_cjk_fonts(text,font_ref)
        if n:
            p.write_text(new,encoding='utf-8'); inline+=n; files.append(str(p.relative_to(args.patch)))
    report={
      'version':VERSION,'font_source':str(args.font),'font_output':str(dst_font),'font_ref':font_ref,
      'gui_definitions_changed':gui_changed,'inline_cjk_font_tags_changed':inline,'inline_files':files,
      'status':'FONT PATCH PREFLIGHT PASSED'
    }
    rp=args.report or (args.patch/'font_patch_report.json')
    rp.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(f"Game Translator {VERSION} - RenPy Font Patch")
    print(f"Font copied: {dst_font}")
    print(f"GUI font definitions changed: {len(gui_changed)} ({', '.join(gui_changed)})")
    print(f"Inline CJK font tags changed: {inline}")
    print(f"Report: {rp}")
    print('STATUS: FONT PATCH PREFLIGHT PASSED')

if __name__=='__main__': main()
