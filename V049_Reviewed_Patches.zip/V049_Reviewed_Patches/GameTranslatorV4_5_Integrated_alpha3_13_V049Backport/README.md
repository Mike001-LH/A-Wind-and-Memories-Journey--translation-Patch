# alpha3.12.1: 完整游戏版本差异更新包
新增 `python3 translator.py game-update build OLD_GAME NEW_GAME --output UPDATE.zip`。
`game-update apply OLD_GAME --package EXTRACTED_UPDATE --output NEW_COPY` 可在工具中安装；生成包内 `apply_update.py` 可独立运行。
全文 SHA-256 校验、独立更新副本、差异资源、删除清单、存档保留；排除打包档案和 Mac 元数据。无 API 调用。详见 GAME_UPDATE_使用说明.txt。
保留 alpha3.11 和此前所有引擎、语言、迁移和选项修复功能；本版本不新增 0.49 选项回补。

## alpha3.11：VX Ace 选项漏提取修复

升级和续翻请先看 `CHOICE_FIX_使用说明.txt`。旧进度先迁入新工作目录；新增识别754条选项，原有文本和进度保留。

# 本版新增字體隔離診斷

先閱讀 README_FONT_PROBE.md。本版尚未宣稱修復中文錯字。

# DXA 相容中文菜單更新

本次更新請先閱讀 README_DXA_COMPAT.md。新增 compatible-menu 診斷模式及菜單導入 CP932 字符檢查。

# Game Translator 4.5 Integrated alpha2 DXA

整合日期：2026-10-04。当前主入口为 `translator.py`，游戏兼容入口为 `unified.py`。
本包合并原来多个版本的已实现功能；不是一次新的全引擎、全语言扩展。
所有翻译都需人工和游戏内检查。分析、恢复与显示修复不调用翻译 API。

本次 DXA 增强及分层启动测试见 **README_DXA.md**。新增纯 Python DXA8 读取/重建、原文提取与受校验的菜单导入；全文剧情翻译尚未开放。

## 安装与帮助

需要 Python 3.10 或更新版本。Mac 示例（每行单独执行）：

```bash
unzip -oq "$HOME/Downloads/GameTranslatorV4_5_Integrated_alpha2_DXA.zip" -d "$HOME/Documents/local-llm-translator"
cd "$HOME/Documents/local-llm-translator/GameTranslatorV4_5_Integrated_alpha2_DXA"
python3 -m pip install -r requirements.txt
python3 translator.py --help
```

Windows 可将 `python3` 换为 `py`。如果系统要求虚拟环境，先执行
`python3 -m venv .venv`，然后 Mac 执行 `source .venv/bin/activate`，再安装依赖。
Ollama 仍需用户自行安装并下载要用的模型；本包不含模型权重。

原有 `python3 unified.py ...`、`python3 translatorpp_adapter.py ...`、
`python3 -m vxace.recover ...` 等命令仍可使用。
旧 `app.py`、`main.py` 和 GUI 启动脚本保留兼容；旧 GUI 不是整合版完整功能入口，
VX Ace、多供应商与省钱设置请使用命令行。

## 功能范围

| 模块 | 已整合能力 | 范围与边界 |
|---|---|---|
| MTool JSON | 本地 Ollama / 官方 DeepSeek、行范围、术语表、QA、续跑 | 平面字符串映射；日/英→中文，不能当作任意 JSON 翻译器 |
| Translator++ Excel | 单 XLSX / 项目目录、去重、术语表、选择性修复、分级审校、续跑 | 保留原列和项目目录；日/英→中文；默认跳过 renpy/common |
| Ren'Py | RPA/RPY/RPYC 提取、反编译、翻译、角色处理、回写 | 官方 DeepSeek、中文输出；保留旧管线高级入口 |
| Bruns | BSO 提取、繁体兼容、残留检查、多轮补译、回写 | 官方 DeepSeek；历史专项收尾工具另有兼容入口 |
| RPG Maker MV/MZ | 提取、样本/完整翻译、游戏副本、离线恢复、换行修复 | 官方 DeepSeek、中文输出；插件代码和图片文字等仍有排除项 |
| KAG/XP3 | 检测、使用解包目录、标准 XP3/嵌入 EXE 提取、KS 翻译、patch.xp3 | 官方 DeepSeek、中文输出；自定义加密/脚本系统仍可能不支持 |
| RPG Maker VX Ace | 数据提取、英/日/中文目标、样本、回写补丁、恢复、迁移、去重 | 自定义脚本、notes、图片等不能宣称全覆盖 |
| VX Ace 省钱与费用 | 短 ID、紧凑请求、按条数和字符数分批、逐批成本、预算、请求数上限 | `--economy` 仅官方 DeepSeek / VX Ace；费率为历史估算或手动指定 |
| VX Ace 线衣与分阶段工作流 | 网关初译、有限语义审校、官方 DeepSeek 有限补译 | 可选；供应商认证错误仍需供应商处理；不自动把未发送全文转付费 |
| 英/日显示修复 | 对白换行分页、物品/技能说明滚动、部分脚本 UI / 姓名框修复 | 专用于风与追忆之旅 demo V0.49，校验源文件；保留原字体字号 |
| Witch's Forest DXA | 原包/ASCII/中文诊断，以及旧菜单探针 | 实验模块；旧菜单探针曾导致闪退，不是正式翻译引擎 |

旧译迁移 `--reuse-from` 支持本工具的 VX Ace 工作目录或 `gt-memory-1`
翻译记忆，不直接支持“给一个旧汉化游戏就自动迁移”，也没有把 MTool/Excel
记录自动转换成 VX Ace 翻译记忆。保留这些格式原有的各自检查点。

## 密钥配置

本包不包含 API 密钥，也不会运行时自动请求付费翻译。
环境变量优先；加载本地配置时会保留另一供应商的密钥。

```bash
python3 translator.py configure --provider deepseek
python3 translator.py configure --provider xianyi
```

粘贴密钥后按回车，隐藏输入不显示字符。只用 DeepSeek 时无需配置线衣。
从旧配置迁入一个供应商（只导入选定密钥，不打印）：

```bash
python3 translator.py configure --provider deepseek --import-env "/旧工具目录/.env"
```

游戏管线也兼容原来 `~/Documents/local-llm-translator/.env` 的公共配置，
找不到密钥时再配置即可。不要把密钥贴到聊天或提交到仓库。

## 游戏分析与续翻

```bash
python3 translator.py game "/游戏目录" --analyze
```

VX Ace 必须给目标语言，例如：

```bash
python3 translator.py game "/游戏目录" --source-language Chinese --target-language ja --analyze
```

继续 Mike 的日语项目（只有确定需要 API 补译才运行这一条）：

```bash
python3 unified.py "/Users/mike/Downloads/A风与追忆之旅 - demoV0.49/备用原版" --source-language Chinese --target-language ja --economy --batch-size 30 --batch-chars 3500 --repair-rounds 2 --max-cost-rmb 2 --allow-partial --output "/Users/mike/Downloads/V049_Japanese_Integrated_1"
```

使用原游戏目录和相同 `--workdir` 会读取旧检查点。默认 VX Ace 工作目录依然是
`游戏目录_GT_Work_ja` / `_en`；以前用了自定义 `--workdir`，续跑时必须继续指定。
不要删掉旧工作目录。输出目录必须是新名字，存在时程序停止，不覆盖旧补丁。
现在的完成报告与历史费用都继续保留；各次新运行有独立的本次预算。

已有完整补丁不需要因为换工具而重翻。`24 条未通过` 等统计只计算已提取文本，
不包括所有图片、脚本与手工 UI，所以不等于游戏所有文本都已翻译。

## MTool 与 Translator++

先离线检查：

```bash
python3 translator.py files "/文件目录/ManualTransFile.json" --dry-run
python3 translator.py files "/Translator++导出项目目录" --dry-run
```

本地模型（不产生翻译 API 费用，模型需已安装）：

```bash
python3 translator.py files "/文件目录/ManualTransFile.json" --provider local --source-language Japanese --quality balanced --output "/输出目录/ManualTransFile_Chinese.json"
```

官方 DeepSeek：

```bash
python3 translator.py files "/Translator++导出项目目录" --provider deepseek --source-language English --quality balanced --batch-size 16 --output "/输出目录/TranslatorPP_Chinese"
```

这些命令的完整旧参数在 `python3 translator.py files --help` 中：
`--resume`、`--repair-existing`、`--glossary`、`--mtool-line-ranges`、
`--include-outside-ui`、`--restore-renpy-common-from`、`--limit` 等均保留。
`--quality fast/balanced/high` 对应初译、选择性审校及更强审校策略。
**文件适配器的 `--budget-rmb` 保留旧版预算显示语义，不是 VX Ace 的自动停机预算。**
文件适配器不会接受游戏管线专用的 `--economy`、`--target-language` 等参数。

## 线衣初译与 DeepSeek 收尾（VX Ace 可选）

模型 ID 使用你在网关实际可用列表中确认的值。以下沿用此前测试的 ID，
不保证供应商持续提供该模型或同样参数。

```bash
python3 translator.py game "/游戏目录" --source-language Chinese --target-language ja --provider xianyi --api-model gemini-3.8-flash-high --api-thinking omit --batch-size 10 --repair-rounds 2 --max-api-calls 300 --ai-review-units 50 --fallback-deepseek --fallback-max-units 50 --fallback-max-api-calls 10 --fallback-max-cost-rmb 2 --allow-partial --output "/新补丁目录"
```

- 初译与网关审校共享 `--max-api-calls`。
- 付费收尾只选择已经尝试过但未通过、或审校失败的有限条目；未发送全文不会自动付费翻译。
- 两个供应商密钥不混用。官方收尾的模型、地址、费率和预算不会继承网关配置。
- 网关价格未知时必须限请求数，金额显示未知而不是零。可手动指定每百万 token 的
  `--api-input-rmb`、`--api-output-rmb`、`--api-cached-input-rmb`。
- `missing project_id` 是此前真实出现过的上游错误，本次整合不宣称修复服务商账户。
- `--economy` 不与网关模式组合，保持已测过的网关返回格式。

费用提示都是估算，不是官方账单。历史未返回用量或价格未知的调用不会被当成免费。
预算按请求边界检查，最后一批可能略超预算。旧 `peak/offpeak` 费率未经本次重新核价。
分阶段报告 `workflow_report.json` 保存各阶段费用；本次费用栏在每个供应商阶段重新计数，
历史已记录总额包含所有有已知估算价格的阶段。

## 离线恢复与显示修复

```bash
python3 translator.py recover-vx "/游戏目录" --target-language ja --repair-newlines --allow-partial --output "/离线恢复的新目录"
python3 translator.py recover-rpg "/游戏目录" --repair-newlines --allow-partial --output "/MV或MZ恢复的新目录"
```

风与追忆之旅 V0.49 日语版示例：

```bash
python3 translator.py display-ja "/Users/mike/Downloads/A风与追忆之旅 - demoV0.49/备用原版" --patch "/Users/mike/Downloads/V049_Japanese_Economy_Full_7" --output "/Users/mike/Downloads/V049_Japanese_DisplayFixed_Integrated"
```

英文使用 `display-en`。这两项不调用 API，保留游戏萝莉体与字号。
输入必须是匹配原版的**未打显示修复**翻译补丁；已经成功修复的现有补丁不用再修一次。
输出仍需游戏内检验。标题、姓名标签、脚本 UI 的替换来自原来的游戏专用配置，
没有把某个游戏的替换规则全局套到所有 VX Ace 游戏上。

## Bruns 历史专项工具

```bash
python3 translator.py bruns-legacy --help
python3 translator.py bruns-legacy final_clean "/旧Bruns工作目录"
```

旧工具使用如 `bruns_alpha9_checkpoint.json` 的历史格式，放在
`legacy/bruns_tools` 内隔离其 imports，防止替换现代 `bruns` 的校验与回写逻辑。
默认审计不收费；部分工具加 `--repair` 会调用官方 API，具体以其 `--help` 为准。
不要用它们强制打开不匹配的现代检查点。现代游戏流程使用 `translator.py game`。

## DXA 研究工具

新的入口：`python3 translator.py dxa --help`。
支持真实资源分析、原文提取、保留压缩格式的重建、单标签诊断、离线菜单回写。
先按 **README_DXA.md** 测试 `repack`，再测 ASCII 和中文。
尚未在 Windows 上确认新的重建包，也尚未开放剧情自动翻译。
旧 `dxa-diagnostic` 与 `dxa-menu-legacy` 仅作兼容保留。

## 合并来源与验证

- 当前显示修复、省钱、引擎基线：上传的 `alpha3_3_4_JapaneseDisplay`。
- 多供应商、审校与收尾：上传的 `old ones/alpha4_1_Staged`。
- 文件适配器：上传的 `translatorpp_adapter_v3_6_5.py`；早期纯本地版本也存于 `legacy`。
- Bruns 历史专项模块：alpha10 系列至 alpha11 finalclean；与现代模块分开运行。
- DXA：上传的 Menu Probe 与 Diagnostic alpha2 原始资源。
- `vendor/unrpyc`：上传的 unrpyc 源码及其原许可证；显式 `--unrpyc` 仍优先。

英文/日文显示修复保留原代码；MTool/Excel 保留自己的 checkpoint schema；
VX Ace 保留原 ID、提取规则、manifest、工作目录规则与缓存格式。
新增测试验证统一入口、格式读写、去重、跨供应商续跑、费用只记一次和限额。
测试使用虚构文本和模拟响应，不调用真实翻译 API。
没有在本环境重新运行 Windows 游戏；不能将离线通过说成所有游戏已实测。

旧 README/变更文档作为各模块历史资料保留，入口与功能边界以本文件为准。
